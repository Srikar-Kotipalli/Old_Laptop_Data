/* eslint-disable import/no-unused-modules */
/* eslint-disable no-else-return */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React from 'react';
import moment from 'moment';
import { Typography } from '@mui/material';
import failedDispatch from '../assets/dispatch/failed_dispatch.svg';
import cancelledDispatch from '../assets/dispatch/cancelled_dispatch.svg';
import completedDispatch from '../assets/dispatch/completed_dispatch.svg';
import newDispatch from '../assets/dispatch/dispatchNew.svg';
import recentDispatch from '../assets/dispatch/recent_dispatch.svg';
import runningDispatch from '../assets/dispatch/running.svg';

export const tooltipTimeFormatter = sec => {
	return `${Math.floor(sec / 60 / 60 / 24)}d ${Math.floor(sec / 60 / 60) % 24}h ${
		Math.floor(sec / 60) % 60
	}m ${`${Math.round(sec % 60)}`}s `;
};

export const timeFormatter = sec => {
	let time = '';
	const days = Math.floor(sec / (3600 * 24));
	const hours = Math.floor(sec / 3600);
	const minutes = `0${Math.floor(sec / 60) % 60}`.slice(-2);
	if (sec === 0) {
		time = '0s';
	} else if (sec > 0 && sec < 60) {
		time = '< 1min';
	} else if (sec >= 60 && sec < 3600) {
		time = `${Math.round(parseInt(minutes, 10))}m`;
	} else if (sec >= 3600 && sec < 86400) {
		time = `${Math.round(hours)}h ${Math.round(parseInt(minutes, 10))}m`;
	} else if (sec >= 86400 && sec < 172800) {
		time = '> 1 day';
	} else if (sec >= 172800) {
		time = `${Math.round(days)} days`;
	}
	return time;
};

// eslint-disable-next-line import/no-unused-modules
export const activityTimeFormatter = sec => {
	let time = '';
	const days = Math.floor(sec / (3600 * 24));
	const hours = Math.floor(sec / 3600);
	const minutes = `0${Math.floor(sec / 60) % 60}`.slice(-2);
	if (sec > 0 && sec < 60) {
		time = '< 1m';
	} else if (sec > 60 && sec < 3600) {
		time = `${Math.round(parseInt(minutes, 10))}m`;
	} else if (sec > 3600 && sec < 86400) {
		time = `${Math.round(hours)}h`;
	} else if (sec > 86400 && sec < 172800) {
		time = '> 1d';
	} else if (sec > 172800) {
		time = `${Math.round(days)}d`;
	}
	return time;
};

export const activityTimer = date => {
	const updatedDate = new Date(date);
	const currentDate = new Date();
	const dif = Math.abs(currentDate - updatedDate) / 1000;
	return timeFormatter(dif);
};

export const dateFormatter = date => {
	return moment(new Date(date)).format('DD MMM, HH:mm:ss');
};

// compare two arrays and return uncommon value
export const arrayCompare = (arr1, arr2) => {
	return arr1.filter(o1 => arr2.map(o2 => o2.id).indexOf(o1.id) === -1);
};

// compare two arrays and return common value
export const arrayCommonCompare = (array1, array2) => {
	return array1.some(element => {
		return array2.includes(element);
	});
};

// eslint-disable-next-line import/no-unused-modules, consistent-return
export const getButtonTextForDeleteArchive = (
	type,
	title,
	itemIsInMultiSelect,
	currentItem,
	allSelected
) => {
	if (itemIsInMultiSelect?.length > 1 || allSelected) {
		return title;
	} else {
		if (type === 'dispatch') {
			if (currentItem?.status === 'RUNNING') {
				return `Stop dispatch and ${title}`;
			}
			return title;
		} else {
			if (currentItem?.status === 'RUNNING') {
				if (currentItem?.count !== 0) {
					return `Stop all ${currentItem?.count} dispatches and ${title}`;
				}
				return `${title} ${type}`;
			} else {
				return `${title} ${currentItem?.title} and all ${currentItem?.count} of its ${
					type === 'experiment' ? 'dispatches' : 'items'
				}`;
			}
		}
	}
};

// eslint-disable-next-line import/no-unused-modules
export const experimentStatus = status => {
	function captialise(stat) {
		if (stat?.toUpperCase() === 'NEW_OBJECT') return 'New';
		else {
			const str = stat;
			if (str) return str.charAt(0) + str.slice(1).toLowerCase();
		}
		return '';
	}

	return (
		<Typography pl={1} variant="status" sx={{ color: theme => theme.palette.text.secondary }}>
			{captialise(status)}
		</Typography>
	);
};

export const startAndEndDate = (value, setDates, dates) => {
	switch (value) {
		case 'All time':
			setDates({ startDate: '', endDate: '' });
			break;
		case 'Last month':
			{
				// Get the current date
				// Get the current date
				const currentDate = new Date();

				// Calculate the start date of last month
				const lastMonthStartDate = new Date(
					currentDate.getFullYear(),
					currentDate.getMonth() - 1,
					1
				);

				// Calculate the end date of last month
				const lastMonthEndDate = new Date(
					currentDate.getFullYear(),
					currentDate.getMonth(),
					0,
					23,
					59,
					59
				);

				// Convert the dates to ISO strings and send them to the backend
				const dataToSend = {
					lastMonthStartDate: lastMonthStartDate.toISOString(),
					lastMonthEndDate: lastMonthEndDate.toISOString()
				};

				setDates({
					...dates,
					startDate: dataToSend.lastMonthStartDate,
					endDate: dataToSend.lastMonthEndDate
				});
			}
			break;
		case 'This month':
			{
				// Get the current date and time in UTC
				const now = new Date();

				// Get the start of the current month
				const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

				// Get the end of the current month
				const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);

				setDates({
					...dates,
					startDate: startOfMonth.toISOString(),
					endDate: endOfMonth.toISOString()
				});
			}
			break;
		case 'This week':
			{
				// Get current date and time
				// Get the current date and time
				const now = new Date();

				// Get the current day of the week (0-6, where 0 is Sunday and 6 is Saturday)
				const currentDay = now.getDay();

				// Calculate the start date and time of the current week
				const startDate = new Date(now);
				startDate.setDate(now.getDate() - currentDay); // Go back to Sunday
				startDate.setHours(0, 0, 0, 0); // Set the time to 00:00:00.000

				// Calculate the end date and time of the current week
				const endDate = new Date(startDate);
				endDate.setDate(startDate.getDate() + 6); // Go forward to Saturday
				endDate.setHours(23, 59, 0, 0); // Set the time to 23:59:00.000

				// Format dates for backend (assuming ISO 8601 format)
				const startOfWeekStr = startDate.toISOString();
				const endOfWeekStr = endDate.toISOString();
				setDates({
					...dates,
					startDate: startOfWeekStr,
					endDate: endOfWeekStr
				});
			}
			break;

		case 'Today':
			{
				// Get current local time
				const now = new Date();

				// Set the start date to the beginning of the day (00:00:00)
				const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());

				// Set the end date to the end of the day (23:59:59)
				const end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);

				// Convert start and end dates to ISO strings
				const startISO = start.toISOString();
				const endISO = end.toISOString();
				setDates({
					...dates,
					startDate: startISO,
					endDate: endISO
				});
			}
			break;
		default:
	}
};

export const stringReducer = (string, count) => {
	const maxLength = count || 14;

	let truncatedText = string?.slice(0, maxLength);

	if (truncatedText?.length < string?.length) {
		truncatedText += '...';
	}

	return truncatedText; // Output: "This is a long text..."
};

export const Capitalize = string => {
	const firstLetter = string?.slice(0, 1);
	// eslint-disable-next-line no-unsafe-optional-chaining
	return firstLetter + string?.slice(1).toLowerCase();
};

export const getTimeDifference = time => {
	const endTime = new Date();
	const startTime = new Date(`${time}Z`);
	return activityTimeFormatter((endTime - startTime) / 1000);
};

export const Prettify = (inputString, type) => {
	let stringWithoutUnderscores = inputString?.replace(/[_<>]/g, ' ');
	stringWithoutUnderscores = stringWithoutUnderscores?.replace(/:/g, ' ');
	if (type === 'sublattice') {
		stringWithoutUnderscores = stringWithoutUnderscores?.replace(/sublattice\s+/gi, 'Sublattice ');
	}
	stringWithoutUnderscores = stringWithoutUnderscores?.replace(/parameter/g, '');

	// Capitalize the strings
	stringWithoutUnderscores = stringWithoutUnderscores
		?.toLowerCase()
		.replace(/\b\w/g, l => l.toUpperCase());

	// Add a gap before the return statement
	if (stringWithoutUnderscores === inputString) {
		return inputString;
	}

	return stringWithoutUnderscores;
};

export const capitalizeName = name => {
	// Split the name into words
	const words = name?.split(' ');

	// Loop through each word
	for (let i = 0; i < words?.length; i++) {
		// Capitalize the first letter of each word.
		words[i] = words[i].charAt(0).toUpperCase() + words[i].slice(1);
	}

	// Join the words back together and return the capitalized name
	return words?.join(' ');
};
export const truncateMiddle = (s, start, end, omission = '…') => {
	if (!s) {
		return '';
	}
	const len = s.length;
	if ((start === 0 && end === 0) || start + end >= len) {
		return s;
	}
	if (!end) {
		return s.slice(0, start) + omission;
	}
	return s.slice(0, start) + omission + s.slice(-end);
};

export const getLocalStartTime = time => {
	const startTimeToLocal = new Date((time = `${time}Z`));
	return startTimeToLocal?.toISOString();
};

export const getQElectronCount = graph => {
	if (graph?.nodes) {
		const electrons = graph?.nodes?.filter(e => e?.contains_qelectrons);
		if (electrons?.length || electrons?.length === 0) return electrons?.length;
		return '-';
	}
	return '-';
};

export function getRandomInt(min, max) {
	min = Math.ceil(min);
	max = Math.floor(max);
	return Math.floor(Math.random() * (max - min) + min); // The maximum is exclusive and the minimum is inclusive
}

export const statusIcons = status => {
	if (status === 'COMPLETED') {
		return completedDispatch;
	}
	if (status === 'FAILED') {
		return failedDispatch;
	}
	if (status === 'NEW_OBJECT') {
		return newDispatch;
	}
	if (status === 'PENDING_POSTPROCESSING') {
		return recentDispatch;
	}
	if (status === 'RUNNING') {
		return runningDispatch;
	}

	return cancelledDispatch;
};

// Function to get the count of each dispatch status
export function getUniqueAttributeValues(array) {
	const lowerCaseStatuses = status => {
		if (status === 'COMPLETED') {
			return 'Completed';
		}
		if (status === 'FAILED') {
			return 'Failed';
		}
		if (status === 'NEW_OBJECT') {
			return 'Starting';
		}
		if (status === 'PENDING_POSTPROCESSING') {
			return 'Pending';
		}
		if (status === 'RUNNING') {
			return 'Running';
		}
		return status;
	};
	const uniqueValues = [];

	array?.forEach(obj => {
		if (!uniqueValues.some(dispatch => dispatch.status === lowerCaseStatuses(obj.status))) {
			uniqueValues.push({
				img: statusIcons(obj.status),
				status: lowerCaseStatuses(obj.status),
				count: 1
			});
		} else {
			const index = uniqueValues.findIndex(
				dispatch => dispatch.status === lowerCaseStatuses(obj.status)
			);
			uniqueValues[index].count++;
		}
	});

	return uniqueValues;
}

// returns date to yyyy-mm-dd format
export const formattedDate = dateString => {
	if (dateString.length !== 0) {
		const parts = dateString.split('-');
		const year = parts[0];
		const month = parts[1].padStart(2, '0'); // padStart is used to ensure 2-digit month
		const day = parts[2].padStart(2, '0'); // padStart is used to ensure 2-digit day
		return `${year}-${month}-${day}`;
	}
	return '';
};

export const replaceMissingDates = (array1, array2) => {
	return array1.map(date => {
		return array2.includes(date) ? date : '';
	});
};

// gets the created at date till T
export const getOnlyDate = date => {
	return date?.split('T')[0];
};

export const getFormattedDate = date => {
	const months = [
		'Jan',
		'Feb',
		'Mar',
		'Apr',
		'May',
		'Jun',
		'Jul',
		'Aug',
		'Sep',
		'Oct',
		'Nov',
		'Dec'
	];

	const typeDate = new Date(date);
	const month = months[typeDate?.getMonth()];
	let suffix = '';
	if (month % 10 === 1) {
		suffix = 'st';
	}
	if (month % 10 === 2) {
		suffix = 'nd';
	}
	if (month % 10 === 3) {
		suffix = 'rd';
	} else {
		suffix = 'th';
	}

	const day = typeDate?.getDate();

	return `${month} ${day}${suffix}`;
};

// returns grouped array when we pass api res array as a parameter
export const groupInputArray = array => {
	const groupedArray = [];
	array?.forEach(element => {
		if (
			!groupedArray.some(obj => Object.values(obj).includes(getOnlyDate(element?.completed_at)))
		) {
			groupedArray.push({
				date: getOnlyDate(element?.completed_at),
				cost: element?.subtotal_in_microdollars,
				count: 1
			});
		} else {
			const index = groupedArray.findIndex(obj => obj.date === getOnlyDate(element?.completed_at)); // get the index
			groupedArray[index] = {
				...groupedArray[index],
				...{ cost: groupedArray[index].cost + element.subtotal_in_microdollars },
				...{ count: groupedArray[index].count + 1 }
			};
		}
	});

	return groupedArray;
};

export const changeDateFormat = date => {
	const today = new Date(date);

	const year = today?.getFullYear();
	const month = today.getMonth() + 1;
	const day = today?.getDate();

	return `${year}-${month}-${day}`;
};

// returns todays date in yyyy-mm-dd format
export const getDate = () => {
	const today = new Date();

	const year = today?.getFullYear();
	const month = today.getMonth() + 1;
	const day = today?.getDate();

	return `${year}-${month}-${day}`;
};

// returns date in dd-mm-yyyy format
export function formatDate(inputDate) {
	const date = new Date(inputDate);

	const day = String(date?.getDate()).padStart(2, '0');
	const month = String(date.getMonth() + 1).padStart(2, '0');
	const year = date?.getFullYear();

	return `${day}-${month}-${year}`;
}
