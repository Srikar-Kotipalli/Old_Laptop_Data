import React from 'react';
import Chart from 'react-apexcharts';

function AreaChart({ UsageChartData, height }) {
	const chartData = {
		series: [
			{
				data: UsageChartData.data
			}
		],
		options: {
			chart: {
				type: 'area',
				toolbar: {
					show: false
				}
			},
			legend: {
				show: false
			},
			dataLabels: {
				enabled: false
			},
			stroke: {
				curve: 'smooth'
			},
			markers: {
				size: 0,
				strokeWidth: 0,
				strokeOpacity: 0,
				strokeDashArray: 0,
				fillOpacity: 0,
				radius: 0,
				offsetX: 0,
				offsetY: 0,
				hover: {
					size: undefined,
					sizeOffset: 0
				}
			},
			yaxis: [
				{
					logBase: 20,
					tickAmount: 5,
					min: 0,
					max: 100,
					axisTicks: {
						show: false
					},
					axisBorder: {
						show: false
					},
					crosshairs: {
						show: false
					},
					labels: {
						style: {
							colors: ['white']
						}
					}
				}
			],
			xaxis: {
				title: {
					text: 'Time',
					style: {
						color: 'white'
					}
				},
				axisTicks: {
					show: false
				},
				crosshairs: {
					show: false
				},
				axisBorder: {
					show: false
				},
				labels: {
					show: false
				},
				tooltip: {
					enabled: false
				},
				type: 'datetime',
				categories: UsageChartData.categories
			},
			grid: {
				borderColor: '#303067'
			},
			tooltip: {
				custom({ series, seriesIndex, dataPointIndex }) {
					return `${series[seriesIndex][dataPointIndex]}`;
				}
			}
		}
	};
	return (
		<Chart
			options={chartData.options}
			series={chartData.series}
			height={height || 220}
			style={{ margin: '0 0 0 -18px' }}
		/>
	);
}

export default AreaChart;
