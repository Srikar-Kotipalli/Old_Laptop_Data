/* eslint-disable react/jsx-props-no-spreading */
import React from 'react';
import Slider from 'react-slick';

import 'slick-carousel/slick/slick.css';

import 'slick-carousel/slick/slick-theme.css';

// eslint-disable-next-line import/no-unused-modules
export default function Carousel({ children, sliderSettings }) {
	return (
		<Slider {...sliderSettings}>
			{/* wrap this omponent around any compoent where we need to add a carousel
			- Slider settings prop is used to send the setings for how the carousel works*/}
			{children}
		</Slider>
	);
}
