import * as React from 'react';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import Divider from '@mui/material/Divider';

function StyledDivider() {
	return (
		<Divider sx={{ borderColor: '#303067' }} orientation="vertical" variant="middle" flexItem />
	);
}

function SolversTab(props) {
	const { value, onChange } = props;

	return (
		<TabContext value={value}>
			<TabList
				onChange={onChange}
				TabIndicatorProps={{
					style: {
						display: 'none'
					}
				}}
			>
				<Tab
					label="Overview"
					value="Overview"
					sx={{ padding: 0, pr: 2, minWidth: '3.5em', alignItems: 'self-start' }}
				/>
				<StyledDivider dividerMargin="10px 0 0 -15px" />
				<Tab label="Runs" value="Runs" sx={{ padding: 0, px: 2, minWidth: '5em' }} />
				<StyledDivider dividerMargin="10px 0 0 -15px" />
				<Tab label="Solvers" value="Solvers" sx={{ padding: 0, pl: 2, minWidth: '5em' }} />
			</TabList>
		</TabContext>
	);
}

export default SolversTab;
