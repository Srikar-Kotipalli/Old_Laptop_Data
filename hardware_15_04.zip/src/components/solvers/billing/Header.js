/* eslint-disable no-unused-vars */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import { TableHead, Table, Typography } from '@mui/material';
import TableSortLabel from '@mui/material/TableSortLabel';
import Checkbox from '@mui/material/Checkbox';
import Box from '@mui/material/Box';
import Icon from '../../icon';
import checkbox from '../../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../../assets/checkboxes/checkboxChecked.svg';
import '../../list/projects/style.css';

function Header({ checkAllHandler, selectAll, selected, toSort, setSelected, setToSort }) {
	const orderByInfo = React.useState('');
	const orderBy = orderByInfo[0];
	const orderInfo = React.useState('asc');
	const order = orderInfo[0];

	return (
		<div>
			<Table
				sx={{
					width: { xs: '105%', sm: '108%', lg: '100%', xl: '100%', xxl: '100%' },
					border: 'none'
				}}
			>
				<TableHead>
					<TableRow sx={{ '&:hover': { backgroundColor: 'transparent' } }}>
						<TableCell
							sx={{
								width: { sm: '1.5%' },
								border: 'none'
							}}
						>
							<Checkbox
								data-testid="headerCheckbox"
								size="small"
								sx={{ padding: '2px 0px 0px 5px' }}
								checked={selectAll}
								onChange={checkAllHandler}
								icon={
									<Icon src={checkbox} alt="checkbox" type="pointer" width="12px" height="12px" />
								}
								checkedIcon={
									<Icon
										src={checkboxChecked}
										alt="checkboxChecked"
										type="pointer"
										width="12px"
										height="12px"
									/>
								}
								// disabled={ || addMode}
							/>
						</TableCell>
						<TableCell
							sx={{
								width: { sm: '19.5%', lg: '17.5%' },
								border: 'none',
								fontSize: '12px',
								fontWeight: 'bold'
							}}
						>
							<Box sx={{ display: 'flex', alignItems: 'center' }}>
								<Box sx={{ paddingTop: '5px', paddingLeft: '6px' }}>
									{/* <ContextMenu type="multiselect" /> */}
								</Box>
								<TableSortLabel
									active={selected === 'organisationName'}
									direction={toSort === 'asc' ? 'asc' : 'desc'}
									onClick={() => {
										setSelected('organisationName');
										if (toSort === 'desc') {
											setToSort('asc');
										} else setToSort('desc');
									}}
								>
									Organization
								</TableSortLabel>
							</Box>
						</TableCell>
						<TableCell
							sortDirection={orderBy === 'server' ? order : false}
							sx={{ width: '17%', border: 'none', fontSize: '12px', fontWeight: 'bold' }}
						>
							{/* <TableSortLabel
								active={orderBy === 'server'}
								direction={order}
								onClick={() => handleSortRequest('server')}
							>
								Server
							</TableSortLabel> */}
							<Typography variant="h3" pl={{ lg: 1, xxl: 2 }} sx={{ fontWeight: 'bold' }}>
								Server
							</Typography>
						</TableCell>
						<TableCell
							sortDirection={orderBy === 'purchaseDate' ? order : false}
							sx={{
								width: { xs: '17%', lg: '18.5%' },
								border: 'none',
								fontSize: '12px',
								fontWeight: 'bold'
							}}
						>
							<TableSortLabel
								active={selected === 'purchaseDate'}
								direction={toSort === 'asc' ? 'asc' : 'desc'}
								onClick={() => {
									setSelected('purchaseDate');
									if (toSort === 'desc') {
										setToSort('asc');
									} else setToSort('desc');
								}}
							>
								<Typography variant="h3" pl={{ sm: 0, lg: 2, xl: 3, xxl: 3.5 }}>
									Purchase Date
								</Typography>
							</TableSortLabel>
						</TableCell>
						<TableCell
							sortDirection={orderBy === 'cost' ? order : false}
							sx={{ width: '18.5%', border: 'none', fontSize: '12px', fontWeight: 'bold' }}
						>
							<TableSortLabel
								active={selected === 'cost'}
								direction={toSort === 'asc' ? 'asc' : 'desc'}
								onClick={() => {
									setSelected('cost');
									if (toSort === 'desc') {
										setToSort('asc');
									} else setToSort('desc');
								}}
							>
								<Typography variant="h3" pl={{ xs: 1, lg: 1, xl: 1.5, xxl: 2 }}>
									Cost{' '}
								</Typography>
							</TableSortLabel>
						</TableCell>
						<TableCell
							sortDirection={orderBy === 'runs' ? order : false}
							sx={{
								width: { lg: '19.5%', xl: '20%', xxl: '19.5%' },
								border: 'none',
								fontSize: '12px',
								fontWeight: 'bold'
							}}
						>
							<TableSortLabel
								active={selected === 'runs'}
								direction={toSort === 'asc' ? 'asc' : 'desc'}
								onClick={() => {
									setSelected('runs');
									if (toSort === 'desc') {
										setToSort('asc');
									} else setToSort('desc');
								}}
							>
								Runs{' '}
							</TableSortLabel>
						</TableCell>
					</TableRow>
				</TableHead>
			</Table>
		</div>
	);
}

export default Header;
