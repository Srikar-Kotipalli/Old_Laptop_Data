/* eslint-disable react/jsx-no-useless-fragment */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import { TableHead } from '@mui/material';
import TableSortLabel from '@mui/material/TableSortLabel';
import Checkbox from '@mui/material/Checkbox';
import Box from '@mui/material/Box';
import Icon from '../../icon';
import checkbox from '../../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../../assets/checkboxes/checkboxChecked.svg';
import checkboxDisabled from '../../../assets/checkboxes/checkboxdisabled.svg';
import ContextMenu from '../../menu/projects/contextMenu';
import './style.css';
import { ProjectContext } from '../../../containers/projects/projectContext';
import { DISPATCH_HEADER } from '../../../constants/tableHeaderConstants';

export default function TableHeader() {
	const projectContext = React.useContext(ProjectContext);
	const header = DISPATCH_HEADER;
	const { sortOrder, sortColumn, onSort, onAllSelected, allSelected, showArchived, addMode } =
		projectContext;
	return (
		<>
			{!!header.length && (
				<TableHead sx={{ '& th': { border: 0 } }}>
					<TableRow className="tableHeader" sx={{ '& td': { border: 0 } }}>
						<TableCell
							align="left"
							sx={{
								width: '7%'
							}}
						>
							<Box display="flex" flexDirection="row">
								<Checkbox
									data-testid="headerCheckbox"
									size="small"
									sx={{ padding: '5px 0px 0px 5px' }}
									checked={allSelected}
									onChange={e => onAllSelected(e)}
									icon={
										<Icon
											src={!showArchived && !addMode ? checkbox : checkboxDisabled}
											alt="checkbox"
											type="pointer"
										/>
									}
									checkedIcon={<Icon src={checkboxChecked} alt="checkboxChecked" type="pointer" />}
									disabled={showArchived || addMode}
								/>
								<Box sx={{ paddingTop: '5px', paddingLeft: '6px' }}>
									<ContextMenu type="multiselect" />
								</Box>
							</Box>
						</TableCell>
						{header.map(h => (
							<TableCell
								width={h.width}
								key={h.id}
								colSpan={h.colSpan || 1}
								align={h.align || 'center'}
								data-testid="tableHeader"
							>
								<TableSortLabel
									active={sortColumn === h.id}
									direction={sortColumn === h.id ? sortOrder : 'asc'}
									onClick={() => onSort(h.id)}
									disabled={h.id === 'tags' || h.id === 'copy' || h.id === 'contextmenu'}
									data-testid="tableSort"
								>
									{h.label}
								</TableSortLabel>
							</TableCell>
						))}
					</TableRow>
				</TableHead>
			)}
		</>
	);
}
