/* eslint-disable react/jsx-no-constructed-context-values */
/* eslint-disable testing-library/no-node-access */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
import ExperimentsListView from '../experimentsListView';
import { ProjectContext } from '../../../../containers/projects/projectContext';

const header = { label: 'Title', align: 'left', width: '20%', id: 'title' };

const onlyExperiments = [
	{
		completedElectrons: 29,
		count: 4,
		id: '854c5de8-b13e-4fab-854d-3596704ds5d20',
		lastUpdated: '2022-01-11 13:04:00',
		title: 'Yellow Viper',
		runTime: 1590600,
		startTime: '2022-01-12 20:22:00',
		status: 'FAILED',
		tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
		totalElectrons: 41,
		type: 'Experiment',
		isOpen: false,
		dispatches: [
			{
				completedElectrons: 4,
				count: '',
				id: 'eb298345-8aa9-4096-bde7-4a5803ecb9c0',
				isPinned: false,
				lastUpdated: '2022-01-11 13:04:00',
				title: 'Fuschia Silver Basset Hound',
				runTime: 235600,
				startTime: '2022-01-12 20:22:00',
				status: 'FAILED',
				tags: ['react', 'rust', 'node', 'js'],
				totalElectrons: 8,
				type: 'Dispatch'
			}
		]
	}
];
const openExperiments = [
	{
		completedElectrons: 29,
		count: 4,
		id: '854c5de8-b13e-4fab-854d-3596704ds5d20',
		lastUpdated: '2022-01-11 13:04:00',
		title: 'Yellow Vipersdsadasd',
		runTime: 1590600,
		startTime: '2022-01-12 20:22:00',
		status: 'FAILED',
		tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
		totalElectrons: 41,
		type: 'Experiment',
		isOpen: true,
		isLoader: false,
		hierarchyListItems: [
			{
				completedElectrons: 4,
				count: '',
				id: 'eb298345-8aa9-4096-bde7-4a5803ecb9c0',
				isPinned: false,
				lastUpdated: '2022-01-11 13:04:00',
				title: 'Yellow Detroiy Bioer',
				runTime: 235600,
				startTime: '2022-01-12 20:22:00',
				status: 'FAILED',
				tags: ['react', 'rust', 'node', 'js'],
				totalElectrons: 8,
				type: 'Dispatch'
			}
		]
	}
];

const timeFormatter = jest.fn();
const dateFormatter = jest.fn();

describe('experiments list view', () => {
	test('renders experiments list view', () => {
		render(
			<ProjectContext.Provider value={{ allItems: onlyExperiments }}>
				<ExperimentsListView header={header} />
			</ProjectContext.Provider>
		);
		const element = screen.getByTestId('experimentsList');
		expect(element).toBeInTheDocument();
	});
	test('check for icon on open of experiment', () => {
		const handleClick = jest.fn();
		render(
			<ProjectContext.Provider value={{ allItems: onlyExperiments }}>
				<ExperimentsListView
					header={header}
					timeFormatter={timeFormatter}
					dateFormatter={dateFormatter}
					handleOpen={handleClick}
				/>
			</ProjectContext.Provider>
		);
		const caretRight = screen.getByAltText('caretRight');
		expect(caretRight).toBeInTheDocument();
		fireEvent.click(caretRight);
		expect(handleClick).toBeCalledTimes(1);
	});
	test('show dispatches inside experiment', () => {
		const handleClick = jest.fn();
		render(
			<ProjectContext.Provider value={{ allItems: openExperiments }}>
				<ExperimentsListView
					header={header}
					timeFormatter={timeFormatter}
					dateFormatter={dateFormatter}
					handleOpen={handleClick}
				/>
			</ProjectContext.Provider>
		);
		const experimentDispatch = screen.getByTestId('dispatchRow');
		expect(experimentDispatch).toBeInTheDocument();
	});
	test('calls onCheckbox function on clicking checkbox', () => {
		const handleClick = jest.fn();
		render(
			<ProjectContext.Provider
				value={{ onCheckboxChecked: handleClick, allItems: onlyExperiments }}
			>
				<ExperimentsListView
					header={header}
					timeFormatter={timeFormatter}
					dateFormatter={dateFormatter}
					handleOpen={handleClick}
				/>
			</ProjectContext.Provider>
		);
		const element = screen
			.getByTestId('experimentCheckbox')
			.querySelector('input[type="checkbox"]');
		expect(element).toBeInTheDocument();
		fireEvent.click(element);
		expect(handleClick).toBeCalledTimes(1);
	});
	test('close hierarchy function', () => {
		const handleClick = jest.fn();
		render(
			<ProjectContext.Provider
				value={{ onCheckboxChecked: handleClick, allItems: openExperiments }}
			>
				<ExperimentsListView
					header={header}
					timeFormatter={timeFormatter}
					dateFormatter={dateFormatter}
					handleOpen={handleClick}
				/>
			</ProjectContext.Provider>
		);
		const element = screen.getByAltText('caretDown');
		expect(element).toBeInTheDocument();
		fireEvent.click(element);
		expect(handleClick).toBeCalledTimes(1);
	});
});
