/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

/* eslint-disable camelcase */
/* eslint spaced-comment: ["error", "always"] */
/* eslint-disable react/jsx-curly-brace-presence */
/* eslint no-inline-comments: "error" */

import React from 'react';
import { Table, TableBody, TableRow, Box } from '@mui/material';
import BillingTableHeader from './tableHeader';
import BillingTableRow from './tableRow';
import BillingTableFooter from './tableFooter';
import NoRecordsFound from './noRecordsFound';
// import { BillingContext } from '../../../containers/settings/billing/billingContext';
// import Loader from '../../loader';

function BillingTable() {
	const billingContext = React.useContext(BillingContext);
	const { invoices, invoicesLoader } = billingContext;

	return (
		<>
			<Table width="100%">
				<BillingTableHeader />
				<TableBody>
					{!invoicesLoader &&
						invoices &&
						invoices?.map((invoice, index) => (
							<TableRow key={invoice?.external_invoice_id} data-testid="billingListView">
								<BillingTableRow invoice={invoice} index={index} hierarchyType="dispatch" />
							</TableRow>
						))}
				</TableBody>
			</Table>
			{invoicesLoader && (
				<Box mt={7}>
					{/* <Loader isFetching={invoicesLoader} position="relative" width="75%" height="100%" /> */}
				</Box>
			)}
			<BillingTableFooter />
			{!invoicesLoader && invoices?.length === 0 && <NoRecordsFound />}
		</>
	);
}

export default BillingTable;
