/* eslint-disable react/jsx-no-useless-fragment */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import TableSortLabel from '@mui/material/TableSortLabel';
import TableHead from '@mui/material/TableHead';
import { BILLING_HEADER } from '../../../constants/tableHeaderConstants';
import { BillingContext } from '../../../containers/billing/billingContext';

function BillingTableHeader() {
	const billingContext = React.useContext(BillingContext);
	const { onSort, sort, direction } = billingContext;
	const header = BILLING_HEADER;
	return (
		<>
			{!!header?.length && (
				<TableHead
					sx={{
						'& th': {
							border: 0,
							background: theme => theme.palette.background.covalentPurple
						}
					}}
				>
					<TableRow
						sx={{
							borderRadius: '8px',
							height: '32px',
							'& td': { border: 0 }
						}}
					>
						{header?.map((h, index) => (
							<TableCell
								width={h?.width}
								key={h?.id}
								colSpan={h?.colSpan || 1}
								align={h?.align || 'center'}
								sx={{
									// Apply specific border radius to first and last cells
									paddingLeft: index === 0 ? '30px' : null,
									borderRadius:
										index === 0 ? '8px 0 0 8px' : index === header.length - 1 ? '0 8px 8px 0' : '0'
								}}
							>
								<TableSortLabel
									sx={{
										color: theme => theme.palette.text.gray03,
										fontSize: '12px',
										fontWeight: 'bold'
									}}
									active={sort === h?.id}
									direction={sort === h?.id ? direction : 'asc'}
									onClick={() => onSort(h?.id)}
									disabled={h?.id === ' '}
									data-testid="tableSort"
								>
									{h?.label}
								</TableSortLabel>
							</TableCell>
						))}
					</TableRow>
				</TableHead>
			)}
		</>
	);
}

export default BillingTableHeader;
