/* eslint-disable react/no-children-prop */
import React from 'react';
import { Grid, Typography, Box } from '@mui/material';
import './style.css';

export default function DescriptionBlock({ desc, minHeight, margin }) {
	return (
		// eslint-disable-next-line object-shorthand
		<Grid container item direction="row" xs={10} sx={{ margin: margin }}>
			<Grid
				item
				xs={12}
				sx={{ borderRadius: '8px 8px 0px 0px', backgroundColor: '#1C1C46', height: '41px' }}
			>
				<Typography pl={2} pt={1} sx={{ color: '#FFF' }}>
					Description
				</Typography>
			</Grid>
			<Grid
				item
				xs={12}
				sx={{ backgroundColor: 'rgba(11, 11, 17, 0.9)', minHeight: minHeight || '991px' }}
			>
				<Box pt="1rem" pl={2} pr="1rem">
					{desc?.map(i => (
						<Typography key={i.id} sx={{ pb: 1 }} className="aboutContent">
							{i?.point}
						</Typography>
					))}
				</Box>
			</Grid>
		</Grid>
	);
}
