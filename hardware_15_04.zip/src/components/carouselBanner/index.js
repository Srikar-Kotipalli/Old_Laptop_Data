import { Grid, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
// import { useDispatch, useSelector } from 'react-redux';
import React from 'react';
import BasicButton from '../basicButton/index';
// import { setTourActive } from '../../redux/tourSlice';

function CarouselBanner({ bannerData }) {
	const navigate = useNavigate();
	// const dispatch = useDispatch();
	// const { isRecent, isOverview } = useSelector(state => state.tour);
	return (
		<Grid sx={{ position: 'relative', height: '300px' }}>
			<img width="100%" src={bannerData.image} alt="banner" />
			<Grid
				xs={7}
				item
				container
				direction="column"
				style={{ position: 'absolute', top: '10%', left: '5%' }}
			>
				<Typography
					variant="bannerHeader"
					pb={0.5}
					sx={{ color: theme => theme.palette.text.secondary }}
				>
					{bannerData.header}
				</Typography>
				<Typography variant="status" pb={0.5} sx={{ color: theme => theme.palette.text.secondary }}>
					{bannerData.paragraph}
				</Typography>
				<Grid item container xs={10} direction="row">
					<Grid item xs={5} pt={2}>
						<BasicButton
							title={bannerData.buttonGetStarted}
							width="100%"
							onClick={() => navigate('/gettingstarted')}
							id="getStartedButton"
						/>
					</Grid>
					<Grid item xs={5} pt={2} pl={1}>
						{/* <BasicButton
							title={bannerData.buttonWalkthrough}
							width="100%"
							onClick={() => {
								if (isRecent && isOverview) {
									dispatch(
										setTourActive({
											tourActive: true
										})
									);
								}
							}}
						/> */}
					</Grid>
				</Grid>
			</Grid>
		</Grid>
	);
}

export default CarouselBanner;
