/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

import React from 'react';
import Icon from '../icon';

function PrimaryButton({
	handler,
	title,
	bgColor,
	borderRadius,
	hoverColor,
	fontSize,
	variant,
	borderisPresent,
	img,
	sx,
	color,
	disabled
}) {
	return (
		<Button
			variant={variant}
			sx={{
				'&:hover': {
					backgroundColor: hoverColor,
					color: '#FFFFFF',
					borderRadius: borderRadius || '25px'
				},
				display: 'flex',
				justifyContent: 'center',
				alignItems: 'center',
				borderRadius: borderRadius || '25px',
				backgroundColor: bgColor,
				border: borderisPresent ? '1px solid ' : null,
				borderColor: borderisPresent ? 'rgba(100, 115, 255, 1)' : null,
				...sx
			}}
			disabled={disabled}
			onClick={handler}
			data-testid="actionButton"
		>
			<Typography
				color={color || 'textPrimary'}
				variant="subtitle2"
				fontSize={fontSize}
				pr={1}
				pl={1}
			>
				{title}
			</Typography>
			{img ? <Icon src={img} /> : null}
		</Button>
	);
}

export default PrimaryButton;
