/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
import AddItemsMenu from '../addItemsMenu';

describe('add new menu', () => {
	const mockAnchorEl = document.createElement('button');
	const open = Boolean(mockAnchorEl);

	test('renders add new menu button', () => {
		render(<AddItemsMenu />);
		const element = screen.getByRole('button', { name: 'Add new' });
		expect(element).toBeInTheDocument();
	});

	test('calls function when add project is clicked', () => {
		const clickHandler = jest.fn();
		render(<AddItemsMenu currentTab="all" addItem={clickHandler} />);
		const button = screen.queryByText('Add new');
		fireEvent.click(button);
		expect(button).toBeInTheDocument();
		const element = screen.getByTestId('addProject');
		fireEvent.click(element);
		expect(clickHandler).toBeCalledTimes(1);
	});

	test('calls function when add experiment is clicked', () => {
		const clickHandler = jest.fn();
		render(<AddItemsMenu currentTab="all" addItem={clickHandler} />);
		const button = screen.queryByText('Add new');
		fireEvent.click(button);
		expect(button).toBeInTheDocument();
		const element = screen.getByTestId('addExperiment');
		fireEvent.click(element);
		expect(clickHandler).toBeCalledTimes(1);
	});

	const additemsMenuIcons = [
		['Project', 'projectIcon'],
		['Experiment', 'experimentIcon']
	];
	test.each(additemsMenuIcons)('the menu opens and we have  %p icon', (fargs, sargs) => {
		render(<AddItemsMenu open={open} currentTab="all" />);
		const button = screen.queryByText('Add new');
		fireEvent.click(button);
		expect(button).toBeInTheDocument();
		const text = screen.queryByText(fargs);
		const icon = screen.getByAltText(sargs);
		expect(text).toBeInTheDocument();
		expect(icon).toBeInTheDocument();
	});
});
