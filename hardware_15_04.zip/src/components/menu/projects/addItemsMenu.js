/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Button from '@mui/material/Button';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import Icon from '../../icon';
import addIcon from '../../../assets/actions/add.svg';
import addIconDisabled from '../../../assets/actions/addDisabled.svg';
import projectIcon from '../../../assets/folderIcons/projectIcon.svg';
import experimentIcon from '../../../assets/folderIcons/folderClosed.svg';

export default function AddItemsMenu(props) {
	const { addItem, currentTab, showArchived, searchValue, tagsToFilter } = props;
	const [anchorEl, setAnchorEl] = React.useState(null);
	const open = Boolean(anchorEl);
	const handleClick = event => {
		if (currentTab !== 'dispatches') setAnchorEl(event.currentTarget);
	};
	const handleClose = () => {
		setAnchorEl(null);
	};
	const addProject = () => {
		addItem('Project');
		setAnchorEl(null);
	};
	const addExperiment = () => {
		addItem('Experiment');
		setAnchorEl(null);
	};

	return (
		<>
			<Button
				sx={{
					'&:hover': {
						backgroundColor: '#1C1C46',
						border: '1px solid #6473FF'
					},
					'&:disabled': {
						border: '1px solid #1c1c46',
						color: '#2b2b3b'
					},
					lineHeight: '1.9',
					height: '32.9px',
					paddingTop: 0.3
				}}
				variant="outlined"
				size="small"
				startIcon={
					<Avatar
						src={
							showArchived ||
							currentTab === 'dispatches' ||
							searchValue?.length >= 3 ||
							tagsToFilter.length > 0
								? addIconDisabled
								: addIcon
						}
						sx={{ width: 16, height: 16, marginBottom: '0.15rem' }}
					/>
				}
				onClick={handleClick}
				disabled={
					showArchived ||
					currentTab === 'dispatches' ||
					searchValue?.length >= 3 ||
					tagsToFilter.length > 0
				}
			>
				<Typography variant="h2">Add new</Typography>
			</Button>
			<Menu
				id="basic-menu"
				anchorEl={anchorEl}
				open={open}
				onClose={handleClose}
				PaperProps={{
					style: {
						transform: 'translateX(0%) translateY(8%)'
					}
				}}
			>
				{currentTab === 'all' && (
					<MenuItem onClick={addProject} data-testid="addProject">
						<Icon src={projectIcon} type="static" alt="projectIcon" />
						<Typography variant="subtitle2">Project</Typography>
					</MenuItem>
				)}
				{currentTab !== 'dispatches' && (
					<MenuItem onClick={addExperiment} data-testid="addExperiment">
						<Icon src={experimentIcon} type="static" alt="experimentIcon" />
						<Typography variant="subtitle2">Experiment</Typography>
					</MenuItem>
				)}
			</Menu>
		</>
	);
}
