import { Grid, Typography } from '@mui/material';
import React from 'react';
import { dbOverviewStatusIcon } from '../../../utils/statusIcons';

function DashboardCard({ title, value }) {
	return (
		<Grid
			item
			xs={3.8}
			sx={{ background: theme => theme.palette.background.covalentPurple, borderRadius: '16px' }}
			p={2}
		>
			{' '}
			<Grid container alignItems="center">
				<Grid item xs={2}>
					{dbOverviewStatusIcon(title)}
				</Grid>
				<Grid item xs={10} pl={1.5}>
					<Typography variant="header20">{title}</Typography>
				</Grid>
			</Grid>
			<Grid container alignItems="center" justifyContent="flex-end">
				<Grid item xs={10} pl={1.5}>
					<Typography variant="bannerParagraph">{value}</Typography>
				</Grid>
			</Grid>
		</Grid>
	);
}

export default DashboardCard;
