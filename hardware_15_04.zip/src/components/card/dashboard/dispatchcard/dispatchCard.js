import * as React from 'react';
import { Typography, Box } from '@mui/material';
import Icon from '../../../icon';
import './style.css';
import DispatchCode from '../../../dashboard/dispatchCode';
import routes from '../../../../constants/routes.json';

function dispatchCard({ img, heading, code, step, goto, description, banner, heading2 }) {
	// Redirects to a page based on the card content coming from Sample Dispatch Card content
	function handleClick() {
		window.open(goto, '_blank');
	}

	return (
		<Box
			sx={{
				borderRadius: '8px',
				padding: '20px 10px',
				background: '#303067',
				transition: '0.1s ease-in',
				'&:hover': {
					transform: 'scale(1.04)'
				},
				boxShadow: '1px 2px rgba(0, 0, 0, 0.25);'
			}}
		>
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'space-between',
					background: 'default',
					borderRadius: '6px',
					padding: '2px'
				}}
			>
				<Box sx={{ display: !heading2 ? 'flex' : 'block', alignItems: 'center' }}>
					<Typography
						sx={{
							paddingRight: '8px',
							fontSize: '14px',
							color: theme => theme.palette.text.secondary,
							flexWrap: 'wrap'
						}}
					>
						{heading}
					</Typography>
					{heading2 && (
						<Box display="flex">
							<Box onClick={() => window.open(routes?.DISPATCHES, '_blank')}>
								<Typography
									sx={{
										paddingRight: '8px',
										fontSize: '14px',
										color: theme => theme.palette.text.secondary,
										flexWrap: 'wrap',
										textDecoration: 'underline'
									}}
								>
									{heading2}
								</Typography>
							</Box>
							<Icon
								src={img}
								alt="icon"
								clickHandler={() => handleClick()}
								title="Go to"
								placement="top"
							/>
						</Box>
					)}
					{!heading2 && (
						<Icon
							src={img}
							alt="icon"
							clickHandler={() => handleClick()}
							title="Go to"
							placement="top"
						/>
					)}
				</Box>
				<Box
					sx={{
						padding: '4px 8px',
						borderRadius: '8px'
					}}
				>
					<Typography
						sx={{
							color: theme => theme.palette.text.secondary,
							fontSize: '14px',
							fontFamily: 'DM Sans'
						}}
					>
						{step}
					</Typography>
				</Box>
			</Box>
			{!banner ? (
				<Box sx={{ p: '5px 0 20px 0' }}>
					<Typography
						sx={{
							fontSize: '12px',
							minHeight: '36px'
						}}
					>
						{description}
					</Typography>
				</Box>
			) : (
				<Box sx={{ pt: '29px' }} />
			)}
			{/* // If there is any parameter called banner display an image */}
			{!banner ? (
				<DispatchCode code={code} goto={goto} n={50} placement="top" width="16rem" />
			) : (
				<Box sx={{ display: 'flex', flexDirection: 'row-reverse', pt: '5px' }}>
					<img src={banner} alt="graph" />
				</Box>
			)}
		</Box>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default dispatchCard;
