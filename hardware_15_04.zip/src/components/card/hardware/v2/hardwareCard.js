/* eslint-disable react/no-array-index-key */
/* eslint-disable react/jsx-boolean-value */
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Typography, Box, Grid } from '@mui/material';
import Divider from '@mui/material/Divider';
import Icon from '../../../icon';
// import img from '../../../../assets/actions/add.svg';
import sucess from '../../../../assets/SuccessIcon.svg';
import theme from '../../../../theme';
import covalent from '../../../../assets/icons/covalent-tag.svg';
import nvidia from '../../../../assets/nvidia.svg';
import CopyButton from '../../../copyButton/index';
import OverflowTooltip from '../../../tooltip/overflowTooltip';

function StyledDivider() {
	return (
		<Divider
			sx={{ borderColor: theme.palette.background.blue03 }}
			orientation="vertical"
			variant="middle"
			flexItem
		/>
	);
}

function HardwareCard({ data }) {
	const navigate = useNavigate();
	const handleOnClick = () => {
		navigate(`/hardware/${data?.id}`);
	};
	return (
		<Box
			sx={{
				bgcolor: theme.palette.background.blue08,
				borderRadius: '8px',
				width: '3640px',
				height: '126px',
				padding: '10px 20px 10px 20px',
				display: 'flex',
				justifyContent: 'space-between'
			}}
			onClick={handleOnClick}
		>
			<Grid
				container
				display="flex"
				justifyContent="space-between"
				alignItems='center'
				alignSelf="center"
			>
				{/* First Part */}
				<Grid item xs={6.5} m='16.5px 0px'>
					<Box display="flex" alignItems='center'>
						<Typography
							fontWeight="bold"
							color={theme.palette.text.secondary}
							variant='h4'
						>
							<OverflowTooltip title={data?.title} length={10} />
						</Typography>
						<Icon width='6px' height='6px' src={sucess} alt="sucess" />
						<CopyButton
							content={data?.title}
							borderEnable={false}
							placement="top"
							bgColor={theme.palette.background.blue14}
							padding="4px"
						/>
					</Box>
					<Grid container display="flex" >
						{data?.tags.map((tag, tagIndex) => (
							<Box
								key={tagIndex}
								sx={{
									bgcolor: theme.palette.background.blue10,
									border: `0.5px solid ${theme.palette.background.blue03}`,
									borderRadius: '4px',
									mr: '4px'
								}}
							>
								<Grid item padding="0px 1px 0px 1px">
									{/* <Icon src={tag} alt={`Tag ${tagIndex + 1}`} /> */}
									{tag === 'covalent' && <Icon src={covalent} alt="nvidia" />}
									{tag === 'nvidia' && <Icon src={nvidia} alt="nvidia" />}
									{tag === 'GPU' && (
										<Typography variant='h2' fontWeight="bold" mt="2px" p="1px">
											GPU
										</Typography>
									)}
								</Grid>
							</Box>
						))}
					</Grid>

					{/* Cost */}
					<Box mt={1}>
						<Typography variant='h4'
							sx={{
								color: theme.palette.text.blue01,
								fontWeight: 'bold'
							}}
						>
							{data?.cost}
						</Typography>
					</Box>
				</Grid>

				{/* Divider */}
				<StyledDivider />

				{/* Second Part */}
				<Grid item xs={4.5} alignItems="center" m='19px 0px'>
					{Object.entries(data?.parameters).map(([key, value], paramIndex) => (
						<Grid key={paramIndex}>
							<Box display="flex" alignItems='center'>
								<Box
								sx={{width:'50%'}}
								>
									<Typography variant='h3' color={theme.palette.text.gray03}>
										{key}
									</Typography>
								</Box>
								<Box
									sx={{paddingLeft: '4px', width:'50%' }}
								>
									<Typography variant='h2' color={theme.palette.text.secondary} fontWeight='bold' >
									<OverflowTooltip title={value} length={10} />
									</Typography>
								</Box>
							</Box>
						</Grid>
					))}
				</Grid>
			</Grid>
		</Box>
	);
}

export default HardwareCard;
