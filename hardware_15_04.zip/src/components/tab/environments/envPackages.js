// /* eslint-disable import/no-unused-modules */
// /*
//  * Copyright 2022 Agnostiq Inc.
//  * Note: This file is subject to a proprietary license agreement entered into between
//  * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
//  * access and use this file is subject to the terms and conditions of such agreement.
//  * Please ensure you carefully review such agreements and, if you have any questions
//  * please reach out to Agnostiq at: [support@agnostiq.com].
//  */
import * as React from 'react';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import Divider from '@mui/material/Divider';

function StyledDivider() {
	return (
		<Divider
			sx={{ display: 'flex', alignSelf: 'center', borderColor: '#303067', height: '20px' }}
			orientation="vertical"
			variant="middle"
			flexItem
		/>
	);
}

function EnvironmentPackageTab(props) {
	const { value, onChange } = props;
	return (
		<TabContext value={value}>
			<TabList
				onChange={onChange}
				TabIndicatorProps={{
					style: {
						display: 'none'
					}
				}}
				sx={{
					'& .MuiTab-root.Mui-selected': {
						color: value === 'Error' && '#FF6464'
					},

					'& .MuiTab-root:hover': {
						color: '#AEB6FF'
					}
				}}
			>
				<Tab label="Pip" value="pip" sx={{ minWidth: 0 }} />
				<StyledDivider />
				<Tab label="Conda" value="conda" sx={{ minWidth: 0 }} />
				<StyledDivider />
				<Tab label="Channels" value="channels" sx={{ minWidth: 0 }} />
				{/* <StyledDivider />
				<Tab label="Variables" value="variables" sx={{ minWidth: 0 }} /> */}
				<StyledDivider />
				<Tab label="Yaml" value="yaml" sx={{ minWidth: 0 }} />
			</TabList>
		</TabContext>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default EnvironmentPackageTab;

// import React, { useState } from 'react';
// import { Tabs, Tab, Box, Typography } from '@mui/material';
// import Divider from '@mui/material/Divider';

// function StyledDivider() {
// 	return (
// 		<Divider sx={{ borderColor: '#303067' }} orientation="vertical" variant="middle" flexItem />
// 	);
// };

// function TabComponent() {
//   const [selectedTab, setSelectedTab] = useState(0);

//   const handleTabChange = (event, newValue) => {
//     setSelectedTab(newValue);
//   };

//   const tabData = [
//     {
//       heading: 'Channels',
//       description: 'Channels Velit suscipit laboriosam rem quibusdam. Nostrum voluptas labore eaque quos. Maiores ratione fugit temporibus.'
//     },
//     {
//       heading: 'pip',
//       description: 'PIP Channels Velit suscipit laboriosam rem quibusdam. Nostrum voluptas labore eaque quos. Maiores ratione fugit temporibus.'
//     },
//     {
//       heading: 'conda',
//       description: 'conda Channels Velit suscipit laboriosam rem quibusdam. Nostrum voluptas labore eaque quos. Maiores ratione fugit temporibus.'
//     },
// 	{
// 		heading: 'Variables',
// 		description: 'Variables Channels Velit suscipit laboriosam rem quibusdam. Nostrum voluptas labore eaque quos. Maiores ratione fugit temporibus.'
// 	},
// 	{
// 		heading: 'yaml',
// 		description: 'Yaml Channels Velit suscipit laboriosam rem quibusdam. Nostrum voluptas labore eaque quos. Maiores ratione fugit temporibus.'
// 	}
//   ];

//   return (
//     <Box>
//       <Tabs
//         value={selectedTab}
//         onChange={handleTabChange}
//         textColor="primary"
//         indicatorColor="primary"
//       >
//         {tabData.map((tab, index) => (
//           // eslint-disable-next-line react/no-array-index-key
//           <Tab key={index} label={tab.heading} />
//         ))}
// 		<StyledDivider />
//       </Tabs>
//       <Box>
//         <Typography variant="h6" component="div">
//           {tabData[selectedTab].heading}
//         </Typography>
//         <Typography variant="body1">
//           {tabData[selectedTab].description}
//         </Typography>
//       </Box>
//     </Box>
//   );
// }

// export default TabComponent;
