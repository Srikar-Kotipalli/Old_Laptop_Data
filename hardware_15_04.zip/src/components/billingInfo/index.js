/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import { Typography, Box, Stack } from '@mui/material';
import { Elements } from '@stripe/react-stripe-js';
import Icon from '../icon';
import { BillingContext } from '../../containers/billing/billingContext';
import AddIcon from '../../assets/actions/addGray.svg';
import EditIcon from '../../assets/actions/editLight.svg';
import DeleteIcon from '../../assets/actions/deleteLight.svg';
import Delete from '../../assets/actions/delete.svg';
import { capitalizeName } from '../../utils/utils';
import Loader from '../loader';
import stripePromise from '../../containers/billing/stripe';
import CheckoutForm from '../../containers/billing/checkoutForm';
import MarketplaceDialogBox from '../dialogBox/marketplace';

function BillingInfo() {
	const billingContext = React.useContext(BillingContext);
	const {
		// defaultPaymentMethod,
		paymentMethod,
		isBillingAccountPresent,
		isLoading,
		toggleOpenDetails,
		openDetails,
		// setOpenDetails,
		externalSetupIntent,
		openDeletePopup,
		toggleDeleteModal,
		deletePaymentMethod
	} = billingContext;

	const appearance = {
		variables: {
			colorPrimary: '#0570de',
			colorBackground: '#08081A',
			colorText: '#ffffff',
			colorDanger: '#df1b41',
			fontFamily: 'Ideal Sans, system-ui, sans-serif',
			spacingUnit: '5px',
			borderRadius: '8px',
			height: '32px'
		}
	};

	return (
		<Box
			sx={{
				marginTop: '20px',
				padding: '26px 30px 26px 30px',
				marginBottom: '20px',
				width: '100%',
				minHeight: '161px',
				border: '1px solid',
				borderRadius: '8px',
				borderColor: theme => theme.palette.background.blue03
				// display: 'flex',
				// alignItems: 'center',
				// justifyContent: 'center'
			}}
		>
			<Typography variant="h4">Billing Information</Typography>
			{isLoading && (
				<Box sx={{ marginTop: '8px' }}>
					<Loader isFetching={isLoading} width="100%" position="relative" height="100%" />
				</Box>
			)}
			{!openDetails ? (
				isBillingAccountPresent ? (
					!isLoading && (
						<Box sx={{ marginTop: '28px' }}>
							{paymentMethod ? (
								<Typography variant="h2">
									{paymentMethod
										? `${capitalizeName(paymentMethod?.card_brand)} card ending ****
						${paymentMethod?.card_last4}`
										: null}{' '}
								</Typography>
							) : (
								<Typography variant="h2">Please add Card Details </Typography>
							)}
							<Stack direction="row" alignItems="center" spacing={1} sx={{ marginTop: '15px' }}>
								{!paymentMethod && (
									<Box
										onClick={() => toggleOpenDetails(true)}
										sx={{
											width: '70px',
											border: '1px solid transparent',
											cursor: 'pointer',
											'&:hover': {
												background: theme => theme.palette.background.covalentPurple,
												borderRadius: '70px',
												border: '1px solid',
												borderColor: theme => theme.palette.background.blue05
											},
											display: 'flex',
											alignItems: 'center',
											justifyContent: 'center'
										}}
									>
										<Box
											sx={{
												width: '24px',
												height: '24px'
											}}
										>
											<Icon clickHandler={() => toggleOpenDetails(true)} title="" src={AddIcon} />
										</Box>

										<Typography
											mr={1}
											variant="h2"
											sx={{ color: theme => theme.palette.text.gray03, cursor: 'pointer' }}
										>
											Add
										</Typography>
									</Box>
								)}

								{paymentMethod && (
									<Box
										sx={{
											width: '24px',
											height: '24px',
											border: '1px solid transparent',
											cursor: 'pointer',
											'&:hover': {
												background: theme => theme.palette.background.covalentPurple,
												borderRadius: '8px',
												border: '1px solid',
												borderColor: theme => theme.palette.background.blue05
											}
										}}
									>
										<Icon
											clickHandler={() => toggleOpenDetails(true)}
											title="Edit"
											src={EditIcon}
										/>
									</Box>
								)}

								{paymentMethod ? (
									<Box
										sx={{
											width: '24px',
											height: '24px',
											border: '1px solid transparent',
											cursor: 'pointer',
											'&:hover': {
												background: theme => theme.palette.background.covalentPurple,
												borderRadius: '8px',
												border: '1px solid',
												borderColor: theme => theme.palette.background.blue05
											}
										}}
									>
										<Icon
											clickHandler={() => toggleDeleteModal(true)}
											title="Delete"
											src={DeleteIcon}
										/>
									</Box>
								) : null}

								{/* <Typography
									variant="h2"
									sx={{ color: theme => theme.palette.text.gray03, cursor: 'pointer' }}
								>
									{paymentMethod ? 'Edit' : 'Add'}
								</Typography> */}
							</Stack>
						</Box>
					)
				) : (
					!isLoading && (
						<Typography
							variant="h2"
							mt={4}
							sx={{ color: theme => theme.palette.text.gray03, cursor: 'pointer' }}
						>
							No billing account found. Please contact the administrator
						</Typography>
					)
				)
			) : (
				<Box marginTop="28px" sx={{ color: 'transparent' }}>
					{externalSetupIntent && (
						<Elements
							stripe={stripePromise()}
							options={{
								clientSecret: externalSetupIntent,
								appearance
							}}
						>
							<CheckoutForm togglePaymentModal={toggleOpenDetails} />
						</Elements>
					)}
				</Box>
			)}
			<MarketplaceDialogBox
				openDialogBox={openDeletePopup}
				setOpenDialogBox={toggleDeleteModal}
				handler={deletePaymentMethod}
				confirmButtonTitle="Delete"
				title="Delete"
				message="Are you sure about removing the existing credit card?"
				srcIcon={Delete}
			/>
		</Box>
	);
}

export default BillingInfo;
