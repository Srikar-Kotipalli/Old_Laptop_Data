import * as React from 'react';
import { Box } from '@mui/material';
import CopyButton from '../copyButton/index';
import Icon from '../icon';
import SyntaxHighlighter from '../syntaxHiglighter';
import Launch from '../../assets/actions/launch.svg';
import theme from '../../theme';

// eslint-disable-next-line import/no-unused-modules, no-unused-vars
function dispatchCode({ code, n, minHeight, goto, placement, width, copyCode, launch, bgColor }) {
	// Opens the link
	const handleClick = () => {
		window.open(goto, '_blank');
	};

	return (
		// This Component uses Syntax Highlighter along with the Modal to view detailed content
		<Box
			sx={{
				display: 'flex',
				justifyContent: 'space-between',
				alignItems: 'center',
				bgcolor: bgColor || theme.palette.background.paper,
				borderRadius: '8px',
				p: '10px 10px 10px 5px',
				minHeight: minHeight || '68px',
				width: width || '24.5rem'
			}}
		>
			<SyntaxHighlighter src={code?.slice(0, n)} />
			<Box sx={{ display: 'flex', alignSelf: 'baseline' }}>
				{!launch && (
					<Icon
						src={Launch}
						alt="controlPane"
						padding="4.3px"
						title="View Full Code"
						clickHandler={handleClick}
						bgColor={theme.palette.background.blue14}
						placement={placement}
					/>
				)}
				<CopyButton
					content={copyCode || code}
					borderEnable={false}
					placement="top"
					bgColor={theme.palette.background.blue14}
					padding="4px"
				/>
			</Box>
		</Box>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default dispatchCode;
