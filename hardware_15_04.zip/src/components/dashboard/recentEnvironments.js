/* eslint-disable quotes */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useEffect } from 'react';

import { Box, Typography, Grid, useMediaQuery } from '@mui/material';
import { RecentEnvironmentCard, SeeAll } from '../card/dashboard/revampedcards';
import { getBatchEnvironments } from '../../api/environments/environmentsApi';
import { formatDate } from '../../utils/utils';
import routes from '../../constants/routes.json';
import Loader from '../loader';

function RecentEnvironments() {
	const zeroToThirteenFifty = useMediaQuery('(max-width:1350px)', { noSsr: true });
	const [recentEnvironments, setRecentEnvironments] = useState([]);
	const recordCount = 2;
	const searchValue = '';
	const sort = 'build_completed_at';
	const sortDirection = 'desc';
	const [openLoader, setOpenLoader] = useState(true);
	const [isNavigationDisabled, setIsNavigationDisabled] = useState(false);
	const [pagination, setPagination] = useState({
		disableLeft: true,
		disableRight: false,
		currentPage: 0,
		totalCount: 0
	});

	useEffect(() => {}, [isNavigationDisabled]);
	useEffect(() => {
		getBatchEnvironments(recordCount, pagination?.currentPage, searchValue, sort, sortDirection)
			.then(response => {
				if (response) {
					setRecentEnvironments(response?.records);
					setPagination(prevState => ({
						...prevState,
						totalCount: response?.metadata?.total_count
					}));
					const totalRecords = response?.metadata?.total_count;
					const lastPage = Math.ceil(totalRecords / recordCount);
					if (Math.ceil(totalRecords / recordCount) === 1) {
						setPagination(prevState => ({
							...prevState,
							disableRight: true
						}));
					}
					if (pagination?.currentPage > 0) {
						setPagination(prevState => ({
							...prevState,
							disableLeft: false
						}));
					} else {
						setPagination(prevState => ({
							...prevState,
							disableLeft: true
						}));
					}
					if (pagination?.currentPage === lastPage - 1) {
						setPagination(prevState => ({
							...prevState,
							disableRight: true
						}));
					}
				}
			})
			.catch(() => {
				setOpenLoader(false);
				setIsNavigationDisabled(false);
				setPagination(prevState => ({
					...prevState,
					disableRight: true,
					disableLeft: true
				}));
			})
			.finally(() => {
				setOpenLoader(false);
				setIsNavigationDisabled(false);
			});
	}, [pagination?.currentPage]);

	const leftClick = () => {
		setIsNavigationDisabled(true);
		setOpenLoader(true);
		setPagination(prevState => ({
			...prevState,
			disableRight: false,
			currentPage: prevState.currentPage - 1
		}));
	};

	const rightClick = () => {
		setIsNavigationDisabled(true);
		setOpenLoader(true);
		setPagination(prevState => ({
			...prevState,
			disableLeft: false,
			currentPage: prevState.currentPage + 1
		}));
	};

	return (
		<Box
			sx={{
				border: theme => `1px solid ${theme.palette.background.blue03}`,
				width: '100%',
				height: '141px',
				padding: zeroToThirteenFifty ? '20px 12px' : '20px',
				borderRadius: '8px'
			}}
		>
			<Box sx={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
				<Typography variant="graphNodeDrawer">Recent Environments</Typography>
				<SeeAll
					goto={routes?.ENVIRONMENTS}
					leftClick={leftClick}
					rightClick={rightClick}
					leftClickDisable={pagination?.disableLeft}
					rightClickDisable={pagination?.disableRight}
					havePagination
					isContentDisabled={isNavigationDisabled}
				/>
			</Box>
			<Grid container>
				{openLoader && (
					<Loader isFetching={openLoader} position="relative" width="100%" height="100%" />
				)}
				{!openLoader &&
					recentEnvironments.length !== 0 &&
					recentEnvironments?.map(dispatch => (
						<Grid item xs={12} sx={{ padding: '5px 0px' }} key={dispatch.id}>
							<RecentEnvironmentCard
								date={formatDate(dispatch?.build_started_at)}
								name={dispatch?.name}
								environmentid={dispatch?.id}
							/>
						</Grid>
					))}
				{!openLoader && recentEnvironments?.length === 0 ? (
					<Grid container mt={2} direction="row" justifyContent="center" alignItems="center">
						<Typography>No Records Found</Typography>
					</Grid>
				) : null}
			</Grid>
			{/* <SharedDispatchCard name="Dispatch name" status="COMPLETED" /> */}
		</Box>
	);
}

export default RecentEnvironments;
