/* eslint-disable no-unused-vars */
/* eslint-disable quotes */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useEffect, useState, useContext } from 'react';

import { Box, Typography, Grid } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import useDidMountEffect from '../../utils/useDidMountEffect';
import { highlightedDispatchesList } from '../../api/experiments/dispatchApi';
import { setDispatchID, setIsRecent } from '../../redux/tourSlice';
import { RecentDispatchCard , SeeAll } from '../card/dashboard/revampedcards';
import { getUniqueAttributeValues } from '../../utils/utils';
import Loader from '../loader';
import Icon from '../icon';
import { DashboardContext } from '../../containers/dashboard/contexts/DashboardContext';
import routes from '../../constants/routes.json';

function RecentDispatches() {
	const [recentDispatches, setRecentDispatches] = useState([]);
	const [fetchRecents, setFetchRecents] = useState(false);
	const [openLoader, setOpenLoader] = useState(true);
	const [statuses, setStatuses] = useState([]);
	const dispatchAction = useDispatch();
	// Live refresh
	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);
	const { dashboardLatticeCount, getDispatchesData, dispatchesData } = useContext(DashboardContext);

	useEffect(() => {
		getDispatchesData(dashboardLatticeCount);
	}, [dashboardLatticeCount]);

	useEffect(() => {
		setStatuses(getUniqueAttributeValues(dispatchesData?.records));
	}, [dispatchesData]);

	useEffect(() => {
		setOpenLoader(true);
		highlightedDispatchesList(5, 'ALL')
			.then(res => {
				setRecentDispatches(res);
				dispatchAction(setDispatchID({ dispatchID: res.length > 0 ? res[0].id : null }));
				dispatchAction(setIsRecent({ isRecent: true }));
			})
			.catch(error => {
				console.error(error);
				dispatchAction(setIsRecent({ isRecent: true }));
			})
			.finally(() => {
				setOpenLoader(false);
			});
	}, [fetchRecents]);

	useDidMountEffect(() => {
		highlightedDispatchesList(5, 'ALL')
			.then(res => {
				setRecentDispatches(res);
			})
			.catch(error => {
				console.error(error);
			});
	}, [liveRefresh]);

	const singleStatus = (img, dispatchStatus, count) => {
		return (
			<Box>
				<Box sx={{ display: 'flex' }}>
					<Icon src={img} width="10px" height="10px" />
					<Typography
						sx={{
							color: theme => theme.palette.text.primary,
							fontSize: '10px',
							marginLeft: '4px',
							display: 'grid',
							placeItems: 'center'
						}}
					>
						{dispatchStatus}
					</Typography>
				</Box>
				<Typography
					sx={{ color: theme => theme.palette.text.primary, fontSize: '10px', pl: '3px' }}
				>
					{count}
				</Typography>
			</Box>
		);
	};

	return (
		<Box
			sx={{
				border: theme => `1px solid ${theme.palette.background.blue03}`,
				borderRadius: '8px',
				padding: '22px',
				height: '467px',
				width: '100%',
				background: theme => theme.palette.background.dashboardCard,
				display: 'flex',
				justifyContent: 'flex-start',
				flexDirection: 'column'
			}}
		>
			<Box sx={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
				<Typography sx={{ color: theme => theme.palette.text.secondary, fontSize: '16px' }}>
					Recent Dispatches
				</Typography>
				<SeeAll goto={routes?.DISPATCHES} haveSeeall />
			</Box>
			<Grid container sx={{ margin: '14px 0 14px 0' }}>
				{statuses?.map(item => {
					return (
						<Grid item xs={3} key={item.img}>
							{singleStatus(item?.img, item?.status, item?.count)}
						</Grid>
					);
				})}
			</Grid>
			{openLoader && (
				<Loader
					isFetching={openLoader}
					position="relative"
					width="100%"
					height="calc(100% - 80px)"
				/>
			)}
			{!openLoader &&
				(recentDispatches.length !== 0 ? (
					recentDispatches?.map(item => {
						return (
							<RecentDispatchCard
								key={item?.id}
								name={item?.title}
								status={item?.status}
								time={{ startTime: item?.startTime, endTime: item?.endTime }}
								dispatchid={item?.id}
							/>
						);
					})
				) : (
					<Box
						sx={{ display: 'flex', justifyContent: 'center', height: '100%', alignItems: 'center' }}
					>
						No records found
					</Box>
				))}
		</Box>
	);
}

export default RecentDispatches;
