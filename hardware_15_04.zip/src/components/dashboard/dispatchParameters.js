import * as React from 'react';
import { Grid, Box, Typography, Input } from '@mui/material';

// eslint-disable-next-line import/no-unused-modules, no-unused-vars
function dispatchParameters({
	name,
	description,
	textFieldValue,
	handleTextFieldChange,
	notEditable
}) {
	return (
		// This Component is used to take the inputs from the UI for the Sample Dispatch
		<Grid container>
			<Grid>
				<Box display="flex">
					<Typography
						fontSize="12px"
						color={theme => theme.palette.text.gray04}
						marginRight="10px"
						fontFamily="DM Mono"
					>
						{name}
					</Typography>
					<Input
						value={textFieldValue}
						disableUnderline
						onChange={handleTextFieldChange}
						sx={{
							bgcolor: theme => theme.palette.background.paper,
							border: '1px solid #303067',
							borderRadius: '8px',
							color: theme => theme.palette.text.gray03,
							fontSize: '14px',
							paddingLeft: '12px !important',
							paddingRight: '12px !important',
							textAlign: 'center',
							height: '20%',
							width: '25%',
							pointerEvents: notEditable && 'none'
						}}
					/>
				</Box>
				<Typography fontSize="12px" color={theme => theme.palette.text.gray03}>
					{description}
				</Typography>
			</Grid>
		</Grid>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default dispatchParameters;
