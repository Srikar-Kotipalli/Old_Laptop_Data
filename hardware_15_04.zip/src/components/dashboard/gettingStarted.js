/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useRef } from 'react';
import { Box, Typography } from '@mui/material';
import { SeeAll, GettingStartedCard } from '../card/dashboard/revampedcards';
import DisabledRightIcon from '../../assets/disabledRight.svg';

function GettingStarted() {
	const gettingStarted = [
		{
			img: DisabledRightIcon,
			heading: 'Getting Started',
			goTo: process.env.REACT_APP_GETTING_STARTED_GETTING_STARTED
		},
		{
			img: DisabledRightIcon,
			heading: 'Tutorials',
			goTo: process.env.REACT_APP_GETTING_STARTED_TUTORIALS
		},
		{
			img: DisabledRightIcon,
			heading: 'How-to\'s',
			goTo: process.env.REACT_APP_GETTING_STARTED_HOW_TOS
		},
		{
			img: DisabledRightIcon,
			heading: 'Covalent Blog',
			goTo: process.env.REACT_APP_GETTING_STARTED_COVALENT_BLOG
		},
		{
			img: DisabledRightIcon,
			heading: 'API Reference',
			goTo: process.env.REACT_APP_GETTING_STARTED_API_REFERENCE
		},
		{
			img: DisabledRightIcon,
			heading: 'Documentation',
			goTo: process.env.REACT_APP_GETTING_STARTED_DOCUMENTATION
		}
	];
	const ref = useRef(null);
	const handleRightClick = () => {
		ref.current.scrollLeft += 60;
	};

	const handleLeftClick = () => {
		ref.current.scrollLeft += -60;
	};
	return (
		<Box
			sx={{
				border: theme => `1px solid ${theme.palette.background.covalentPurple}`,
				borderRadius: '8px',
				padding: '22px',
				height: '141px',
				width: '100%',
				background: theme => theme.palette.background.dashboardCard,
				cursor: 'pointer'
			}}
		>
			<div style={{ display: 'flex', justifyContent: 'space-between', margin: '0 0 27px 0' }}>
				<Typography
					sx={{ color: theme => theme.palette.text.secondary, fontSize: '16px', fontWeight: '400' }}
				>
					Getting Started
				</Typography>
				<SeeAll
					havePagination
					rightClick={handleRightClick}
					leftClick={handleLeftClick}
					haveSeeall={false}
				/>
			</div>
			<Box
				ref={ref}
				sx={{
					whiteSpace: 'nowrap',
					overflowX: 'auto',
					paddingBottom: '12px',
					scrollBehavior: 'smooth'
				}}
			>
				{gettingStarted?.map(item => {
					return (
						<GettingStartedCard
							img={item?.img}
							heading={item?.heading}
							goTo={item?.goTo}
							key={item?.heading}
						/>
					);
				})}
			</Box>
		</Box>
	);
}

export default GettingStarted;
