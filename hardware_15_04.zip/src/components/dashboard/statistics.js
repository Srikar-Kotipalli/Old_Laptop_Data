/* eslint-disable quotes */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to AgnostiUser has no billing accountq at: [support@agnostiq.com].
 */

import React, { useEffect, useState } from 'react';
import Chart from 'react-apexcharts';
import { Box, Grid, Typography, Select, MenuItem, SvgIcon } from '@mui/material';
// import { BarChart } from '@mui/x-charts/BarChart';
// import CostImage from '../../assets/cost.svg';
import { Auth } from 'aws-amplify';
import Icon from '../icon';
import { getDispatchesCharges } from '../../api/dashboard/dashboardApi';
import GraphTab from '../tab/graph';
import {
	startAndEndDate,
	formattedDate,
	replaceMissingDates,
	getFormattedDate,
	groupInputArray,
	changeDateFormat,
	getDate
} from '../../utils/utils';

import RevampedActivityList from './revampedActivityList';
import useUpdateEffect from '../../utils/useUpdateEffect';
import Loader from '../loader';
import GraphIcon from '../../assets/dashboard/graphIcon.svg';

function CustomIcon(props) {
	return (
		// eslint-disable-next-line react/jsx-props-no-spreading
		<SvgIcon {...props} style={{ transform: 'translateY(20%)' }}>
			<svg width="16" height="16" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path
					d="M8 10.9998L3 5.9998L3.7 5.2998L8 9.59981L12.3 5.2998L13 5.9998L8 10.9998Z"
					fill="#CBCBD7"
				/>
			</svg>
		</SvgIcon>
	);
}

// function DonutChart() {
// 	const donutInputData = {
// 		data: [44, 55, 41, 17],
// 		labels: ['CPU', 'GPU1', 'GPU2', 'GPU3']
// 	};
// 	const donutData = {
// 		options: {
// 			series: donutInputData.data,
// 			background: {
// 				enabled: true,
// 				foreColor: 'red'
// 			},
// 			stroke: { colors: ['transparent'] },
// 			labels: donutInputData.labels,
// 			colors: ['#5552FF', '#303067', '#BB5DA2', '#55A2C2'],
// 			chart: {
// 				type: 'donut'
// 			},
// 			plotOptions: {
// 				pie: {
// 					// customScale: 0.4,
// 					// size: 20,
// 					donut: {
// 						size: '70%'
// 					}getDate
// 				}
// 			},
// 			dataLabels: {
// 				enabled: false
// 			}
// 			// responsive: [
// 			// 	{
// 			// 		breakpoint: 480,
// 			// 		options: {
// 			// 			chart: {
// 			// 				width: 200
// 			// 			},
// 			// 			legend: {
// 			// 				position: 'center'
// 			// 			}
// 			// 		}getDate
// 			// 	}
// 			// ]
// 		}
// 	};
// 	return (
// 		<Chart
// 			options={donutData.options}
// 			series={donutData.options.series}
// 			height={150}
// 			type="donut"
// 		/>
// 	);
// }

// const tempData = {
// 	allTimeMonth: {
// 		min: 0,
// 		max: 1500,
// 		divisions: 5,
// 		axis: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July'],
// 		data: [512, 912, 671, 1344, 1000, 1182, 1217]
// 		// data: costs
// 	}
// };

function DispatchChart({ UsageChartData }) {
	const chartData = {
		series: [
			{
				data: UsageChartData?.data
			}
		],
		options: {
			chart: {
				type: 'area',
				toolbar: {
					show: false
				}
			},
			grid: {
				show: false
			},
			legend: {
				show: false
			},
			dataLabels: {
				enabled: false
			},
			stroke: {
				curve: 'smooth'
			},
			markers: {
				size: 0,
				strokeWidth: 0,
				strokeOpacity: 0,
				strokeDashArray: 0,
				fillOpacity: 0,
				radius: 0,
				offsetX: 0,
				offsetY: 0,
				hover: {
					size: undefined,
					sizeOffset: 0
				}
			},
			yaxis: [
				{
					title: {
						text: UsageChartData?.parameters?.yAxisTitle,
						style: {
							color: 'white'
						}
					},
					tickAmount: UsageChartData?.parameters?.xAxisParams?.tickAmount,
					min: UsageChartData?.parameters?.xAxisParams?.min,
					max: UsageChartData?.parameters?.xAxisParams?.max,
					axisTicks: {
						show: true
					},
					axisBorder: {
						show: true
					},
					crosshairs: {
						show: true
					},
					labels: {
						style: {
							colors: ['white']
						}
					}
				}
			],
			// xaxis: {
			// 	title: {
			// 		text: 'Time',
			// 		style: {
			// 			color: 'white'
			// 		}
			// 	},
			// 	axisTicks: {
			// 		show: false
			// 	},
			// 	crosshairs: {
			// 		show: false
			// 	},
			// 	axisBorder: {
			// 		show: false
			// 	},
			// 	labels: {
			// 		show: false
			// 	},
			// 	tooltip: {
			// 		enabled: false
			// 	},
			// 	// type: 'datetime',
			// 	categories: UsageChartData.categories
			// },
			xaxis: {
				title: {
					text: UsageChartData?.parameters?.xAxisTitle,
					style: {
						color: 'white'
					}
				},
				axisTicks: {
					show: false
				},
				crosshairs: {
					show: false
				},
				axisBorder: {
					show: false
				},
				labels: {
					show: true, // Set this to true to display X-axis labels
					style: {
						colors: ['white']
					}
				},
				tooltip: {
					enabled: false
				},
				// type: 'datetime',
				categories: UsageChartData?.categories
			},
			// grid: {
			// 	borderColor: '#303067'
			// },
			tooltip: {
				custom({ series, seriesIndex, dataPointIndex }) {
					return `${series[seriesIndex][dataPointIndex]}`;
				}
			}
		}
	};
	console.log('data',chartData?.series);
	return <Chart options={chartData?.options} series={chartData?.series} height={220} />;
}

// eslint-disable-next-line no-unused-vars
function CostChart() {
	// const chartData = {
	// 	series: [
	// 		{
	// 			name: 'Net Profit',
	// 			data: [100, 55, 57, 56, 61, 58, 63, 60, 66]
	// 		},
	// 		{
	// 			name: 'Revenue',
	// 			data: [76, 85, 101, 98, 87, 105, 91, 114, 94]
	// 		},
	// 		{
	// 			name: 'Free Cash Flow',
	// 			data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
	// 		}
	// 	],
	// 	options: {
	// 		chart: {
	// 			type: 'bar',
	// 			height: 220
	// 		},
	// 		plotOptions: {
	// 			bar: {
	// 				horizontal: false,
	// 				columnWidth: '55%',
	// 				endingShape: 'rounded'
	// 			}
	// 		},
	// 		dataLabels: {
	// 			enabled: false
	// 		},
	// 		stroke: {
	// 			show: true,
	// 			width: 2,
	// 			colors: ['transparent']
	// 		},
	// 		xaxis: {
	// 			categories: ['Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct']
	// 		},
	// 		yaxis: {
	// 			title: {
	// 				text: '$ (thousands)'
	// 			}
	// 		},
	// 		fill: {
	// 			opacity: 0
	// 		}
	// 	}

	// 	// tooltip: {
	// 	// 	y: {
	// 	// 		formatter: function (val) {
	// 	// 			return '$ ' + val + ' thousands';
	// 	// 		}
	// 	// 	}
	// 	// }
	// };
	const chartData = {
		options: {
			chart: {
				id: 'basic-bar'
			},
			xaxis: {
				categories: ['Category 1', 'Category 2', 'Category 3', 'Category 4', 'Category 5']
			},
			grid: {
				show: false
			}
		},
		series: [
			{
				name: 'Series 1',
				data: [30, 40, 45, 50, 49]
			},
			{
				name: 'Series 2',
				data: [20, 35, 30, 40, 60]
			},
			{
				name: 'Series 3',
				data: [45, 25, 50, 20, 30]
			}
		]
	};
	return <Chart options={chartData?.options} series={chartData?.series} type="bar" height={220} />;
}

function Statistics({ MenuItemArray = [], fromHardware = false }) {
	const [selected, setSelected] = useState(fromHardware ? 'All Time' : 'This week');
	const [dates, setDates] = useState({ startDate: '', endDate: '' });
	const [tabValue, setTabValue] = useState(fromHardware ? 'Cost over time' : 'Cost');
	const [hasBillingAccount, setHasBillingAccount] = useState(true);
	const [graphLoader, setGraphLoader] = useState(true);
	const [costs, setCosts] = useState([0]);
	const [xAxis, setXAxis] = useState([0]);
	const [maxDispatchYAxis, setMaxDispatchYAxis] = useState([0]);
	const [dispatchCount, setDispatchCount] = useState([0]);
	const [maxYAxis, setMaxYAxis] = useState(0);

	const [totalRecords, setTotalRecords] = useState(0);

	const selectionChangeHandler = event => {
		setSelected(event?.target?.value);
		startAndEndDate(event?.target?.value, setDates, dates);
	};

	// sets the costs and dates for cost graph
	const costArray = (array, select) => {
		const groupedArray = groupInputArray(array);
		let costValues = [];
		let dispatchCountValues = [];

		const today = new Date();

		const week = [];
		const month = [];
		const last3Months = [];

		if (select === 'This week') {
			costValues = [0, 0, 0, 0, 0, 0, 0, 0];
			dispatchCountValues = [0, 0, 0, 0, 0, 0, 0, 0];
			const xAxisDates = [
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 7)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 6)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 5)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 4)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 3)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 2)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 1)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today?.getDate()))
			];

			// getting only the dates from each object
			const onlyDates = groupedArray?.map(obj => obj.date);

			const transformedDates = xAxisDates?.map(e => {
				return new Date(e)?.toDateString();
			});

			// adding the dates which has cost to the xAxis array which are not present
			for (let i = 0; i < onlyDates?.length; i++) {
				if (!transformedDates?.includes(new Date(onlyDates[i])?.toDateString())) {
					week.push(onlyDates[i]);
				}
			}

			week?.push(...xAxisDates);
			week?.sort((a, b) => new Date(a) - new Date(b)); // sort the array in asc order
			setXAxis(week?.map(formattedDate));

			// sets the cost array which is used in the graph
			for (let i = 0; i < week.length; i++) {
				if (
					groupedArray.some(
						obj => new Date(obj?.date)?.toDateString() === new Date(week[i])?.toDateString()
					)
				) {
					const index = groupedArray.findIndex(
						obj => new Date(obj?.date)?.toDateString() === new Date(week[i])?.toDateString()
					);
					costValues[i] = groupedArray[index].cost / 1000000;
					dispatchCountValues[i] = groupedArray[index]?.count;
				} else {
					costValues[i] = 0;
					dispatchCountValues[i] = 0;
				}
			}
		}
		if (select === 'This month') {
			costValues = [0, 0, 0, 0, 0];
			dispatchCountValues = [0, 0, 0, 0, 0];
			const xMonth = [
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 28)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 21)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 14)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 7)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today?.getDate()))
			];
			const xAxisDates = [];

			for (let i = 28; i >= 0; i--) {
				xAxisDates?.push(
					changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - i))
				);
			}

			const onlyDates = groupedArray?.map(obj => obj.date);

			const transformedDates = xAxisDates?.map(e => {
				return new Date(e)?.toDateString();
			});

			for (let i = 0; i < onlyDates?.length; i++) {
				if (!transformedDates.includes(new Date(onlyDates[i])?.toDateString())) {
					month?.push(onlyDates[i]);
				}
			}

			month?.push(...xAxisDates);
			month?.sort((a, b) => new Date(a) - new Date(b));
			setXAxis(month?.map(getFormattedDate));

			for (let i = 0; i < month?.length; i++) {
				if (
					groupedArray?.some(
						obj => new Date(obj.date).toDateString() === new Date(month[i]).toDateString()
					)
				) {
					const index = groupedArray?.findIndex(
						obj => new Date(obj.date).toDateString() === new Date(month[i]).toDateString()
					);
					costValues[i] = groupedArray[index].cost / 1000000;
					dispatchCountValues[i] = groupedArray[index]?.count;
				} else {
					costValues[i] = 0;
					dispatchCountValues[i] = 0;
				}
			}
			setXAxis(replaceMissingDates(xAxisDates, xMonth)?.map(formattedDate));
		}
		if (select === 'Last 3 months' || select === 'All Time') {
			costValues = [0, 0, 0, 0, 0, 0, 0];
			dispatchCountValues = [0, 0, 0, 0, 0, 0, 0];
			const xLast3months = [
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 90)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 75)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 60)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 45)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 30)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 15)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today?.getDate()))
			];
			const xAxisDates = [];

			for (let i = 90; i >= 0; i--) {
				xAxisDates.push(
					changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - i))
				);
			}

			const onlyDates = groupedArray?.map(obj => obj.date);

			const transformedDates = xAxisDates?.map(e => {
				return new Date(e)?.toDateString();
			});

			for (let i = 0; i < onlyDates?.length; i++) {
				if (!transformedDates?.includes(new Date(onlyDates[i])?.toDateString())) {
					last3Months?.push(onlyDates[i]);
				}
			}

			last3Months?.push(...xAxisDates);
			last3Months?.sort((a, b) => new Date(a) - new Date(b));
			setXAxis(last3Months?.map(getFormattedDate));

			for (let i = 0; i < last3Months.length; i++) {
				if (
					groupedArray?.some(
						obj => new Date(obj?.date)?.toDateString() === new Date(last3Months[i])?.toDateString()
					)
				) {
					const index = groupedArray?.findIndex(
						obj => new Date(obj?.date)?.toDateString() === new Date(last3Months[i])?.toDateString()
					);
					costValues[i] = groupedArray[index].cost / 1000000;
					dispatchCountValues[i] = groupedArray[index].count;
				} else {
					costValues[i] = 0;
					dispatchCountValues[i] = 0;
				}
			}
			setXAxis(replaceMissingDates(xAxisDates, xLast3months)?.map(formattedDate));
		}
		return { cost: costValues, dispatch: dispatchCountValues };
	};

	// returns the date 'days' days previous to todays date in yyyy-mm-dd format
	const beforeDate = days => {
		const today = new Date();

		const nDaysAgo = new Date(today);
		nDaysAgo?.setDate(nDaysAgo.getDate() - days);

		const year = nDaysAgo?.getFullYear();
		const month = nDaysAgo.getMonth() + 1;
		const day = nDaysAgo?.getDate();

		return `${year}-${month}-${day}`;
	};

	// returns the date 'n' months previous to todays date in yyyy-mm-dd format
	const prevMonths = n => {
		const today = new Date();

		const nMonthsAgo = new Date(today?.getFullYear(), today.getMonth() - n, today?.getDate());

		const year = nMonthsAgo?.getFullYear();
		const month = nMonthsAgo.getMonth() + 1;
		const day = nMonthsAgo?.getDate();

		return `${year}-${month}-${day}`;
	};

	const [fromDate, setFromDate] = useState(beforeDate(7));

	const onTabChange = (_e, val) => {
		setTabValue(val);
	};

	useEffect(() => {
		setGraphLoader(true);
		Auth.currentAuthenticatedUser()
			.then(user => {
				const res = user?.attributes;
				const userID = res && res['custom:userID'];
				getDispatchesCharges(userID, fromDate, getDate(), 0)
					.then(payload => {
						if (payload) {
							setTotalRecords(payload.metadata.total_count);
						}
						setGraphLoader(false);
					})
					.catch(() => {
						setHasBillingAccount(false);
						setGraphLoader(false);
					});
			})
			.catch(() => {
				setHasBillingAccount(false);
				setGraphLoader(false);
			});
	}, [fromDate]);

	useUpdateEffect(() => {
		Auth.currentAuthenticatedUser()
			.then(user => {
				const res = user?.attributes;
				const userID = res && res['custom:userID'];
				getDispatchesCharges(userID, fromDate, getDate(), totalRecords)
					.then(payload => {
						if (payload) {
							setCosts(costArray(payload?.records, selected).cost);
							setMaxYAxis(1.2 * Math.max(...costArray(payload.records, selected).cost));
							setMaxDispatchYAxis(
								Math.ceil(1.1 * Math.max(...costArray(payload.records, selected).dispatch))
							);
							setDispatchCount(costArray(payload?.records, selected).dispatch);
						}
					})
					.catch(() => {
						setHasBillingAccount(false);
					});
			})
			.catch(() => {
				setHasBillingAccount(false);
			});
	}, [totalRecords, fromDate]);

	useEffect(() => {
		if (selected === 'This week') {
			setFromDate(beforeDate(7));
		}
		if (selected === 'This month') {
			setFromDate(prevMonths(1));
		}

		if (selected === ('Last 3 months' || 'All Time')) {
			setFromDate(prevMonths(3));
		}
	}, [selected]);

	const costGraphData = {
		allTimeMonth: {
			min: 0,
			max: maxYAxis,
			divisions: 5,
			axis: xAxis,
			data: costs
		}
	};

	const hardwareGraphData = {
		allTimeMonth: {
			min: 0,
			max: maxYAxis,
			divisions: 5,
			axis: xAxis,
			data: costs
		}
	};

	const dispatchGraphData = {
		allTimeMonth: {
			min: 0,
			max: maxDispatchYAxis,
			divisions: 5,
			axis: xAxis,
			data: dispatchCount
		}
	};
	return (
		<Box
			sx={{
				border: theme => `1px solid ${theme.palette.background.blue03}`,
				borderRadius: '8px',
				height: '317px',
				padding: '20px',
				display: 'flex',
				background: theme => theme.palette.background.covalentSidebar
			}}
		>
			<Grid container>
				<Grid item xs={fromHardware ? 12 : 8}>
					<Box sx={{ display: 'flex', width: '90%', justifyContent: 'space-between' }}>
						<GraphTab
							value={tabValue}
							onChange={!fromHardware && onTabChange}
							firstValue={fromHardware ? 'Cost over time' : 'Cost'}
							secondValue={!fromHardware && 'Dispatch'}
							headingFontSize="16px"
						/>
						<Box sx={{ display: 'flex', alignItems: 'center' }}>
							<Select
								IconComponent={CustomIcon}
								value={selected}
								onChange={selectionChangeHandler}
								variant="outlined"
								size="small"
								className="shownBtn"
								sx={{
									background: theme => theme.palette.background.paper,
									borderRadius: '200px',
									padding: '0 0 0 14px',
									width: '150px',
									height: '30px',
									color: 'white',
									fontSize: '14px',
									'.MuiOutlinedInput-notchedOutline': {
										borderColor: theme => theme.palette.background.blue05
									},
									'&.Mui-focused .MuiOutlinedInput-notchedOutline': {
										borderColor: theme => theme.palette.background.blue05
									},
									'&:hover .MuiOutlinedInput-notchedOutline': {
										borderColor: theme => theme.palette.background.blue05
									},
									'&:hover': {
										background: theme => theme.palette.background.covalentPurple
									},
									'.MuiSvgIcon-root ': {
										fill: 'transparent !important'
									}
								}}
							>
								{
									MenuItemArray?.map(menuItem => (
										<MenuItem value={menuItem} sx={{ fontSize: '14px' }}>
											{menuItem}
										</MenuItem>
									))
								}
								{/* <MenuItem value='This week' sx={{ fontSize: '14px' }}>
									This week
								</MenuItem>
								<MenuItem value='This month' sx={{ fontSize: '14px' }}>
									This month
								</MenuItem>
								<MenuItem value='Last 3 months' sx={{ fontSize: '14px' }}>
									Last 3 months
								</MenuItem> */}
							</Select>
						</Box>
					</Box>

					{tabValue === 'Cost' && (
						<Box sx={{ width: '90%', height: 'calc(100% - 38px)' }}>
							{hasBillingAccount ? (
								graphLoader ? (
									<Loader isFetching={graphLoader} position="relative" width="100%" height="100%" />
								) : (
									<DispatchChart
										UsageChartData={{
											data: costGraphData?.allTimeMonth?.data,
											categories: costGraphData?.allTimeMonth?.axis,
											parameters: {
												xAxisTitle: 'Time',
												yAxisTitle: 'Cost ($)',
												xAxisParams: {
													tickAmount: costGraphData?.allTimeMonth?.divisions,
													min: costGraphData?.allTimeMonth?.min,
													max: costGraphData?.allTimeMonth?.max
												}
											},
											isHardware: true
										}}
									/>
								)
							) : (
								<Box
									sx={{
										width: '100%',
										height: '100%',
										display: 'flex',
										alignItems: 'center',
										justifyContent: 'center'
									}}
								>
									<Box sx={{ display: 'grid', placeItems: 'center' }}>
										<Icon src={GraphIcon} style={{ rotate: '-90deg' }} />
										<Typography>Breakdown will be shown once costs are incurred</Typography>
									</Box>
								</Box>
							)}
						</Box>
					)}
					{tabValue === 'Cost over time' && (
						<Box sx={{ width: '90%', height: 'calc(100% - 38px)' }}>
							{hasBillingAccount ? (
								graphLoader ? (
									<Loader isFetching={graphLoader} position="relative" width="100%" height="100%" />
								) : (
									<DispatchChart
										UsageChartData={{
											data: [1,3,0,5,4,3,4,5],
											categories: ['2024-01-23','2024-01-29','2024-02-01','2024-02-11','2024-02-14','2024-02-20','2024-02-15','2024-02-28'],
											parameters: {
												xAxisTitle: 'Time',
												yAxisTitle: 'Cost',
												xAxisParams: {
													tickAmount: costGraphData?.allTimeMonth?.divisions,
													min: 0,
													max: 10
												}
											},
											isHardware: true
										}}
									/>
								)
							) : (
								<Box
									sx={{
										width: '100%',
										height: '100%',
										display: 'flex',
										alignItems: 'center',
										justifyContent: 'center'
									}}
								>
									<Box sx={{ display: 'grid', placeItems: 'center' }}>
										<Icon src={GraphIcon} style={{ rotate: '-90deg' }} />
										<Typography>Breakdown will be shown once costs are incurred</Typography>
									</Box>
								</Box>
							)}
						</Box>
					)}
					{tabValue === 'Dispatch' && (
						<Box sx={{ width: '90%', height: 'calc(100% - 38px)' }}>
							{hasBillingAccount ? (
								graphLoader ? (
									<Loader isFetching={graphLoader} position="relative" width="100%" height="100%" />
								) : (
									// <BarChart
									// 	series={[{ data: dispatchCount }]}
									// 	height={220}
									// 	xAxis={[{ data: xAxis, scaleType: 'band', label: 'Time' }]}
									// 	yAxis={[
									// 		{
									// 			label: 'Dispatch'
									// 		}
									// 	]}
									// />
									<DispatchChart
										UsageChartData={{
											data: dispatchGraphData?.allTimeMonth?.data,
											categories: dispatchGraphData?.allTimeMonth?.axis,
											parameters: {
												xAxisTitle: 'Time',
												yAxisTitle: 'Dispatch',
												xAxisParams: {
													tickAmount: dispatchGraphData?.allTimeMonth?.divisions,
													min: dispatchGraphData?.allTimeMonth?.min,
													max: dispatchGraphData?.allTimeMonth?.max
												}
											}
										}}
									/>
								)
							) : (
								<Box
									sx={{
										width: '100%',
										height: '100%',
										display: 'grid',
										placeItems: 'center'
									}}
								>
									<Box sx={{ display: 'grid', placeItems: 'center' }}>
										<Icon src={GraphIcon} style={{ rotate: '-90deg' }} />
										<Typography>Breakdown will be shown once costs are incurred</Typography>
									</Box>
								</Box>
							)}
						</Box>
					)}
				</Grid>

				{
					!fromHardware && (
						<Grid item xs={4} sx={{ height: '100%' }}>
							{/* <Box
						sx={{
							border: theme => `1px solid ${theme.palette.background.blue03}`,
							background: theme => theme.palette.background.dashboardCard,
							borderRadius: '8px',
							boxShadow: '0px 4px 4px 0px rgba(0, 0, 0, 0.45)',
							padding: '20px'
						}}
					>
						<Box sx={{ display: 'flex', alignItems: 'center', marginBottom: '30px' }}>
							<Icon src={CostImage} />
							<Typography
								sx={{
									marginLeft: '5px',
									display: 'flex',
									alignItems: 'center',
									color: theme => theme.palette.text.blue01,
									fontWeight: '700',
									fontSize: '14px'
								}}
							>
								Hardware Breakdown
							</Typography>
						</Box>
						<DonutChart />
					</Box> */}
							<Box sx={{ height: '100%' }}>
								<Typography sx={{ mb: '5px' }}>Activity</Typography>
								<RevampedActivityList />
							</Box>
						</Grid>
					)}
			</Grid>
		</Box>
	);
}

export default Statistics;
