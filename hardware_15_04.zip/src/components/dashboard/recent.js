/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Grid, Typography } from '@mui/material';
import SimpleDashboardCard from '../card/dashboard/simplecard';
import {
	highlightedDispatchesList,
	pinDispatches,
	unPinDispatches
} from '../../api/experiments/dispatchApi';
import useDidMountEffect from '../../utils/useDidMountEffect';
import CustomisedSnackbar from '../snackbar/projects';
import Loader from '../loader';
import { setDispatchID, setIsRecent } from '../../redux/tourSlice';

function Recent() {
	const [recentDispatches, setRecentDispatches] = useState([]);
	const [fetchRecents, setFetchRecents] = useState(false);
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [openLoader, setOpenLoader] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState('');
	const [currentDispatchData, setCurrentDispatchData] = useState(null);
	const dispatchAction = useDispatch();
	// Live refresh
	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);

	const onPin = dispatch => {
		setOpenLoader(true);
		let pinAction = null;
		const params = {
			id: dispatch.id
		};

		setCurrentDispatchData({
			id: dispatch.id,
			isPinned: !dispatch.isPinned,
			name: dispatch.title
		});
		pinAction = !dispatch.isPinned ? pinDispatches : unPinDispatches;
		pinAction(params)
			.then(response => {
				setFetchRecents(prev => !prev);
				setSnackbarMessage(response);
				setOpenSnackbar(true);
			})
			.catch(() => {
				setOpenSnackbar(true);
				setSnackbarMessage('Something went wrong,please contact the administrator!');
			});
	};

	useEffect(() => {
		setOpenLoader(true);
		highlightedDispatchesList(6, 'ALL')
			.then(res => {
				setRecentDispatches(res);
				dispatchAction(setDispatchID({ dispatchID: res.length > 0 ? res[0].id : null }));
				dispatchAction(setIsRecent({ isRecent: true }));
			})
			.catch(error => {
				console.error(error);
				dispatchAction(setIsRecent({ isRecent: true }));
			})
			.finally(() => {
				setOpenLoader(false);
			});
	}, [fetchRecents]);

	useDidMountEffect(() => {
		highlightedDispatchesList(6, 'ALL')
			.then(res => {
				setRecentDispatches(res);
			})
			.catch(error => {
				console.error(error);
			});
	}, [liveRefresh]);

	return (
		<Grid>
			<CustomisedSnackbar
				action="pin"
				open={openSnackbar}
				multipleSelectedItems={[]}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
				onClick={() => onPin(currentDispatchData)}
			/>
			<Typography pt={3} sx={{ fontSize: '20px', color: theme => theme.palette.text.secondary }}>
				Recent
			</Typography>
			<Grid
				container
				pt={2}
				direction="row"
				rowGap={2}
				columnGap={{ xs: 1, sm: 2, md: 3, lg: 3, xl: 3.7, xxl: 4 }}
			>
				{openLoader && (
					<Loader isFetching={openLoader} position="relative" width="100%" height="8.42rem" />
				)}
				{!openLoader &&
					recentDispatches?.map((data, index) => {
						// eslint-disable-next-line react/no-array-index-key
						return <SimpleDashboardCard data={data} pin onPin={onPin} key={index} />;
					})}
				{recentDispatches.length === 0 && !openLoader ? (
					<Grid
						container
						mt={2}
						direction="row"
						justifyContent="center"
						alignItems="center"
						sx={{ height: '7.3rem' }}
					>
						<Typography>No dispatches found</Typography>
					</Grid>
				) : null}
			</Grid>
		</Grid>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default Recent;
