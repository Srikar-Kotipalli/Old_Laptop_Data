/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable react/no-array-index-key */
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Box, Grid, Typography, Tooltip, useMediaQuery, useTheme } from '@mui/material';
import { statusTitle } from '../../../utils/statusIcons';
import useLength from '../../../utils/useLength';
import OverlappingIcons from '../../icon/overlappingIcons';
import './style.css';
import { getTimeDifference, stringReducer } from '../../../utils/utils';
import Loader from '../../loader';
import OverflowTooltip from '../../tooltip/overflowTooltip';

function ActivityList({ items, height, count, openActivityLoader, isDashboard = false }) {
	const navigate = useNavigate();

	const theme = useTheme();
	const onlySmallScreen = useMediaQuery(theme.breakpoints.only('sm')); // 1000px-1420px
	const getClassName = length => {
		if (length === 1) {
			return 'single';
		}
		if (length === 2 && count === 2) {
			return 'double';
		}
		if (count > 2) {
			return 'many';
		}
		return 'empty';
	};
	const goTo = goto => {
		navigate(goto);
	};
	return (
		<Grid
			sx={{
				width: '100%',
				height,
				overflow: 'auto',
				scrollbarWidth: 'thin',
				scrollbarColor: '#1c1c46 #08081a',
				scrollBehavior: 'smooth'
			}}
			className={getClassName(items?.length)}
		>
			{openActivityLoader && (
				<Loader
					isFetching={openActivityLoader}
					width="100%"
					position="relative"
					height="90%"
					zIndex="700"
				/>
			)}
			{items?.length <= 0 && !openActivityLoader && (
				<Typography>Once you get setup your latest activity will show here</Typography>
			)}
			{items?.length > 0 &&
				!openActivityLoader &&
				items?.slice(0, 20).map((item, index) => {
					return (
						<Grid
							container
							direction="row"
							key={index}
							sx={{ display: 'flex', alignItems: 'center' }}
						>
							{isDashboard ? (
								<Grid
									container
									item
									direction="row"
									xs={12}
									alignItems="center"
									justifyContent="space-between"
									sx={{
										display: 'flex',
										height: '50px',
										borderBottom: '1px solid',
										borderColor: '#303067',
										'&:hover': {
											background: theme.palette.background.blue0380
										},
										cursor: 'pointer'
									}}
									onClick={() => goTo(`/graph/${item?.item_id}`)}
								>
									<Grid item sx={{ display: 'flex', alignItems: 'center' }} xs={10}>
										<OverlappingIcons
											type={item?.category.toUpperCase()}
											status={item?.sub_category}
										/>
										<Box
											sx={{
												display: 'flex',
												pl: '5px',
												width: '100%'
											}}
										>
											<Typography variant="h2">
												<Box sx={{ display: 'flex' }}>
													<OverflowTooltip
														title={`${item?.category} ${item?.title} `}
														length={useLength({ xs: 3, s: 4, m: 7, l: 10, xl: 14 })}
														fontSize="14px"
														color={theme?.palette?.text?.secondary}
													/>
												</Box>
											</Typography>
											<Box sx={{ display: 'flex' }}>
												<Typography variant="h2" pl={0.3}>
													{item.sub_category === 'FAILED' ||
													item.sub_category === 'COMPLETED' ||
													item.sub_category === 'NEW_OBJECT'
														? 'has'
														: 'is'}
												</Typography>

												{statusTitle(item?.sub_category, item?.sub_category.toLowerCase(), 0.4)}
											</Box>
										</Box>
									</Grid>

									<Grid
										item
										sx={{ display: 'flex', alignItems: 'center', color: theme.palette.text.gray03 }}
										xs={2}
									>
										<Typography
											fontSize="25px"
											sx={{
												position: 'relative',
												top: '1px'
											}}
										>
											{' \u00b7 '}
										</Typography>
										&nbsp;
										<Grid style={{ color: theme.palette.text.gray03, fontSize: '14px' }}>
											{getTimeDifference(item?.created_at)}
										</Grid>
									</Grid>
								</Grid>
							) : (
								<Grid
									container
									item
									direction="row"
									xs={12}
									alignItems="center"
									justifyContent="space-between"
									sx={{
										display: 'flex',
										height: '50px',
										borderBottom: '1px solid',
										borderColor: '#303067'
									}}
								>
									<Grid item sx={{ display: 'flex', alignItems: 'center' }} xs={10}>
										<OverlappingIcons
											type={item?.category.toUpperCase()}
											status={item?.sub_category}
										/>
										<Link
											style={{ color: '#CBCBD7', textDecoration: 'none' }}
											to={`/graph/${item?.item_id}`}
											state={{}}
										>
											<Tooltip title={item.title}>
												<Typography variant="h2" pl={0.7}>
													{onlySmallScreen
														? stringReducer(`${item.category} ${item.title}`, 8)
														: stringReducer(`${item.category} ${item.title}`)}
												</Typography>
											</Tooltip>
										</Link>
										<Typography variant="h2" pl={0.3}>
											{item.sub_category === 'FAILED' ||
											item.sub_category === 'COMPLETED' ||
											item.sub_category === 'NEW_OBJECT'
												? 'has'
												: 'is'}
										</Typography>

										{statusTitle(item?.sub_category, item?.sub_category.toLowerCase(), 0.4)}
									</Grid>

									<Grid
										item
										sx={{ display: 'flex', alignItems: 'center', color: theme.palette.text.gray03 }}
										xs={2}
									>
										<Typography
											fontSize="40px"
											sx={{
												position: 'relative',
												top: '1px'
											}}
										>
											{' \u00b7 '}
										</Typography>
										<Grid style={{ color: theme.palette.text.gray03, fontSize: '14px' }}>
											{getTimeDifference(item?.created_at)}
										</Grid>
									</Grid>
								</Grid>
							)}
						</Grid>
					);
				})}
		</Grid>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default ActivityList;
