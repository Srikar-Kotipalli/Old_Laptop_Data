/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable no-else-return */
import * as React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import { Grid } from '@mui/material';
import Icon from '../icon';
import closeIcon from '../../assets/actions/close.svg';
import PrimaryButton from '../primaryButton';
import { getButtonTextForDeleteArchive } from '../../utils/utils';
import { ProjectContext } from '../../containers/projects/projectContext';

export default function DialogBox({
	totalItems,
	openDialogBox,
	setOpenDialogBox,
	icon,
	title,
	handler,
	message,
	selected,
	handleCloseForDelete,
	type,
	paddingBottom,
	multipleSelectedItems,
	currentItem,
	width,
	allSelected,
	view,
	location
}) {
	const projectContext = React.useContext(ProjectContext);
	const { allItems } = projectContext;

	const handleClose = () => setOpenDialogBox(false);

	const areMultipleItemsDeleted = () => {
		// eslint-disable-next-line no-const-assign
		if (view === 'grid' || location === 'expSidebar') {
			return false;
		} else if (allSelected && view !== 'grid') {
			return true;
		}
		return multipleSelectedItems.length > 1;
	};

	const checkSharedInAllSelected = () => {
		if (allSelected) {
			const checkShared = allItems.filter(e => e?.shared);
			if (checkShared?.length > 0) return false;
			return true;
		}
		return false;
	};

	// eslint-disable-next-line consistent-return
	const getDialogBoxMessages = () => {
		if (title === 'Move') {
			return (
				<>
					<Typography
						sx={{ paddingBottom: '5px', paddingLeft: '4px' }}
						color="textPrimary"
						variant="subtitle2"
						data-testid="message"
					>
						{message} {totalItems} {totalItems === 1 ? 'item' : 'items'} to
					</Typography>
					<Typography
						sx={{ paddingBottom: '5px', paddingLeft: '4px', fontWeight: 'bold' }}
						color="textPrimary"
						variant="subtitle2"
						data-testid="title"
					>
						{selected && selected.length === 0 && title === 'Move' ? 'root' : selected[0]?.title} ?
					</Typography>
				</>
			);
			// eslint-disable-next-line no-else-return
		} else {
			if (areMultipleItemsDeleted()) {
				return (
					<>
						<Typography
							sx={{ paddingBottom: '5px', paddingLeft: '4px' }}
							color="textPrimary"
							variant="subtitle2"
							data-testid="message"
						>
							Are you sure about {title === 'Delete' ? 'deleting' : 'archiving'}
						</Typography>
						<Typography
							sx={{ paddingBottom: '5px', paddingLeft: '4px', fontWeight: 'bold' }}
							color="textSecondary"
							variant="subtitle2"
							data-testid="title"
						>
							{checkSharedInAllSelected() ? 'all' : multipleSelectedItems.length}
						</Typography>
						<Typography
							sx={{ paddingBottom: '5px', paddingLeft: '4px', fontWeight: 'bold' }}
							color="textPrimary"
							variant="subtitle2"
							data-testid="title"
						>
							items ?
						</Typography>
					</>
				);
			} else if (type !== 'dispatch') {
				if (currentItem?.status !== 'RUNNING' || type === 'project') {
					return (
						<>
							<Typography
								sx={{ paddingBottom: '5px', paddingLeft: '4px' }}
								color="textPrimary"
								variant="subtitle2"
								data-testid="message"
							>
								{title === 'Delete' ? 'Deleting' : 'Archiving'}
							</Typography>
							<Typography
								sx={{ paddingLeft: '4px', fontWeight: 'bold' }}
								color="textSecondary"
								variant="subtitle2"
								data-testid="title"
								noWrap
							>
								{type === 'experiment' ? 'Experiment' : 'Project'} {currentItem?.title}
							</Typography>
							<Typography
								sx={{ paddingBottom: '5px', paddingLeft: '4px', fontWeight: 'bold' }}
								color="textPrimary"
								variant="subtitle2"
								data-testid="title"
								noWrap
							>
								will {title === 'Delete' ? 'delete' : 'archive'}
							</Typography>
							<Typography
								sx={{ paddingBottom: '5px', paddingLeft: '4px', fontWeight: 'bold' }}
								color="textSecondary"
								variant="subtitle2"
								data-testid="title"
								noWrap
							>
								all of its {type === 'experiment' ? 'dispatches' : 'items'}
							</Typography>
							<Typography
								sx={{ paddingBottom: '5px', paddingLeft: '4px', fontWeight: 'bold' }}
								color="textPrimary"
								variant="subtitle2"
								data-testid="title"
								noWrap
							>
								,are you sure you want to {title === 'Delete' ? 'delete' : 'archive'}?
							</Typography>
						</>
					);
				} else {
					return (
						<>
							<Typography
								sx={{ paddingLeft: '4px', fontWeight: 'bold' }}
								color="textSecondary"
								variant="subtitle2"
								data-testid="title"
								noWrap
							>
								Experiment {currentItem?.title}
							</Typography>
							<Typography
								sx={{ paddingBottom: '5px', paddingLeft: '4px', fontWeight: 'bold' }}
								color="textPrimary"
								variant="subtitle2"
								data-testid="title"
								noWrap
							>
								has running dispatches,
							</Typography>
							<Typography
								sx={{ paddingBottom: '5px', paddingLeft: '4px', fontWeight: 'bold' }}
								color="textPrimary"
								variant="subtitle2"
								data-testid="title"
								noWrap
							>
								are you sure you want to {title === 'Delete' ? 'delete' : 'archive'} it?
							</Typography>
						</>
					);
				}
			} else {
				if (currentItem?.status === 'RUNNING') {
					return (
						<>
							<Typography
								sx={{ paddingLeft: '4px', fontWeight: 'bold' }}
								color="textSecondary"
								variant="subtitle2"
								data-testid="title"
								noWrap
							>
								Dispatch {currentItem?.title}
							</Typography>
							<Typography
								sx={{ paddingBottom: '5px', paddingLeft: '4px', fontWeight: 'bold' }}
								color="textPrimary"
								variant="subtitle2"
								data-testid="title"
								noWrap
							>
								is currently
							</Typography>
							<Typography
								sx={{ paddingBottom: '5px', paddingLeft: '4px', fontWeight: 'bold' }}
								color="textSecondary"
								variant="subtitle2"
								data-testid="title"
								noWrap
							>
								running,
							</Typography>
							<Typography
								sx={{ paddingBottom: '5px', paddingLeft: '4px', fontWeight: 'bold' }}
								color="textPrimary"
								variant="subtitle2"
								data-testid="title"
								noWrap
							>
								are you sure you want to {title === 'Delete' ? 'delete' : 'archive'} it?
							</Typography>
						</>
					);
					// eslint-disable-next-line no-else-return
				} else {
					return (
						<>
							<Typography
								sx={{ paddingBottom: '5px', paddingLeft: '4px', fontWeight: 'bold' }}
								color="textPrimary"
								variant="subtitle2"
								data-testid="title"
								noWrap
							>
								Are you sure you want to {title === 'Delete' ? 'delete' : 'archive'}
							</Typography>
							<Typography
								sx={{ paddingLeft: '4px', fontWeight: 'bold' }}
								color="textSecondary"
								variant="subtitle2"
								data-testid="title"
								noWrap
							>
								Dispatch {currentItem?.title}?
							</Typography>
						</>
					);
				}
			}
		}
	};

	const getTitle = () => {
		let titleMsg = '';
		if (title === 'Move') {
			titleMsg = `${title} ${totalItems}`;
			if (totalItems <= 1) {
				titleMsg += ' item ?';
			} else {
				titleMsg += ' items ?';
			}
		} else {
			if (areMultipleItemsDeleted()) {
				titleMsg = `${title} items?`;
			} else {
				titleMsg = `${title} ${type}?`;
			}
		}
		return titleMsg;
	};

	const getPrimaryButtonText = () => {
		if (title === 'Move') {
			if (selected && selected.length === 0) return 'Move to root';
			return title;
		} else
			return getButtonTextForDeleteArchive(
				type,
				title,
				multipleSelectedItems,
				currentItem,
				allSelected
			);
	};

	return (
		<div>
			<Modal
				open={openDialogBox}
				onClose={handleClose}
				aria-labelledby="modal-modal-title"
				aria-describedby="modal-modal-description"
				data-testid="dialogBox"
			>
				<Box
					sx={{
						position: 'absolute',
						top: '50%',
						left: '50%',
						transform: 'translate(-50%, -50%)',
						minWidth: width || 500,
						bgcolor: 'background.paper',
						border: '1px solid #6473FF',
						borderRadius: '24px',
						boxShadow: 24,
						p: 2
					}}
				>
					<Grid sx={{ display: 'flex', justifyContent: 'space-between' }}>
						<Grid sx={{ display: 'flex' }}>
							<Icon src={icon} type="static" alt="arrowRightAltIcon" padding="0px 3px 6px 3.5px" />
							<Typography
								sx={{
									paddingBottom: paddingBottom || '5px',
									paddingLeft: '4px',
									fontWeight: 'bold'
								}}
								color={title !== 'Move' ? 'textSecondary' : 'textPrimary'}
								variant="subtitle2"
								data-testid="messageTitle"
							>
								{getTitle()}
							</Typography>
						</Grid>
						<Grid>
							<Icon
								src={closeIcon}
								type="pointer"
								alt="arrowRightAltIcon"
								clickHandler={title === 'Move' ? handleClose : handleCloseForDelete}
							/>
						</Grid>
					</Grid>
					<Grid sx={{ display: 'flex' }} mt={2}>
						{getDialogBoxMessages()}
					</Grid>
					<Grid
						container
						display="flex"
						justifyContent="flex-end"
						spacing={1}
						mt={2}
						sx={{ maxWidth: '100%' }}
					>
						<Grid item>
							<PrimaryButton
								handler={title === 'Move' ? handleClose : handleCloseForDelete}
								title="Cancel"
								bgColor="#08081A"
								hoverColor="#5552FF"
								className="cancelButton"
							/>
						</Grid>
						<Grid item>
							<PrimaryButton
								handler={handler}
								title={getPrimaryButtonText()}
								bgColor="#5552FF"
								hoverColor="#403cff"
							/>
						</Grid>
					</Grid>
				</Box>
			</Modal>
		</div>
	);
}
