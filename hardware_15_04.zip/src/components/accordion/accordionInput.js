/* eslint-disable no-shadow */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React from 'react';
import { Grid, InputLabel, Input, Tooltip } from '@mui/material';
import Add from '../../assets/actions/add.svg';
import Icon from '../icon';
import AccordionChip from './accordionChip';

function AccordionInput({
	stringLabel,
	valueLabel,
	variant,
	data,
	setAddData,
	modeInput,
	setOpenSnackbar,
	setSnackbarMessage
}) {
	// state for input field
	const [inputData, setInputData] = React.useState({ name: '', value: '' });

	// this is responsible for the data display on chips
	const [chipData, setChipData] = React.useState(data);

	// this is to handle the error in input
	const [error, setError] = React.useState(false);
	const [mode, setMode] = React.useState(modeInput);

	React.useEffect(() => {
		setChipData(data);
	}, [data]);

	React.useEffect(() => {
		setMode(modeInput);
		if (modeInput === '') {
			setInputData({ name: '', value: '' });
		}
	}, [modeInput]);

	const addInputData = e => {
		setError(false);
		setInputData({ ...inputData, [e.target.name]: e.target.value });
	};

	const onAddition = () => {
		if (inputData.value === '' || (inputData.name === '' && variant === 'key')) {
			setError(true);
		} else {
			if (inputData.name === '') {
				if (data.indexOf(inputData.value) === -1) {
					data.unshift(inputData.value);
					setAddData([...chipData]);
					setInputData({ ...inputData, value: '' });
				} else {
					setSnackbarMessage('The value is already present!');
					setOpenSnackbar(true);
				}
			} else {
				if (variant !== 'name') {
					const joinData = `${inputData.name}:${inputData.value}`;
					data.unshift(joinData);
					setAddData([...chipData]);
					setInputData({ ...inputData, name: '', value: '' });
				}
			}
		}
	};

	// this function is to delete the chip
	const deleteChip = index => {
		const result = chipData.filter((_datas, idx) => idx !== index);
		setChipData(result);
		setAddData(result);
	};

	const errorFieldFn = errorData => {
		if (errorData) {
			return 'The field cannot be empty';
		}
		return 'Add';
	};

	const nodeJustify = val => {
		if (val === 'add' || val === 'edit') {
			return 'space-evenly';
		}
		return 'flex-start';
	};

	const borderWidth = keyVal => {
		if (keyVal !== 'key') {
			return '1px solid';
		}
		return 'null';
	};

	return (
		<Grid
			item
			mr={1}
			xs={2.9}
			sx={{
				borderRight: borderWidth(variant),
				borderColor: theme => theme.palette.background.covalentPurple
			}}
		>
			{stringLabel && variant === 'name' ? (
				<Grid sx={{ display: 'flex', alignItems: 'center' }}>
					<InputLabel
						variant="standard"
						sx={{
							fontSize: '12px',
							mr: 1,
							color: 'text.secondary'
						}}
					>
						{stringLabel}
					</InputLabel>
					{(mode === 'add' || mode === 'edit') && (
						<Input
							autoComplete="off"
							readOnly
							placeholder="String"
							sx={[
								{
									input: {
										'&::placeholder': {
											color: theme => theme.palette.text.primary,
											opacity: 1
										}
									},
									px: 2,
									py: 0.5,
									width: '70%',
									height: '24px',
									border: '1px solid #303067',
									borderRadius: '60px',
									fontSize: '12px',
									color: theme => theme.palette.text.secondary
								}
							]}
							onKeyPress={e => {
								if (e.key === 'Enter') onAddition();
							}}
							name="name"
							onChange={e => addInputData(e)}
							value={inputData.name}
							disableUnderline
						/>
					)}
				</Grid>
			) : null}
			{(!variant || variant === 'name') && (
				<Grid mt={variant ? 2 : 0}>
					<Grid sx={{ display: 'flex', alignItems: 'center' }}>
						<InputLabel
							variant="standard"
							sx={{
								fontSize: '12px',
								mr: 1,
								color: 'text.secondary',
								marginLeft: '12px'
							}}
						>
							{valueLabel}
						</InputLabel>
						{mode === 'add' || mode === 'edit' ? (
							<Input
								autoComplete="off"
								sx={[
									{
										input: {
											'&::placeholder': {
												color: theme => theme.palette.text.primary,
												opacity: 1
											}
										},
										px: 2,
										py: 0.5,
										width: '50%',
										height: '24px',
										border: '1px solid #303067',
										borderRadius: '60px',
										fontSize: '12px',
										color: theme => theme.palette.text.secondary
									}
								]}
								name="value"
								value={inputData.value}
								onChange={e => addInputData(e)}
								onKeyPress={e => {
									if (e.key === 'Enter') onAddition();
								}}
								disableUnderline
								placeholder="Value"
							/>
						) : null}
						{mode === 'add' || mode === 'edit' ? (
							<Grid
								container
								direction="row"
								alignItems="center"
								justifyItems="center"
								ml={2}
								sx={{
									border: '1px solid',
									borderColor: theme => theme.palette.background.blue05,
									borderRadius: '8px',
									width: '24px',
									height: '24px'
								}}
							>
								<Tooltip title={errorFieldFn(error)} placement="top">
									<span>
										<Icon src={Add} padding="0px 0px 3px 3px" clickHandler={onAddition} />
									</span>
								</Tooltip>
							</Grid>
						) : null}
					</Grid>
				</Grid>
			)}
			{variant === 'key' ? (
				<Grid>
					<Grid
						sx={{
							display: 'flex',
							alignItems: 'center',
							justifyContent: nodeJustify(mode)
						}}
					>
						<InputLabel
							variant="standard"
							sx={{
								fontSize: '12px',
								mr: 1,
								color: 'text.secondary'
							}}
						>
							{valueLabel}
						</InputLabel>
						{mode === 'add' || mode === 'edit' ? (
							<>
								<Input
									autoComplete="off"
									sx={[
										{
											input: {
												'&::placeholder': {
													color: theme => theme.palette.text.primary,
													opacity: 1
												}
											},
											px: 2,
											py: 0.5,
											width: '25%',
											height: '24px',
											border: '1px solid #303067',
											borderRadius: '60px',
											fontSize: '12px',
											color: theme => theme.palette.text.secondary
										}
									]}
									name="name"
									value={inputData.name}
									onChange={e => addInputData(e)}
									onKeyPress={e => {
										if (e.key === 'Enter') onAddition();
									}}
									disableUnderline
									placeholder="Key"
								/>
								<Input
									autoComplete="off"
									sx={[
										{
											input: {
												'&::placeholder': {
													color: theme => theme.palette.text.primary,
													opacity: 1
												}
											},
											px: 2,
											py: 0.5,
											width: '25%',
											height: '24px',
											border: '1px solid #303067',
											borderRadius: '60px',
											fontSize: '12px',
											color: theme => theme.palette.text.secondary
										}
									]}
									name="value"
									value={inputData.value}
									onChange={e => addInputData(e)}
									onKeyPress={e => {
										if (e.key === 'Enter') onAddition();
									}}
									disableUnderline
									placeholder="Value"
								/>
								<Grid
									container
									direction="row"
									alignItems="center"
									justifyItems="center"
									ml={2}
									sx={{
										border: '1px solid',
										borderColor: theme => theme.palette.background.blue05,
										borderRadius: '8px',
										width: '24px',
										height: '24px'
									}}
								>
									<Tooltip title={errorFieldFn(error)} placement="top">
										<span>
											<Icon src={Add} padding="0px 0px 3px 3px" clickHandler={onAddition} />
										</span>
									</Tooltip>
								</Grid>
							</>
						) : null}
					</Grid>
				</Grid>
			) : (
				// eslint-disable-next-line react/jsx-no-useless-fragment
				<></>
			)}
			<AccordionChip
				chipData={chipData}
				setChipData={setChipData}
				deleteChip={deleteChip}
				variant={variant}
				modeInput={mode}
			/>
		</Grid>
	);
}

export default AccordionInput;
