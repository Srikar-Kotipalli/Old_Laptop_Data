/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import Chip from '@mui/material/Chip';
import Grid from '@mui/material/Grid';
import Icon from '../icon';
import Delete from '../../assets/actions/close.svg';
import PackagesTooltip from '../tooltip/packagesTooltip';

function AccordionChip({ chipData, deleteChip, variant, modeInput }) {
	const [mode, setMode] = React.useState(modeInput);

	React.useEffect(() => {
		setMode(modeInput);
	}, [modeInput]);

	return (
		<Grid
			pl={1}
			pr={1}
			container
			item
			xs={11.7}
			spacing={1}
			mt={2}
			sx={{
				height: variant === 'name' || chipData.length < 5 ? '80px' : '120px',
				overflow: 'auto'
			}}
		>
			{chipData &&
				chipData.map((chip, index) => {
					return (
						<Grid item xs={6} key={chip} container justifyContent="space-between">
							<Chip
								sx={{
									width: '100%',
									border: '1px solid',
									borderColor: theme => theme.palette.background.covalentPurple,
									borderRadius: '8px',
									padding: '0px 5px',
									display: 'flex',
									justifyContent: 'space-between'
								}}
								// icon={<Icon src={Drag} padding="1px 0px 0px 0px" />}
								label={<PackagesTooltip chip={chip} width="100%" />}
								onDelete={
									mode === 'add' || mode === 'edit'
										? e => {
												console.log(e);
										  }
										: null
								}
								deleteIcon={
									mode === 'add' || mode === 'edit' ? (
										<Icon
											src={Delete}
											padding="1px 0px 0px 0px"
											clickHandler={() => deleteChip(index)}
										/>
									) : null
								}
							/>
						</Grid>
					);
				})}
		</Grid>
	);
}

export default AccordionChip;
