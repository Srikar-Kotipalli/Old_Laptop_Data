/* eslint-disable no-unused-vars */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import { Grid, Button, Tooltip } from '@mui/material';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import YAML from 'yaml';
import ReactFileReader from 'react-file-reader';
import ExpandMoreIcon from '../../assets/arrows/caretDown.svg';
import ExpandLessIcon from '../../assets/arrows/caretUp.svg';
import Icon from '../icon';
import Upload from '../../assets/actions/upload.svg';
import Save from '../../assets/actions/save.svg';
import MenuIcon from '../../assets/menus/menuVerticalIcon.svg';
import EditIcon from '../../assets/actions/edit.svg';
import Custom from '../../assets/environments/custom.svg';
import settings from '../../assets/helperMenu/settings.svg';
import EllipsisTooltip from '../tooltip/ellipsisTooltip';
import CustomisedSnackbar from '../snackbar/projects';
import CopyButton from '../copyButton';

import {
	getYamlFile,
	getEnvironment,
	setDefaultEnvironment,
	addEnvironment,
	editEnvironment
} from '../../api/environments/environmentsApi';
import InputBase from './inputbase';

import AccordionInput from './accordionInput';
import { envStatusIcons } from '../../utils/statusIcons';
import Loader from '../loader';

function EnvAccordion(props) {
	const { accordianData, modeInput, setReloadBatch, entireData, setAccordianData } = props;

	const [data, setData] = React.useState(accordianData);
	const [expand, setExpand] = React.useState(!!accordianData?.isAddMode);
	const [envData, setEnvData] = React.useState({});
	const [isShown, setIsShown] = React.useState({ accordion: false, description: false });
	const [openLoader, setOpenLoader] = React.useState(false);
	const [mode, setMode] = React.useState(modeInput);
	const [openSnackbar, setOpenSnackbar] = React.useState(false);
	const [snackbarMessage, setSnackbarMessage] = React.useState('');

	// column data
	const [name, setName] = React.useState(accordianData?.name);
	const [channels, setChannels] = React.useState([]);
	const [pip, setPip] = React.useState([]);
	const [conda, setConda] = React.useState([]);
	// const [variables, setVariables] = React.useState([]);

	// state for inline text edits

	// state for menu
	const [anchorEl, setAnchorEl] = React.useState(null);
	const open = Boolean(anchorEl);

	const handleClick = event => {
		event.stopPropagation();
		setAnchorEl(event.currentTarget);
	};
	const handleClose = event => {
		event.stopPropagation();
		setAnchorEl(null);
	};

	React.useEffect(() => {
		setMode(modeInput);
	}, [modeInput]);

	React.useEffect(() => {
		setExpand(!!accordianData?.isAddMode);
		setData(accordianData);
		setName(accordianData?.name);
	}, [accordianData]);

	const setEnvironmentDefault = e => {
		handleClose(e);
		setOpenLoader(true);
		setDefaultEnvironment(data?.name)
			.then(_res => {
				setOpenLoader(false);
				setSnackbarMessage('Environment set as default.');
				setOpenSnackbar(true);
				setTimeout(() => setReloadBatch(prevState => !prevState), 1000);
			})
			.catch(err => {
				setSnackbarMessage(
					err?.detail ? err.detail : 'Something went wrong, contact administrator'
				);
				setOpenSnackbar(true);
				setOpenLoader(false);
			});
	};

	const cancelAddEdit = () => {
		if (mode === 'edit') {
			setMode('');
			setName(data?.name);
			setData({ ...data, isAddTitle: false });
			// eslint-disable-next-line no-unsafe-optional-chaining
			setChannels([...envData?.channels]);
			setPip(() => {
				const tempArr = [];
				envData?.dependencies?.forEach(element => {
					if (typeof element === 'object' && element?.pip) tempArr.push(...element['pip']);
				});
				return tempArr;
			});
			setConda(() => {
				const tempArr = [];
				envData?.dependencies?.forEach(element => {
					if (typeof element !== 'object') tempArr.push(element);
				});
				return tempArr;
			});
			// setVariables([]);
			const index = entireData?.records.findIndex(e => e?.id === accordianData?.id);
			// eslint-disable-next-line no-unsafe-optional-chaining
			const tempRecords = [...entireData?.records];
			if (index !== -1) tempRecords[index].mode = '';
			entireData.records = [...tempRecords];
			setAccordianData({ ...entireData });
		} else {
			const checkAddEnvsIndex = entireData?.records.findIndex(e => e?.isAddMode === true);
			// eslint-disable-next-line no-unsafe-optional-chaining
			const tempRecords = [...entireData?.records];
			if (checkAddEnvsIndex !== -1) tempRecords?.splice(checkAddEnvsIndex, 1);
			entireData.records = [...tempRecords];
			setAccordianData({ ...entireData });
		}
	};

	const toggleAcordion = (isMode = '') => {
		if (!expand && !accordianData?.isAddMode) {
			setExpand(prev => !prev);
			setOpenLoader(true);
			getEnvironment(data?.id)
				.then(response => {
					if (response?.definition) {
						getYamlFile(response?.definition)
							.then(res => {
								const parsedData = YAML.parse(res?.data);
								setEnvData({ ...parsedData });
								if (isMode !== 'edit') {
									// eslint-disable-next-line no-unsafe-optional-chaining
									setChannels([...parsedData?.channels]);
									setPip(() => {
										const tempArr = [];
										parsedData?.dependencies?.forEach(element => {
											if (typeof element === 'object' && element?.pip)
												tempArr.push(...element['pip']);
										});
										return tempArr;
									});
									setConda(() => {
										const tempArr = [];
										parsedData?.dependencies?.forEach(element => {
											if (typeof element !== 'object') tempArr.push(element);
										});
										return tempArr;
									});
									// setVariables([]);
								}
								setOpenLoader(false);
							})
							.catch(_error => {
								setEnvData({});
								setExpand(prev => !prev);
								if (isMode !== 'edit') {
									setChannels([]);
									setPip([]);
									setConda([]);
									// setVariables([]);
								}
								setOpenLoader(false);
								setSnackbarMessage('Something went wrong, contact administrator');
								setOpenSnackbar(true);
							});
					} else {
						setEnvData({});
						if (isMode !== 'edit') {
							setChannels([]);
							setPip([]);
							setConda([]);
							// setVariables([]);
						}
						setExpand(prev => !prev);
						setOpenLoader(false);
					}
				})
				.catch(_error => {
					setOpenLoader(false);
					setExpand(prev => !prev);
					setSnackbarMessage('Something went wrong, contact administrator');
					setOpenSnackbar(true);
				});
		} else {
			if (mode === 'edit') {
				setMode('');
				const checkEnvsIndex = entireData?.records.findIndex(e => e?.id === accordianData?.id);
				// eslint-disable-next-line no-unsafe-optional-chaining
				const tempRecords = [...entireData?.records];
				if (checkEnvsIndex !== -1) tempRecords[checkEnvsIndex].mode = '';
				entireData.records = [...tempRecords];
				setAccordianData({ ...entireData });
			}
			if (mode !== 'add') setExpand(prev => !prev);
		}
	};

	const handleFiles = files => {
		const checkAddEnvsIndex = entireData?.records.findIndex(
			e => (e?.isAddMode === true || e?.mode === 'edit') && e?.id !== accordianData?.id
		);
		if (checkAddEnvsIndex !== -1) {
			setSnackbarMessage('Please add/edit one environment at a time');
			setOpenSnackbar(true);
		} else {
			const index = entireData?.records.findIndex(e => e?.id === accordianData?.id);
			// eslint-disable-next-line no-unsafe-optional-chaining
			const tempRecords = [...entireData?.records];
			if (index !== -1) tempRecords[index].mode = 'edit';
			entireData.records = [...tempRecords];
			setAccordianData({ ...entireData });

			if (mode === '') {
				setMode('edit');
			}
			if (!expand) toggleAcordion(mode === '' ? 'edit' : mode);

			const reader = new FileReader();
			// eslint-disable-next-line func-names
			reader.onload = function (_e) {
				const readData = YAML.parse(reader.result);
				if (mode === 'add') setName(readData['name']);
				setData({ ...data, isAddTitle: false });
				setChannels(readData?.channels);
				setPip(() => {
					const tempArr = [];
					readData?.dependencies?.forEach(element => {
						if (typeof element === 'object' && element?.pip) tempArr.push(...element['pip']);
					});
					return tempArr;
				});
				setConda(() => {
					const tempArr = [];
					readData?.dependencies?.forEach(element => {
						if (typeof element !== 'object') tempArr.push(element);
					});
					return tempArr;
				});
				setSnackbarMessage('Imported Environment data');
				setOpenSnackbar(true);
			};
			reader.readAsText(files[0]);
		}
	};

	const handleEditClick = event => {
		handleClose(event);
		const checkAddEnvsIndex = entireData?.records.findIndex(
			e => e?.isAddMode === true || e?.mode === 'edit'
		);
		if (checkAddEnvsIndex !== -1) {
			setSnackbarMessage('Please add/edit one environment at a time');
			setOpenSnackbar(true);
		} else {
			setMode('edit');
			const index = entireData?.records.findIndex(e => e?.id === accordianData?.id);
			// eslint-disable-next-line no-unsafe-optional-chaining
			const tempRecords = [...entireData?.records];
			if (index !== -1) tempRecords[index].mode = 'edit';
			entireData.records = [...tempRecords];
			setAccordianData({ ...entireData });
			if (!expand) toggleAcordion();
		}
	};

	const saveEnvironment = () => {
		if (name === '') {
			setSnackbarMessage('Environment name cannot be empty');
			setOpenSnackbar(true);
		} else {
			const newEnvData = {};
			newEnvData['channels'] = channels;
			newEnvData['dependencies'] = [];
			newEnvData.dependencies.push({ pip });
			newEnvData.dependencies.push(...conda);
			// const variablesInput = [];
			// variables.forEach(e => {
			// 	const arr = e?.split(':');
			// 	const tempObj = {};
			// 	tempObj['name'] = arr[0];
			// 	tempObj['value'] = arr[1];
			// 	tempObj['sensitive'] = false;
			// 	variablesInput.push(tempObj);
			// });
			const dataa = YAML.stringify(newEnvData);
			const yamlFileCreate = new Blob([dataa], { type: 'yml' });
			if (mode === 'add') {
				setOpenLoader(true);
				setData({ ...data, isAddTitle: false });
				setIsShown({ ...isShown, accordion: false });
				addEnvironment(yamlFileCreate, name)
					.then(_res => {
						setSnackbarMessage('Environment Added Successfully');
						setExpand(false);
						setOpenLoader(false);
						setOpenSnackbar(true);
						setTimeout(() => setReloadBatch(prevState => !prevState), 900);
					})
					.catch(err => {
						setOpenLoader(false);
						setSnackbarMessage(
							err?.detail && typeof err?.detail === 'string'
								? err.detail
								: 'Something went wrong, contact administrator'
						);
						setOpenSnackbar(true);
					});
			} else {
				setOpenLoader(true);
				editEnvironment(data?.id, yamlFileCreate)
					.then(_res => {
						setOpenLoader(false);
						setExpand(false);
						setSnackbarMessage('Environment Edited Successfully');
						setOpenSnackbar(true);
						setTimeout(() => setReloadBatch(prevState => !prevState), 1000);
					})
					.catch(error => {
						setOpenLoader(false);
						setSnackbarMessage(
							error?.detail && typeof error?.detail === 'string'
								? error.detail
								: 'Something went wrong, contact administrator'
						);
						setOpenSnackbar(true);
					});
			}
		}
	};

	return (
		<>
			<CustomisedSnackbar
				testId="envSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			<Grid item xs={12} mt={2}>
				<Accordion
					elevation={0}
					expanded={expand}
					sx={{
						border: '1px solid',
						borderColor: expand
							? theme => theme.palette.background.blue05
							: theme => theme.palette.background.covalentPurple
					}}
				>
					<AccordionSummary
						aria-controls="panel1a-content"
						id="panel1a-header"
						onClick={toggleAcordion}
					>
						<Grid container direction="row" justifyContent="space-between">
							<Grid sx={{ display: 'flex' }}>
								{/* <Checkbox
									icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
									checkedIcon={<Icon src={checkboxChecked} alt="checkboxChecked" type="pointer" />}
									sx={{ fontSize: '18px' }}
								/> */}
								{data?.default ? (
									<>
										<Grid mr={0.9}>
											<Icon src={Custom} padding="0px 0px 0px 0px" />
										</Grid>
										{data?.isAddTitle && (
											<InputBase data={data} setData={setData} setName={setName} name={name} />
										)}
										{!data?.isAddTitle && (
											<>
												<Grid
													ml={1}
													mt={0.3}
													sx={{
														color: theme => theme.palette.text.secondary,
														width: '200px',
														display: 'flex'
													}}
													onMouseEnter={() => setIsShown({ ...isShown, accordion: true })}
													onMouseLeave={() => setIsShown({ ...isShown, accordion: false })}
												>
													<EllipsisTooltip
														onMouseEnter={() => setIsShown({ ...isShown, accordion: true })}
														onMouseLeave={() => setIsShown({ ...isShown, accordion: false })}
														ml={1}
														mt={0.3}
														type="grid"
														value={name}
														variant="environment"
													/>
													{isShown.accordion && mode === 'add' && (
														<Icon
															src={EditIcon}
															clickHandler={() => setData({ ...data, isAddTitle: true })}
														/>
													)}
													{!data?.isAddMode && envStatusIcons(data?.status)}
												</Grid>

												<Grid
													ml={1.5}
													px={1}
													container
													direction="row"
													alignItems="center"
													justifyContent="center"
													sx={{
														border: '1px solid',
														borderRadius: '8px',
														borderColor: theme => theme.palette.text.secondary
													}}
												>
													<Typography
														variant="h3"
														sx={{ color: theme => theme.palette.text.secondary }}
													>
														Default
													</Typography>
												</Grid>
											</>
										)}
									</>
								) : (
									<>
										<Grid mr={0.9}>
											<Icon src={Custom} padding="0px 0px 0px 0px" />
										</Grid>
										{data?.isAddTitle && (
											<InputBase data={data} setData={setData} setName={setName} name={name} />
										)}
										{!data?.isAddTitle && (
											<Grid
												ml={1}
												mt={0.3}
												onMouseEnter={() => setIsShown({ ...isShown, accordion: true })}
												onMouseLeave={() => setIsShown({ ...isShown, accordion: false })}
												sx={{
													color: theme => theme.palette.text.secondary,
													width: '200px',
													display: 'flex'
												}}
											>
												<EllipsisTooltip
													ml={1}
													mt={0.3}
													onMouseEnter={() => setIsShown({ ...isShown, accordion: true })}
													onMouseLeave={() => setIsShown({ ...isShown, accordion: false })}
													type="grid"
													value={name}
													variant="env"
												/>
												{!data?.isAddMode && envStatusIcons(data?.status)}
												{isShown.accordion && mode === 'add' && (
													<Icon
														src={EditIcon}
														clickHandler={() => setData({ ...data, isAddTitle: true })}
													/>
												)}
											</Grid>
										)}
									</>
								)}
							</Grid>
							<Grid
								item
								xs={1.2}
								sx={{ display: 'flex', justifyContent: 'space-evenly', alignItems: 'center' }}
							>
								{/* <Typography variant="h2">Last </Typography>
								<Typography variant="h2">updated: </Typography>
								<Typography variant="h2">03 Feb,12:05:38 </Typography> */}
								<CopyButton content={name} borderEnable={false} />
								<ReactFileReader
									fileTypes={['.yml']}
									handleFiles={
										data?.status === 'READY' || data?.isAddMode
											? handleFiles
											: e => {
													console.log(e);
											  }
									}
									disabled={data?.status !== 'READY' && !data?.isAddMode}
								>
									<Tooltip title="Upload yml">
										<div>
											<Icon src={Upload} />
										</div>
									</Tooltip>
								</ReactFileReader>
								<Tooltip title="Menu">
									<div>
										<Icon src={MenuIcon} clickHandler={e => handleClick(e)} />
									</div>
								</Tooltip>
								<Tooltip title={!expand ? 'Expand' : 'Collapse'}>
									<div>
										<Icon
											src={!expand ? ExpandMoreIcon : ExpandLessIcon}
											padding="0.3px 0px 0px 0px"
										/>
									</div>
								</Tooltip>
								<Menu
									id="basic-menu"
									anchorEl={anchorEl}
									open={open}
									onClose={e => handleClose(e)}
									PaperProps={{
										style: {
											transform: 'translateX(0%) translateY(8%)'
										}
									}}
								>
									<MenuItem
										onClick={e => setEnvironmentDefault(e)}
										data-testid="add"
										disabled={data?.status !== 'READY'}
									>
										<Icon src={settings} type="static" alt="defaultIcon" />
										<Typography variant="subtitle2">Set as default</Typography>
									</MenuItem>
									<MenuItem
										onClick={e => handleEditClick(e)}
										data-testid="edit"
										disabled={mode === 'add' || mode === 'edit' || data?.status !== 'READY'}
										// eslint-disable-next-line react/jsx-boolean-value
									>
										<Icon src={EditIcon} type="static" alt="editIcon" />
										<Typography variant="subtitle2">Edit</Typography>
									</MenuItem>
									{/* <MenuItem
										onClick={() => {
											replicateEnvironment(data?.id, '');
										}}
										data-testid="add"
									>
										<Icon src={Copy} type="static" alt="duplicateIcon" />
										<Typography variant="subtitle2">Duplicate</Typography>
									</MenuItem>

									<MenuItem onClick={() => {}} data-testid="delete">
										<Icon src={DeleteIcon} type="static" alt="deleteIcon" />
										<Typography variant="subtitle2">Delete</Typography>
									</MenuItem> */}
								</Menu>
							</Grid>
						</Grid>
					</AccordionSummary>
					<AccordionDetails>
						{/* <Grid item xs={12} mb={4} ml={1}>
						<Typography variant="h2">Machine Learning</Typography>
						<Grid container sx={{ display: 'flex' }}>
							{data?.isDescAdd ? (
								<InputBase data={data} setData={setData} variant="description" />
							) : null}
							{!data.isDescAdd ? (
								<Grid item xs={8} style={{ overflowY: 'auto' }}>
									<Typography
										style={{ wordWrap: 'break-word' }}
										mt={1}
										variant="h2"
										onMouseEnter={() => setIsShown({ ...isShown, description: true })}
										onMouseLeave={() => setIsShown({ ...isShown, description: false })}
									>
										{data?.description}
										{isShown.description ? (
											<Icon
												src={EditIcon}
												clickHandler={() => setData({ ...data, isDescAdd: true })}
											/>
										) : (
											<Icon src={InvisibleEditIcon} />
										)}
									</Typography>
								</Grid>
							) : null}
						</Grid>
					</Grid> */}
						{openLoader ? (
							<Loader isFetching={openLoader} width="100%" position="relative" height="140%" />
						) : (
							<>
								<Grid container item xs={12} ml={1}>
									<AccordionInput
										valueLabel="Channels"
										data={channels || []}
										setAddData={setChannels}
										modeInput={mode}
										setSnackbarMessage={setSnackbarMessage}
										setOpenSnackbar={setOpenSnackbar}
									/>
									<AccordionInput
										valueLabel="Pip packages"
										data={pip || []}
										setAddData={setPip}
										modeInput={mode}
										setSnackbarMessage={setSnackbarMessage}
										setOpenSnackbar={setOpenSnackbar}
									/>
									<AccordionInput
										valueLabel="Conda packages"
										data={conda || []}
										setAddData={setConda}
										modeInput={mode}
										setSnackbarMessage={setSnackbarMessage}
										setOpenSnackbar={setOpenSnackbar}
									/>
									{/* <AccordionInput
										valueLabel="Variables"
										variant="key"
										data={variables || []}
										setAddData={setVariables}
										modeInput={mode}
										setSnackbarMessage={setSnackbarMessage}
										setOpenSnackbar={setOpenSnackbar}
									/> */}
								</Grid>
								<Grid
									mt={2}
									container
									item
									xs={12}
									direction="row"
									alignItems="center"
									justifyContent="flex-end"
								>
									{(mode === 'add' || mode === 'edit') && (
										<Grid>
											<Button
												sx={{
													'&:hover': {
														background: theme => theme.palette.background.blue06
													},
													background: '#08081A',
													border: '1px solid #1c1c46',
													color: theme => theme.palette.text.secondary,
													borderRadius: '70px',
													height: '2.5rem',
													width: '5rem',
													marginRight: '0.7rem'
												}}
												onClick={cancelAddEdit}
											>
												{/* <Icon src={Loader} padding="0px 0px 0px 0px" /> */}
												<Typography variant="h2">Cancel</Typography>
											</Button>
											<Button
												sx={{
													'&:hover': {
														background: theme => theme.palette.background.blue04
													},
													background: theme => theme.palette.background.blue04,
													color: theme => theme.palette.text.secondary,
													borderRadius: '70px'
												}}
												onClick={saveEnvironment}
											>
												{/* <Icon src={Loader} padding="0px 0px 0px 0px" /> */}

												<Grid>
													<img src={Save} alt="save" />
												</Grid>
												<Typography variant="h2" ml={1}>
													Save Environment
												</Typography>
											</Button>
										</Grid>
									)}
								</Grid>
							</>
						)}
					</AccordionDetails>
				</Accordion>
			</Grid>
		</>
	);
}

export default EnvAccordion;
