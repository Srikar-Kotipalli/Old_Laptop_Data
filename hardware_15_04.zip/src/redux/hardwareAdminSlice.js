/* eslint-disable quotes */
/* eslint-disable max-len */
/* eslint-disable import/prefer-default-export */
/* eslint-disable import/no-unused-modules */
/* eslint-disable import/no-named-as-default */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
	accessRequests: [
		{
			type: 'hardware',
			category: 'Code Quality',
			hardwareId: 2,
			technology: 'IBM Quantum',
			per: 'hour',
			downloads: 180,
			name: 'IBMQ_Manila',
			content:
				'Quantum hardware with 80 qubit counts and 99.7% fidelity rate, perfect for quantum algorithm development.',
			price: 0,
			cardimage: 'http://localhost:8080/3aeada74398ae6d53c535fbf80a445a9.svg',
			hardwareimage:
				"data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3e %3cpath fill-rule='evenodd' clip-rule='evenodd' d='M22.5 8.25V9.75H19.5V14.25H22.5V15.75H19.5V18C19.5 18.3978 19.342 18.7794 19.0607 19.0607C18.7794 19.342 18.3978 19.5 18 19.5H15.75V22.5H14.25V19.5H9.75V22.5H8.25V19.5H6C5.60218 19.5 5.22064 19.342 4.93934 19.0607C4.65804 18.7794 4.5 18.3978 4.5 18V15.75H1.5V14.25H4.5V9.75H1.5V8.25H4.5V6C4.5 5.60218 4.65804 5.22064 4.93934 4.93934C5.22064 4.65804 5.60218 4.5 6 4.5H8.25V1.5H9.75V4.5H14.25V1.5H15.75V4.5H18C18.3978 4.5 18.7794 4.65804 19.0607 4.93934C19.342 5.22064 19.5 5.60218 19.5 6V8.25H22.5ZM6 18H18V6H6V18ZM8.25 15.75V8.25H15.75V15.75H8.25ZM9.75 14.25H14.25V9.75H9.75V14.25Z' fill='%235552FF'/%3e %3c/svg%3e",
			statusimage:
				"data:image/svg+xml,%3csvg width='7' height='8' viewBox='0 0 7 8' fill='none' xmlns='http://www.w3.org/2000/svg'%3e %3ccircle cx='3.5' cy='4' r='3.5' fill='%2355D899'/%3e %3c/svg%3e",
			chipdata: [
				{
					key: 0,
					label: 'python'
				},
				{
					key: 1,
					label: 'react'
				},
				{
					key: 2,
					label: 'rust'
				},
				{
					key: 3,
					label: '+2'
				}
			],
			headData: {
				name: 'IBMQ_Manila',
				label: 'IM',
				desc: 'Quantum hardware with 80 qubit counts and 99.7% fidelity rate, perfect for quantum algorithm development.',
				count: '180',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			},
			requestDate: '2023-07-21T10:34:05.823Z',
			requestedBy: 'Test'
		},
		{
			type: 'hardware',
			category: 'Learning',
			hardwareId: 8,
			technology: 'IBM Quantum',
			per: 'shot',
			downloads: 210,
			name: 'IBMQ_Cairo',
			content:
				'Quantum hardware with 2 qubit counts and 99.9% fidelity rate, ideal for research in quantum physics with smaller queue times',
			price: 0.035,
			cardimage: 'http://localhost:8080/1598008f07084ff5dd52d5734ebff6d6.svg',
			hardwareimage:
				"data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3e %3cpath fill-rule='evenodd' clip-rule='evenodd' d='M22.5 8.25V9.75H19.5V14.25H22.5V15.75H19.5V18C19.5 18.3978 19.342 18.7794 19.0607 19.0607C18.7794 19.342 18.3978 19.5 18 19.5H15.75V22.5H14.25V19.5H9.75V22.5H8.25V19.5H6C5.60218 19.5 5.22064 19.342 4.93934 19.0607C4.65804 18.7794 4.5 18.3978 4.5 18V15.75H1.5V14.25H4.5V9.75H1.5V8.25H4.5V6C4.5 5.60218 4.65804 5.22064 4.93934 4.93934C5.22064 4.65804 5.60218 4.5 6 4.5H8.25V1.5H9.75V4.5H14.25V1.5H15.75V4.5H18C18.3978 4.5 18.7794 4.65804 19.0607 4.93934C19.342 5.22064 19.5 5.60218 19.5 6V8.25H22.5ZM6 18H18V6H6V18ZM8.25 15.75V8.25H15.75V15.75H8.25ZM9.75 14.25H14.25V9.75H9.75V14.25Z' fill='%235552FF'/%3e %3c/svg%3e",
			statusimage:
				"data:image/svg+xml,%3csvg width='7' height='8' viewBox='0 0 7 8' fill='none' xmlns='http://www.w3.org/2000/svg'%3e %3ccircle cx='3.5' cy='4' r='3.5' fill='%2355D899'/%3e %3c/svg%3e",
			chipdata: [
				{
					key: 0,
					label: 'python'
				},
				{
					key: 1,
					label: 'react'
				},
				{
					key: 2,
					label: 'rust'
				},
				{
					key: 3,
					label: '+2'
				}
			],
			headData: {
				name: 'IBMQ_Cairo',
				label: 'IC',
				desc: 'Quantum hardware with 2 qubit counts and 99.9% fidelity rate, ideal for research in quantum physics with smaller queue times',
				count: '210',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			},
			requestDate: '2023-07-21T10:34:07.047Z',
			requestedBy: 'Test'
		},
		{
			type: 'hardware',
			category: 'Healthcare',
			hardwareId: 4,
			technology: 'IonZ Quantum',
			per: 'shot',
			downloads: 300,
			name: 'IonZ_Vancouver',
			content:
				'Quantum hardware with 110 qubit counts and 99.7% fidelity rate, suitable for high precision quantum tasks.',
			price: 0.0275,
			hardwareimage:
				"data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3e %3cpath fill-rule='evenodd' clip-rule='evenodd' d='M22.5 8.25V9.75H19.5V14.25H22.5V15.75H19.5V18C19.5 18.3978 19.342 18.7794 19.0607 19.0607C18.7794 19.342 18.3978 19.5 18 19.5H15.75V22.5H14.25V19.5H9.75V22.5H8.25V19.5H6C5.60218 19.5 5.22064 19.342 4.93934 19.0607C4.65804 18.7794 4.5 18.3978 4.5 18V15.75H1.5V14.25H4.5V9.75H1.5V8.25H4.5V6C4.5 5.60218 4.65804 5.22064 4.93934 4.93934C5.22064 4.65804 5.60218 4.5 6 4.5H8.25V1.5H9.75V4.5H14.25V1.5H15.75V4.5H18C18.3978 4.5 18.7794 4.65804 19.0607 4.93934C19.342 5.22064 19.5 5.60218 19.5 6V8.25H22.5ZM6 18H18V6H6V18ZM8.25 15.75V8.25H15.75V15.75H8.25ZM9.75 14.25H14.25V9.75H9.75V14.25Z' fill='%235552FF'/%3e %3c/svg%3e",
			statusimage:
				"data:image/svg+xml,%3csvg width='7' height='8' viewBox='0 0 7 8' fill='none' xmlns='http://www.w3.org/2000/svg'%3e %3ccircle cx='3.5' cy='4' r='3.5' fill='%2355D899'/%3e %3c/svg%3e",
			chipdata: [
				{
					key: 0,
					label: 'python'
				},
				{
					key: 1,
					label: 'react'
				},
				{
					key: 2,
					label: 'rust'
				},
				{
					key: 3,
					label: '+2'
				}
			],
			headData: {
				name: 'IonZ_Vancouver',
				label: 'IV',
				desc: 'Quantum hardware with 110 qubit counts and 99.7% fidelity rate, suitable for high precision quantum tasks.',
				count: '300',
				created_date: '2-10-2022',
				last_build: '13-6-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			},
			requestDate: '2023-07-21T10:34:09.239Z',
			requestedBy: 'Test'
		},
		{
			type: 'hardware',
			category: 'Monitoring',
			hardwareId: 17,
			technology: 'Google Quantum',
			per: 'shot',
			downloads: 320,
			name: 'Google_Quantum4',
			content:
				'Quantum hardware with 115 qubit counts and 99.7% fidelity rate, perfect for advanced quantum computing tasks.',
			price: 0.03,
			hardwareimage:
				"data:image/svg+xml,%3csvg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3e %3cpath fill-rule='evenodd' clip-rule='evenodd' d='M22.5 8.25V9.75H19.5V14.25H22.5V15.75H19.5V18C19.5 18.3978 19.342 18.7794 19.0607 19.0607C18.7794 19.342 18.3978 19.5 18 19.5H15.75V22.5H14.25V19.5H9.75V22.5H8.25V19.5H6C5.60218 19.5 5.22064 19.342 4.93934 19.0607C4.65804 18.7794 4.5 18.3978 4.5 18V15.75H1.5V14.25H4.5V9.75H1.5V8.25H4.5V6C4.5 5.60218 4.65804 5.22064 4.93934 4.93934C5.22064 4.65804 5.60218 4.5 6 4.5H8.25V1.5H9.75V4.5H14.25V1.5H15.75V4.5H18C18.3978 4.5 18.7794 4.65804 19.0607 4.93934C19.342 5.22064 19.5 5.60218 19.5 6V8.25H22.5ZM6 18H18V6H6V18ZM8.25 15.75V8.25H15.75V15.75H8.25ZM9.75 14.25H14.25V9.75H9.75V14.25Z' fill='%235552FF'/%3e %3c/svg%3e",
			statusimage:
				"data:image/svg+xml,%3csvg width='7' height='8' viewBox='0 0 7 8' fill='none' xmlns='http://www.w3.org/2000/svg'%3e %3ccircle cx='3.5' cy='4' r='3.5' fill='%2355D899'/%3e %3c/svg%3e",
			chipdata: [
				{
					key: 0,
					label: 'python'
				},
				{
					key: 1,
					label: 'react'
				},
				{
					key: 2,
					label: 'rust'
				},
				{
					key: 3,
					label: '+2'
				}
			],
			headData: {
				name: 'Google_Quantum4',
				label: 'GQ',
				desc: 'Quantum hardware with 115 qubit counts and 99.7% fidelity rate, perfect for advanced quantum computing tasks.',
				count: '320',
				created_date: '2-10-2022',
				last_build: '5-6-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			},
			requestDate: '2023-07-21T10:34:10.703Z',
			requestedBy: 'Test'
		}
	],
	allHardwares: []
};

export const hardwareAdminSlice = createSlice({
	name: 'common',
	initialState,
	reducers: {
		addAccessRequestHardware: (state, action) => {
			const { hardware } = action.payload;
			const checkIndex = state.accessRequests?.findIndex(
				e => e?.hardwareId === hardware?.hardwareId && !e?.isDenied
			);
			if (checkIndex === -1) state.accessRequests.push(hardware);
		},
		markGrantedHardwareRequest: (state, action) => {
			const { request } = action.payload;
			const checkIndex = state.accessRequests?.findIndex(
				e => e?.hardwareId === request?.hardwareId && !e?.isDenied
			);
			if (checkIndex !== -1)
				state.accessRequests[checkIndex] = { ...state.accessRequests[checkIndex], isGranted: true };
		},
		markDeniedHardwareRequest: (state, action) => {
			const { request } = action.payload;
			const checkIndex = state.accessRequests?.findIndex(
				e => e?.hardwareId === request?.hardwareId && !e?.isDenied
			);
			if (checkIndex !== -1)
				state.accessRequests[checkIndex] = { ...state.accessRequests[checkIndex], isDenied: true };
		}
	}
});

export const { addAccessRequestHardware, markGrantedHardwareRequest, markDeniedHardwareRequest } =
	hardwareAdminSlice.actions;
