import React, { forwardRef, useEffect, useState } from 'react';
import { Box, Grid } from '@mui/material';
import { VirtuosoGrid } from 'react-virtuoso';
import HardwareCard from '../../../components/card/hardware/v2/hardwareCard';
import SubHeaderControls from '../../../components/subHeaderControls';
// import Icon from '../../../components/icon';
// import covLoader from '../../../assets/loaders/covLoader.svg';


// To control how the List and how each Item within the List are rendered and this object is needed.
const gridComponents = {
	List: forwardRef(({ style, children }, ref) => (  // List is the container.
		<Grid container
			ref={ref}
			style={{
				display: 'flex',
				flexWrap: 'wrap',
				...style
			}}
		>
			{children}
		</Grid>
	)),
	Item: ({ children }) => (  		// Each individual item
		<Grid item xs={12} sm={6} md={4} lg={4} xl={3}
			style={{
				padding: '0.5rem'
			}}
		>
			{children}
		</Grid>
	)
};

// Layout for all the items in the grid
const ItemWrapper = ({ children }) => (
	<Box
		style={{
			display: 'flex',
			width: '100%',
			cursor:'pointer'
		}}
	>
		{children}
	</Box>
);

const CustomHardwareCard = (data) => (
	<ItemWrapper width='200px'>
		<HardwareCard data={data} />
	</ItemWrapper>
);

function Hardware() {
	const [data, setData] = useState([]);
	const newData = [];
	// const [isLoading, setIsLoading] = useState(false);

	useEffect(() => {
		// setTimeout(() => {
			for (let i = 1; i <= 51; i++) {
				newData.push({
					id: i.toString(),
					title: 'A100 40Gb',
					status: 'online',
					cost: '$15/hr',
					parameters: {
						'Max CPU': '123',
						'Max Mem': '234GB',
						'GPUs': '1,2,4,10'
					},
					tags: ['covalent', 'nvidia', 'GPU'],
					created_date: '22-03-2024'
				});
			}
			setData(newData);
			// setIsLoading(true);
		// }, 2000);
	}, []);

	return (
		<>
			{/* {
				!isLoading && (
					<Box sx={{
						height: '62vh', display: 'flex', justifyContent: 'center', alignSelf: 'enter', border: theme => `1 px solid ${theme?.palette?.background?.blue03}`
					}}>
						<Icon type="pointer" src={covLoader} display="flex" />
					</Box>
				)
			} */}

			{/* {
				isLoading && ( */}

					<Box sx={{ height: '75vh' }}>
						<Box sx={{ marginBottom: '20px', alignItems: 'center' }}>
							<SubHeaderControls
								width="100%"
								filterComponent
								sortComponenet='true'
								sort=''
								setSort=''
								sortBy=''
								setSortBy=''
								searchValue=''
								setSearchValue=''
								placement={null}
								fromHardware='true'
							/>
						</Box>
						<Box sx={{
							height: '85%'
						}} >
							<VirtuosoGrid
								totalCount={data.length}
								components={gridComponents}
								overscan={100}
								itemContent={(index) => CustomHardwareCard(data[index])}
							/>
						</Box>
					</Box>
				{/* )
			} */}
		</>
	);
}

export default Hardware;
