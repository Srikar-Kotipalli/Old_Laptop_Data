/* eslint-disable react/jsx-boolean-value */
import React from 'react';
import { Box, Grid, Typography } from '@mui/material';
import Divider from '@mui/material/Divider';
import theme from '../../../theme';
import nvidia from '../../../assets/nvidia.svg';
import CopyButton from '../../../components/copyButton/index';
import Icon from '../../../components/icon';
import sucess from '../../../assets/SuccessIcon.svg';
import detail from '../../../assets/graph/qelectron.svg';
import metaIcon from '../../../assets/icons/metadata_hardware.svg';
import Button from '../../../components/primaryButton/index';
import SyntaxHighlighter from '../../../components/dashboard/dispatchCode';
import Statistics from '../../../components/dashboard/statistics';

function StyledDivider() {
	return (
		<Divider
			sx={{ borderColor: theme.palette.background.blue03, mt: 0, mb: 0 }}
			orientation="vertical"
			variant="middle"
			flexItem
		/>
	);
}

function HardwareDetail() {
	const code = 'import numpy as np \n \n x = np.linspace(0,1,100) \n np.sin(x**2)';
	const data = [
		{
			id: '1',
			title: 'Metadata1',
			units: '256 Units',
			description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras urna.'
		},
		{
			id: '2',
			title: 'Metadata2',
			units: '64 Units',
			description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras urna.'
		},
		{
			id: '3',
			title: 'Metadata3',
			units: '32 Units',
			description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras urna.'
		},
		{
			id: '4',
			title: 'Metadata4',
			units: '16 Units',
			description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras urna.'
		},
		{
			id: '5',
			title: 'Metadata5',
			units: '64 Units',
			description: 'NVIDIA: Advancing cutting-edge hardware technology for high-performance computing and graphics processing.'
		},
		{
			id: '6',
			title: 'Metadata6',
			units: '512 Units',
			description: 'NVIDIA: Advancing cutting-edge hardware technology for high-performance computing and graphics processing.'
		}
	];

	const menuItems = ['Last day', 'Last Week', 'Last Month', '3 Months', 'All Time'];
	return (
		<Grid container display="flex" justifyContent="space-between">
			<Grid container justifyContent="space-between">
				<Grid item display='flex' justifyContent='space-evenly' xs={5}>
					<Grid item xs={5}>
						<Typography color={theme.palette.text.gray03} fontSize="14px">
							Hardware
						</Typography>
						<Box display="flex" pb="6px">
							<Typography
								fontWeight="bold"
								color={theme.palette.text.secondary}
								fontSize="20px"
							>
								A100 40Gb
							</Typography>
							<Box sx={{ padding: '0px 4px 0px 4px' }}>
								<Icon src={sucess} alt="sucess" />
							</Box>
							<CopyButton
								content="A100 40Gb"
								borderEnable={false}
								placement="top"
								bgColor={theme.palette.background.blue14}
								padding="4px"
							/>
						</Box>
					</Grid>
					<StyledDivider />
					<Grid item xs={3} pl="9px">
						<Box>
							<Typography color={theme.palette.text.gray03} fontSize="14px">
								Cost
							</Typography>
							<Typography
								fontWeight="bold"
								color={theme.palette.text.secondary}
								fontSize="20px"
							>
								$12.3/hr
							</Typography>
						</Box>
					</Grid>
					<StyledDivider />
					<Grid item xs={3} pl="9px">
						<Box>
							<Typography color={theme.palette.text.gray03} fontSize="14px">
								Parameter
							</Typography>
							<Box>
								<Icon src={nvidia} alt="parameter" height="27px" width="90px" />
							</Box>
						</Box>
					</Grid>
				</Grid>
				<Grid item>
					<Box alignSelf="flex-end">
						<Button
							title="Request Access"
							variant="contained"
							bgColor={theme.palette.background.paper}
							borderisPresent="1px solid #6473FF"
							sx={{
								'&:hover': {
									backgroundColor: theme?.palette?.background?.covalentPurple,
									borderRadius: '25px',
									borderColor: theme?.palette?.background?.blue05
								}
							}}
						/>
					</Box>
				</Grid>
			</Grid>
			<Grid container m="20px 10px 0 0" sx={{ display: 'flex', justifyContent: 'space-between' }}>
				<Grid
					item
					xs={5}
					style={{ border: '1px solid #303067', borderRadius: '8px', paddingBottom: '45px', padding: '20px' }}
				>
					{/* Hardware Details */}
					<Box display="flex">
						<Icon src={detail} alt="details icon" />
						<Box sx={{ paddingLeft: '12px' }} alignSelf="center">
							<Typography fontSize="16px">Hardware Details</Typography>
						</Box>
					</Box>
					<Grid xs={6}>
						<Box display="flex" justifyContent="space-between" mt="25px">
							<Box
								fontSize="12px"
								sx={{ color: theme?.palette?.text?.gray03 }}
								width="70%"
							>
								Status
							</Box>
							<Box
								fontSize="16px"
								fontWeight="bold"
								sx={{ color: theme?.palette?.text?.success }}
								width="30%"
							>
								Online
							</Box>
						</Box>
						<Box display="flex" justifyContent="space-between" mt="25px">
							<Box
								fontSize="12px"
								sx={{ color: theme?.palette?.text?.gray03 }}
								width="70%"
							>
								Provider
							</Box>
							<Box
								fontSize="16px"
								fontWeight="bold"
								sx={{ color: theme?.palette?.text?.gray04 }}
								width="30%"
							>
								Covalent
							</Box>
						</Box>
						<Box display="flex" justifyContent="space-between" mt="25px">
							<Box
								fontSize="12px"
								sx={{ color: theme?.palette?.text?.gray03 }}
								width="70%"
							>
								Total Runtime
							</Box>
							<Box
								fontSize="16px"
								sx={{ color: theme?.palette?.text?.secondary }}
								width="30%"
							>
								21Hrs
							</Box>
						</Box>
						<Box display="flex" justifyContent="space-between" mt="25px">
							<Box
								fontSize="12px"
								sx={{ color: theme?.palette?.text?.gray03 }}
								width="70%"
							>
								Total Cost
							</Box>
							<Box
								fontSize="16px"
								sx={{ color: theme?.palette?.text?.secondary }}
								width="30%"
							>
								$3500
							</Box>
						</Box>
						<Box display="flex" justifyContent="space-between" mt="25px">
							<Box
								fontSize="12px"
								sx={{ color: theme?.palette?.text?.gray03 }}
								width="70%"
							>
								Parameter
							</Box>
							<Box
								fontSize="16px"
								sx={{ color: theme?.palette?.text?.secondary }}
								width="30%"
							>
								nvidia
							</Box>
						</Box>
					</Grid>
				</Grid>
				<Grid item xs={6.5} >
					{/* Graph */}
					<Statistics MenuItemArray={menuItems} fromHardware={true} />
				</Grid>
			</Grid>
			<Grid margin="15px 0 15px 0">
				<Box display="flex">
					<Icon src={detail} alt="details icon" />
					<Box sx={{ paddingLeft: '12px', mb: '12px' }} alignSelf="center">
						<Typography fontSize="16px">Usage Example</Typography>
					</Box>
				</Box>
				<SyntaxHighlighter code={code} launch={true} n="200" width="100%" bgColor="#04040A"/>
			</Grid>
			<Grid margin="15px 0 15px 0">
				<Box display="flex">
					<Icon src={detail} alt="details icon" />
					<Box sx={{ paddingLeft: '12px', mb: '25px' }} alignSelf="center">
						<Typography variant='h4' color={theme.palette.text.primary}>Metadata</Typography>
					</Box>
				</Box>
				<Grid container style={{ border: `1px solid ${theme.palette.background.blue03}`, borderRadius: '8px', padding: '20px', display: 'flex', justifyContent: 'space-around' }}>
					{
						// MetaData
						data.map((item, index, array) => (
							<>
								<Grid item xs={1.75} sx={{ display: 'flex', alignItems: 'center', mb: index !== array.length - 1 ? 2 : 0 }}>
									<Icon src={metaIcon} alt=" metadata icon" />
									<Typography variant='h2' >
										{item.title}
									</Typography>
								</Grid>
								<Grid item xs={1.25} sx={{ display: 'flex', alignItems: 'center', mb: index !== array.length - 1 ? 2 : 0 }}>
									<Typography variant='h2' >
										{item.units}
									</Typography>
								</Grid>
								<StyledDivider />
								<Grid item xs={8} sx={{ display: 'flex', alignItems: 'center', ml: '9px', mb: index !== array.length - 1 ? 2 : 0 }} >
									<Typography variant='h2' >
										{item.description}
									</Typography>
								</Grid>
							</>
						))
					}
				</Grid>
			</Grid>
		</Grid>
	);
}

export default HardwareDetail;
