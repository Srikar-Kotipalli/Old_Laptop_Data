/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { Grid, Typography, Tooltip, Box } from '@mui/material';
import { useDebounce } from 'use-debounce';
import Pagination from '@mui/material/Pagination';
import Backdrop from '@mui/material/Backdrop';
import React, { useState, useEffect } from 'react';
import ScrollToTopButton from '../../../components/scrollToTopButton';
import BorderButton from '../../../components/primaryButton/environments';
import Icon from '../../../components/icon';
import Add from '../../assets/actions/add.svg';
import SearchInput from '../../../components/inputBase/projects/searchInput';
import covLoader from '../../assets/loaders/covLoader.svg';
import EnvAccordion from '../../../components/accordion';
import CustomisedSnackbar from '../../../components/snackbar/projects';
import {
	getBatchEnvironments,
	getDefaultEnvironment
} from '../../../api/environments/environmentsApi';

function Environments() {
	const [accordionData, setAccordianData] = useState({});
	const [openLoader, setOpenLoader] = useState(false);
	const [reloadBatch, setReloadBatch] = useState(true);
	const [searchKey, setSearchKey] = React.useState('');
	const [searchValue] = useDebounce(searchKey, 1000);
	// pagination state variables
	const [page, setPage] = useState(1);
	const [totalRecords, setTotalRecords] = useState(0);
	const [openSnackbar, setOpenSnackbar] = React.useState(false);
	const [snackbarMessage, setSnackbarMessage] = React.useState('');

	const cancelSearch = () => {
		setSearchKey('');
		setOpenLoader(true);
	};

	const postGetBatch = response => {
		getDefaultEnvironment()
			.then(resDefault => {
				const indexDefault = response?.records?.findIndex(e => e.id === resDefault?.environment_id);
				if (resDefault?.environment_id && indexDefault !== -1) {
					const records = response?.records;
					records[indexDefault]['default'] = true;
					response.records = records;
					setAccordianData(response);
					setTotalRecords(response?.metadata?.total_count);
				} else {
					setAccordianData(response);
					setTotalRecords(response?.metadata?.total_count);
				}
				setOpenLoader(false);
			})
			.catch(() => {
				setAccordianData(response);
				setTotalRecords(response?.metadata?.total_count);
				setOpenLoader(false);
			});
	};

	useEffect(() => {
		setOpenLoader(true);
		getBatchEnvironments(10, page - 1, searchValue)
			.then(response => {
				postGetBatch(response);
			})
			.catch(() => {
				postGetBatch({});
			});
	}, [reloadBatch, page, searchValue]);

	const handlePageChange = (_event, pageValue) => {
		setPage(pageValue);
	};

	const addNewEnv = () => {
		const resData = { ...accordionData };
		const envArray = resData?.records || [];
		const checkAddEnvsIndex = envArray?.findIndex(e => e?.isAddMode === true || e?.mode === 'edit');
		if (checkAddEnvsIndex === -1) {
			envArray?.unshift({
				id: '',
				name: '',
				definition: '',
				status: 'IN_PROGRESS',
				isAddMode: true,
				isAddTitle: true,
				modeInput: 'add'
			});
			resData['records'] = [...envArray];
			setAccordianData(resData);
			setOpenLoader(false);
		} else {
			setSnackbarMessage('Please add/edit one environment at a time');
			setOpenSnackbar(true);
		}
	};

	return (
		<>
			<Backdrop open={openLoader} sx={{ zIndex: 2000, backgroundColor: 'rgba(0,0,0,0.85)' }}>
				<Icon type="pointer" src={covLoader} />
			</Backdrop>
			<CustomisedSnackbar
				testId="envSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			<Grid>
				<Grid container direction="row" alignItems="center" justifyContent="flex-end">
					<Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
						{/* <BorderButton title="Show" img={Show} padding={0.3} paddingLeft={1} /> */}
						<BorderButton
							title="Add New"
							img={Add}
							padding={0.3}
							paddingLeft={0.7}
							handler={addNewEnv}
							overallMargin="0 30px 0 0px"
						/>
						<SearchInput
							sx={{
								border: '1px solid #303067',
								borderRadius: '20px',
								width: '258px',
								height: '32.69px',
								'&.Mui-focused ': {
									border: '1px solid #6473ff'
								}
							}}
							value={searchKey || ''}
							onChange={e => setSearchKey(e.target.value)}
							cancelSearch={cancelSearch}
							// sx={{
							// 	border: '1px solid',
							// 	borderColor: theme => theme.palette.background.blue05,
							// 	width: '228px',
							// 	height: '32px',
							// 	borderRadius: '18px'
							// }}
						/>
					</Box>
				</Grid>
				<Grid>
					{!openLoader &&
						accordionData &&
						accordionData?.records?.length > 0 &&
						accordionData?.records.map(data => (
							<Grid key={data?.name}>
								<EnvAccordion
									accordianData={data}
									modeInput={data?.modeInput || ''}
									setAccordianData={setAccordianData}
									setReloadBatch={setReloadBatch}
									entireData={accordionData}
								/>
							</Grid>
						))}
					{accordionData && (!accordionData?.records || accordionData?.records?.length === 0) && (
						<Grid item mt="12%" ml="37%">
							<Typography
								sx={{
									fontSize: '20px',
									letterSpacing: '0.05em',
									fontWeight: 700
								}}
							>
								No Environments Found
							</Typography>
						</Grid>
					)}
				</Grid>
			</Grid>
			<Grid container className="footer" data-testid="tableFooter" sx={{ mb: 4 }}>
				<Pagination
					color="primary"
					shape="rounded"
					variant="outlined"
					count={totalRecords && totalRecords > 10 ? Math.ceil(totalRecords / 10) : 1}
					page={page}
					onChange={handlePageChange}
					showFirstButton
					showLastButton
					siblingCount={2}
					boundaryCount={2}
					data-testid="paginationItem"
				/>
				<Tooltip title="Scroll to top">
					<Grid>
						<ScrollToTopButton data-testid="scrollToTopButton" />
					</Grid>
				</Tooltip>
			</Grid>
		</>
	);
}

export default Environments;
