/* eslint-disable react/jsx-boolean-value */
/* eslint-disable import/no-unused-modules */
/* eslint-disable no-shadow */
/* eslint-disable react/jsx-props-no-spreading */
import React, { useState } from 'react';
import { Box, Grid, Input, InputBase, Button, Typography, Tooltip } from '@mui/material';
import Icon from '../../../components/icon';
import SearchIcon from '../../../assets/actions/search.svg';
import PipInfoCard from '../../../components/card/environments/v2/pipInfoCard';
import YamlEditor from '../../../components/aceEditor';
import { capitalizeName } from '../../../utils/utils';
import useUpdateEffect from '../../../utils/useUpdateEffect';

function EditorWithPreview({ content, setContent, tabValue, variant, newDelimeter }) {
	const [inputValue, setInputValue] = useState('');
	// eslint-disable-next-line no-unused-vars
	const [searchQuery, setSearchQuery] = useState('');
	const [isEditing, setIsEditing] = useState(new Array(content?.length).fill(false));
	const [inputValidation, setInputValidation] = useState(false);
	const contentArray = content?.split('\n')?.filter(v => v !== '');
	const uniqueArr = contentArray?.filter((item, index) => contentArray?.indexOf(item) === index);

	useUpdateEffect(() => {
		setInputValidation(false);
	}, [inputValue]);

	const filteredData = uniqueArr?.filter(item =>
		item.toLowerCase().includes(searchQuery.toLowerCase())
	);

	const handleDragEnd = updatedData => {
		// Update the content with the reordered data
		setContent(updatedData);
	};

	const handleInputChange = event => {
		setInputValue(event.target.value);
	};

	const handleEdit = (index, newText) => {
		const updatedItems = contentArray.map((item, i) => {
			if (i === index) {
				return newText;
			}
			return item;
		});
		setContent(updatedItems);
	};

	const concated = `${content}\n${inputValue}`;
	const concatedArray = concated?.split('\n');
	const uniqueConcatedArr = concatedArray?.filter(
		(item, index) => concatedArray?.indexOf(item) === index
	);

	const validateInput = () => {
		if (inputValue.trim() === '') {
			setInputValidation(true);
			setTimeout(() => setInputValidation(false), 3000);
		}
	};

	const addInputToEditor = () => {
		setContent(uniqueConcatedArr?.filter(v => v !== ''));
		validateInput();
		setInputValue('');
	};

	const handleInputEnter = event => {
		const updatedEditing = new Array(filteredData?.length).fill(false);
		setIsEditing(updatedEditing);
		if (event.key === 'Enter') {
			addInputToEditor();
		}
	};

	const handleDelete = index => {
		const deletion = [...filteredData];
		deletion.splice(index, 1);
		setContent(deletion);
	};

	const handleEditorChange = newValue => {
		// You can do something with the new content here
		const updatedEditing = new Array(filteredData?.length).fill(false);
		setIsEditing(updatedEditing);
		const ContArray = newValue?.split('\n');
		const uniqueContArr = ContArray?.filter(
			(item, index) => ContArray?.indexOf(item) === index
		).map(item => item.trim());
		setContent(uniqueContArr);
		// setContent(newValue);
	};

	return (
		<Grid container spacing={3} paddingBottom="35px">
			<Grid item xs={6}>
				<Grid
					paddingBottom={inputValidation ? '7px' : '25px'}
					paddingTop="25px"
					display="flex"
					justifyContent="space-between"
				>
					<Box width="87%">
						<Input
							sx={{
								padding: '8px 12px',
								height: '32px',
								width: '87%',
								border: inputValidation ? '1px solid #FF6464' : '1px solid #303067',
								borderRadius: '60px',
								fontSize: '14px',
								color: '#CBCBD7',
								background: '#08081A'
							}}
							placeholder="Type here to add packages"
							value={inputValue}
							onChange={handleInputChange}
							onKeyDown={handleInputEnter}
							disableUnderline
						/>
						<Typography sx={{ color: '#FF6464', fontSize: '12px' }}>
							{inputValidation && 'Package name cannot be empty'}
						</Typography>
					</Box>
					<Tooltip title="Add">
						<Button
							sx={{
								color: '#CBCBD7',
								background: '#5552FF',
								borderRadius: '20px',
								width: '41px',
								height: '30px',
								fontSize: '14px',
								minWidth: '0px !important',
								'&:hover': {
									backgroundColor: theme => theme.palette.background.blue14
								}
							}}
							onClick={addInputToEditor}
						>
							<Typography fontSize="21px">+</Typography>
						</Button>
					</Tooltip>
				</Grid>
				<YamlEditor
					// onChange={value => setContent(value.split('\n'))}
					onChange={handleEditorChange}
					value={content}
					height="320px"
					color="#52886E"
				/>
			</Grid>
			<Grid item xs={6}>
				<Grid sx={{ border: '1px solid #303067' }}>
					<Grid display="flex" justifyContent="space-between" padding="20px 12px 20px 12px ">
						<Box display="grid" alignContent="center">
							<Typography ml={0.5} color="#6D7CFF" fontSize="16px">
								{capitalizeName(tabValue)}
							</Typography>
						</Box>

						<InputBase
							placeholder="Search"
							value={searchQuery}
							onChange={e => setSearchQuery(e.target.value)}
							startAdornment={<Icon src={SearchIcon} alt="Search" style={{ paddingTop: '4px' }} />}
							sx={{
								color: 'rgba(203, 203, 215, 1)',
								border: '1px solid rgba(48, 48, 103, 1)',
								borderRadius: '60px',
								padding: '4px',
								height: '32px',
								width: '45%'
							}}
						/>
					</Grid>
					<Grid sx={{ height: '300px', overflowY: 'auto' }} pl={1} pr={3} mb={3}>
						<PipInfoCard
							onDragEnd={handleDragEnd}
							newDelimeter={newDelimeter}
							// data={filteredData.filter(v => v !== '')}
							data={filteredData}
							value={true}
							editIcon={true}
							deleteIcon={true}
							deleteHandle={handleDelete}
							editHandle={handleEdit}
							variant={variant}
							isEditing={isEditing}
							setIsEditing={setIsEditing}
						/>
					</Grid>
				</Grid>
			</Grid>
		</Grid>
	);
}

export default EditorWithPreview;
