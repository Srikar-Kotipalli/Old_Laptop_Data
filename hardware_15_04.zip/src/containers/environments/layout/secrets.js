/* eslint-disable react/jsx-no-useless-fragment */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import {
	TableCell,
	Typography,
	Grid,
	TableSortLabel,
	Tooltip,
	Box,
	useMediaQuery
} from '@mui/material';
import React, { useEffect, useState } from 'react';
import { stringReducer } from '../../../utils/utils';
import {
	// getSecrets,
	deleteSecrets,
	createSecrets
} from '../../../api/environments/environmentsApi';
import AddSceret from './addSecret';
import VirtuosoTable from '../../../components/virtuosoTable';
import CopyButton from '../../../components/copyButton';
import EditIcon from '../../../assets/actions/edit.svg';
import DeleteIcon from '../../../assets/actions/delete.svg';
import DeleteDisabled from '../../../assets/actions/deleteDisabled.svg';
import NoSecretsFoundIcon from '../../../assets/secretsArchieveIcon.svg';
import Icon from '../../../components/icon';
import MarketplaceDialogBox from '../../../components/dialogBox/marketplace';
import { EnvironmentContext } from '../contexts/EnivironmentsContext';
import Loader from '../../../components/loader';
import CustomisedSnackbar from '../../../components/snackbar/projects';

const headers = [
	{
		id: 'secret',
		getter: 'secret',
		label: 'Secret',
		sortable: true,
		width: '40%',
		align: 'left'
	},
	{
		id: 'actions',
		getter: 'actions',
		label: 'Actions',
		align: 'center'
	}
];

function ResultsTableHead({ order, orderBy, onSort }) {
	return (
		<>
			{headers?.map((header, index) => {
				return (
					<TableCell
						key={header?.id}
						style={{
							width: header?.width,
							textAlign: header?.align,
							fontSize: '12px',
							cursor: header?.id === 'actions' ? 'default' : null
						}}
					>
						{header?.sortable ? (
							<TableSortLabel
								data-testid="tableHeader"
								active={orderBy === header?.id}
								direction={orderBy === header?.id ? order : 'asc'}
								onClick={() => onSort(header?.id)}
								sx={{
									paddingLeft: index === 0 ? 0.7 : 0,
									paddingRight: header?.padding,
									fontSize: '12px',
									'.Mui-active': {
										color: theme => theme?.palette?.text?.tertiary
									}
								}}
							>
								{header?.label}
							</TableSortLabel>
						) : (
							<Box sx={{ cursor: header?.id === 'actions' ? 'default' : null }}>
								{header?.label}
							</Box>
						)}
					</TableCell>
				);
			})}
		</>
	);
}

const RenderRows = ({ user, onEditIconHandler, onDeleteIconHandler, mode, editSecretName }) => {
	return (
		<>
			<TableCell
				style={{
					borderColor: 'transparent',
					background:
						mode === 'edit' && editSecretName === user ? 'rgba(48, 48, 103, 0.6)' : 'transparent',
					width: '50%',
					cursor: 'default'
				}}
				key={user}
			>
				<Grid
					sx={{
						fontSize: '14px',
						display: 'flex',
						alignItems: 'center'
					}}
				>
					<Tooltip title={user?.length > 20 ? user : null} placement="right">
						<Typography
							component="span"
							sx={{
								mx: 1,
								verticalAlign: 'middle',
								fontSize: '14px',
								color: theme => theme?.palette?.text?.primary
							}}
						>
							{stringReducer(user, 20)}
						</Typography>
					</Tooltip>
				</Grid>
			</TableCell>
			<TableCell
				style={{
					width: '18.333333%',
					borderColor: 'transparent',
					textAlign: 'center',
					fontSize: '14px',
					background:
						mode === 'edit' && editSecretName === user ? 'rgba(48, 48, 103, 0.6)' : 'transparent',
					cursor: 'default'
				}}
			>
				<Box sx={{ display: 'flex', justifyContent: 'center' }}>
					<CopyButton
						content={user}
						placement="bottom"
						padding="4px"
						margin="0px 20px 0px 0px"
						bgColor="#08081a"
					/>
					<Icon
						src={EditIcon}
						bgColor="#08081a"
						backgroundColor={mode === 'edit' && editSecretName === user ? '#08081a' : 'transparent'}
						padding="4px"
						type="pointer"
						title="Edit"
						margin="0px 20px 0px 0px"
						clickHandler={() => onEditIconHandler(user)}
					/>
					<Icon
						src={mode === 'edit' ? DeleteDisabled : DeleteIcon}
						disabled={mode === 'edit'}
						bgColor="#08081a"
						padding="4px"
						type="pointer"
						title={mode === 'edit' ? '' : 'Delete'}
						clickHandler={() => onDeleteIconHandler(user)}
					/>
				</Box>
			</TableCell>
		</>
	);
};

function Secrets({ searchKey, setSearchKey }) {
	const environmentContext = React.useContext(EnvironmentContext);
	const {
		storedData,
		count,
		openSecretLoader,
		setFetchApi,
		secretsData,
		setSecretsData,
		fetchApi,
		fetchSecretsApi,
		setOpenSecretLoader
	} = environmentContext;

	const [mode, setMode] = useState('create');
	const [sortColumn, setSortColumn] = useState('secret');
	const [sortOrder, setSortOrder] = useState('desc');
	const [openDialogBox, setOpenDialogBox] = useState(false);
	const [deleteSecret, setDeleteSecret] = useState(false);
	const [selectedName, setSelectedName] = useState('');
	const [secretName, setSecretName] = useState('');
	const [label, setLabel] = useState('');

	const [snackbarOpen, setSnackbarOpen] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState('');
	const [error, setError] = useState('');
	const [editSecretName, setEditSecretName] = useState('');
	const [disableSaveButton, setDisableSaveButton] = useState(false);

	useEffect(() => {
		return () => {
			setSecretName('');
			setLabel('');
		};
	}, []);

	useEffect(() => {
		setOpenSecretLoader(true);
		fetchSecretsApi();
	}, [fetchApi]);

	useEffect(() => {
		const filteredAndSortedData = storedData
			.filter(item => item?.toLowerCase().includes(searchKey?.toLowerCase()))
			.sort((a, b) => (sortOrder === 'asc' ? a?.localeCompare(b) : b?.localeCompare(a)));

		setSecretsData(filteredAndSortedData);
	}, [searchKey, sortOrder]);

	const handleChangeSort = column => {
		const isAsc = sortColumn === column && sortOrder === 'asc';
		setSortOrder(isAsc ? 'desc' : 'asc');
		setSortColumn(column);
	};

	const onDeleteIconHandler = name => {
		setOpenDialogBox(true);
		setDeleteSecret(true);
		setSelectedName(name);
	};

	const onEditIconHandler = name => {
		setMode('edit');
		setLabel('');
		setEditSecretName(name);
		setError('');
	};

	const deleteSecretHandler = async () => {
		setDisableSaveButton(true);
		await deleteSecrets(selectedName)
			.then(() => {
				setSnackbarOpen(true);
				setSnackbarMessage(`Secret ${selectedName} deleted successfully`);
			})
			.catch(err => console.error(err))
			.finally(() => {
				setSearchKey('');
				setDisableSaveButton(false);
				setOpenDialogBox(false);
				setSelectedName('');
				setFetchApi(prev => !prev);
				setMode('create');
				setSecretName('');
				setLabel('');
				setEditSecretName('');
			});
	};

	const createSecretHandler = async () => {
		setDisableSaveButton(true);
		const bodyParameters = {
			name: secretName,
			value: label
		};
		await createSecrets(bodyParameters)
			.then(() => {
				setSnackbarOpen(true);
				setSnackbarMessage(
					mode === 'edit'
						? ` Secret ${secretName} edited successfully`
						: `Secret ${secretName} created successfully`
				);
			})
			.catch(err => {
				setSnackbarOpen(true);
				console.error(err?.detail);
				if (err?.detail === 'Forbidden: At most 101 secrets allowed')
					setSnackbarMessage(
						'Limit of 100 secrets has been reached. Delete some secrets to create new ones.'
					);
				else setSnackbarMessage(err?.detail);
			})
			.finally(() => {
				setDisableSaveButton(false);
			});

		setFetchApi(prev => !prev);
		setOpenDialogBox(false);
		setSecretName('');
		setLabel('');
		setMode('create');
		setError('');
		setSearchKey('');
		setEditSecretName('');
	};

	const snackbarClose = () => {
		setSnackbarOpen(false);
	};

	const isWideScreen = useMediaQuery('(min-height: 1000px)');
	const isMediumScreen = useMediaQuery('(min-height: 900px)');
	const isMediumScreen2 = useMediaQuery('(min-height: 850px)');

	const getHeightByScreenHeight = () => {
		if (isWideScreen) {
			return '62vh';
		} else if (isMediumScreen) {
			return '58vh';
		} else if (isMediumScreen2) {
			return '55vh';
		}
		return '50vh';
	};

	return (
		<Grid container sx={{ width: '100vw' }} mt={3} spacing={2}>
			<CustomisedSnackbar
				message={snackbarMessage}
				open={snackbarOpen}
				onClose={snackbarClose}
				clickHandler={snackbarClose}
			/>
			<MarketplaceDialogBox
				openDialogBox={openDialogBox}
				setOpenDialogBox={setOpenDialogBox}
				handler={
					deleteSecret
						? deleteSecretHandler
						: mode === 'create'
						? createSecretHandler
						: createSecretHandler
				}
				disableSaveButton={disableSaveButton}
				title={
					deleteSecret ? 'Delete Secret' : mode === 'create' ? 'Create a new secret' : 'Edit secret'
				}
				message={
					deleteSecret ? (
						<>
							<Typography sx={{ display: 'flex' }}>Are you sure about deleting secret</Typography>
							<Typography px={0.5} sx={{ display: 'flex', fontWeight: 'bold' }}>
								{selectedName}
							</Typography>
							?
						</>
					) : mode === 'create' ? (
						<>
							<Typography sx={{ display: 'flex' }}>
								{' '}
								Are you sure about creating a new secret
							</Typography>
							<Typography px={0.5} sx={{ display: 'flex', fontWeight: 'bold' }}>
								{secretName}
							</Typography>
							?
						</>
					) : (
						<>
							<Typography sx={{ display: 'flex' }}> Are you sure about editing</Typography>
							<Typography px={0.5} sx={{ display: 'flex', fontWeight: 'bold' }}>
								{secretName}
							</Typography>
							?
						</>
					)
				}
				confirmButtonTitle={deleteSecret ? 'Delete' : mode === 'create' ? 'Create' : 'Edit'}
			/>
			{openSecretLoader && <Loader isFetching={openSecretLoader} width="100%" height="100%" />}
			{!openSecretLoader && (
				<>
					<Grid item xs={4}>
						<>
							{secretsData && secretsData?.length < 1 && !openSecretLoader ? (
								<Box
									mt={2}
									sx={{
										width: '100%',
										height: '220px',
										borderRadius: '8px',
										display: 'flex',
										justifyContent: 'center',
										alignItems: 'center',
										flexDirection: 'column',
										border: theme => `1px solid ${theme?.palette?.background?.blue03}`
									}}
								>
									<Icon src={NoSecretsFoundIcon} type="static" alt="noSecretsIcon" />
									<Typography variant="h2" mt="22px">
										No Secrets to show
									</Typography>
								</Box>
							) : (
								secretsData && (
									<VirtuosoTable
										data={secretsData}
										ResultsTableHead={ResultsTableHead}
										RenderRows={RenderRows}
										editSecretName={editSecretName}
										sortColumn={sortColumn}
										mode={mode}
										sortOrder={sortOrder}
										handleChangeSort={handleChangeSort}
										height={getHeightByScreenHeight()}
										limit={7}
										onDeleteIconHandler={onDeleteIconHandler}
										onEditIconHandler={onEditIconHandler}
									/>
								)
							)}
						</>
					</Grid>
					<Grid container item xs={8} direction="row" justifyContent="center">
						<AddSceret
							setSnackbarMessage={setSnackbarMessage}
							setSnackbarOpen={setSnackbarOpen}
							mode={mode}
							secretsData={secretsData}
							setMode={setMode}
							setOpenDialogBox={setOpenDialogBox}
							setDeleteSecret={setDeleteSecret}
							secretName={secretName}
							setSecretName={setSecretName}
							label={label}
							setLabel={setLabel}
							setFetchApi={setFetchApi}
							count={count}
							error={error}
							setError={setError}
							editSecretName={editSecretName}
							fetchApi={fetchApi}
							setEditSecretName={setEditSecretName}
							storedData={storedData}
						/>
					</Grid>
				</>
			)}
		</Grid>
	);
}

export default Secrets;
