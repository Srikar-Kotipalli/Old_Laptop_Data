import { Box, Grid, Typography } from '@mui/material';
import React from 'react';
import Utilization from '../../../components/solvers/overview/utilization';
import Cost from '../../../components/solvers/overview/cost';
import SolversUtilization from '../../../components/solvers/overview/solvesUtilization';
import RecentSolvers from './recentsolvers';
import ActivityList from '../../../components/sidebar/projects/activityList';

function SolversOverview({ solversCardClick }) {
	const activityList = [
		{
			tenant_id: null,
			message: 'Dispatch 67ff875e-fb36-428f-accc-a2ecac643312 has failed',
			sub_category: 'FAILED',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T11:02:40.928053',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: '67ff875e-fb36-428f-accc-a2ecac643312',
			category: 'Dispatch',
			title: '67ff875e-fb36-428f-accc-a2ecac643312'
		},
		{
			tenant_id: null,
			message: 'Dispatch 7e64f4b7-b714-4b06-a16a-85f08d7fa7c3 has failed',
			sub_category: 'FAILED',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T11:02:29.885997',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: '7e64f4b7-b714-4b06-a16a-85f08d7fa7c3',
			category: 'Dispatch',
			title: '7e64f4b7-b714-4b06-a16a-85f08d7fa7c3'
		},
		{
			tenant_id: null,
			message: 'Dispatch 67ff875e-fb36-428f-accc-a2ecac643312 is running',
			sub_category: 'RUNNING',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T11:02:15.083105',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: '67ff875e-fb36-428f-accc-a2ecac643312',
			category: 'Dispatch',
			title: '67ff875e-fb36-428f-accc-a2ecac643312'
		},
		{
			tenant_id: null,
			message: 'Dispatch 7e64f4b7-b714-4b06-a16a-85f08d7fa7c3 is running',
			sub_category: 'RUNNING',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T11:01:57.548104',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: '7e64f4b7-b714-4b06-a16a-85f08d7fa7c3',
			category: 'Dispatch',
			title: '7e64f4b7-b714-4b06-a16a-85f08d7fa7c3'
		},
		{
			tenant_id: null,
			message: 'Dispatch 1e079095-fc58-4232-b3ba-ba35b122b778 has failed',
			sub_category: 'FAILED',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T11:01:19.168857',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: '1e079095-fc58-4232-b3ba-ba35b122b778',
			category: 'Dispatch',
			title: '1e079095-fc58-4232-b3ba-ba35b122b778'
		},
		{
			tenant_id: null,
			message: 'Dispatch ec59473b-1fa3-44be-9d1b-066267bae9a8 has failed',
			sub_category: 'FAILED',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T11:00:56.105831',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: 'ec59473b-1fa3-44be-9d1b-066267bae9a8',
			category: 'Dispatch',
			title: 'ec59473b-1fa3-44be-9d1b-066267bae9a8'
		},
		{
			tenant_id: null,
			message: 'Dispatch 1e079095-fc58-4232-b3ba-ba35b122b778 is running',
			sub_category: 'RUNNING',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T11:00:53.025272',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: '1e079095-fc58-4232-b3ba-ba35b122b778',
			category: 'Dispatch',
			title: '1e079095-fc58-4232-b3ba-ba35b122b778'
		},
		{
			tenant_id: null,
			message: 'Dispatch ec59473b-1fa3-44be-9d1b-066267bae9a8 is running',
			sub_category: 'RUNNING',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T11:00:23.555639',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: 'ec59473b-1fa3-44be-9d1b-066267bae9a8',
			category: 'Dispatch',
			title: 'ec59473b-1fa3-44be-9d1b-066267bae9a8'
		},
		{
			tenant_id: null,
			message: 'Dispatch aa08cd91-7f0b-4849-9999-fd338f52b702 has failed',
			sub_category: 'FAILED',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T11:00:07.494359',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: 'aa08cd91-7f0b-4849-9999-fd338f52b702',
			category: 'Dispatch',
			title: 'aa08cd91-7f0b-4849-9999-fd338f52b702'
		},
		{
			tenant_id: null,
			message: 'Dispatch aa08cd91-7f0b-4849-9999-fd338f52b702 is running',
			sub_category: 'RUNNING',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T10:59:36.712106',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: 'aa08cd91-7f0b-4849-9999-fd338f52b702',
			category: 'Dispatch',
			title: 'aa08cd91-7f0b-4849-9999-fd338f52b702'
		},
		{
			tenant_id: null,
			message: 'Dispatch 73746712-be09-41bc-b429-7b4ecbe6dc2a has failed',
			sub_category: 'FAILED',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T10:58:37.169868',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: '73746712-be09-41bc-b429-7b4ecbe6dc2a',
			category: 'Dispatch',
			title: '73746712-be09-41bc-b429-7b4ecbe6dc2a'
		},
		{
			tenant_id: null,
			message: 'Dispatch 5c7a1c64-6f22-48ee-98a8-411d4a70bbd0 has failed',
			sub_category: 'FAILED',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T10:58:26.258950',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: '5c7a1c64-6f22-48ee-98a8-411d4a70bbd0',
			category: 'Dispatch',
			title: '5c7a1c64-6f22-48ee-98a8-411d4a70bbd0'
		},
		{
			tenant_id: null,
			message: 'Dispatch 5c7a1c64-6f22-48ee-98a8-411d4a70bbd0 is running',
			sub_category: 'RUNNING',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T10:58:26.158508',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: '5c7a1c64-6f22-48ee-98a8-411d4a70bbd0',
			category: 'Dispatch',
			title: '5c7a1c64-6f22-48ee-98a8-411d4a70bbd0'
		},
		{
			tenant_id: null,
			message: 'Dispatch 73746712-be09-41bc-b429-7b4ecbe6dc2a is running',
			sub_category: 'RUNNING',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T10:58:17.311094',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: '73746712-be09-41bc-b429-7b4ecbe6dc2a',
			category: 'Dispatch',
			title: '73746712-be09-41bc-b429-7b4ecbe6dc2a'
		},
		{
			tenant_id: null,
			message: 'Dispatch 5c7a1c64-6f22-48ee-98a8-411d4a70bbd0 is running',
			sub_category: 'RUNNING',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T10:57:47.547266',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: '5c7a1c64-6f22-48ee-98a8-411d4a70bbd0',
			category: 'Dispatch',
			title: '5c7a1c64-6f22-48ee-98a8-411d4a70bbd0'
		},
		{
			tenant_id: null,
			message: 'Dispatch e59fc9c0-e937-403c-8c71-27dcba65a228 has failed',
			sub_category: 'FAILED',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T10:56:59.686165',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: 'e59fc9c0-e937-403c-8c71-27dcba65a228',
			category: 'Dispatch',
			title: 'e59fc9c0-e937-403c-8c71-27dcba65a228'
		},
		{
			tenant_id: null,
			message: 'Dispatch e59fc9c0-e937-403c-8c71-27dcba65a228 is running',
			sub_category: 'RUNNING',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T10:56:36.278438',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: 'e59fc9c0-e937-403c-8c71-27dcba65a228',
			category: 'Dispatch',
			title: 'e59fc9c0-e937-403c-8c71-27dcba65a228'
		},
		{
			tenant_id: null,
			message: 'Dispatch 8bfffb07-099d-4384-a153-9a166231e80a has failed',
			sub_category: 'FAILED',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T10:56:20.371250',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: '8bfffb07-099d-4384-a153-9a166231e80a',
			category: 'Dispatch',
			title: '8bfffb07-099d-4384-a153-9a166231e80a'
		},
		{
			tenant_id: null,
			message: 'Dispatch 8bfffb07-099d-4384-a153-9a166231e80a is running',
			sub_category: 'RUNNING',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T10:55:55.364949',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: '8bfffb07-099d-4384-a153-9a166231e80a',
			category: 'Dispatch',
			title: '8bfffb07-099d-4384-a153-9a166231e80a'
		},
		{
			tenant_id: null,
			message: 'Dispatch 054b4b44-8147-4ab3-b040-84a5285ee19e has failed',
			sub_category: 'FAILED',
			experiment_id: 'None',
			project_id: 'None',
			created_at: '2023-06-07T10:55:52.424770',
			owner_id: '8b49a762-8760-4e69-bab3-84979fa1726f',
			item_id: '054b4b44-8147-4ab3-b040-84a5285ee19e',
			category: 'Dispatch',
			title: '054b4b44-8147-4ab3-b040-84a5285ee19e'
		}
	];

	return (
		<Box>
			<Grid container columnSpacing={2} sx={{ my: 3 }}>
				<Grid item xs={4}>
					<Utilization />
				</Grid>
				<Grid item xs={4}>
					<Cost />
				</Grid>
				<Grid item xs={4}>
					<SolversUtilization />
				</Grid>
			</Grid>
			<Grid container columnSpacing={2}>
				<Grid item xs={9}>
					<RecentSolvers solversCardClick={solversCardClick} />
				</Grid>
				<Grid item xs={3}>
					<Typography
						pb={2}
						variant="header20"
						sx={{ color: theme => theme.palette.text.secondary }}
					>
						Activity List
					</Typography>
					<ActivityList
						openActivityLoader={false}
						items={activityList}
						count={activityList?.length}
						noLabel
						height="34rem"
					/>
				</Grid>
			</Grid>
		</Box>
	);
}

export default SolversOverview;
