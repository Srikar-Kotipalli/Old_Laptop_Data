/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState } from 'react';
import { Typography, Box, Grid } from '@mui/material';
import Accordion from '../../../components/solvers/billing/Accordion';
import Header from '../../../components/solvers/billing/Header';

function Billing({ searchValue, toFilter }) {
	const [selected, setSelected] = useState('organisationName');
	const [toSort, setToSort] = useState('asc');

	const accordianData = [
		{
			id: 1,
			organisationName: 'nvidia',
			purchaseDate: '12 Feb, 12:05:38',
			cost: '$124',
			runs: 1700,
			solvers: [
				{ id: 0, name: 'solverName', purchaseDate: '03 Feb, 12:05:38', cost: '$1234', Runs: 123 },
				{ id: 1, name: 'solverName', purchaseDate: '03 Feb, 12:05:38', cost: '$1234', Runs: 123 },
				{ id: 2, name: 'solverName', purchaseDate: '03 Feb, 12:05:38', cost: '$1234', Runs: 123 },
				{ id: 3, name: 'solverName', purchaseDate: '03 Feb, 12:05:38', cost: '$1234', Runs: 123 }
			]
		},
		{
			id: 2,
			organisationName: 'covalent',
			purchaseDate: '03 Feb, 12:05:38',
			cost: '$600',
			runs: 2300,
			solvers: [
				{ id: 5, name: 'solverName', purchaseDate: '03 Feb, 12:05:38', cost: '$1234', Runs: 123 },
				{ id: 6, name: 'solverName', purchaseDate: '03 Feb, 12:05:38', cost: '$1234', Runs: 123 },
				{ id: 7, name: 'solverName', purchaseDate: '03 Feb, 12:05:38', cost: '$1234', Runs: 123 },
				{ id: 8, name: 'solverName', purchaseDate: '03 Feb, 12:05:38', cost: '$1234', Runs: 123 }
			]
		},
		{
			id: 3,
			organisationName: 'IBM',
			purchaseDate: '07 Feb, 12:05:38',
			cost: '$300',
			runs: 1900,
			solvers: [
				{ id: 9, name: 'solverName', purchaseDate: '03 Feb, 12:05:38', cost: '$1234', Runs: 123 },
				{ id: 10, name: 'solverName', purchaseDate: '03 Feb, 12:05:38', cost: '$1234', Runs: 123 },
				{ id: 11, name: 'solverName', purchaseDate: '03 Feb, 12:05:38', cost: '$1234', Runs: 123 },
				{ id: 12, name: 'solverName', purchaseDate: '03 Feb, 12:05:38', cost: '$1234', Runs: 123 }
			]
		}
	];

	const [datas, setDatas] = React.useState([]);

	const [selectedItems, setSelectedItems] = React.useState([]);

	const [selectAll, setSelectAll] = React.useState(false);

	React.useEffect(() => {
		let sortedData = [...accordianData];

		if (searchValue) {
			const filteredData = sortedData.filter(item =>
				item.organisationName.toLowerCase().includes(searchValue.toLowerCase())
			);
			sortedData = filteredData;
		}

		if (toFilter === 'last_updated') {
			sortedData.sort((a, b) => {
				const dateA = new Date(a.purchaseDate);
				const dateB = new Date(b.purchaseDate);
				if (toSort === 'asc') {
					return dateA - dateB;
				}
				return dateB - dateA;
			});
			setDatas(sortedData);
		}

		if (toFilter === 'popular') {
			sortedData.sort((a, b) => {
				const dateA = new Date(a.purchaseDate);
				const dateB = new Date(b.purchaseDate);
				if (toSort === 'asc') {
					return dateB - dateA;
				}
				return dateA - dateB;
			});
			setDatas(sortedData);
		}
		setDatas(sortedData);
	}, [selected, toSort, searchValue, toFilter]);

	const checkAllHandler = () => {
		if (!selectAll) {
			const postIds = datas.map(item => {
				return item.id;
			});
			setSelectedItems(postIds);
		} else {
			setSelectedItems([]);
		}
		setSelectAll(prev => !prev);
	};

	const checkboxHandler = e => {
		const isSelected = e.target.checked;
		const value = parseInt(e.target.value, 10);
		if (isSelected) {
			setSelectedItems([...selectedItems, value]);
		} else {
			setSelectAll(false);
			setSelectedItems(prevData => {
				return prevData.filter(id => {
					return id !== value;
				});
			});
		}
	};

	return (
		<Grid mt={3}>
			<Header
				checkAllHandler={checkAllHandler}
				selectAll={selectAll}
				selected={selected}
				toSort={toSort}
				setSelected={setSelected}
				setToSort={setToSort}
			/>
			{datas.length !== 0 ? (
				datas.map(data => {
					return (
						<Accordion
							key={data.id}
							data={data}
							checkboxHandler={checkboxHandler}
							selectedItems={selectedItems}
						/>
					);
				})
			) : (
				<Box
					sx={{
						padding: '10px'
					}}
				>
					<Typography fontFamily="DM Sans" color="#CBCBD7" variant="h2">
						No Records Found
					</Typography>
				</Box>
			)}
		</Grid>
	);
}

export default Billing;
