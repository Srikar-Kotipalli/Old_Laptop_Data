import React from 'react';
import { Grid, Box, Stack, Typography } from '@mui/material';
import Icon from '../../../../components/icon';
import IONQLOGO from '../../../../assets/IONQBIGLogo.svg';
import pinColorIcon from '../../../../assets/pinColorIcon.svg';
import moreVerticalIcon from '../../../../assets/menus/menuVerticalIcon.svg';
import modelBuilderIcon from '../../../../assets/modelBuilderIcon.svg';
import infoCircleIcon from '../../../../assets/infoCircleIcon.svg';
import { statusIcon, statusColor } from '../../../../components/icon/misc';
import CopyButton from '../../../../components/copyButton';
import MarketplaceChip from '../../../../components/marketplace/chip/marketplaceChip';
import ScatterChart from '../../../../components/chart/scatterChart';

function SolversTabList({ solversData }) {
	const solversSeriesData = [
		{
			name: 'SAMPLE A',
			data: [
				[3, 5],
				[2, 2],
				[2, 3]
			]
		},
		{
			name: 'SAMPLE B',
			data: [
				[3, 5],
				[1, 3],
				[5, 2]
			]
		},
		{
			name: 'SAMPLE C',
			data: [
				[2, 3],
				[2, 3],
				[6, 3]
			]
		}
	];

	return (
		// eslint-disable-next-line react/jsx-no-useless-fragment
		<>
			{solversData?.map(data => {
				return (
					<Box
						className="solverstabCtr"
						sx={{ backgroundColor: 'rgba(28, 28, 70, 0.40)' }}
						key={data.id}
					>
						<Grid container>
							<Grid item xs={4} sx={{ borderRight: '1px solid #303067' }}>
								<Grid container spacing={2} alignItems="center">
									<Grid item xs={9}>
										<Icon type="static" src={IONQLOGO} height="20px" width="57px" />
									</Grid>
									<Grid item xs={3}>
										<Stack direction="row" spacing={1} alignItems="center">
											<Box
												sx={{
													width: '24px',
													height: '24px',
													borderRadius: '8px',
													backgroundColor: '#1C1C46'
												}}
											>
												<Icon src={pinColorIcon} height="12px" width="12px" padding="6px" />
											</Box>
											<Box sx={{ pt: 0.5 }}>
												<Icon src={moreVerticalIcon} />
											</Box>
										</Stack>
									</Grid>
								</Grid>
								<Stack direction="row" spacing={1.5} alignItems="center" sx={{ my: 2 }}>
									<Icon type="static" src={modelBuilderIcon} />
									<Typography>{data?.name}</Typography>
									<Box
										sx={{
											width: '7px',
											height: '7px',
											background: '#55D899',
											borderRadius: '50%'
										}}
									/>
								</Stack>
								<MarketplaceChip items={data?.chipdata} isExpandable={false} />
								<Grid
									container
									columnSpacing={{ xs: 30, xl: 36, xxl: 38 }}
									sx={{ mt: 1 }}
									rowSpacing={2}
								>
									<Grid item xs={6}>
										<Typography sx={{ mb: 1.5, fontSize: '14px', marginLeft: '10px' }}>
											Last Status
										</Typography>
										<Stack direction="row" alignItems="center">
											<Grid ml={1} sx={{ color: statusColor(data.status), fontSize: '12px' }}>
												{statusIcon(data.status)}
												{data.last_status_count}/{data.last_status_total}
											</Grid>
										</Stack>
									</Grid>
									<Grid
										item
										pl={3}
										xs={6}
										sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}
									>
										<Typography className="solvTabHead2" sx={{ mb: 1.5 }}>
											API Calls
										</Typography>
										<Stack direction="row">
											<Typography className="solvTabHead1">
												{data.total_api_count}/{data.total_api_calls}
											</Typography>
											<Box>
												<Icon
													src={infoCircleIcon}
													height="12px"
													width="12px"
													padding="0 0 10px 4px"
												/>
											</Box>
										</Stack>
									</Grid>
								</Grid>
							</Grid>
							<Grid
								item
								xs={4}
								sx={{ borderRight: '1px solid #303067' }}
								px={{ xs: 13, xl: 16, xxl: 18 }}
							>
								<Grid
									item
									container
									direction="row"
									justifyContent="center"
									spacing={2}
									sx={{ mt: 1, height: '100%' }}
								>
									<Grid item xs={6}>
										<Typography className="solvTabHead2" sx={{ mb: 1.5 }}>
											Total Cost
										</Typography>
										<Stack direction="row">
											<Typography className="solvTabHead1">
												{data.total_cost_count}/{data.total_cost}
											</Typography>
											<Box>
												<Icon
													src={infoCircleIcon}
													height="12px"
													width="12px"
													padding="0 0 10px 4px"
												/>
											</Box>
										</Stack>
									</Grid>
									<Grid item xs={6}>
										<Typography className="solvTabHead2" sx={{ mb: 1.5 }}>
											Last Dispatch ID
										</Typography>
										<Stack direction="row">
											<Typography className="solvTabHead1 elipsDispatch">
												{data.dispatch_id}
											</Typography>
											<Box sx={{ mt: '-3px', ml: 0.5 }}>
												<CopyButton content="code" borderEnable={false} />
											</Box>
										</Stack>
									</Grid>
									<Grid item xs={6}>
										<Typography className="solvTabHead2" sx={{ mb: 1.5 }}>
											Parameter
										</Typography>
										<Stack direction="row">
											<Typography className="solvTabHead1">
												{data.total_parameter_count}/{data.total_paramerter}
											</Typography>
											<Box>
												<Icon
													src={infoCircleIcon}
													height="12px"
													width="12px"
													padding="0 0 10px 4px"
												/>
											</Box>
										</Stack>
									</Grid>
									<Grid item xs={6}>
										<Typography className="solvTabHead2" sx={{ mb: 1.5 }}>
											Utilisation
										</Typography>
										<Stack direction="row">
											<Typography className="solvTabHead1">{data.utilsation}</Typography>
											<Box>
												<Icon
													src={infoCircleIcon}
													height="12px"
													width="12px"
													padding="0 0 10px 4px"
												/>
											</Box>
										</Stack>
									</Grid>
								</Grid>
							</Grid>
							<Grid item xs={4} sx={{ pl: 2 }}>
								<ScatterChart solversSeriesData={solversSeriesData} height={200} />
							</Grid>
						</Grid>
					</Box>
				);
			})}
		</>
	);
}

export default SolversTabList;
