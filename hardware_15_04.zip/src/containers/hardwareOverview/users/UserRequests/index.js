import React, { useEffect, useState } from 'react';
import {
	Box,
	Grid,
	Stack,
	Typography,
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableContainer,
	TableRow,
	Checkbox,
	Avatar,
	TableSortLabel
} from '@mui/material';
import Icon from '../../../../components/icon';
import checkbox from '../../../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../../../assets/checkboxes/checkboxChecked.svg';
import utilizationIcon from '../../../../assets/utilizationIcon.svg';
import PieChart from '../../../../components/chart/pieChart';

function BoxComponent({ header, value }) {
	return (
		<Grid item xs={6} pl={6}>
			{' '}
			<Typography variant="h3">{header}</Typography>
			<Typography
				variant="button"
				display="block"
				gutterBottom
				sx={{ color: theme => theme.palette.text.gray03, mb: 0 }}
			>
				{value}
			</Typography>
		</Grid>
	);
}

function UserTable({
	searchValue,
	selected,
	sort,
	startDate,
	endDate,
	setSelected,
	setSort,
	toFilter
}) {
	const data = [
		{
			id: 1,
			userId: 'Agnostiq',
			total: 2000,
			requestedDate: 'Wed Jul 26 2023 00:00:00'
		},
		{
			id: 2,
			userId: 'Agnostiq-1',
			total: 3365,
			requestedDate: 'Wed Jul 27 2023 00:00:00'
		},
		{
			id: 3,
			userId: 'covalent',
			total: 8569,
			requestedDate: 'Wed Jul 28 2023 00:00:00'
		},
		{
			id: 4,
			userId: 'Agnostiq-3',
			total: 5214,
			requestedDate: 'Wed Jul 29 2023 00:00:00'
		},
		{
			id: 5,
			userId: 'Agnostiq-4',
			total: 4587,
			requestedDate: 'Wed Jul 29 2023 00:00:00'
		}
	];

	const revenueChartData = {
		series: [23, 11, 54, 72, 66],
		labels: ['Agnostiq', 'Agnostiq-1', 'Agnostiq-2', 'Agnostiq-3', 'Agnostiq-4'],
		colors: ['#8B31FF', '#41418D', '#AD7BFF', '#6D7CFF', '#AD7BFF']
	};

	// const [datas, setDatas] = useState(data);
	const [selectedItems, setSelectedItems] = useState([]);
	const [selectAll, setSelectAll] = React.useState(false);
	const [datas, setDatas] = useState([]);

	useEffect(() => {
		let sortedData = [...data];

		if (startDate && endDate) {
			sortedData = sortedData.filter(item => {
				const itemDate = new Date(item.requestedDate);
				return itemDate >= startDate && itemDate <= endDate;
			});
		}

		if (searchValue) {
			const filteredData = sortedData.filter(
				item =>
					item?.userId?.toLowerCase().includes(searchValue.toLowerCase()) ||
					item?.total?.toString().toLowerCase().includes(searchValue.toLowerCase())
			);
			sortedData = filteredData;
		}

		if (selected === 'userId') {
			sortedData.sort((a, b) => {
				const userIdA = a.userId.toLowerCase();
				const userIdB = b.userId.toLowerCase();

				if (sort === 'asc') {
					return userIdA.localeCompare(userIdB);
				}
				return userIdB.localeCompare(userIdA);
			});
			setDatas(sortedData);
		}
		if (toFilter === 'last_updated') {
			sortedData.sort((a, b) => {
				const dateA = a.total;
				const dateB = b.total;
				if (sort === 'asc') {
					return dateA - dateB;
				}
				return dateB - dateA;
			});
			setDatas(sortedData);
		}
		if (selected === 'downloads' || toFilter === 'popular') {
			sortedData.sort((a, b) => {
				const dateA = a.total;
				const dateB = b.total;
				if (sort === 'asc') {
					return dateB - dateA;
				}
				return dateA - dateB;
			});
			setDatas(sortedData);
		}

		setDatas(sortedData);
	}, [selected, sort, searchValue, startDate, endDate, toFilter]);

	const checkAllHandler = () => {
		if (!selectAll) {
			const postIds = data.map(item => {
				return item.id;
			});
			setSelectedItems(postIds);
			// console.log(selectedItems);
		} else {
			setSelectedItems([]);
		}
		setSelectAll(prev => !prev);
	};

	const handleRowSelect = (event, id) => {
		if (event.target.checked) {
			setSelectedItems(prevSelectedRows => [...prevSelectedRows, id]);
		} else {
			setSelectedItems(prevSelectedRows => prevSelectedRows.filter(rowId => rowId !== id));
			setSelectAll(false);
		}
	};

	return (
		<Grid container sx={{ height: 'auto' }}>
			<Grid item xs={6}>
				<TableContainer sx={{ width: '94%' }}>
					<Table className="tabComponentTable">
						<TableHead>
							<TableRow
								sx={{
									color: '#CBCBD7',
									'&:hover': { backgroundColor: 'transparent' }
								}}
							>
								<TableCell sx={{ borderBottom: 'none' }}>
									<Checkbox
										data-testid="headerCheckbox"
										size="small"
										sx={{ padding: '2px 0px 0px 5px' }}
										checked={selectAll}
										onChange={checkAllHandler}
										icon={
											<Icon
												src={checkbox}
												alt="checkbox"
												type="pointer"
												width="12px"
												height="12px"
											/>
										}
										checkedIcon={
											<Icon
												src={checkboxChecked}
												alt="checkboxChecked"
												type="pointer"
												width="12px"
												height="12px"
											/>
										}
									/>
								</TableCell>
								<TableCell sx={{ borderBottom: 'none' }}>
									<TableSortLabel
										active={selected === 'userId'}
										direction={sort === 'asc' ? 'asc' : 'desc'}
										onClick={() => {
											setSelected('userId');
											if (sort === 'desc') {
												setSort('asc');
											} else setSort('desc');
										}}
										sx={{ fontWeight: 'bold' }}
									>
										User Id
									</TableSortLabel>
								</TableCell>
								<TableCell sx={{ borderBottom: 'none' }}>
									<TableSortLabel
										active={selected === 'popular'}
										direction={sort === 'asc' ? 'asc' : 'desc'}
										onClick={() => {
											setSelected('popular');
											if (sort === 'desc') {
												setSort('asc');
											} else setSort('desc');
										}}
										sx={{ fontWeight: 'bold' }}
									>
										Total
									</TableSortLabel>
								</TableCell>
								<TableCell sx={{ borderBottom: 'none' }}> </TableCell>
								<TableCell sx={{ borderBottom: 'none' }}> </TableCell>
							</TableRow>
						</TableHead>
						<TableBody>
							{datas.map(row => (
								<TableRow key={row.id}>
									<TableCell width="59">
										<Checkbox
											// data-testid="headerCheckbox"
											size="small"
											sx={{ padding: '2px 0px 0px 5px' }}
											value={row.id}
											checked={selectedItems.includes(row.id)}
											onChange={event => handleRowSelect(event, row.id)}
											icon={
												<Icon
													src={checkbox}
													alt="checkbox"
													type="pointer"
													width="12px"
													height="12px"
												/>
											}
											checkedIcon={
												<Icon
													src={checkboxChecked}
													alt="checkboxChecked"
													type="pointer"
													width="12px"
													height="12px"
												/>
											}
											// disabled={ || addMode}
										/>
									</TableCell>
									<TableCell align="left" width="300">
										<Stack direction="row" alignItems="center" gap={1}>
											<Avatar
												sx={{
													width: 24,
													height: 24,
													fontSize: 12,
													bgcolor: '#8B31FF',
													color: 'white'
												}}
											>
												{row.userId.slice(0, 1)}
											</Avatar>
											<Box>{row.userId}</Box>
										</Stack>
									</TableCell>
									<TableCell width="200">$ {row.total}</TableCell>
									{/* <TableCell width="200">{row.requestedDate}</TableCell> */}
									<TableCell width="30" />
								</TableRow>
							))}
							{datas.length === 0 && (
								<TableRow>
									<TableCell width="59" />
									<TableCell align="left" width="300">
										<Typography color="textPrimary" variant="subtitle2">
											No records found
										</Typography>
									</TableCell>
									<TableCell width="200" />
									<TableCell width="30" />
								</TableRow>
							)}
						</TableBody>
					</Table>
					{/* {datas.length === 0 && (
						<Typography className="listHeading" color="textPrimary" variant="subtitle2">
							No records found
						</Typography>
					)} */}
				</TableContainer>
			</Grid>
			<Grid
				mt={3.5}
				mb={1}
				pt={2}
				pb={5}
				px={5}
				item
				xs={4}
				sx={{ border: '1px solid #303067', borderRadius: '8px' }}
			>
				<Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1 }}>
					<Box className="utilizationHeaderIcon">
						<Icon type="static" src={utilizationIcon} />
					</Box>
					<Box>
						<Typography className="utilzationLabel" color="white">
							Org Split
						</Typography>
					</Box>
				</Stack>
				<Grid item xs={12} sx={{ marginTop: 5, display: 'flex', justifyContent: 'center' }}>
					<PieChart revenueChartData={revenueChartData} height={150} />
				</Grid>
				<Grid container item xs={12} sx={{ marginTop: 5 }} direction="column">
					<Grid container item sx={{ display: 'flex' }}>
						<BoxComponent header="Org" value={4} />
						<BoxComponent header="Hardware" value={12} />
					</Grid>
					<Grid item pt={4} sx={{ display: 'flex' }}>
						<BoxComponent header="Revenue" value="$1234" />
						<BoxComponent header="Parameter" value="Value" />
					</Grid>
				</Grid>
			</Grid>
		</Grid>
	);
}

export default UserTable;
