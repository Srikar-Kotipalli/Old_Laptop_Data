import React from 'react';
import { Avatar, Box, Grid, Stack, Typography } from '@mui/material';
import HardwareImage from '../../../assets/hardwareImage.svg';
import SolverImage from '../../../assets/EnvironmentImage.svg';
import Icon from '../../../components/icon';

function OverviewHeader({ data, placement }) {
	return (
		<Grid container p={0} mt={4} alignItems="center">
			<Grid item xs={4} p={0}>
				<Stack direction="row" spacing={2} alignItems="center">
					<Box>
						<Avatar variant="rounded" className="avatartImg">
							<Icon src={!placement ? HardwareImage : SolverImage} alt="" />
						</Avatar>
					</Box>
					<Box>
						<Typography className="typHead">{data?.name}</Typography>
						<Typography className="typPara">{data?.desc}</Typography>
					</Box>
				</Stack>
			</Grid>
		</Grid>
	);
}

export default OverviewHeader;
