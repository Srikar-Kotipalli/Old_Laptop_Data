import * as React from 'react';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import Divider from '@mui/material/Divider';

function StyledDivider() {
	return (
		<Divider
			sx={{ borderColor: '#303067', height: '20px', marginTop: '14px' }}
			orientation="vertical"
			variant="middle"
			flexItem
		/>
	);
}

function HardwareOverviewTab(props) {
	const { value, onChange } = props;

	return (
		<TabContext value={value}>
			<TabList
				onChange={onChange}
				TabIndicatorProps={{
					style: {
						display: 'none'
					}
				}}
			>
				<Tab label="Overview" value="Overview" sx={{ marginRight: '-5px' }} />
				<StyledDivider />
				<Tab label="Hardware" value="Hardware" sx={{ margin: '0 -5px 0 -5px' }} />
				<StyledDivider />
				<Tab label="Users" value="Users" sx={{ margin: '0 -15px 0 -15px' }} />
				<StyledDivider />
				<Tab label="Access Requests" value="Access Requests" sx={{ margin: '0 -5px 0 -5px' }} />
				<StyledDivider />
				<Tab label="Job Queue" value="Job Queue" sx={{ margin: '0 0 0 -5px' }} />
			</TabList>
		</TabContext>
	);
}

export default HardwareOverviewTab;
