/* eslint-disable camelcase */
/* eslint-disable no-unused-vars */
/* eslint-disable react/jsx-no-useless-fragment */
import React, { useContext } from 'react';
import { Box, Tooltip } from '@mui/material';
import { useParams } from 'react-router-dom';
import Expanded from '../../../assets/graph/Expanded.svg';
import Collapsed from '../../../assets/graph/collapsed.svg';
import Back from '../../../assets/back.svg';
import { GraphContext } from '../contexts/GraphContext';
import { dpexpStatusIcons } from '../../../utils/statusIcons';
import { Prettify } from '../../../utils/utils';
import OverflowTooltip from '../../../components/tooltip/overflowTooltip';
import Icon from '../../../components/icon';

// eslint-disable-next-line no-unused-vars
function SublatticeFunctionChip({ functionInfo, handleOpen, handleHierarchyBack }) {
	const {
		setSelectedNodeId,
		setTabValue,
		selectedNodeId,
		setSublatticeId,
		sublatticeId,
		setNodeClickFrom,
		setBreadcrumb,
		getLatticeAPI
	} = useContext(GraphContext);
	const { dispatchID } = useParams();
	const populateBreadcrumbs = () => {
		const breadcrumbdata = [];
		let data = functionInfo?.parentInfo;
		while (data) {
			breadcrumbdata.push({
				name: Prettify(data?.name, data?.type),
				id: data?.sublattice_dispatch_id
			});
			data = data.parentInfo;
		}
		breadcrumbdata.push({ name: 'Main Graph', id: dispatchID });
		breadcrumbdata.reverse();
		setBreadcrumb([...breadcrumbdata]);
	};

	return (
		<Box
			onClick={() => {
				populateBreadcrumbs();
				getLatticeAPI(functionInfo?.sublattice_dispatch_id, 'sublattice');
				setSelectedNodeId(functionInfo?.id);
				setSublatticeId(functionInfo?.dispatchID);
				setNodeClickFrom('');
			}}
			sx={{
				height: '38px',
				borderRadius: '8px',
				background:
					(selectedNodeId === functionInfo?.transport_graph_node_id ||
						(selectedNodeId === '' && functionInfo?.transport_graph_node_id === 0)) &&
					sublatticeId === functionInfo?.dispatchID
						? '#303067'
						: 'transparent',
				padding: '10px',
				display: 'flex',
				justifyContent: 'space-between',
				border: '1px solid #08081A',
				'&:hover': {
					background: '#1C1C46'
				},
				alignItems: 'center',
				cursor: 'pointer'
			}}
		>
			<Box sx={{ display: 'flex' }}>
				<Box sx={{ cursor: 'pointer', fontSize: '14px' }}>
					{functionInfo?.back ? (
						<OverflowTooltip title={`...${Prettify(functionInfo?.name)}`} length={20} />
					) : (
						<OverflowTooltip title={Prettify(functionInfo?.name)} length={20} />
					)}
				</Box>
				<Box sx={{ display: 'grid', placeItems: 'center', marginLeft: '8px' }}>
					{dpexpStatusIcons(functionInfo?.status, true)}
				</Box>
			</Box>
			<Box sx={{ display: 'flex', flexDirection: 'row', alignItems: 'flex-end' }}>
				{functionInfo?.back && (
					<Tooltip title="Back to parent">
						<Box
							onClick={e => {
								e.stopPropagation();
								handleHierarchyBack(functionInfo);
							}}
						>
							<Icon src={Back} alt="hierarchyBack" />
						</Box>
					</Tooltip>
				)}
				{functionInfo?.sublattice_dispatch_id && (
					<Tooltip title={functionInfo?.expanded ? 'Collapse' : 'Expand'}>
						<Box
							onClick={e => {
								e.stopPropagation();
								handleOpen(functionInfo);
							}}
						>
							<Icon src={functionInfo?.expanded ? Expanded : Collapsed} alt="expanded" />
						</Box>
					</Tooltip>
				)}
			</Box>
		</Box>
	);
}

export default SublatticeFunctionChip;
