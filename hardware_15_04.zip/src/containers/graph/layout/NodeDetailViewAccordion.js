/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable no-unsafe-optional-chaining */
/* eslint-disable react/no-array-index-key */
/* eslint-disable react/jsx-no-bind */
/* eslint-disable react/jsx-boolean-value */
import React, { useState, useContext, useEffect } from 'react';
import {
	Accordion,
	AccordionSummary,
	AccordionDetails,
	Box,
	Typography,
	Grid,
	Stepper,
	Step,
	StepLabel,
	Skeleton
} from '@mui/material';
import NodeDetailViewAccordionHeader from './NodeDetailViewAccordionHeader';
import NodeCard from './NodeCard';
import GraphTab from '../../../components/tab/graph';
import CodeAccordion from './CodeAccordion';
import NodeParameter from './NodeParameter';
import Cost from '../../../assets/graph/nodeIcons/CostMin.svg';
import { Prettify } from '../../../utils/utils';
import { GraphContext } from '../contexts/GraphContext';
import { getTimeLineIcon } from '../../../utils/statusIcons';
import noStatus from '../../../assets/dispatch/noStatus.svg';
import placeholder from '../../../assets/dispatch/placeholder.svg';
import cpushares from '../../../assets/specifications/spc-cpu.svg';
import memory from '../../../assets/specifications/spc-memory.svg';
import spcTimerIcon from '../../../assets/specifications/spc-timer.svg';
import spcGatewayIcon from '../../../assets/specifications/spec-gateway-api.svg';
import spcGpuIcon from '../../../assets/specifications/spec-gpu.svg';
import spcEnvIcon from '../../../assets/specifications/spec-env.svg';
import statusImg from '../../../assets/graph/nodeIcons/StatusMin.svg';
import progress from '../../../assets/graph/progress.svg';

// code=input
function NodeDetailViewAccordion({ data, nodeStatus, isFetchingNodeData, enableShareOption }) {
	const {
		timeline,
		nodeError,
		selectedNodeCode,
		selectedNodeCodeCopy,
		selectedNodeInput,
		selectedNodeInputCopy,
		selectedNodeResult,
		selectedNodeResultCopy,
		nodeCost,
		isFetchingNodeCost,
		selectedNodeConsole,
		isFetchingNodeCode,
		isFetchingNodeError,
		isFetchingNodeConsole,
		isFetchingNodeInput,
		isFetchingNodeResult
	} = useContext(GraphContext);

	const [tabValue, setTabValue] = useState(
		nodeStatus === 'FAILED'
			? 'Error'
			: nodeStatus === 'NEW_OBJECT' || nodeStatus === 'RUNNING'
			? 'Input'
			: 'Result'
	);

	useEffect(() => {
		if (nodeStatus === 'FAILED') setTabValue('Error');
		else if (nodeStatus === 'NEW_OBJECT' || nodeStatus === 'RUNNING') setTabValue('Input');
		else setTabValue('Result');
	}, [nodeStatus]);

	const onTabChange = (_e, val) => {
		setTabValue(val);
	};
	const [expanded, setExpanded] = React.useState(true);

	const specs = [
		{
			heading: 'CPU Shares',
			value: `${
				(data?.executor?.cpu_shares / 1024) % 1 === 0
					? (data?.executor?.cpu_shares / 1024).toFixed(0)
					: (data?.executor?.cpu_shares / 1024).toFixed(1)
			} `,
			imgSrc: cpushares
		},
		{
			heading: 'Memory',
			value: `${
				(data?.executor?.memory / 1024) % 1 === 0
					? (data?.executor?.memory / 1024).toFixed(0)
					: (data?.executor?.memory / 1024).toFixed(1)
			} `,
			imgSrc: memory
		},
		{ heading: 'Time Limit', value: data?.executor?.time_limit, imgSrc: spcTimerIcon },
		{ heading: 'GPUs', value: data?.executor?.num_gpus, imgSrc: spcGpuIcon },
		{ heading: 'GPU Type', value: data?.executor?.gpu_type, imgSrc: spcGatewayIcon },
		{ heading: 'Environment', value: data?.executor?.environment_name, imgSrc: spcEnvIcon }
	];

	// eslint-disable-next-line consistent-return
	function date(string) {
		const DateVal = new Date(`${string}Z`);
		if (DateVal) {
			let day = DateVal?.getDate();
			day = day < 10 ? `0${day}` : day;
			const month = DateVal?.toLocaleString('default', { month: 'short' });
			return `${day} ${month}`;
		}
		return '-';
	}

	// eslint-disable-next-line consistent-return
	function time(string) {
		const Time = new Date(`${string}Z`);
		if (Time) {
			let hour = Time?.getHours();
			let min = Time?.getMinutes();
			const ampm = hour >= 12 ? 'pm' : 'am';
			hour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
			min = min < 10 ? `0${min}` : min;
			return `${hour}:${min} ${ampm}`;
		}
	}

	function getNoStatus() {
		return (
			<Box
				sx={{
					height: '26px',
					width: '26px',
					borderRadius: '4px',
					border: '1px solid rgba(48, 48, 103, 0.20)',
					display: 'grid',
					placeItems: 'center',
					background: 'rgba(28, 28, 70, 0.30)'
				}}
			>
				<img src={noStatus} alt="img" />
			</Box>
		);
	}

	return (
		<Accordion
			disableGutters
			expanded={expanded}
			sx={{
				border: '1px solid #303067',
				borderBottomLeftRadius: '8px',
				borderBottomRightRadius: '8px'
			}}
		>
			<AccordionSummary
				aria-controls="panel1a-content"
				id="panel1a-header"
				sx={{ cursor: 'default !important' }}
			>
				<Box sx={{ width: '100%' }}>
					<Box
						sx={{
							display: 'flex'
						}}
					>
						<NodeDetailViewAccordionHeader
							name={Prettify(data?.name)}
							nodeID={data?.transport_graph_node_id}
							isFetching={isFetchingNodeData}
							setExpanded={setExpanded}
							expanded={expanded}
						/>
					</Box>

					<Box
						sx={{
							height: '1px',
							background: '#5552FF',
							width: 'calc(100% + 33px)',
							margin: '12px 0 0 -17px'
						}}
					/>
					<Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
						<Box
							sx={{
								display: 'flex',
								flexDirection: 'row',
								alignItems: 'center',
								justifyContent: 'space-between'
							}}
						>
							<Box mt="2rem" width="10rem">
								<NodeCard
									title="Status"
									value={data?.status}
									hasImage={true}
									isLoading={isFetchingNodeData}
									type="status"
									transparent
									imgSource={statusImg}
								/>
							</Box>
							<Box mt="1.4rem" sx={{ paddingLeft: '2rem' }}>
								<Box sx={{ display: 'flex' }}>
									<Box sx={{ display: 'grid', placeItems: 'center' }}>
										<img src={Cost} alt="placeholderimg" />
									</Box>
									<Box sx={{ marginLeft: '7px' }}>
										<Typography
											sx={{
												color: '#86869A',
												fontSize: '12px',
												fontWeight: null,
												margin: '1px 0 0 0',
												cursor: 'default'
											}}
										>
											Cost
										</Typography>
									</Box>
								</Box>
								<Box>
									{isFetchingNodeCost && (
										<Skeleton variant="rounded" width={80} height={27} sx={{ mt: '8px' }} />
									)}
									{!isFetchingNodeCost && nodeStatus !== 'COMPLETED' && nodeStatus !== 'FAILED' ? (
										<>
											<img src={progress} alt="progress" />
											<Typography
												sx={{
													fontSize: '12px',
													color: '#86869A'
												}}
											>
												{enableShareOption
													? 'Cost will be displayed after computation'
													: 'Private for shared dispatches'}
											</Typography>
										</>
									) : (
										// eslint-disable-next-line react/jsx-no-useless-fragment
										<>
											{!isFetchingNodeCost && (
												<Typography
													sx={{
														fontSize: !enableShareOption ? '12px' : '18px',
														color: !enableShareOption ? '#86869A' : '#DAC3FF',
														padding: '8px 0 0 0px'
													}}
												>
													{enableShareOption ? nodeCost : 'Private for shared dispatches'}
												</Typography>
											)}
										</>
									)}
								</Box>
							</Box>
						</Box>
						<Box>
							<Box sx={{ width: '100%', marginTop: '25px' }}>
								{timeline?.length > 0 && (
									<Stepper
										alternativeLabel
										sx={{
											'& .MuiStepConnector-line': {
												borderColor: '#303067 !important'
											}
										}}
									>
										{timeline?.map(label => (
											<Step key={label?.index}>
												<StepLabel
													StepIconComponent={() =>
														label?.status === 'placeholder'
															? getNoStatus()
															: getTimeLineIcon(label?.icon)
													}
												/>
												<Box
													sx={{
														width: label?.width || '150px',
														display: 'grid',
														placeItems: 'center',
														margin: '10px 0 0 0'
													}}
												>
													{label?.status === 'placeholder' ? (
														<Box
															sx={{
																width: label?.width || '150px',
																display: 'grid',
																placeItems: 'center',
																margin: '10px 0 0 0'
															}}
														>
															<img
																src={placeholder}
																alt="placeholder"
																style={{ marginTop: '4px' }}
															/>
														</Box>
													) : (
														<>
															<Typography
																sx={{ color: label?.color, fontSize: '12px', fontWeight: '400' }}
															>
																{label?.status}
															</Typography>
															<Typography
																sx={{
																	color: '#86869A',
																	fontSize: '10px',
																	fontWeight: '400',
																	marginTop: '7px'
																}}
															>
																{`${date(label?.time)} ${time(label?.time)}`}
															</Typography>
														</>
													)}
												</Box>
											</Step>
										))}
									</Stepper>
								)}
							</Box>
						</Box>
					</Box>

					<Grid
						container
						direction="row"
						justifyContent="space-between"
						sx={{
							padding: '0px 10px 0px 10px',
							marginTop: '39px',
							// border: '1px solid #303067',
							borderRadius: '10px',
							height: '50px',
							marginLeft: '1px',
							width: '100%',
							background: 'rgba(28, 28, 70, 0.40)'
						}}
					>
						<NodeCard
							direction="row"
							transparent
							cardWidth="45%"
							cardHeight="100%"
							title="Runtime"
							started_at={data?.started_at}
							completed_at={data?.completed_at}
							nodeRuntime={true}
							isLoading={isFetchingNodeData}
							type="started_completed_noderuntime"
							fontColor="#DAC3FF"
							fontSize="14px"
							sx={{ height: '100%', display: 'flex', alignItems: 'center' }}
						/>
						<NodeCard
							transparent
							direction="row"
							cardWidth="50%"
							cardHeight="100%"
							title="Start Time ~ End Time"
							date={true}
							started_at={data?.started_at}
							completed_at={data?.completed_at}
							isLoading={isFetchingNodeData}
							type="runtime"
							fontColor="#DAC3FF"
							fontSize="14px"
							sx={{ height: '100%', display: 'flex', alignItems: 'center' }}
						/>
					</Grid>
				</Box>
			</AccordionSummary>

			<AccordionDetails>
				<Box mt={4}>
					<GraphTab
						value={tabValue}
						onChange={onTabChange}
						firstValue={
							nodeStatus === 'FAILED'
								? 'Error'
								: nodeStatus === 'NEW_OBJECT' || nodeStatus === 'RUNNING'
								? null
								: 'Result'
						}
						secondValue="Input"
						thirdValue="Code"
						fourthValue={nodeStatus === 'COMPLETED' && nodeStatus !== 'FAILED' ? 'Std Out' : ''}
						pl="14.4px"
					/>
				</Box>

				{tabValue === 'Result' && (
					<CodeAccordion
						haveHeading={false}
						code={selectedNodeResult}
						codeCopy={selectedNodeResultCopy}
						containerWidth="100%"
						forValue="node"
						isFetching={isFetchingNodeResult}
					/>
				)}
				{tabValue === 'Error' && (
					<CodeAccordion
						haveHeading={false}
						code={nodeError}
						normalCopy={true}
						codeCopy={nodeError}
						containerWidth="100%"
						accordionBorder="1px solid #FF6464"
						forValue="node"
						isFetching={isFetchingNodeError}
					/>
				)}
				{tabValue === 'Input' && (
					<CodeAccordion
						haveHeading={false}
						code={selectedNodeInput}
						codeCopy={selectedNodeInputCopy}
						containerWidth="100%"
						forValue="node"
						isFetching={isFetchingNodeInput}
					/>
				)}
				{tabValue === 'Code' && (
					<CodeAccordion
						haveHeading={false}
						code={selectedNodeCode}
						codeCopy={selectedNodeCodeCopy}
						containerWidth="100%"
						forValue="node"
						isFetching={isFetchingNodeCode}
					/>
				)}
				{tabValue === 'Std Out' && (
					<CodeAccordion
						haveHeading={false}
						code={selectedNodeConsole}
						normalCopy={true}
						codeCopy={selectedNodeConsole}
						containerWidth="100%"
						forValue="node"
						isFetching={isFetchingNodeConsole}
					/>
				)}

				<Typography
					sx={{
						fontWeight: '400',
						fontSize: '12px',
						color: '#86869A',
						margin: '39px 0 15px 0',
						cursor: 'default'
					}}
				>
					Specifications
				</Typography>
				<Grid container>
					{specs?.map((item, index) => {
						return (
							(item?.value || item?.value === 0) && (
								<Grid item xs={6} sm={4} md={4} lg={4} key={index}>
									<NodeParameter
										heading={item?.heading}
										time={item?.value}
										imgSrc={item?.imgSrc}
										padding="12px 15px 12px 15px"
										isFetching={isFetchingNodeData}
										placement="specifications"
										fontWeight="400"
									/>
								</Grid>
							)
						);
					})}
				</Grid>
			</AccordionDetails>
		</Accordion>
	);
}
export default NodeDetailViewAccordion;
