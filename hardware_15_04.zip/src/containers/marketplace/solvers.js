/* eslint-disable import/no-named-as-default */
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Grid, Typography, Box } from '@mui/material';
// eslint-disable-next-line no-unused-vars
import { useParams, useNavigate } from 'react-router-dom';
import UsageBlock from '../../components/marketplace/usageBlock';
import DescriptionBlock from '../../components/marketplace/descriptionBlock';
import Breadcrumb from '../../components/breadcrumb';
import MarketplaceHeader from '../../components/marketplace/header';
import './style.css';
import MarketplaceCard from '../../components/card/marketplace/marketplaceCard';
import RequestAccessButton from '../../components/marketplace/requestAccessButton';
import MarketplaceChip from '../../components/marketplace/chip/marketplaceChip';
import { addAccessRequestSolver } from '../../redux/solverAdminSlice';
import MarketplaceDialogBox from '../../components/dialogBox/marketplace/index';
import CustomisedSnackbar from '../../components/snackbar/projects/index';

function Solver() {
	const { solverId } = useParams();
	const [indexId, setIndexId] = useState('');
	const [headerData, setHeaderData] = useState({});
	// eslint-disable-next-line no-unused-vars
	const isvalididInfo = useState(true);
	const setisValidid = isvalididInfo[1];
	const { user } = useSelector(state => state.common);
	const { allMySolvers } = useSelector(state => state.solver);
	const { solverdata } = useSelector(state => state.marketplace);
	const navigate = useNavigate();
	const relatedSolversData = solverdata.details.slice(0, 4);
	const dispatch = useDispatch();
	const [openDialogBox, setOpenDialogBox] = useState(false);
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState(false);

	const onRequestAccess = () => {
		let tempArray = {};
		const index = allMySolvers?.findIndex(e => e?.solverId === parseInt(solverId, 10));
		if (index === -1) {
			const i = solverdata?.details?.findIndex(e => e?.solverId === parseInt(solverId, 10));
			tempArray = { ...solverdata?.details[i] };
			tempArray['requestDate'] = new Date().toISOString();
			if (user?.attributes) {
				if (user?.attributes['custom:isOrganisation'] === 'True')
					tempArray['requestedBy'] = user?.attributes['custom:organisationName'];
				else tempArray['requestedBy'] = user?.attributes?.given_name;
			}
			dispatch(addAccessRequestSolver({ solver: tempArray }));
			setOpenDialogBox(false);
			setOpenSnackbar(true);
			setSnackbarMessage('Access Requested Successfully!');
		} else {
			setOpenDialogBox(false);
			setOpenSnackbar(true);
			setSnackbarMessage('Access granted already!');
		}
	};

	useEffect(() => {
		const index = solverdata?.details?.findIndex(e => e?.solverId === parseInt(solverId, 10));
		setHeaderData(solverdata?.details[index]?.headData);
	}, [solverId]);

	useEffect(() => {
		window.scrollTo({
			top: 0,
			behavior: 'smooth'
		});
		// eslint-disable-next-line radix
		const index = solverdata?.details?.findIndex(e => e?.solverId === parseInt(solverId));
		if (index !== -1 && !/[a-zA-Z]/.test(solverId)) {
			setIndexId(index);
			setisValidid(true);
		} else {
			setisValidid(false);
			navigate('/invalidId');
		}
	}, []);

	useEffect(() => {
		window.scrollTo({
			top: 0,
			behavior: 'smooth'
		});
		// eslint-disable-next-line radix
		const index = solverdata?.details?.findIndex(e => e?.solverId === parseInt(solverId));
		if (index !== -1 && !/[a-zA-Z]/.test(solverId)) {
			setIndexId(index);
			setisValidid(true);
		} else {
			setIndexId('');
			setisValidid(false);
			navigate('/invalidId');
		}
	}, [solverId]);

	return (
		// eslint-disable-next-line react/jsx-no-useless-fragment
		<>
			{/* {!isvalidid ? (
				navigateFunc()
			) : ( */}
			{/* // eslint-disable-next-line react/jsx-no-useless-fragment */}
			<Grid sx={{ width: { lg: '100%', xl: '100%' } }}>
				{/* {solverdata.details[indexId]?.solverdetails?.parameters ? ( */}
				<Box>
					<MarketplaceDialogBox
						openDialogBox={openDialogBox}
						setOpenDialogBox={setOpenDialogBox}
						title="Confirm Request"
						message="Are you sure you want to request access?"
						confirmButtonTitle="Request Access"
						handler={onRequestAccess}
					/>
					<CustomisedSnackbar
						testId="solversSnackbar"
						open={openSnackbar}
						message={snackbarMessage}
						clickHandler={() => setOpenSnackbar(false)}
						onClose={() => setOpenSnackbar(false)}
					/>
					<Box>
						<Breadcrumb secondary="Marketplace" to="/marketplace" name={headerData?.name} />
						<Box>
							<MarketplaceHeader data={headerData} />
						</Box>
						<Grid
							container
							sx={{
								border: '1px solid #303067',
								borderRadius: '8px'
							}}
							padding="10px"
						>
							<Grid item xs={6}>
								<Box sx={{ mt: 2, ml: 3, mb: 5 }}>
									<Box>
										<Typography className="headtitleCtr">Tags/ Categories</Typography>
										<MarketplaceChip items={solverdata?.details[indexId]?.chipdata} isExpandable />
									</Box>
									<Box sx={{ my: 4, mr: '100px' }}>
										<Typography className="headtitleCtr">
											About {solverdata?.details[indexId]?.technology}
										</Typography>
										<Box>
											{solverdata.details[indexId]?.solverdetails.about.map(u => (
												<Typography sx={{ pb: 1 }} key={u.id} className="aboutContent">
													{u.point}
												</Typography>
											))}
										</Box>
									</Box>
									<Box sx={{ my: 4, mr: '100px' }}>
										<Typography className="headtitleCtr">Industries</Typography>
										<Box>
											{solverdata.details[indexId]?.solverdetails.industries.listitems.map(item => (
												<li key={item.id} className="aboutContent">
													{item.point}
												</li>
											))}
										</Box>
									</Box>
									<Box sx={{ my: 4, mr: '100px' }}>
										<Typography className="headtitleCtr">Setup</Typography>
										<Box>
											<Typography sx={{ pb: 2 }} className="aboutContent">
												{solverdata.details[indexId]?.solverdetails.setup}
											</Typography>
										</Box>
									</Box>

									<Box sx={{ my: 4, mr: '100px' }}>
										<Typography className="headtitleCtr">Citations</Typography>
										<Box>
											<Typography sx={{ pb: 2 }} className="aboutContent">
												{solverdata.details[indexId]?.solverdetails.citations}
											</Typography>
										</Box>
									</Box>
									<Box>
										<RequestAccessButton
											handleClick={() => setOpenDialogBox(true)}
											solverId={solverId}
											type="solver"
										/>
									</Box>
								</Box>
							</Grid>
							<Grid item xs={6} mt="0.5rem" sx={{ paddingRight: '1rem' }}>
								<DescriptionBlock
									desc={solverdata.details[indexId]?.solverdetails?.industries?.desc}
									minHeight="200px"
									margin="16px 0 40px 14%"
								/>
								<UsageBlock
									code={solverdata.details[indexId]?.solverdetails?.usage}
									heading="Usage"
									margin="16px 0 40px 14%"
								/>
								<UsageBlock
									code={solverdata.details[indexId]?.solverdetails?.curl}
									heading="Curl command"
									margin="16px 0 40px 14%"
									className="preWrapCls"
								/>
								<UsageBlock
									code={solverdata.details[indexId]?.solverdetails?.parameters}
									heading="Parameters"
									margin="16px 0 40px 14%"
									className="preWrapCls"
								/>
							</Grid>
						</Grid>

						<Grid
							container
							sx={{
								border: '1px solid #303067',
								mt: '3rem',
								borderRadius: '8px',
								mb: '20px'
							}}
						>
							<Typography pt="1rem" pl="1rem" pb="1rem" sx={{ color: '#FFF' }}>
								Related Solvers
							</Typography>

							<Grid container spacing={2} sx={{ padding: '15px' }}>
								{relatedSolversData.map(item => (
									<Grid key={item.id} item xs={6} sm={4} md={3} lg={3} xl={3} xxl={3}>
										<MarketplaceCard
											technology={item.technology}
											downloads={item.downloads}
											per={item.per}
											name={item?.name}
											price={item.price}
											content={item.content}
											cardimage={item.cardimage}
											hardwareimage={item?.hardwareimage}
											solverImage={item?.solverImage}
											statusimage={item.statusimage}
											chipdata={item.chipdata}
											tabvalue="Solvers"
											hardwareId={item.hardwareId}
											solverId={item.solverId}
											type={item.type}
											category={item.category}
										/>
									</Grid>
								))}
							</Grid>
						</Grid>
					</Box>
				</Box>
				{/* // ) : (
				// 	<Grid sx={{ position: 'absolute', top: 0, width: '100%', left: 0 }}>
				// 		<PageNotFoundScreen />
				// 	</Grid>
				// )} */}
			</Grid>
			{/* )} */}
		</>
	);
}

export default Solver;
