import React from 'react';
import InfiniteScroll from 'react-infinite-scroll-component';
import { Typography } from '@mui/material';

function InfiniteScrollWrapper({ items, fetchMoreData, hasMore, children }) {
	return (
		<InfiniteScroll
			dataLength={items.length}
			next={fetchMoreData}
			hasMore={hasMore}
			loader={<Typography>.....Loading</Typography>}
		>
			{children}
		</InfiniteScroll>
	);
}

export default InfiniteScrollWrapper;
