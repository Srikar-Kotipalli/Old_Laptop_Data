/* eslint-disable */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

export const getPositionIndex = (item, data) => {
	let index = null;
	let secondaryIndex = null;
	let tertiaryIndex = null;
	const indexData = data;
	if (indexData.findIndex(e => e.id === item.id) !== -1) {
		index = indexData.findIndex(e => e.id === item.id);
	} else {
		indexData.forEach((element, mainIndex) => {
			if (element.isOpen && element?.hierarchyListItems.findIndex(e => e.id === item.id) !== -1) {
				secondaryIndex = element?.hierarchyListItems.findIndex(e => e.id === item.id);
				index = mainIndex;
			} else {
				element.isOpen &&
					element?.hierarchyListItems?.forEach((hierarchyItem, hierarchyIndex) => {
						if (
							hierarchyItem.isOpen &&
							hierarchyItem.dispatches?.findIndex(e => e.id === item.id) !== -1
						) {
							tertiaryIndex = hierarchyItem.dispatches.findIndex(e => e.id === item.id);
							secondaryIndex = hierarchyIndex;
							index = mainIndex;
						}
					});
			}
		});
	}
	return { index, secondaryIndex, tertiaryIndex };
};

export const getStatusPostDeleteOrArchive = children => {
	if (children?.length !== 0) {
		const findFailed = children?.findIndex(i => i.status === 'FAILED');
		if (findFailed !== -1) {
			return 'FAILED';
		} else {
			const findRunning = children?.findIndex(i => i.status === 'RUNNING');
			if (findRunning !== -1) {
				return 'RUNNING';
			}
		}
		return 'COMPLETED';
	}
	return null;
};

export const getElectronsPostDeleteOrArchive = children => {
	let completedElectrons = 0;
	let totalElectrons = 0;
	if (children?.length !== 0) {
		children?.forEach(item => {
			completedElectrons += item.completedElectrons;
			totalElectrons += item.totalElectrons;
		});
	}
	return { completedElectrons, totalElectrons };
};

// eslint-disable-next-line import/no-unused-modules
export const getTimePostDeleteOrArchive = children => {
	let runTime = 0;
	let startTime = '';
	const startTimeValues = [];
	const lastUpdated = new Date();
	if (children?.length !== 0) {
		children?.forEach(item => {
			runTime += item.runTime;
			startTimeValues.push(new Date(item.startTime).getTime());
		});
		startTime = new Date(Math.min(...startTimeValues));
	}
	return { runTime, startTime, lastUpdated };
};
