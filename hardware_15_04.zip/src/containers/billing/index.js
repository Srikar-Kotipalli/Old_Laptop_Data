/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React, { useState, useMemo, useEffect } from 'react';
import { Auth } from 'aws-amplify';
import { Grid, Typography } from '@mui/material';
import PricingCard from '../../components/card/settings/pricingCard';
import BillingTable from '../../components/list/billing';
import { BillingContext } from './billingContext';
import {
	getAllInvoices,
	addPaymentMethods,
	getBillingAccounts,
	getPaymentMethods,
	getUserCharges,
	downloadInvoiceDetails,
	detachPaymentMethod
} from '../../api/billing/billingApi';
import CustomisedSnackbar from '../../components/snackbar/projects';

function BillingContainer() {
	const [openSnackbar, setOpenSnackbar] = React.useState(false);
	const [snackbarMessage, setSnackbarMessage] = React.useState('');
	const [invoices, setInvoices] = useState([]);
	const [invoicesLoader, setInvoicesLoader] = useState(false);
	const [sort, setSort] = useState('issued_date');
	const [direction, setDirection] = useState('desc');
	const [totalRecords, setTotalRecords] = useState();
	const [page, setPage] = useState(1);
	const count = 10;
	const handlePageChanges = (_event, pageValue) => {
		setPage(pageValue);
	};

	const downloadInvoice = invoiceId => {
		downloadInvoiceDetails(invoiceId)
			.then(response => {
				// Create a URL for the Blob
				const blobUrl = window.URL.createObjectURL(response);
				// Create a temporary anchor element
				const a = document.createElement('a');
				a.style.display = 'none';
				a.href = blobUrl;
				a.download = `${invoiceId}.pdf`;
				// Attach the anchor to the document body
				document.body.appendChild(a);
				// Trigger a click event to initiate the download
				a.click();
				// Remove the anchor element
				document.body.removeChild(a);
				// Revoke the Blob URL to release memory (optional)
				window.URL.revokeObjectURL(blobUrl);
			})
			.then(() => {
				setOpenSnackbar(true);
				setSnackbarMessage('PDF downloaded successfully');
			})
			.catch(error => {
				console.log(error);
				setOpenSnackbar(true);
				setSnackbarMessage('PDF could not be downloaded');
			});
	};

	const getBillingInvoices = () => {
		setInvoicesLoader(true);
		getAllInvoices(sort, direction, page - 1, count)
			.then(response => {
				setInvoices(response?.records || []);
				setTotalRecords(response?.metadata?.total_count);
				setInvoicesLoader(false);
			})
			.catch(() => {
				setInvoices([]);
				setTotalRecords(null);
				setInvoicesLoader(false);
			});
	};

	const onSort = id => {
		const isAsc = sort === id && direction === 'asc';
		setDirection(isAsc ? 'desc' : 'asc');
		setSort(id);
	};

	useEffect(() => {
		getBillingInvoices();
	}, [page, sort, direction]);

	// check if billing account exists
	const [billingAccount, setBillingAccount] = useState(null);
	const [isBillingAccountPresent, setIsBillingAccountPresent] = useState(false);
	const [triggerBillingApi, setTriggerBillingApi] = useState(false);
	const [triggerIntent, setTriggerIntent] = useState(false);

	// check if default payment-method is present
	const [paymentMethod, setPaymentMethod] = useState(null);
	const [defaultPaymentMethod, setDefaultPaymentMethod] = useState(false);
	const [isLoading, setIsLoading] = useState(true);
	const [isChargesLoading, setIsChargesLoading] = useState(true);
	const [openDeletePopup, setOpenDeletePopup] = useState(false);
	const [open, setOpen] = useState(false);

	const toggleDeleteModal = value => {
		setOpenDeletePopup(value);
	};

	const togglePaymentModal = value => {
		setOpen(value);
	};

	useEffect(() => {
		const paymentMethodsPromise = getPaymentMethods()
			.then(paymentMeth => {
				if (paymentMeth && Array.isArray(paymentMeth)) {
					if (paymentMeth.length > 0) {
						setPaymentMethod(paymentMeth?.[0]);
						setDefaultPaymentMethod(true);
					}
				}
			})
			.catch(() => {
				setPaymentMethod(null);
				setDefaultPaymentMethod(false);
			});
		const billingAccountsPromise = getBillingAccounts()
			.then(billingAcc => {
				if (billingAcc) {
					setBillingAccount(billingAcc);
					setIsBillingAccountPresent(true);
				}
			})
			.catch(() => {
				setBillingAccount(null);
				setIsBillingAccountPresent(false);
			});
		Promise.all([paymentMethodsPromise, billingAccountsPromise]).finally(() => {
			setIsLoading(false);
			togglePaymentModal(false);
		});
	}, [triggerBillingApi]);

	// get external setup intent
	const [externalSetupIntent, setExternalSetupIntent] = useState(null);
	useEffect(() => {
		addPaymentMethods()
			.then(resp => setExternalSetupIntent(resp?.external_setup_intent))
			.catch(err => {
				console.log(err);
			})
			.finally(() => {
				togglePaymentModal(false);
			});
	}, [triggerIntent]);

	const deletePaymentMethod = () => {
		toggleDeleteModal(false);
		if (paymentMethod) {
			setIsLoading(true);
			detachPaymentMethod(paymentMethod?.external_payment_method_id)
				.then(() => {
					setPaymentMethod(null);
					setDefaultPaymentMethod(false);
				})
				.catch(err => {
					console.log(err);
				})
				.finally(() => {
					setIsLoading(false);
					setTriggerIntent(prev => !prev);
				});
		}
	};

	// get user charges
	const [charges, setCharges] = useState(null);
	useEffect(() => {
		Auth.currentAuthenticatedUser().then(user => {
			const res = user?.attributes;
			const userID = res && res['custom:userID'];
			setIsChargesLoading(true);
			getUserCharges(userID)
				.then(payload => {
					if (payload) {
						setCharges(payload);
					}
					setIsChargesLoading(false);
				})
				.catch(() => {
					setCharges(null);
					setIsChargesLoading(false);
				});
		});
	}, []);

	// Context API values to pass to child components
	const contextValues = useMemo(
		() => ({
			invoices,
			sort,
			direction,
			totalRecords,
			page,
			setPage,
			setDirection,
			onSort,
			setInvoices,
			setTotalRecords,
			handlePageChanges,
			downloadInvoice,
			setTriggerBillingApi,
			setTriggerIntent,
			externalSetupIntent,
			paymentMethod,
			defaultPaymentMethod,
			billingAccount,
			isBillingAccountPresent,
			charges,
			isLoading,
			invoicesLoader,
			isChargesLoading,
			deletePaymentMethod,
			setOpenSnackbar,
			setSnackbarMessage,
			openDeletePopup,
			toggleDeleteModal,
			togglePaymentModal,
			open,
			setOpen
		}),
		[
			count,
			sort,
			direction,
			page,
			totalRecords,
			externalSetupIntent,
			paymentMethod,
			defaultPaymentMethod,
			billingAccount,
			isBillingAccountPresent,
			charges,
			isLoading,
			invoices,
			invoicesLoader,
			isChargesLoading,
			openDeletePopup,
			toggleDeleteModal,
			togglePaymentModal,
			open,
			setOpen
		]
	);

	return (
		<BillingContext.Provider value={contextValues}>
			<CustomisedSnackbar
				testId="billingSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			<Typography
				variant="h6"
				mt={3}
				sx={{
					color: 'white',
					fontSize: '16px'
				}}
			>
				Billing
			</Typography>
			<PricingCard />
			<Typography
				variant="h6"
				mt={3}
				sx={{
					color: 'white',
					fontSize: '16px'
				}}
			>
				Invoices list
			</Typography>
			<Grid item xs={10} className="containerSpacing" mt={1} pb={5}>
				<BillingTable />
			</Grid>
		</BillingContext.Provider>
	);
}

export default BillingContainer;
