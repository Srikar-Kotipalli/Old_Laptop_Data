import React, { useState } from 'react';
import { Grid, Box } from '@mui/material';
import RecentDispatches from '../../../components/dashboard/recentDispatches';
import SharedDispatches from '../../../components/dashboard/sharedDispatches';
import RecentEnvironments from '../../../components/dashboard/recentEnvironments';
import Summary from '../../../components/dashboard/summary';
import Button from '../../../components/primaryButton/index';
import Statistics from '../../../components/dashboard/statistics';
import Tutorials from '../../../components/dashboard/tutorials';
import GettingStarted from '../../../components/dashboard/gettingStarted';
import DashboardProvider from '../contexts/DashboardContext';

function Dashboard() {
	const [tutorialsOpen, setTutorialsOpen] = useState(false);
	const menuItems = ['This week', 'This month', 'Last 3 months'];  // Array for the Menu Items for the graph dropdown
	return (
		<DashboardProvider>
			<Box sx={{ pr: '10px', display: 'flex', justifyContent: 'end' }}>
				<Button
					variant="outlined"
					sx={{
						'&:hover': {
							backgroundColor: theme => theme?.palette?.background?.covalentPurple,
							borderRadius: '25px',
							borderColor: theme => theme?.palette?.background?.blue05
						},
						display: 'flex',
						justifyContent: 'center',
						borderRadius: '25px',
						height: '32px',
						border: '1px solid #CBCBD7',
						right: '0'
					}}
					color="white"
					handler={() => setTutorialsOpen(true)}
					title="Get Started"
				/>
			</Box>

			<Box
				sx={{
					// height: 'calc(100vh - 123px)',
					// width: 'calc(100vw - 123px)',
					height: '100%',
					width: '100%'
				}}
			>
				<Grid container>
					<Grid
						item
						xs={8}
						sx={{
							padding: '10px'
						}}
					>
						<Box>
							<Summary />
							<Tutorials tutorialsOpen={tutorialsOpen} setTutorialsOpen={setTutorialsOpen} />
						</Box>
						<Box sx={{ paddingTop: '10px' }}>
							<Statistics MenuItemArray={menuItems} />
						</Box>
					</Grid>
					<Grid
						item
						xs={4}
						sx={{
							padding: '10px 10px 10px 0'
						}}
					>
						<RecentDispatches />
					</Grid>
					<Grid
						item
						xs={4.5}
						sx={{
							padding: '10px'
						}}
					>
						<SharedDispatches />
					</Grid>
					<Grid
						item
						xs={3.5}
						sx={{
							padding: '10px'
						}}
					>
						<RecentEnvironments />
					</Grid>
					<Grid
						item
						xs={4}
						sx={{
							padding: '10px 10px 10px 0'
						}}
					>
						<GettingStarted />
					</Grid>
				</Grid>
			</Box>
		</DashboardProvider>
	);
}

export default Dashboard;
