/* eslint-disable react/jsx-no-constructed-context-values */
/* eslint-disable react/function-component-definition */
/* eslint-disable no-unused-vars */
import React, { createContext, useState } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import { getLatticeBatch, getLatticeBatchByCount } from '../../../api/dashboard/dashboardApi';

export const DashboardContext = createContext();

const DashboardProvider = ({ children }) => {
	const [dashboardLatticeCount, setDashboardLatticeCount] = useState(0);
	const [dispatchesData, setDispatchesData] = useState({});

	const getLatticeCount = () => {
		getLatticeBatch()
			.then(response => {
				setDashboardLatticeCount(response?.metadata?.total_count);
			})
			.catch(error => {
				console.error(error);
			});
	};

	const getDispatchesData = count => {
		getLatticeBatchByCount(count)
			.then(response => {
				setDispatchesData(response);
			})
			.catch(error => {
				console.error(error);
			});
	};

	return (
		<DashboardContext.Provider
			value={{
				getLatticeCount,
				dashboardLatticeCount,
				getDispatchesData,
				dispatchesData
			}}
		>
			{children}
		</DashboardContext.Provider>
	);
};

export default DashboardProvider;
