/* eslint-disable no-unused-vars */
/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable import/no-unused-modules */
import React, { useEffect, useState } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import { Grid } from '@mui/material';
import { useSelector } from 'react-redux';
import GraphLayout from './GraphLayout';
import { getGraphDetails, getLatticeByDispatchID } from '../../api/graph/graphLayoutApi';
import Loader from '../../components/loader';
import CustomisedSnackbar from '../../components/snackbar/projects';
import PageNotFoundScreen from '../pagenotfound';
import DispatchNotFoundScreen from '../pagenotfound/dispatchNotFound';

function ElectronFunction() {
	// Live refresh
	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);
	const socketData = useSelector(({ socket }) => socket.socketData);
	const { dispatchID } = useParams();
	const [GraphPreview, setGraphPreviewData] = useState([]);
	const [latticeDetails, setLatticeDetails] = useState([]);
	const [openLoader, setOpenLoader] = useState(false);
	const [notFound, setNotFound] = useState(false);
	const [showPostProcess, setPostProcess] = useState(false);

	// for snackbar state
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage] = useState('');
	const location = useLocation();
	const userId = location?.state?.userId;

	const getGraphDetailsApi = () => {
		setOpenLoader(true);
		getGraphDetails(dispatchID)
			.then(response => {
				const nodes12 = [];
				const edges12 = [];
				response?.nodes?.map(node => {
					return nodes12.push({
						name: node?.name,
						type: node?.type,
						function_id: node?.function_id,
						value_id: node?.value_id,
						deps_id: node?.deps_id,
						call_before_id: node?.call_before_id,
						call_after_id: node?.call_after_id,
						executor_id: node?.executor_id,
						results_id: node?.results_id,
						stdout_id: node?.stdout_id,
						stderr_id: node?.stderr_id,
						error_id: node?.error_id,
						created_at: node?.created_at,
						started_at: node?.started_at,
						completed_at: node?.completed_at,
						status: node?.status,
						python_version: node?.python_version,
						runtime: node?.runtime,
						parent_lattice_id: node?.parent_lattice_id,
						transport_graph_node_id: node?.transport_graph_node_id,
						id: node?.transport_graph_node_id,
						node_id: node?.transport_graph_node_id,
						executor_label: node?.executor?.environment_name
					});
				});
				response?.edges?.map(edge => {
					return edges12.push({
						edge_name: edge?.edge_name,
						parameter_type: edge?.parameter_type,
						arg_index: edge?.arg_index,
						source: edge?.from_node_id,
						target: edge?.to_node_id
					});
				});
				const data = {
					nodes: nodes12,
					links: edges12
				};
				setGraphPreviewData(data);
			})
			.catch(_error => {
				setNotFound(true);
			})
			.finally(() => {
				setOpenLoader(false);
			});
	};

	const getLatticeAPi = () => {
		setOpenLoader(true);
		getLatticeByDispatchID(dispatchID)
			.then(response => {
				setLatticeDetails(response);
			})
			.catch(_error => {
				setNotFound(true);
			});
	};

	useEffect(() => {
		getGraphDetailsApi();
		getLatticeAPi();
	}, []);

	useEffect(() => {
		if (socketData?.dispatch_id === dispatchID) {
			getGraphDetailsApi();
			getLatticeAPi();
		}
	}, [liveRefresh]);

	const nodeMap = new Map((GraphPreview?.nodes ?? []).map(node => [node.name, node]));

	const searchName = ':postprocess:';
	const searchStatus = 'FAILED';
	const desiredNode = nodeMap.get(searchName);

	useEffect(() => {
		if (desiredNode && desiredNode.status === searchStatus) {
			setPostProcess(true);
		}
	}, [GraphPreview]);

	return (
		<>
			{notFound ? (
				<DispatchNotFoundScreen />
			) : (
				<>
					<CustomisedSnackbar
						testId="projectSnackbar"
						open={openSnackbar}
						message={snackbarMessage}
						clickHandler={() => setOpenSnackbar(false)}
						onClose={() => setOpenSnackbar(false)}
					/>
					{openLoader && (
						<Grid container direction="row" justifyContent="space-between">
							<Loader isFetching={openLoader} width="100%" position="relative" height="70vh" />
						</Grid>
					)}

					<GraphLayout
						id="graphTour"
						showPostProcess={showPostProcess}
						setPostProcess={setPostProcess}
						GraphPreview={GraphPreview}
						latticeDetails={latticeDetails}
						dispatchID={dispatchID}
						userId={userId}
					/>
				</>
			)}
		</>
	);
}

const UUID_PATTERN =
	/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;

export function DispatchLayoutValidate() {
	const { dispatchID } = useParams();
	if (!UUID_PATTERN.test(dispatchID)) {
		return <PageNotFoundScreen />;
	}
	return <ElectronFunction />;
}

export default DispatchLayoutValidate;
