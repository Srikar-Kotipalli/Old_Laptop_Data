/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react';
import { Grid, Stack, Box, Button, Typography, InputBase } from '@mui/material';
// import Chip from '@mui/material/Chip';
import YAML from 'yaml';
import jsYaml from 'js-yaml';
import ReactFileReader from 'react-file-reader';
import Chip from '@mui/material/Chip';
import { styled } from '@mui/material/styles';
import { makeStyles } from '@mui/styles';
import { useNavigate, useLocation } from 'react-router-dom';
import { addEnvironment, editEnvironment } from '../../api/environments/environmentsApi';
// import { styled } from '@mui/material/styles';
import EnvironmentPackageTab from '../../components/tab/environments/envPackages';
import Icon from '../../components/icon';
import Breadcrumb from '../../components/breadcrumb';
import CopyButton from '../../components/copyButton';
import Edit from '../../assets/actions/edit.svg';
import Close from '../../assets/actions/close.svg';
import Delete from '../../assets/actions/delete.svg';
import Running from '../../assets/dispatch/dispatchRunningDashboard.svg';
// import EditorWithPreview from './editor';
import EditorWithPreview from './layout/editorWithPreview';
import CustomisedSnackbar from '../../components/snackbar/projects';
import EnvironmnetTab from '../../components/tab/environments/envOperations';
import MarketplaceDialogBox from '../../components/dialogBox/marketplace';
import YamlEditor from '../../components/aceEditor';
import EnvAccordion from '../../components/accordion/environments';
import DefaultBadge from '../../components/badge/environments';
import { capitalizeName } from '../../utils/utils';
import KeyValueInput from './layout/environmentsKeyValue';
import './style.css';
import routes from '../../constants/routes.json';

const useStyles = makeStyles(theme => ({
	disabledInput: {
		color: '#FFF' // White text color for disabled input
	}
}));

function AddNewEnvironment({
	editName,
	editChannels,
	editPip,
	editConda,
	editid,
	setTabValue,
	fetch,
	setFetch
}) {
	const [expanded, setExpanded] = useState(true);
	const [value, setValue] = useState('pip');
	const [name, setName] = useState(editName || '');
	const [yamlMessage, setYamlMessage] = useState('');
	const [openSnackbar, setOpenSnackbar] = React.useState(false);
	const [snackbarMessage, setSnackbarMessage] = React.useState('');
	const [openDialogBox, setOpenDialogBox] = useState(false);
	const [disableButton, setDisableButton] = useState(false);
	// const [tabValue, setTabValue] = useState('Edit');
	const [channels, setChannels] = React.useState(editChannels || []);
	const [pip, setPip] = React.useState(editPip || []);
	const [conda, setConda] = React.useState(editConda || []);
	// const [variables, setVariables] = React.useState([]);
	const [chipdata, setChipData] = useState([]);
	const [tags, setTags] = useState('');
	// const [description, setDescription] = useState('');
	const [filename, setFilename] = useState('');
	const [fileUpload, setFileUpload] = useState(false);
	const [YamlData, setYamlData] = useState('');
	const [YamlReadOnlyContent, setYamlReadOnlyContent] = useState('');

	const channelsAsString = channels?.join('\n');
	const pipAsString = pip?.join('\n');
	const condaAsString = conda?.join('\n');
	const navigate = useNavigate();
	const location = useLocation();

	const [openLoader, setOpenLoader] = useState(false);

	const isReadOnly = location?.pathname?.includes(routes?.ADD_ENVIRONMENT);

	const changeYamlData = setYamlFunction => {
		const newData = {};
		newData['channels'] = channels?.filter(
			(a, index, array) => a !== '' && array.indexOf(a) === index
		);
		newData['dependencies'] = [];
		newData?.dependencies?.push({
			pip: pip?.filter((a, index, array) => a !== '' && array.indexOf(a) === index)
		});
		newData?.dependencies?.push(
			...conda.filter((a, index, array) => a !== '' && array.indexOf(a) === index)
		);
		setYamlFunction(newData ? YAML?.stringify(newData) : '');
	};

	useEffect(() => {
		changeYamlData(setYamlReadOnlyContent);
	}, [pip, conda, channels]);

	useEffect(() => {
		changeYamlData(setYamlData);
	}, [value, fileUpload]);

	const handleValidateYaml = yamlContent => {
		try {
			const parsedYaml = jsYaml?.load(yamlContent); // Parse the YAML
			// Validation logic here
			if (!parsedYaml || typeof parsedYaml !== 'object') {
				setYamlMessage('Invalid YAML: YAML must be an object.');
			}
			setYamlMessage('');
			return true;
		} catch (error) {
			setYamlMessage(`Invalid YAML :${error?.reason}`);
			return false;
		}
	};

	useEffect(() => {
		if (YamlData) {
			const validYaml = handleValidateYaml(YamlData);
			if (validYaml) {
				const contArray = YamlData?.split('\n');
				// const uniqueContArr = contArray.filter((item, index) => contArray.indexOf(item) === index);
				const uniqueContArr = contArray?.filter(v => v !== '');
				const uniqueDataArr = uniqueContArr?.join('\n');
				if (uniqueDataArr) {
					const readEdited = jsYaml?.load(uniqueDataArr);
					const newPip = [];
					if (Array.isArray(readEdited?.['channels'])) {
						const newChannels = readEdited?.['channels'] || [];
						setChannels(newChannels);
					} else {
						setChannels([]);
					}
					if (Array.isArray(readEdited?.['dependencies'])) {
						readEdited?.['dependencies']?.forEach(element => {
							if (
								typeof element === 'object' &&
								element?.pip !== null &&
								element?.pip !== undefined
							) {
								if (Array.isArray(element['pip'])) {
									newPip.push(...element['pip']);
								}
							}
						});
						setPip([...newPip]);
						const newConda = [];
						readEdited?.dependencies?.forEach(element => {
							if (typeof element !== 'object') {
								newConda?.push(element);
							}
						});
						setConda([...newConda]);
					} else {
						setPip([]);
						setConda([]);
					}
				}
			}
		}
	}, [YamlData]);

	const handleChange = (_e, val) => {
		setValue(val);
	};

	// const handleTabClick = (_e, val) => {
	// 	setTabValue(val);
	// };

	const handleAccordionChange = () => {
		setExpanded(!expanded);
	};

	const ListItem = styled('li')(({ theme }) => ({
		margin: theme.spacing(0.5)
	}));

	const handleDelete = tag => {
		// handle delete
		const chips = [...chipdata];
		const index = chips?.indexOf(tag);
		if (index !== -1) {
			chips?.splice(index, 1);
		}
		setChipData([...chips]);
	};

	const handleKeyDown = event => {
		if (event.key === 'Enter') {
			const chips = [...chipdata];
			let tagsArray = tags?.trim()?.replace(/ +/g, ' ')?.toLowerCase()?.split(/,+/);
			tagsArray = tagsArray?.filter(e => e !== '');
			tagsArray = tagsArray?.map(e => e?.trim());
			chips?.push(...tagsArray);
			setChipData([...new Set(chips)]);
			setTags('');
		}
	};

	const handleFiles = files => {
		setFileUpload(false);
		const reader = new FileReader();
		// eslint-disable-next-line func-names
		reader.onload = function (_e) {
			const readData = YAML.parse(reader?.result);
			if (!readData?.channels && !readData?.dependencies) {
				setOpenSnackbar(true);
				setSnackbarMessage('Invalid file format or missing data.');
			} else {
				setName(name?.length === 0 ? readData?.name : name);
				setChannels(readData?.channels ? readData?.channels : []);
				setPip(
					readData?.dependencies
						? () => {
								const tempArr = [];
								readData?.dependencies?.forEach(element => {
									if (typeof element === 'object' && element?.pip) tempArr?.push(...element['pip']);
								});
								return tempArr;
						  }
						: []
				);
				setConda(
					readData?.dependencies
						? () => {
								const tempArr = [];
								readData?.dependencies?.forEach(element => {
									if (typeof element !== 'object') tempArr?.push(element);
								});
								return tempArr;
						  }
						: []
				);
				// Set the filename here
				setFilename(files[0]?.name);
				setFileUpload(true);
			}
		};
		reader.readAsText(files[0]);
	};

	const saveEnvironment = () => {
		if (!name) {
			setOpenSnackbar(true);
			setSnackbarMessage('Environment name cannot be empty');
		} else if (yamlMessage) {
			setOpenSnackbar(true);
			setSnackbarMessage('Invalid YAML format');
		} else {
			setDisableButton(true);
			setOpenLoader(true);
			const yamlFileCreate = new Blob([YamlReadOnlyContent], { type: 'yml' });
			if (!editName) {
				addEnvironment(yamlFileCreate, name)
					.then(_res => {
						setOpenSnackbar(true);
						setSnackbarMessage('Environment Added Successfully');
						navigate(`/environments/${_res.id}`);
					})
					.catch(err => {
						setSnackbarMessage(
							err?.detail ? err?.detail : 'Something went wrong, contact administrator'
						);
						setOpenSnackbar(true);
					})
					.finally(() => {
						setOpenLoader(false);
						setDisableButton(false);
					});
			} else {
				editEnvironment(editid, yamlFileCreate)
					.then(_res => {
						// setSnackbarMessage('Environment Edited Successfully');
						// setOpenSnackbar(true);
						if (_res?.id) {
							setTimeout(() => navigate(`/environments/${_res.id}`));
							setTimeout(() => setTabValue('overview'));
						}
					})
					.catch(error => {
						setOpenSnackbar(true);
						if (error?.status === 422) {
							setSnackbarMessage(
								error?.detail?.length > 0
									? error?.detail[0]?.msg
									: 'Something went wrong, contact administrator'
							);
						} else {
							setSnackbarMessage(
								error?.detail ? error?.detail : 'Something went wrong, contact administrator'
							);
						}
					})
					.finally(() => {
						setOpenLoader(false);
						setDisableButton(false);
					});
			}
		}
	};

	const handleEditorChange = newValue => {
		setYamlData(newValue);
	};

	const cancelEnv = () => {
		if (!editName) {
			// setName('');
			// setDescription('');
			// setTags([]);
			// setChannels([]);
			// setPip([]);
			// setConda([]);
			// setVariables([]);
			navigate('/environments');
		} else {
			setTabValue('overview');
		}
	};

	const classes = useStyles();

	return (
		<>
			{!editName ? (
				<Box>
					<MarketplaceDialogBox
						setOpenDialogBox={setOpenDialogBox}
						openDialogBox={openDialogBox}
						handler={cancelEnv}
						confirmButtonTitle="Discard"
						title="Discard"
						message="Are you sure you want to discard the changes?"
						srcIcon={Delete}
					/>
					<Box pb="37px">
						<Breadcrumb secondary="Environments" name="Add Environment" to="/environments" />
					</Box>
					{/* <Box pb="19px">
						<Typography fontSize="24px" color="#CBCBD7">
							Environments
						</Typography>
					</Box> */}
					<Grid container sx={{ justifyContent: 'space-between' }} pb="32px">
						{/* <Grid item xs={6} sm={6} md={8} lg={8} xl={8} p="15px 0 15px 0">
							<EnvironmnetTab value={tabValue} onChange={handleTabClick} />
						</Grid>
						<Grid item xs={6} sm={6} md={4} lg={4} xl={4}>
							<Grid container sx={{ justifyContent: 'space-around' }} xs={12}>
								<Box sx={{ float: 'right', mt: 2 }}>
									<Grid container>
										<Grid>
											<Stack direction="row" spacing={2} alignItems="center">
												<Box className="createdlabel">Created Date</Box>
												<Box className="createdlabelsub" sx={{ fontSize: '14px' }}>
													10-2-22
												</Box>
											</Stack>
										</Grid>
										<Grid sx={{ ml: 5 }}>
											<Stack direction="row" spacing={2} alignItems="center">
												<Box className="createdlabel">Last Build</Box>
												<Box className="createdlabelsub" sx={{ fontSize: '14px' }}>
													5-5-23
												</Box>
											</Stack>
										</Grid>
										<Grid sx={{ ml: 5 }}>
											<Stack direction="row" spacing={1} alignItems="center">
												<Tooltip title="Edit">
													<div>
														<Icon src={Edit} alt="Edit" />
													</div>
												</Tooltip>
												<CopyButton content="" />
												<Tooltip title="Delete">
													<div>
														<Icon src={Delete} alt="delete" />
													</div>
												</Tooltip>
											</Stack>
										</Grid>
									</Grid>
								</Box>
							</Grid>
						</Grid> */}
					</Grid>
				</Box>
			) : (
				''
			)}
			<CustomisedSnackbar
				testId="envSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			<Grid container spacing={2} pb="2rem">
				<Grid item xs={7}>
					<Grid container>
						<Grid item xs={7}>
							<Stack direction="column" spacing={2}>
								<Box>
									{!editName ? (
										<Typography fontSize="24px" color="#CBCBD7" sx={{ cursor: 'default' }}>
											Add a new Environment
										</Typography>
									) : (
										<Typography fontSize="24px" color="#CBCBD7" sx={{ cursor: 'default' }}>
											Edit Environment
										</Typography>
									)}
								</Box>
								<Grid sx={{ padding: '15px 0 15px 0' }}>
									<InputBase
										sx={{
											padding: '8px 12px',
											width: '80%',
											height: '32px',
											border: '1px solid #303067',
											borderRadius: '60px',
											fontSize: '14px',
											color: name ? '#F1F1F6' : '#CBCBD7', // Set the text color to white when disabled
											background: '#08081A',
											cursor: !editName ? 'default' : 'auto'
										}}
										value={name || ''}
										onChange={e => setName(e.target.value)}
										readOnly={!isReadOnly}
										placeholder="Environment Name"
									/>
								</Grid>

								{/* // Commenting this as this is dummy data and can be uncomment to check this placeholder data. */}

								{/* <Grid sx={{ paddingBottom: '32px' }}>
									<InputBase
										placeholder="Description"
										multiline
										disableUnderline
										rows={4}
										maxRows={4}
										sx={{
											border: '1px solid #303067',
											borderRadius: '6px',
											width: '80%',
											padding: '8px 12px'
										}}
										value={description}
										onChange={e => setDescription(e.target.value)}
										className="textAreaBox"
									/>
								</Grid>
								<Grid>
									<InputBase
										sx={{
											padding: '8px 12px',
											width: '80%',
											height: '32px',
											border: '1px solid #303067',
											borderRadius: '60px',
											fontSize: '14px',
											color: '#CBCBD7',
											background: '#08081A'
										}}
										value={tags || ''}
										onChange={e => setTags(e.target.value)}
										onKeyDown={handleKeyDown}
										disableUnderline
										placeholder="Press Enter to Add Tags"
									/>
								</Grid> */}
								{/* <Box paddingBottom="40px">
									<Box
										sx={{
											display: 'flex',
											listStyle: 'none',
											background: 'none',
											flexWrap: 'wrap',
											overflowY: 'auto',
											maxHeight: '45px'
										}}
										component="ul"
									>
										{chipdata?.map((data, index) => {
											return (
												// eslint-disable-next-line react/no-array-index-key
												<ListItem key={index}>
													<Chip label={data} size="small" onDelete={() => handleDelete(data)} />
												</ListItem>
											);
										})}
									</Box>
								</Box> */}
							</Stack>
						</Grid>
						<Grid item xs={4}>
							<Stack direction="row" spacing={2} sx={{ padding: '0 0 0 0' }}>
								<Button
									disabled={disableButton}
									sx={{
										background: '#08081A',
										fontSize: '14px',
										padding: '8px 16px',
										height: '32px',
										color: 'white',
										borderRadius: '70px',
										'&:hover': {
											backgroundColor: '#2A2A5C'
										},
										'&:disabled': {
											color: theme => theme.palette.text.gray03
										}
									}}
									onClick={!editName ? () => setOpenDialogBox(true) : cancelEnv}
								>
									Cancel
								</Button>
								<Button
									disabled={disableButton}
									variant="contained"
									color="primary"
									sx={{
										background: '#5552FF',
										fontSize: '14px',
										padding: '8px 16px',
										height: '32px',
										minWidth: '170px',
										color: 'white',
										borderRadius: '70px',
										'&:disabled': {
											background: theme => theme.palette.background.covalentPurple,
											color: theme => theme.palette.text.secondary,
											border: '1px solid',
											borderColor: theme => theme.palette.background.blue04,
											borderRadius: '70px'
										},
										'&:hover': {
											background: '#3633ff'
										}
									}}
									onClick={saveEnvironment}
								>
									{openLoader ? 'Saving changes' : 'Save changes'}{' '}
									{openLoader ? (
										<Box ml={1}>
											<Icon
												src={Running}
												status="circleRunningStatus"
												type="static"
												alt="runningIcon"
											/>
										</Box>
									) : null}
								</Button>
							</Stack>
						</Grid>
						<Box sx={{ paddingBottom: '15px', marginLeft: '-15px' }}>
							<EnvironmentPackageTab value={value} onChange={handleChange} />
						</Box>
						<Grid item xs={12} pb={2}>
							<Box>
								{value !== 'yaml' ? (
									<Typography sx={{ color: '#6D7CFF', paddingBottom: '12px', cursor: 'default' }}>
										{capitalizeName(value)} packages
									</Typography>
								) : (
									<Typography sx={{ color: '#6D7CFF', paddingBottom: '12px', cursor: 'default' }}>
										{capitalizeName(value)} Data
									</Typography>
								)}
								<Box sx={{ wordWrap: 'break-word', width: '70%' }}>
									<Typography color="#CBCBD7" fontSize="14px" sx={{ cursor: 'default' }}>
										Enter the libraries and packages that represents your computations need.
									</Typography>
								</Box>
							</Box>
						</Grid>
						{value === 'channels' && (
							<EditorWithPreview
								newDelimeter=""
								content={channelsAsString}
								setContent={setChannels}
								tabValue={value}
								variant="dnd"
							/>
						)}
						{value === 'pip' && (
							<EditorWithPreview
								content={pipAsString}
								setContent={setPip}
								tabValue={value}
								variant="dnd"
							/>
						)}
						{value === 'conda' && (
							<EditorWithPreview
								newDelimeter="="
								content={condaAsString}
								setContent={setConda}
								tabValue={value}
								variant="dnd"
							/>
						)}
						{/* {value === 'variables' && (
							<Box ml={-2} width="120%">
								<KeyValueInput initialPairs={variables} setContent={setVariables} />
							</Box>
						)} */}
						{value === 'yaml' && (
							<Grid item xs={7}>
								<Grid container sx={{ paddingTop: '20px' }} direction="column">
									<Grid item>
										<ReactFileReader fileTypes={['.yml']} handleFiles={handleFiles}>
											<Button
												sx={{
													color: '#86869A',
													border: '1px solid rgba(48, 48, 103, 1)',
													borderRadius: '60px',
													padding: '3px',
													width: '73%'
												}}
											>
												Upload a Yaml File
											</Button>
										</ReactFileReader>
										{fileUpload && filename ? (
											<Box padding="28px 0 0 0">
												<DefaultBadge
													// eslint-disable-next-line react/jsx-boolean-value
													isDefault={true}
													value={filename}
													icon={Close}
													onClick={() => {
														if (!editName) {
															setFileUpload(false);
															setChannels([]);
															setName('');
															setPip([]);
															setConda([]);
															// setVariables([]);
															setFilename('');
															setYamlData('');
															setYamlReadOnlyContent('');
														} else {
															// setFetch(prev => !prev);
															setFileUpload(false);
															setChannels(editChannels);
															setPip(editPip);
															setConda(editConda);
														}
													}}
												/>
											</Box>
										) : (
											''
										)}
									</Grid>
									<Grid item sx={{ padding: '25px 0 25px 0' }} xs={4}>
										<Grid width="80% !important">
											<YamlEditor
												value={YamlData}
												onChange={handleEditorChange}
												height="300px"
												color="#52886E"
												backgroundColor="#1D1D32"
											/>
											{yamlMessage && <Typography color="red">{yamlMessage}</Typography>}
										</Grid>
									</Grid>
								</Grid>
							</Grid>
						)}
					</Grid>
				</Grid>
				<Grid item xs={4.5} lg={4.8} xl={4.7} xxl={4.6}>
					<Box>
						<EnvAccordion
							expanded={expanded}
							handleChange={handleAccordionChange}
							yamlContent={YamlReadOnlyContent}
						/>
					</Box>
				</Grid>
			</Grid>
		</>
	);
}

export default AddNewEnvironment;
