/* eslint-disable no-unused-vars */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useEffect } from 'react';
import { useDebounce } from 'use-debounce';
import { Grid, Typography, Pagination, Box } from '@mui/material';
import YAML from 'yaml';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import OverviewHeader from '../../components/overviewHeader';
import Breadcrumb from '../../components/breadcrumb';
import SubHeaderControls from '../../components/subHeaderControls';
import {
	deleteEnivronment,
	getBatchEnvironments,
	getDefaultEnvironment,
	getYamlFile,
	getEnvironment,
	setDefaultEnvironment
} from '../../api/environments/environmentsApi';
import Icon from '../../components/icon';
import covLoader from '../../assets/loaders/covLoader.svg';
import Warning from '../../assets/environments/warning.svg';
import EnvironmentImage from '../../assets/environments/overviewIcon.svg';
import './style.css';
import CovalentCard from '../../components/card';
import EnvCardOverviewLayout from '../../components/card/layouts/environments/environments';
import CustomisedSnackbar from '../../components/snackbar/projects';
import useUpdateEffect from '../../utils/useUpdateEffect';
import CommonTab from '../../components/tab/graph';
import Secrets from './layout/secrets';
import urls from '../../constants/routes.json';
import EnvironmentProvider from './contexts/EnivironmentsContext';
import useSocketConnection from '../../socketHooks/useSocketConnection';
import { setEnvPage } from '../../redux/environmentSlice';

function Environments() {
	useSocketConnection();
	const [envData, setEnvData] = useState({});
	const [dataFetched, setDataFetched] = useState(false);
	const [openLoader, setOpenLoader] = useState(false);
	const [sort, setSort] = useState('asc');
	const [sortBy, setSortBy] = useState('status');
	const [searchKey, setSearchKey] = React.useState('');
	const [searchValue] = useDebounce(searchKey, 1000);
	const [reloadBatch, setReloadBatch] = useState(true);
	const [deleteId, setDeleteId] = useState(0);
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState('');
	const [isDefaultEnvPresent, setIsDefaultEnvPresent] = React.useState(true);
	const [cName, setCName] = useState('');
	const [value, setValue] = useState('Environments');
	const environmentAction = useDispatch();
	const { envPage } = useSelector(state => state.environment);
	const data = {
		name: 'Environments',
		desc: 'Manage & Create your compute environments'
	};
	const location = useLocation();

	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);
	const socketData = useSelector(({ socket }) => socket.socketData);

	// const secretData = {
	// 	name: 'Environment Management',
	// 	desc: 'Manage & Create your environments secrets'
	// };

	const updateEnvRecordFromSocket = id => {
		// update the environment which is received from socket
		getEnvironment(id)
			.then(res => {
				const indexToUpdate = envData?.records?.findIndex(e => e.id === id) ?? -1;
				const envResponseData = { ...envData };
				const envRecords = envResponseData?.records;
				const recordToUpdate = envRecords?.find(e => e.id === id);
				// update the package data along with the status
				getYamlFile(res?.definition)
					.then(file => {
						const parsedData = YAML.parse(file?.data);
						if (recordToUpdate && (indexToUpdate ?? -1) !== -1 && envRecords?.length > 0) {
							recordToUpdate.status = res?.status;
							recordToUpdate.parsedData = parsedData;
							envResponseData['records'] = envRecords;
							setEnvData(envResponseData);
						}
					})
					.catch(error => {
						console.error('Error parsing YAML:', error);
						return res;
					});
			})
			.catch(err => {
				console.error('Error parsing Env Data:', err);
				setEnvData({});
			});
	};

	useUpdateEffect(() => {
		if (socketData?.message === 'environment') {
			const envIdVal = socketData?.env_id;
			if (Object.keys(envData)?.length !== 0) {
				updateEnvRecordFromSocket(envIdVal);
			}
		}
	}, [liveRefresh]);

	const secretData = {
		name: 'Environment Management',
		desc: 'Manage & Create your environments secrets'
	};

	const [page, setPage] = useState(1);
	const [totalRecords, setTotalRecords] = useState(0);
	const [offset, setOffset] = useState(0);

	const recordsPerPage = 9;

	const handlePageChanges = (_event, pageValue) => {
		setPage(pageValue);
		environmentAction(setEnvPage({ envPage: pageValue }));
		const offsetValue = pageValue === 1 ? 0 : (pageValue - 1) * recordsPerPage;
		setOffset(offsetValue);
	};

	const onDelete = id => {
		deleteEnivronment(id)
			.then(() => {
				// After successful deletion, update the UI by reloading the data
				setDeleteId(id);
				setReloadBatch(!reloadBatch); // Toggle reloadBatch to trigger a re-fetch
				setSnackbarMessage(`Environment ${cName} has been deleted successfully`);
				setOpenSnackbar(true);
			})
			.catch(error => {
				// Handle error if the delete operation fails
				// console.error('Error deleting environment:', error);
				setSnackbarMessage(
					error?.detail ? error?.detail : 'Something went wrong please contact the administrator'
				);
				setOpenSnackbar(true);
			});
	};

	const setDefault = name => {
		setDefaultEnvironment(name)
			.then(_res => {
				setReloadBatch(!reloadBatch);
			})
			.finally(() => {
				setSnackbarMessage(`Environment ${cName} set as default.`);
				setOpenSnackbar(true);
			})
			.catch(err => {
				setSnackbarMessage(
					err?.detail ? err.detail : 'Something went wrong, contact administrator'
				);
				setOpenSnackbar(true);
			});
	};

	const postGetBatch = response => {
		getDefaultEnvironment()
			.then(resDefault => {
				const indexDefault = response?.records?.findIndex(e => e.id === resDefault?.environment_id);
				if (!resDefault?.environment_id) setIsDefaultEnvPresent(false);
				if (indexDefault !== -1) {
					setDataFetched(true);
					const records = response?.records;
					records[indexDefault]['default'] = true;
					response.records = records;
					setEnvData(response);
					setTotalRecords(response?.metadata?.total_count);
				} else {
					setDataFetched(true);
					setEnvData(response);
					setTotalRecords(response?.metadata?.total_count);
				}
			})
			.catch(() => {
				setEnvData(response);
				setTotalRecords(response?.metadata?.total_count);
			})
			.finally(() => {
				setOpenLoader(false);
			});
	};

	const fetchEnvData = () => {
		const pageVal = searchValue !== '' ? 0 : envPage - 1;
		const apiSearchVal = searchKey === '' ? '' : searchValue;
		getBatchEnvironments(recordsPerPage, pageVal, apiSearchVal, sortBy, sort)
			.then(response => {
				Promise.all(
					response?.records?.map(record => {
						return getYamlFile(record?.definition)
							.then(file => {
								const parsedData = YAML.parse(file?.data);
								return { ...record, parsedData };
							})
							.catch(error => {
								console.error('Error parsing YAML:', error);
								return record; // Fallback to original record on error
							});
					})
				)
					.then(parsedRecords => {
						const updatedResponse = {
							...response,
							records: parsedRecords
						};
						postGetBatch(updatedResponse);
					})
					.catch(() => {
						postGetBatch({});
					});
			})
			.catch(() => {
				postGetBatch({});
			});
	};

	useEffect(() => {
		setEnvData([]);
		if (value === 'Environments') {
			fetchEnvData();
			setOpenLoader(true);
		}
	}, [reloadBatch, page, envPage, searchValue, deleteId, value, sort, sortBy]);

	// const handlePageChange = (_event, pageValue) => {
	// 	setPage(pageValue);
	// };

	const onTabChange = (_e, val) => {
		setValue(val);
		setSearchKey('');
	};

	return (
		<>
			<CustomisedSnackbar
				testId="envSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			{/* // Commenting this as this is dummy data and can be uncomment to check this placeholder data. */}
			{/* <Breadcrumb secondary="Organization" name="Environments" to="/environments" /> */}
			{/* <OverviewHeader data={value !== 'Secrets' ? data : secretData} image={EnvironmentImage} /> */}
			<Box mt={3}>
				<CommonTab
					firstValue="Environments"
					secondValue="Secrets"
					value={value}
					onChange={onTabChange}
				/>
			</Box>
			<Grid container maxWidth="90%">
				{value === 'Environments' && (
					<SubHeaderControls
						width="102.2%"
						filterComponent
						sortComponenet={value === 'Environments'}
						sort={sort}
						setSort={setSort}
						sortBy={sortBy}
						setSortBy={setSortBy}
						searchValue={searchKey}
						setSearchValue={setSearchKey}
						placement={value !== 'Secrets' ? 'add' : null}
					/>
				)}
				{value === 'Secrets' && (
					<EnvironmentProvider>
						<Secrets searchKey={searchKey} setSearchKey={setSearchKey} />
					</EnvironmentProvider>
				)}
				{value === 'Environments' && !isDefaultEnvPresent && !envData?.records?.length < 1 && (
					<Grid
						mt={5}
						item
						sx={{
							background: theme => theme?.palette?.background?.paper,
							borderRadius: '8px',
							border: '1px solid',
							padding: '10px 18px 10px 15px',
							borderColor: theme => theme?.palette?.background?.blue03
						}}
					>
						<Typography fontSize={14}>
							<Icon type="default" src={Warning} />
							There is no user default environment set up
						</Typography>
					</Grid>
				)}
				{value === 'Environments' && (
					<Grid
						container
						mt={5}
						ml={0.8}
						pr={3}
						pb={3}
						className="envcardContainer"
						sx={{ borderColor: theme => theme?.palette?.background?.blue03 }}
						spacing={3}
					>
						{openLoader && (
							<Grid
								xs={12}
								container
								item
								height="20rem"
								direction="row"
								justifyContent="center"
								alignSelf="center"
							>
								<Icon type="pointer" src={covLoader} display="flex" />
							</Grid>
						)}
						{envData?.records &&
							!openLoader &&
							envData?.records?.map(env => {
								return (
									<CovalentCard key={env?.id}>
										<EnvCardOverviewLayout
											envData={env}
											onDelete={onDelete}
											onDefault={setDefault}
											setCName={setCName}
										/>{' '}
									</CovalentCard>
								);
							})}
						{(Object.keys(envData)?.length === 0 ||
							(envData?.records && envData?.records?.length < 1)) &&
							!openLoader && (
								<Grid item xs={4} xxl={3}>
									<Typography>No records found</Typography>
								</Grid>
							)}
						{envData?.records && !envData?.records?.length < 1 && (
							<Grid container className="footer" data-testid="tableFooter">
								<Pagination
									sx={{
										'& .MuiPaginationItem-root': {
											'&:hover': {
												backgroundColor: theme => theme?.palette?.background?.blue03
											}
										}
									}}
									color="primary"
									shape="rounded"
									variant="outlined"
									count={
										totalRecords && totalRecords > recordsPerPage
											? Math.ceil(totalRecords / recordsPerPage)
											: 1
									}
									page={envPage}
									onChange={handlePageChanges}
									showFirstButton
									showLastButton
									siblingCount={2}
									boundaryCount={2}
									data-testid="paginationItem"
								/>
							</Grid>
						)}
					</Grid>
				)}
			</Grid>
		</>
	);
}

export default Environments;
