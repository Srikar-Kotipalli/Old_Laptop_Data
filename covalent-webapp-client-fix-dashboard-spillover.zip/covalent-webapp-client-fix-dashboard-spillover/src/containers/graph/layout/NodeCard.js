/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
import React, { useContext } from 'react';
import { Grid, CardContent, Card, Box, Typography, Skeleton } from '@mui/material';
import progress from '../../../assets/graph/nodeIcons/RuntimeMin.svg';
import Icon from '../../../components/icon';
import GraphRuntime from '../../../utils/GraphRuntime';
import { statusColor } from '../../../components/icon/misc';
import { statusIcon } from '../../../utils/statusIcons';
import { Capitalize, dateFormatter } from '../../../utils/utils';
import { GraphContext } from '../contexts/GraphContext';

function NodeCard({
	title,
	value,
	isFetching = false,
	// hasImage = false,
	cardWidth,
	cardHeight,
	backend,
	runtime,
	nodeRuntime,
	totalErrors,
	started_at,
	completed_at,
	date,
	isLoading,
	type,
	fontSize,
	statusElectrons,
	transparent,
	direction,
	imgSource,
	fontColor,
	sx
}) {
	const { latticeDetails } = useContext(GraphContext);
	return (
		<Card
			square
			sx={{
				backgroundColor: transparent ? 'transparent' : 'rgba(28, 28, 70, 0.3)',
				borderRadius: '8px',
				height: cardHeight || '90px',
				width: cardWidth || '85%',
				boxShadow: transparent && 'none'
			}}
		>
			<CardContent sx={sx}>
				<Grid
					container
					item
					direction={direction || 'column'}
					alignItems={direction === 'row' ? 'center' : null}
				>
					<Box display="flex" direction="row">
						<Icon src={imgSource || progress} padding="0px 3px 1px 3px" type="static" />
						<Box
							sx={{
								fontSize: fontSize || (theme => theme.typography.sidebar),
								color: theme => theme.typography.sidebarTitle.color,
								paddingLeft: '6px',
								paddingRight: direction === 'row' ? '12px' : null,
								display: 'flex',
								alignItems: 'center'
							}}
						>
							{title}
						</Box>
					</Box>
					{isFetching ? (
						<Skeleton data-testid="qelectron_skl" width={80} height={30} />
					) : (
						<>
							<Box sx={{ display: 'flex' }}>
								{!value && type === 'status' ? (
									<Box
										sx={{
											paddingLeft: '7px',
											marginTop: '6px'
										}}
									>
										<Skeleton variant="rounded" width={80} height={20} />
									</Box>
								) : isLoading && value ? (
									<>
										<Typography
											sx={{
												fontSize: '18px',
												color: statusColor(value),
												paddingLeft: '7px',
												marginTop: '6px',
												whiteSpace: 'pre-line !important'
											}}
										>
											<Skeleton variant="rounded" width={80} height={27} />
										</Typography>
									</>
								) : (
									<>
										<Box sx={{ paddingTop: '8px' }}>{statusIcon(value)}</Box>
										<Typography
											sx={{
												fontSize: fontSize || '18px',
												color: statusColor(value),
												paddingLeft: '7px',
												marginTop: '6px',
												whiteSpace: 'pre-line !important'
											}}
										>
											{value
												? value === 'NEW_OBJECT'
													? latticeDetails?.status === 'FAILED'
														? 'Canceled'
														: 'Starting'
													: Capitalize(String(value))
												: ''}
										</Typography>
									</>
								)}
							</Box>
							<Box>
								{statusElectrons && statusElectrons?.length > 0 && (
									<Box display="flex">
										<Typography
											sx={{
												fontSize: '12px',
												color: '#86869A',
												paddingLeft: '7px',
												marginTop: '20px',
												whiteSpace: 'pre-line !important'
											}}
										>
											{value
												? value === 'NEW_OBJECT'
													? latticeDetails?.status === 'FAILED'
														? 'Canceled'
														: 'Starting'
													: Capitalize(String(value))
												: ''}
										</Typography>
										<Typography
											sx={{
												fontSize: '12px',
												fontWeight: 700,
												color: '#CBCBD7',
												paddingLeft: '7px',
												marginTop: '20px',
												marginLeft: '20px',
												whiteSpace: 'pre-line !important'
											}}
										>
											{`${statusElectrons[0]} / ${statusElectrons[1]}`}
										</Typography>
									</Box>
								)}
							</Box>
						</>
					)}
					{backend ? (
						<Box sx={{ marginTop: '18px' }}>
							<Typography
								sx={{
									color: '#86869A',
									fontSize: '12px',
									fontWeight: '400',
									padding: ' 0 0 0 4px'
								}}
							>
								Backend
							</Typography>
							{!isFetching && (
								<Typography
									sx={{
										color: '#CBCBD7',
										fontSize: '14px',
										fontWeight: '700',
										padding: ' 0 0 0 4px'
									}}
								>
									{Capitalize(backend)}
								</Typography>
							)}
							{isFetching && <Skeleton variant="rounded" width={70} height={20} />}
						</Box>
					) : null}
					{runtime ? (
						<Box sx={{ marginTop: '18px', padding: '0 4px 0 4px' }}>
							<Box sx={{ display: 'flex' }}>
								<Typography sx={{ color: '#86869A', fontSize: '12px', fontWeight: '400' }}>
									Shortest
								</Typography>
								{!isFetching && (
									<Typography
										sx={{
											color: '#CBCBD7',
											fontSize: '12px',
											fontWeight: '700',
											marginLeft: '60px'
										}}
									>
										{runtime?.shortest || '-'}
									</Typography>
								)}
								{isFetching && (
									<Skeleton sx={{ marginLeft: '60px' }} variant="rounded" width={30} height={20} />
								)}
							</Box>
							<Box sx={{ display: 'flex', paddingTop: '8px' }}>
								<Typography sx={{ color: '#86869A', fontSize: '12px', fontWeight: '400' }}>
									Longest
								</Typography>
								{!isFetching && (
									<Typography
										sx={{
											color: '#CBCBD7',
											fontSize: '12px',
											fontWeight: '700',
											marginLeft: '64px'
										}}
									>
										{runtime?.longest || '-'}
									</Typography>
								)}
								{isFetching && (
									<Skeleton sx={{ marginLeft: '64px' }} variant="rounded" width={30} height={20} />
								)}
							</Box>
						</Box>
					) : null}
					{type === 'started_completed_noderuntime' && !started_at && !isLoading ? (
						<Box>-</Box>
					) : type === 'started_completed_noderuntime' && !started_at ? (
						<Skeleton variant="rounded" width={20} height={20} />
					) : started_at && nodeRuntime && isLoading ? (
						<Skeleton variant="rounded" width={20} height={20} />
					) : (
						started_at &&
						nodeRuntime && (
							<GraphRuntime
								startTime={started_at}
								endTime={completed_at}
								className="overviewsubhead"
								sx={{ color: fontColor ? `${fontColor} !important` : '', fontSize: fontSize || '' }}
							/>
						)
					)}

					{isLoading && date && type === 'runtime' ? (
						<Skeleton variant="text" width={100} height={20} />
					) : (
						date &&
						type === 'runtime' && (
							<Box sx={{ display: 'flex', alignItems: direction === 'row' ? 'center' : null }}>
								{started_at ? (
									<Typography
										sx={{
											whiteSpace: 'nowrap',
											fontSize: fontSize || '14px',
											color: fontColor || ''
										}}
									>
										{dateFormatter(`${started_at}Z`)}
									</Typography>
								) : (
									<Typography
										sx={{
											whiteSpace: 'nowrap',
											fontSize: fontSize || '14px',
											color: fontColor || ''
										}}
									>
										{completed_at ? 'None' : '-'}
									</Typography>
								)}
								{completed_at && (
									<Typography
										sx={{
											whiteSpace: 'nowrap',
											fontSize: fontSize || '14px',
											pl: '2px',
											color: fontColor || ''
										}}
									>
										- {dateFormatter(`${completed_at}Z`)}
									</Typography>
								)}
								{!completed_at && started_at && (
									<Typography
										sx={{
											whiteSpace: 'nowrap',
											fontSize: fontSize || '14px',
											pl: '2px',
											color: fontColor || ''
										}}
									>
										- None
									</Typography>
								)}
							</Box>
						)
					)}

					{totalErrors || totalErrors === 0 ? (
						<Box sx={{ marginTop: '18px' }}>
							<Typography
								started_at
								sx={{
									color: '#FF6464',
									fontSize: '12px',
									fontWeight: '400',
									padding: ' 0 0 0 4px'
								}}
							>
								Total Errors
							</Typography>
							<Typography
								sx={{
									color: '#CBCBD7',
									fontSize: '14px',
									fontWeight: '700',
									padding: '3px 0 0 4px'
								}}
							>
								{totalErrors}
							</Typography>
						</Box>
					) : null}
				</Grid>
			</CardContent>
		</Card>
	);
}
export default NodeCard;
