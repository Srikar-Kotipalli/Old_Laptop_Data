/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable consistent-return */
/* eslint-disable array-callback-return */
/* eslint-disable quotes */
/* eslint-disable react/no-unstable-nested-components */
/* eslint-disable no-shadow */
/* eslint-disable no-unused-vars */
/* eslint-disable react/no-array-index-key */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable react/jsx-no-bind */
/**
 * Copyright 2023 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */

import React, { useEffect, useState, useContext } from 'react';
// import { useDispatch } from 'react-redux';
import {
	Table,
	TableRow,
	TableCell,
	TableBody,
	Typography,
	TableContainer,
	Box,
	styled,
	tableCellClasses,
	tableRowClasses,
	tableBodyClasses,
	tableSortLabelClasses,
	linkClasses,
	FormControlLabel,
	Checkbox,
	Grid,
	Skeleton,
	Tooltip,
	Chip,
	TableSortLabel,
	Menu,
	MenuItem,
	SvgIcon,
	Button,
	useMediaQuery
} from '@mui/material';

import { TableVirtuoso } from 'react-virtuoso';
import 'react-virtualized/styles.css';
import { getLocalStartTime, dateFormatter, truncateMiddle, Prettify } from '../../../utils/utils';
import { statusIcon } from '../../../utils/statusIcons';
import filter from '../../../assets/qelectron/filter.svg';
import CopyButton from '../../../components/copyButton';
import PackagesTooltip from '../../../components/tooltip/packagesTooltip';
import Icon from '../../../components/icon';
import Collapsed from '../../../assets/graph/collapsed_withoutborder.svg';
import SearchInput from '../../../components/inputBase/projects/searchInput';
import closeIcon from '../../../assets/actions/close.svg';
import arrowDown from '../../../assets/arrows/arrowDown.svg';
import { GraphContext } from '../contexts/GraphContext';
import { getQelectronJobOverview } from '../../../api/graph/graphLayoutApi';
import DeletableTags from '../../../components/tags/projects/deletableTags';
import checkbox from '../../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../../assets/checkboxes/checkboxChecked.svg';
import './style.css';
import VirtuosoTable from '../../../components/virtuosoTable';

const headers = [
	{
		id: 'circuit_id',
		getter: 'circuit_id',
		label: 'Job Id / Status',
		sortable: true,
		width: '55%',
		align: 'left'
	},
	{
		id: 'start_time',
		getter: 'start_time',
		label: 'Start Time',
		sortable: true,
		align: 'left'
	},
	{
		id: 'executor',
		getter: 'executor',
		label: 'Executor',
		sortable: true,
		align: 'left'
	},
	{
		id: 'backend',
		getter: 'backend',
		label: 'Backend Name',
		sortable: true,
		align: 'center'
	}
];

function ResultsTableHead({ order, orderBy, onSort }) {
	return (
		<>
			{headers?.map(header => {
				return (
					<TableCell key={header?.id} style={{ width: header?.width, textAlign: header?.align }}>
						{header.sortable ? (
							<TableSortLabel
								data-testid="tableHeader"
								active={orderBy === header.id}
								direction={orderBy === header.id ? order : 'asc'}
								onClick={() => onSort(header.id)}
								sx={{
									fontSize: '12px',
									'.Mui-active': {
										color: theme => theme.palette.text.tertiary
									}
								}}
							>
								{header.id === 'job_id' && (
									<span style={{ flex: 'none' }}>
										{' '}
										<Icon src={filter} />{' '}
									</span>
								)}
								{header.label}
							</TableSortLabel>
						) : (
							header.label
						)}
					</TableCell>
				);
			})}
		</>
		// </TableHead >
	);
}

const StyledTable = styled(Table)(({ theme }) => ({
	// customize text
	[`& .${tableBodyClasses.root} .${tableCellClasses.root}, & .${tableCellClasses.head}`]: {
		fontSize: '1rem'
	},

	// subdue header text
	[`& .${tableCellClasses.head}, & .${tableSortLabelClasses.active}`]: {
		color: theme.palette.text.tertiary,
		backgroundColor: 'transparent'
	},

	// copy btn on hover
	[`& .${tableBodyClasses.root} .${tableRowClasses.root}`]: {
		'& .copy-btn': { visibility: 'hidden' },
		'&:hover .copy-btn': { visibility: 'visible' }
	},

	// customize hover
	[`& .${tableBodyClasses.root} .${tableRowClasses.root}:hover`]: {
		backgroundColor: theme.palette.background.qElectronList,

		[`& .${tableCellClasses.root}`]: {
			borderColor: 'transparent',
			paddingTop: 4,
			paddingBottom: 4
		},
		[`& .${linkClasses.root}`]: {
			color: theme.palette.text.tertiary
		}
	},

	[`& .${tableBodyClasses.root} .${tableRowClasses.root}`]: {
		backgroundColor: 'transparent',
		cursor: 'pointer',

		[`& .${tableCellClasses.root}`]: {
			borderColor: 'transparent',
			paddingTop: 4,
			paddingBottom: 4
		}
		// [`& .${linkClasses.root}`]: {
		//   color: theme.palette.text.tertiary,
		// },
	},

	// customize selected
	[`& .${tableBodyClasses.root} .${tableRowClasses.root}.Mui-selected`]: {
		backgroundColor: theme.palette.background.qElectronList
	},
	[`& .${tableBodyClasses.root} .${tableRowClasses.root}.Mui-selected:hover`]: {
		backgroundColor: theme.palette.background.default
	},
	// customize border
	[`& .${tableCellClasses.root}`]: {
		borderColor: 'transparent',
		paddingTop: 4,
		paddingBottom: 4
	},

	[`& .${tableCellClasses.root}:first-of-type`]: {
		borderTopLeftRadius: 8,
		borderBottomLeftRadius: 8
	},
	[`& .${tableCellClasses.root}:listDatalast-of-type`]: {
		borderTopRightRadius: 8,
		borderBottomRightRadius: 8
	}
}));

function QelectronList({ dataList, isFetching, setSelectedJobIndex }) {
	// const dispatch = useDispatch();
	const { setSelectedJob, selectedJob, setSelectedJobDetails, setIsFetchingSelectedJobDetails } =
		useContext(GraphContext);
	const [sortColumn, setSortColumn] = useState('start_time');
	const [sortOrder, setSortOrder] = useState('desc');
	const [searchKey, setSearchKey] = useState('');
	const [selected, setSelected] = useState('last_updated');
	const [selectedBackends, setSelectedBackends] = useState([]);
	const [selectedExecutors, setSelectedExecutors] = useState([]);
	const [anchorElBackend, setAnchorElBackend] = useState(null);
	const [anchorElExecutor, setAnchorElExecutor] = useState(null);
	const [tagsToFilter, setTagsToFilter] = useState([]);
	const [initialData, setInitialData] = useState(dataList);
	const [data, setData] = useState(dataList);
	const [gridHeight, setGridHeight] = useState(null);

	const cancelSearch = () => {
		setSearchKey('');
	};

	const uniqueBackendNames = new Set();
	const uniqueExecutorNames = new Set();

	initialData.forEach(item => {
		uniqueBackendNames.add(item.backend);
		uniqueExecutorNames.add(item.executor);
	});

	const uniqueBackendNamesArray = Array.from(uniqueBackendNames);
	const uniqueExecutorNamesArray = Array.from(uniqueExecutorNames);

	const handleBackendChange = event => {
		const backendName = event.target.value;
		setTagsToFilter(prevTags => {
			if (prevTags.includes(backendName)) {
				// If the backend is already selected, remove it from the chips
				return prevTags.filter(name => name !== backendName);
			}
			// If the backend is not selected, add it to the chips
			return [...prevTags, backendName];
		});
		setSelectedBackends(prevSelected => {
			if (prevSelected.includes(backendName)) {
				// If the backend is already selected, remove it
				return prevSelected.filter(name => name !== backendName);
			}
			// If the backend is not selected, add it
			return [...prevSelected, backendName];
		});
	};

	const handleExecutorChange = event => {
		const executorName = event.target.value;
		setTagsToFilter(prevTags => {
			if (prevTags.includes(executorName)) {
				// If the executor is already selected, remove it from the chips
				return prevTags.filter(name => name !== executorName);
			}
			// If the executor is not selected, add it to the chips
			return [...prevTags, executorName];
		});
		setSelectedExecutors(prevSelected => {
			if (prevSelected.includes(executorName)) {
				// If the executor is already selected, remove it
				return prevSelected.filter(name => name !== executorName);
			}
			// If the executor is not selected, add it
			return [...prevSelected, executorName];
		});
	};

	const clearAllFilters = () => {
		setTagsToFilter([]);
		setSelectedBackends([]); // Clear selected backends
		setSelectedExecutors([]); // Clear selected executors
	};

	const handleDeleteTag = tag => {
		const isBackendTag = uniqueBackendNamesArray.includes(tag);
		const isExecutorTag = uniqueExecutorNamesArray.includes(tag);

		if (isBackendTag) {
			// Remove the tag from the selected backends
			setSelectedBackends(prevSelected => prevSelected.filter(name => name !== tag));
		} else if (isExecutorTag) {
			// Remove the tag from the selected executors
			setSelectedExecutors(prevSelected => prevSelected.filter(name => name !== tag));
		}

		// Remove the tag from the tagsToFilter
		setTagsToFilter(prevTags => prevTags.filter(name => name !== tag));
	};

	const calculateGridHeight = dataList => {
		let calculatedHeight = '50vh';

		if (dataList.length < 8) {
			const baseHeight = 90;
			calculatedHeight = baseHeight + dataList.length * 35;
		}

		return calculatedHeight;
	};

	useEffect(() => {
		setData([...dataList]);
		setInitialData([...dataList]);
	}, [dataList]);

	useEffect(() => {
		let filteredData = [...dataList];

		if (selectedBackends.length > 0) {
			filteredData = filteredData.filter(item => selectedBackends.includes(item.backend));
		}

		if (selectedExecutors.length > 0) {
			filteredData = filteredData.filter(item => selectedExecutors.includes(item.executor));
		}

		const sortedData = [...filteredData];

		if (sortColumn === 'start_time') {
			sortedData.sort((a, b) => {
				const dateA = new Date(a?.start_time);
				const dateB = new Date(b?.start_time);
				if (sortOrder === 'asc') {
					return dateA - dateB;
				}
				return dateB - dateA;
			});
		} else {
			sortedData.sort((a, b) => {
				if (sortOrder === 'asc') {
					return a[sortColumn].localeCompare(b[sortColumn]);
				}
				return b[sortColumn].localeCompare(a[sortColumn]);
			});
		}

		setData(sortedData);

		if (searchKey !== '') {
			// Apply search filter
			setData(
				sortedData.filter(
					item =>
						item?.circuit_id?.toLowerCase().includes(searchKey.toLowerCase()) ||
						item?.executor?.toLowerCase().includes(searchKey.toLowerCase()) ||
						item?.backend?.toLowerCase().includes(searchKey.toLowerCase())
				)
			);
		}

		setGridHeight(calculateGridHeight(data));
	}, [searchKey, selected, selectedBackends, selectedExecutors, dataList, sortColumn, sortOrder]);

	useEffect(() => {
		setIsFetchingSelectedJobDetails(true);
		getQelectronJobOverview(selectedJob)
			.then(res => {
				setSelectedJobDetails(res);
				setIsFetchingSelectedJobDetails(false);
			})
			.catch(err => {
				setSelectedJobDetails({});
				setIsFetchingSelectedJobDetails(false);
			});
	}, [selectedJob]);

	const selectionChangeHandler = event => {
		setSelected(event.target.value);
	};

	const handleChangeSort = column => {
		const isAsc = sortColumn === column && sortOrder === 'asc';
		setSortOrder(isAsc ? 'desc' : 'asc');
		setSortColumn(column);
	};

	function CustomIcon(props) {
		return (
			// eslint-disable-next-line react/jsx-props-no-spreading
			<SvgIcon {...props} style={{ transform: 'translateY(20%)' }}>
				<svg
					width="16"
					height="16"
					viewBox="0 0 16 22"
					fill="none"
					xmlns="http://www.w3.org/2000/svg"
				>
					<path
						d="M8 10.9998L3 5.9998L3.7 5.2998L8 9.59981L12.3 5.2998L13 5.9998L8 10.9998Z"
						fill="#CBCBD7"
					/>
				</svg>
			</SvgIcon>
		);
	}

	function RenderRow({ index, key, style, user }) {
		const result = user;
		return (
			<div key={key} className="row" style={style}>
				<TableCell align="left" style={{ width: '40%' }}>
					<Grid
						sx={{
							fontSize: '14px',
							display: 'flex',
							alignItems: 'center'
						}}
					>
						{statusIcon(result?.status)}
						<Tooltip title={result?.circuit_id} placement="right">
							<Typography
								component="span"
								sx={{
									mx: 1,
									verticalAlign: 'middle',
									fontSize: '14px',
									color: theme => theme.palette.text.primary
								}}
							>
								{truncateMiddle(result?.circuit_id, 12, 12)}
							</Typography>
						</Tooltip>
						<CopyButton borderEnable content={result?.circuit_id} backgroundColor="#08081A" />
					</Grid>
				</TableCell>
				<TableCell align="left" sx={{ width: '20%' }}>
					<Box
						sx={{
							display: 'flex',
							fontSize: '14px'
						}}
					>
						{result?.start_time ? dateFormatter(new Date(result?.start_time)?.toISOString()) : '-'}
					</Box>
				</TableCell>
				<TableCell align="left" sx={{ width: '20%' }}>
					<Box
						sx={{
							display: 'flex',
							fontSize: '14px'
						}}
					>
						{result?.executor}
					</Box>
				</TableCell>
				<TableCell sx={{ width: '20%' }}>
					<Chip
						sx={{
							width: '90%',
							border: '1px solid',
							borderColor: theme => theme.palette.background.covalentPurple, // <tr style={{ marginBottom: '5px', background: '#08081a' }}>
							// 	<th style={{ width: '40%', textAlign: 'left' }}>Job Id/ Status</th>
							// 	<th style={{ width: '20%', textAlign: 'left' }}>Start Time</th>
							// 	<th style={{ width: '20%', textAlign: 'center' }}>Executor</th>
							// 	<th style={{ width: '20%', textAlign: 'center' }}>Backend</th>
							// </tr>
							padding: '0px 5px',
							display: 'flex',
							justifyContent: 'space-between',
							background: result?.backendColor
						}}
						label={<PackagesTooltip chip={Prettify(result?.backend)} width="100%" />}
					/>
				</TableCell>
			</div>
		);
	}

	const openMenuBackend = event => {
		setAnchorElBackend(event.currentTarget);
	};

	const closeMenuBackend = () => {
		setAnchorElBackend(null);
	};

	const openMenuExecutor = event => {
		setAnchorElExecutor(event.currentTarget);
	};

	const closeMenuExecutor = () => {
		setAnchorElExecutor(null);
	};

	const renderBackendMenuItems = uniqueBackendNamesArray.map(backend => (
		<MenuItem key={backend} sx={{ fontSize: '12px' }}>
			<FormControlLabel
				control={
					<Checkbox
						checked={selectedBackends.includes(backend)}
						onChange={handleBackendChange}
						size="small"
						value={backend}
						icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
						checkedIcon={<Icon src={checkboxChecked} alt="checkboxChecked" type="pointer" />}
					/>
				}
				label={<Typography variant="subtitle2">{backend}</Typography>}
			/>
		</MenuItem>
	));

	const renderExecutorMenuItems = uniqueExecutorNamesArray.map(executor => (
		<MenuItem key={executor}>
			<FormControlLabel
				control={
					<Checkbox
						checked={selectedExecutors.includes(executor)}
						onChange={handleExecutorChange}
						value={executor}
						size="small"
						icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
						checkedIcon={<Icon src={checkboxChecked} alt="checkboxChecked" type="pointer" />}
					/>
				}
				label={<Typography variant="subtitle2">{executor}</Typography>}
			/>
		</MenuItem>
	));

	function getPaddingByScreenWidth() {
		const isWideScreen = useMediaQuery('(min-width: 1900px)');
		const isMediumScreen = useMediaQuery('(min-width: 1800px)');

		if (isWideScreen) {
			return '0px 2vw'; // Adjust the padding value for screens above 1900px
		} else if (isMediumScreen) {
			return '0px 2vw'; // Adjust the padding value for screens above 1800px
		}
		return '0px 1vw'; // Default padding for screens below 1800px
	}

	const RenderRows = ({ user, index }) => {
		return (
			<>
				<TableCell
					style={{
						width: '45%',
						borderColor: 'transparent',
						background: user?.circuit_id === selectedJob ? 'rgba(48, 48, 103, 0.60)' : 'transparent'
					}}
					key={index}
				>
					<Grid
						pl={0.5}
						onClick={() => {
							setSelectedJob(user?.circuit_id);
							setSelectedJobIndex(index);
						}}
						sx={{
							fontSize: '14px',
							display: 'flex',
							alignItems: 'center'
						}}
					>
						{statusIcon(user?.status)}
						<Tooltip title={user?.circuit_id} placement="right">
							<Typography
								component="span"
								sx={{
									mx: 1,
									verticalAlign: 'middle',
									fontSize: '14px',
									color: theme => theme.palette.text.primary
								}}
							>
								{truncateMiddle(user?.circuit_id, 12, 12)}
							</Typography>
						</Tooltip>
						<CopyButton borderEnable content={user?.circuit_id} backgroundColor="#08081A" />
					</Grid>
				</TableCell>
				<TableCell
					style={{
						width: '18.333333%',
						borderColor: 'transparent',
						background: user?.circuit_id === selectedJob ? 'rgba(48, 48, 103, 0.60)' : 'transparent'
					}}
				>
					<Box
						onClick={() => {
							setSelectedJob(user?.circuit_id);
							setSelectedJobIndex(index);
						}}
						sx={{
							display: 'flex',
							fontSize: '14px'
						}}
					>
						{user?.start_time ? dateFormatter(new Date(user?.start_time)?.toISOString()) : '-'}
					</Box>
				</TableCell>
				<TableCell
					style={{
						width: '18.333333%',
						borderColor: 'transparent',
						textAlign: 'left',
						fontSize: '14px',
						background: user?.circuit_id === selectedJob ? 'rgba(48, 48, 103, 0.60)' : 'transparent'
					}}
				>
					<Box
						onClick={() => {
							setSelectedJob(user?.circuit_id);
							setSelectedJobIndex(index);
						}}
					>
						{user?.executor}
					</Box>
				</TableCell>
				<TableCell
					style={{
						width: '18.333333%',
						alignItems: 'center',
						borderColor: 'transparent',
						background: user?.circuit_id === selectedJob ? 'rgba(48, 48, 103, 0.60)' : 'transparent'
					}}
				>
					<Box
						onClick={() => {
							setSelectedJob(user?.circuit_id);
							setSelectedJobIndex(index);
						}}
					>
						<Chip
							sx={{
								margin: 'auto',
								width: '90%',
								border: '1px solid',
								borderColor: theme => theme.palette.background.covalentPurple,
								borderRadius: '8px',
								padding: getPaddingByScreenWidth,
								display: 'flex',
								justifyContent: 'center',
								background: user?.backendColor
							}}
							label={<PackagesTooltip chip={Prettify(user?.backend)} width="100%" />}
						/>
					</Box>
				</TableCell>
			</>
		);
	};

	return (
		<Box sx={{ width: '100%' }}>
			<Box mt={3}>
				<Box sx={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
					<SearchInput
						sx={{ border: '1px solid #303067', width: '30%' }}
						value={searchKey || ''}
						onChange={e => setSearchKey(e.target.value)}
						cancelSearch={cancelSearch}
					/>

					<Box sx={{ display: 'flex' }}>
						<Button
							variant="outlined"
							onClick={openMenuBackend}
							sx={{
								'border-radius': '25px',
								height: '32px',
								marginRight: '1rem',
								display: 'flex',
								alignItems: 'center'
							}}
						>
							<Typography mr={1} sx={{ fontSize: '14px' }}>
								Backend
							</Typography>
							<Icon src={arrowDown} padding="1px 0px 0px 0px" />
						</Button>
						<Menu
							anchorEl={anchorElBackend}
							open={Boolean(anchorElBackend)}
							onClose={closeMenuBackend}
						>
							{renderBackendMenuItems}
						</Menu>
						<Button
							variant="outlined"
							onClick={openMenuExecutor}
							sx={{
								'border-radius': '25px',
								height: '32px',
								display: 'flex',
								alignItems: 'center'
							}}
						>
							<Typography mr={1} sx={{ fontSize: '14px' }}>
								Executor
							</Typography>
							<Icon src={arrowDown} padding="1px 0px 0px 0px" />
						</Button>
						<Menu
							anchorEl={anchorElExecutor}
							open={Boolean(anchorElExecutor)}
							onClose={closeMenuExecutor}
						>
							{renderExecutorMenuItems}
						</Menu>
						{/* <Button
							variant="outlined"
							sx={{
								'&:hover': {
									backgroundColor: theme => theme.palette.background.covalentPurple,
									color: '#FFFFFF',
									borderRadius: '25px',
									borderColor: theme => theme.palette.background.blue05
								},
								display: 'flex',
								justifyContent: 'center',
								borderRadius: '25px',
								height: '32px',
								width: '121px',
								marginLeft: '2rem'
							}}
							endIcon={
								<img
									src={ascending}
									alt={sort}
									style={{ transform: sort === 'dsc' ? 'rotate(180deg)' : '' }}
								/>
							}
							onClick={handleSortClick}
						>
							<Typography variant="h2" pt={0}>
								{sort === 'asc' ? 'Ascending' : 'Descending'}
							</Typography>
						</Button> */}
					</Box>
				</Box>
				<Box mb={2}>
					{tagsToFilter.length > 0 && (
						<Grid item xs={12} sx={{ display: 'flex', paddingTop: '5px', paddingLeft: '5px' }}>
							<DeletableTags variant="shared" tags={tagsToFilter} deleteTagss={handleDeleteTag} />
							<Tooltip title="Clear all filtered tags" placement="right">
								<Grid
									sx={{
										display: 'flex',
										backgroundColor: '#303067',
										marginLeft: '5px',
										borderRadius: '8px',
										pt: 0.3,
										cursor: 'pointer'
									}}
									onClick={clearAllFilters}
								>
									<Icon src={closeIcon} />
								</Grid>
							</Tooltip>
						</Grid>
					)}
				</Box>
			</Box>
			{!isFetching && data && (
				<>
					{data && data?.length > 0 && !isFetching && (
						<>
							{/* <Grid container p={0} m={0} xs={12} sx={{ height: gridHeight }}>
								<TableVirtuoso
									style={{ width: '200%' }}
									data={data}
									fixedHeaderContent={() => (
										<TableRow style={{ marginBottom: '5px', background: '#08081a' }}>
											{data && data?.length > 0 && (
												<ResultsTableHead
													order={sortOrder}
													orderBy={sortColumn}
													onSort={handleChangeSort}
												/>
											)}
										</TableRow>
									)}
									itemContent={(index, user) => <RenderRows user={user} index={index} />}
								/>
							</Grid> */}
							<VirtuosoTable
								data={data}
								ResultsTableHead={ResultsTableHead}
								RenderRows={RenderRows}
								sortOrder={sortOrder}
								sortColumn={sortColumn}
								handleChangeSort={handleChangeSort}
								height="50vh"
								limit={7}
							/>
						</>
					)}
					<Grid xs={12}>
						{data && data?.length === 0 && !isFetching && (
							<Typography
								sx={{
									textAlign: 'center',
									color: 'text.secondary',
									fontSize: 'h6.fontSize',
									paddingTop: 9,
									paddingBottom: 2
								}}
							>
								No results found.
							</Typography>
						)}
					</Grid>
				</>
			)}
			{isFetching && data?.length === 0 && (
				<Box>
					<TableContainer>
						<StyledTable>
							<TableBody>
								{[...Array(3)].map(() => (
									<TableRow
										key={Math.random()}
										sx={{
											height: '2.5rem'
										}}
									>
										<TableCell>
											<Skeleton sx={{ my: 1, mx: 1 }} />
										</TableCell>
										<TableCell>
											<Skeleton sx={{ my: 1, mx: 1 }} />
										</TableCell>
										<TableCell>
											<Skeleton sx={{ my: 1, mx: 1 }} />
										</TableCell>
									</TableRow>
								))}
							</TableBody>
						</StyledTable>
					</TableContainer>
				</Box>
			)}
		</Box>
	);
}

export default QelectronList;
