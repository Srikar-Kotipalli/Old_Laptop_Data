/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable react/no-array-index-key */
/* eslint-disable react/jsx-props-no-spreading */
/* eslint-disable camelcase */
/* eslint-disable react/jsx-boolean-value */
/* eslint-disable no-unused-vars */
/* eslint-disable max-len */
import React, { useState, useEffect, useContext, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Skeleton from '@mui/material/Skeleton';
import Avatar from '@mui/material/Avatar';
import AvatarGroup from '@mui/material/AvatarGroup';
import { Tooltip, Stepper, Step, StepLabel, Divider, Button, LinearProgress } from '@mui/material';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import CopyButton from '../../../components/copyButton/index';
import Expanded from '../../../assets/graph/Expanded.svg';
import Collapsed from '../../../assets/graph/collapsed.svg';
import Share from '../../../assets/graph/share.svg';
import Electrons from '../../../assets/graph/accordion/Electrons.svg';
import Runtime from '../../../assets/graph/accordion/Runtime.svg';
import Status from '../../../assets/graph/accordion/status.svg';
import CostImg from '../../../assets/graph/accordion/CostImg.svg';
import Inputimage from '../../../assets/graph/accordion/Input.svg';
import Output from '../../../assets/graph/accordion/Output.svg';
import ErrorFunction from '../../../assets/graph/ErrorFunction.svg';
import NodeData from './NodeData';
import Input from './Input';
import CodeAccordion from './CodeAccordion';
import GraphDescription from './GraphDescription';
import FunctionChip from './FunctionChip';
import { getTimeLineIcon, statusIcon } from '../../../utils/statusIcons';
import { statusColor } from '../../../components/icon/misc';
import { Capitalize, getQElectronCount } from '../../../utils/utils';
import { GraphContext } from '../contexts/GraphContext';
import noStatus from '../../../assets/dispatch/noStatus.svg';
import placeholder from '../../../assets/dispatch/placeholder.svg';
import Icon from '../../../components/icon';
// import progress from '../../../assets/graph/progress.svg';
import routes from '../../../constants/routes.json';
import Refresh from '../../../assets/graph/Refresh.svg';

// function CustomAvatar(props) {
// 	const { user, variant, index } = props;

// 	const avatarColors = ['#AD7BFF', '#6D7CFF', '#8B31FF', '#464660', '#998CEB'];

// 	function stringAvatar(name) {
// 		return {
// 			sx: {
// 				bgcolor: avatarColors[index],
// 				width: '1.75rem',
// 				height: '1.75rem',
// 				fontSize: '12px',
// 				color: theme => theme.palette.text.secondary
// 			},
// 			children: variant === 'total' ? ` +${name}` : `${name?.toUpperCase()?.slice(0, 1)}`
// 		};
// 	}
// 	return (
// 		<Tooltip title={variant === 'total' ? ` +${user}` : `${user}`}>
// 			<Avatar {...stringAvatar(user)} />
// 		</Tooltip>
// 	);
// }

function getNoStatus() {
	return (
		<Box
			sx={{
				height: '26px',
				width: '26px',
				borderRadius: '4px',
				border: '1px solid rgba(48, 48, 103, 0.20)',
				display: 'grid',
				placeItems: 'center',
				background: 'rgba(28, 28, 70, 0.30)'
			}}
		>
			<img src={noStatus} alt="img" style={{ cursor: 'default' }} />
		</Box>
	);
}

function AccordianWithoutErrors({
	setIsFetchingNodedata,
	isFetchingLatticeDetails,
	isFetchingLatticeInput,
	isFetchingLatticeResult,
	isFetchingLatticeError,
	isFetchingLatticeErrorFunctions,
	dispatchID,
	dispatchResult,
	dispatchResultcopy,
	input,
	Code,
	description,
	status,
	error,
	errorFunctions,
	executedElectrons,
	totalElectrons,
	started_at,
	completed_at,
	dispatchCodeCopy,
	userList,
	handleErrorScroll,
	RefreshClick
	// setSharePopupEnable,
	// enableShareOption
}) {
	const {
		entireGraph,
		latticeTimeline,
		latticeCost,
		isFetchingLatticeCost,
		isFetchingLatticeCode,
		// sharePopupEnable,
		// setSharePopupEnable,
		enableShareOption
		// setEnableShareOption
	} = useContext(GraphContext);

	// const errorRef = useRef(null);
	const navigate = useNavigate();
	const [funcErrors, setFuncErrors] = useState(
		entireGraph?.nodes?.filter(e => e?.status === 'FAILED')
	);
	const [expanded, setExpanded] = React.useState(false);

	useEffect(() => {
		setFuncErrors(
			entireGraph?.nodes?.filter(e => e?.status === 'FAILED' && e?.type !== 'parameter')
		);
	}, [entireGraph]);

	const handleAccordionChange = () => {
		setExpanded(!expanded);
	};

	// const handleErrorScroll = () => {
	// 	if (errorRef?.current) {
	// 		errorRef?.current?.scrollIntoView({
	// 			behavior: 'smooth'
	// 		});
	// 	}
	// };

	// eslint-disable-next-line consistent-return
	function date(string) {
		const DateVal = new Date(`${string}Z`);
		if (DateVal) {
			let day = DateVal?.getDate();
			day = day < 10 ? `0${day}` : day;
			const month = DateVal?.toLocaleString('default', { month: 'short' });
			return `${day} ${month}`;
		}
		return '-';
	}

	// eslint-disable-next-line consistent-return
	function time(string) {
		const Time = new Date(`${string}Z`);
		if (Time) {
			let hour = Time?.getHours();
			let min = Time?.getMinutes();
			const ampm = hour >= 12 ? 'pm' : 'am';
			hour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
			min = min < 10 ? `0${min}` : min;
			return `${hour}:${min} ${ampm}`;
		}
	}

	const [progress, setProgress] = React.useState(10);

	React.useEffect(() => {
		const timer = setInterval(() => {
			setProgress(prevProgress => (prevProgress >= 100 ? 10 : prevProgress));
		}, 100000);
		return () => {
			clearInterval(timer);
		};
	}, []);

	return (
		<Accordion
			disableGutters
			expanded={expanded}
			sx={{
				background: 'rgba(28, 28, 70, 0.40)',
				width: '100%',
				boxShadow: '0px 4px 14px 0px rgba(0, 0, 0, 0.55)',
				border: '1px solid #303067',
				borderRadius: '8px',
				cursor: 'default !important'
			}}
		>
			<AccordionSummary
				aria-controls="panel1a-content"
				id="panel1a-header"
				sx={{ cursor: 'default !important' }}
			>
				<Box sx={{ width: '100%', padding: '0px' }}>
					<Box
						sx={{
							display: 'flex',
							justifyContent: 'space-between',
							paddingTop: '8px',
							cursor: 'pointer'
						}}
						onClick={handleAccordionChange}
					>
						<Box sx={{ display: 'flex' }}>
							<Typography
								sx={{
									color: 'white',
									fontSize: '14px',
									'&:hover': { textDecoration: 'underline' }
								}}
								onClick={() => navigate(routes?.DISPATCHES)}
							>
								Dispatches
							</Typography>
							<Typography
								sx={{ color: 'white', fontSize: '14px', ml: '5px' }}
							>{`/ ${dispatchID}`}</Typography>
							<Box
								sx={{
									width: '24px',
									height: '24px',
									border: '1px solid #303067',
									borderRadius: '8px',
									marginLeft: '20px'
								}}
							>
								<CopyButton content={dispatchID} borderEnable={false} placement="right" />
							</Box>
						</Box>
						<Box sx={{ display: 'flex' }}>
							{/* {enableShareOption && (
								<>
									<AvatarGroup
										sx={{ mr: 2, mt: -0.2 }}
										max={5}
										className="customAvatarCtr"
										onClick={e => {
											e.stopPropagation();
										}}
									>
										{userList?.length > 0 &&
											userList?.map((users, index) => (
												<CustomAvatar
													user={users?.sharedWithEmail}
													index={index}
													key={Math.random()}
												/>
											))}
									</AvatarGroup>
									<Tooltip title="Share dispatch">
										<Box
											onClick={e => {
												e.stopPropagation();
												setSharePopupEnable(prev => !prev);
											}}
										>
											<Icon src={Share} alt="share" bgColor="#2a2a5c" padding="4px" />
										</Box>
									</Tooltip>
								</>
							)} */}
							<Box
								sx={{
									display: 'flex',
									padding: '0px 15px 0px 10px',
									border: '1px solid #5552FF',
									borderRadius: '8px',
									gap: '11px',
									height: '26px',
									'&:hover': {
										backgroundColor: theme => theme.palette.background.covalentPurple
									}
								}}
								onClick={e => {
									e.stopPropagation();
									RefreshClick(prevState => !prevState);
								}}
							>
								<Icon src={Refresh} alt="refresh" />
								<Typography>Refresh</Typography>
							</Box>
							<Tooltip title={expanded ? 'View less' : 'View more'}>
								<Box sx={{ marginLeft: '15px' }}>
									<img src={expanded ? Expanded : Collapsed} alt="expanded" />
								</Box>
							</Tooltip>
						</Box>
					</Box>
					<Box
						sx={{
							width: 'calc(100% + 33px)',
							background: '#5552FF',
							height: '1px',
							margin: '10px 0 0 -17px'
						}}
					/>
					<Grid container spacing={2} sx={{ padding: '30px 0px 10px 30px' }}>
						<Grid item xs={8} sx={{ display: 'flex' }}>
							<Grid container spacing={2} sx={{ width: '100%', pb: '15px', cursor: 'default' }}>
								<Grid item xs={12} md={11} lg={12}>
									<Box sx={{ marginTop: '10px', display: 'flex' }}>
										{isFetchingLatticeDetails ? (
											<Skeleton width={25} height={45} />
										) : (
											<Box
												sx={{
													placeItems: 'center',
													display: 'grid',
													border: '1px solid #30306733',
													mt: '12px',
													mb: '12px',
													borderRadius: '4px'
												}}
											>
												{statusIcon(status)}
											</Box>
										)}
										<Box>
											<Typography
												sx={{
													fontSize: '20px',
													color: statusColor(status),
													marginLeft: '8px'
												}}
											>
												{isFetchingLatticeDetails ? (
													<Skeleton variant="rounded" width={140} height={40} />
												) : (
													<>
														{status
															? status === 'NEW_OBJECT'
																? 'Starting'
																: Capitalize(status)
															: '-'}
													</>
												)}
											</Typography>
											<Typography
												sx={{
													marginLeft: '8px',
													fontSize: '12px',
													fontWeight: 400,
													color: '#86869A'
												}}
											>
												Status
											</Typography>
										</Box>
									</Box>
									{/* <NodeData heading="Status" imgSrc={Status} type="onlyTitle" /> */}
								</Grid>
								<Grid item xs={12} lg={12} md={12} sx={{ width: '90%' }}>
									<Box sx={{ width: 'inherit', display: 'grid' }}>
										{isFetchingLatticeDetails ? (
											<Skeleton
												variant="rounded"
												width="90%"
												height={80}
												// sx={{ marginLeft: '3rem' }}
											/>
										) : (
											<Box sx={{ ml: '-14%' }}>
												<Stepper
													alternativeLabel
													sx={{
														'& .MuiStepConnector-line': {
															borderColor: '#303067 !important'
														}
													}}
												>
													{latticeTimeline?.map(label => (
														<Step key={label.status}>
															<StepLabel StepIconComponent={() => getTimeLineIcon(label?.icon)} />
															<Box
																sx={{
																	width: '100%',
																	display: 'grid',
																	placeItems: 'center',
																	margin: '10px 0 0 0px'
																}}
															>
																<Typography
																	sx={{ color: label?.color, fontSize: '12px', fontWeight: '400' }}
																>
																	{label?.status}
																</Typography>
																<Typography
																	sx={{
																		color: '#86869A',
																		fontSize: '12px',
																		fontWeight: '400',
																		mt: '5px'
																	}}
																>
																	{` ${time(label?.time)}`}
																</Typography>
																<Typography
																	sx={{ color: '#86869A', fontSize: '10px', fontWeight: '400' }}
																>
																	{`${date(label?.time)}`}
																</Typography>
															</Box>
														</Step>
													))}
													{latticeTimeline?.length === 1 && (
														<>
															<Step key="Pending">
																<StepLabel StepIconComponent={() => getNoStatus()} />
																<Box
																	sx={{
																		width: '100%',
																		display: 'grid',
																		placeItems: 'center',
																		margin: '10px 0 0 0'
																	}}
																>
																	<img
																		src={placeholder}
																		alt="placeholder"
																		style={{ marginTop: '4px' }}
																	/>
																</Box>
															</Step>
															<Step key="Pending">
																<StepLabel StepIconComponent={() => getNoStatus()} />
																<Box
																	sx={{
																		width: '100%',
																		display: 'grid',
																		placeItems: 'center',
																		margin: '10px 0 0 0'
																	}}
																>
																	<img
																		src={placeholder}
																		alt="placeholder"
																		style={{ marginTop: '4px' }}
																	/>
																</Box>
															</Step>
														</>
													)}
													{latticeTimeline?.length === 2 && (
														<Step key="Pending">
															<StepLabel StepIconComponent={() => getNoStatus()} />
															<Box
																sx={{
																	width: '100%',
																	display: 'grid',
																	placeItems: 'center',
																	margin: '10px 0 0 0'
																}}
															>
																<img
																	src={placeholder}
																	alt="placeholder"
																	style={{ marginTop: '4px', cursor: 'default' }}
																/>
															</Box>
														</Step>
													)}
												</Stepper>
											</Box>
										)}
									</Box>
								</Grid>
							</Grid>
							<Divider orientation="vertical" color="#303067" sx={{ mr: '5%' }} />
							<Grid container spacing={2} sx={{ width: '100%' }}>
								<Grid item xs={12} md={12} sm={12} lg={12}>
									<Typography
										sx={{
											mt: '10px',
											fontSize: '16px',
											fontWeight: 400,
											fontFamily: 'DM Sans',
											color: '#FFFFFF'
										}}
									>
										Dispatch Metrics
									</Typography>
								</Grid>
								<Grid item xs={6} md={6} lg={6}>
									<Box sx={{ display: 'flex' }}>
										<Box sx={{ display: 'grid', placeItems: 'center' }}>
											<Box
												sx={{
													height: '26px',
													width: '26px',
													borderRadius: '8px',
													border: '0px solid #303067',
													background: '#1C1C46',
													display: 'grid',
													placeItems: 'center',
													cursor: 'default'
												}}
											>
												<Box>
													<img src={CostImg} alt="placeholderimg" />
												</Box>
											</Box>
										</Box>
										<Box sx={{ marginLeft: '8px' }}>
											{isFetchingLatticeCost ? (
												<Skeleton variant="rounded" width={60} height={30} />
											) : (
												<>
													{status !== 'COMPLETED' && status !== 'FAILED' ? (
														<Box>
															{/* <img src={progress} alt="progress" /> */}
															<Typography
																sx={{
																	fontSize: '12px',
																	color: enableShareOption ? '#86869A' : '#CBCBD7',
																	padding: '14px 0 0 0px'
																}}
															>
																{enableShareOption && (
																	// <Box sx={{pt:"5px",pb:"2px"}}>
																	<LinearProgress
																		// variant='buffer'
																		sx={{
																			bgcolor: 'inherit',
																			'& .MuiLinearProgress-bar': {
																				background: `linear-gradient(90deg, #303067 ${
																					55 - progress
																				}%, #171740 95%)`,
																				animationDuration: '2.5s'
																				// animation:"infinite"
																			},
																			width: '100%',
																			height: '2.9px',
																			mb: '3px'
																		}}
																		// width={10} height={27}
																		value={progress}
																	/>
																	// </Box>
																)}
																{enableShareOption
																	? 'Cost will be displayed after computation'
																	: 'Private for shared dispatches'}
															</Typography>
														</Box>
													) : (
														<Typography
															sx={{
																color: '#CBCBD7',
																fontSize: !enableShareOption ? '12px' : '20px',
																fontWeight: '500',
																marginBottom: '3px',
																cursor: 'default'
															}}
														>
															{enableShareOption
																? `${latticeCost || '-'}`
																: 'Private for shared dispatches'}
														</Typography>
													)}
												</>
											)}
											{(isFetchingLatticeCost || status === 'COMPLETED' || status === 'FAILED') && (
												<Typography
													sx={{
														color: '#86869A',
														fontSize: '12px',
														fontWeight: '400',
														cursor: 'default'
													}}
												>
													Cost
												</Typography>
											)}
										</Box>
									</Box>
								</Grid>
								<Grid item xs={6} md={6} lg={6} sx={{ cursor: 'default' }}>
									<NodeData
										value={`${
											executedElectrons || executedElectrons === 0 ? executedElectrons : '-'
										}/${totalElectrons || totalElectrons === 0 ? totalElectrons : '-'}`}
										heading="Total Electrons"
										imgSrc={Electrons}
										type="titleValue"
										isLoading={isFetchingLatticeDetails}
									/>
									{/* )} */}
								</Grid>
								{/* <Grid item xs={6} md={4} lg={3}> */}
								{/* {isFetchingLatticeDetails ? (
										<Skeleton variant="rounded" width={100} height={40} />
									) : ( */}
								{/* <NodeData
										value={getQElectronCount(entireGraph)}
										heading="qelectrons"
										imgSrc={Qelectron}
										type="titleValue"
										isLoading={isFetchingLatticeDetails}
									/> */}
								{/* )} */}
								{/* </Grid> */}
								<Grid item xs={6} md={6} lg={6} sx={{ cursor: 'default' }}>
									<NodeData
										completed_at={completed_at}
										started_at={started_at}
										heading="Runtime"
										imgSrc={Runtime}
										type="titleValue"
										isLoading={isFetchingLatticeDetails}
									/>
								</Grid>
							</Grid>
							<Divider orientation="vertical" color="#303067" sx={{ mr: '5%' }} />
						</Grid>
						<Grid item xs={3.5}>
							<Box sx={{ width: '25vw' }}>
								<Input
									img={Inputimage}
									heading="Input"
									json={dispatchResult}
									jsonInput={input}
									copyContent={input}
									value="Input"
									isLoading={isFetchingLatticeInput}
								/>
							</Box>
							{status === 'FAILED' && (
								<Box sx={{ marginTop: '30px', width: '25vw' }}>
									<Input
										img={Output}
										heading="Error"
										isError={true}
										handleErrorScroll={handleErrorScroll}
									/>
								</Box>
							)}
							{status === 'COMPLETED' && (
								<Box sx={{ marginTop: '30px', width: '25vw' }}>
									<Input
										img={Output}
										heading="Results"
										json={dispatchResult}
										jsonInput={input}
										copyContent={dispatchResultcopy}
										isLoading={isFetchingLatticeResult}
										Value="Results"
									/>
								</Box>
							)}
						</Grid>
					</Grid>
					{/* {errorFunctions && errorFunctions?.length !== 0 ? (
						<Box sx={{ padding: '30px 0px 30px 30px', cursor: 'default' }}>
							<>
								<Box ref={errorRef} sx={{ display: 'flex', alignItems: 'center' }}>
									<img src={ErrorFunction} alt="errorstatus" />
									<Typography
										sx={{
											color: '#AEB6FF',
											fontSize: '14px',
											fontWeight: '700',
											marginLeft: '5px'
										}}
									>
										Functions with Errors
									</Typography>
								</Box>
								<Grid
									container
									spacing={1}
									sx={{ position: 'relative', width: '65%', maxHeight: '10rem', mt: 0.7 }}
								>
									<CustomScrolls>
										<Grid container spacing={1} width="98%" sx={{ maxHeight: '10rem' }}>
											{funcErrors?.map((info, index) => (
												<Grid item xs={4} key={index}>
													<FunctionChip functionInfo={info} from="funcChip" />
												</Grid>
											))}
										</Grid>
									</CustomScrolls>
								</Grid>
							</>
						</Box>
					) : null} */}
					<Box
						onClick={() => setExpanded(!expanded)}
						sx={{
							display: 'flex',
							fontWeight: 400,
							mt: '40px',
							ml: '15px',
							fontSize: '14px',
							cursor: 'pointer',
							color: 'rgba(255, 255, 255, 1)',
							// border:"1px solid yellow",
							width: '105px',
							whiteSpace: 'nowrap'
						}}
					>
						{expanded ? 'Show less' : 'Show more'}{' '}
						<Box sx={{ marginLeft: '10px', display: 'flex', alignItems: 'center' }}>
							{/* <img src={expanded ? Expanded : Collapsed} alt="expanded" /> */}
							{expanded ? (
								<ExpandLessIcon sx={{ fontSize: '20px' }} />
							) : (
								<ExpandMoreIcon sx={{ fontSize: '20px' }} />
							)}
						</Box>
					</Box>
				</Box>
			</AccordionSummary>
			<AccordionDetails>
				<CodeAccordion
					code={Code}
					codeCopy={dispatchCodeCopy}
					isFetching={isFetchingLatticeCode}
					page="LatticeAccordion"
				/>
				<Box sx={{ marginTop: '30px' }}>
					{description && <GraphDescription code={description} />}
				</Box>
			</AccordionDetails>
		</Accordion>
	);
}
// eslint-disable-next-line import/no-unused-modules
export default AccordianWithoutErrors;
