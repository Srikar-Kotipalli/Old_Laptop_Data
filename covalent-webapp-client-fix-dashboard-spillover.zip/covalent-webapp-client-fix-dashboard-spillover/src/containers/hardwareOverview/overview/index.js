import { Box, Grid, Stack, Typography } from '@mui/material';
import React from 'react';
import LinearProgress, { linearProgressClasses } from '@mui/material/LinearProgress';
import { styled } from '@mui/material/styles';
import costDownIcon from '../../../assets/costDownIcon.svg';
import Icon from '../../../components/icon';
import utilizationIcon from '../../../assets/utilizationIcon.svg';
import costIcon from '../../../assets/costIcon.svg';
import AreaChart from '../../../components/chart/areaChart';
import PieChart from '../../../components/chart/pieChart';

const BorderLinearProgress = styled(LinearProgress)(() => ({
	height: '2px',
	borderRadius: '8px',
	[`&.${linearProgressClasses.colorPrimary}`]: {
		backgroundColor: '#303067'
	},
	[`& .${linearProgressClasses.bar}`]: {
		borderRadius: 5,
		backgroundColor: '#5552FF'
	}
}));

function HardwareOverviewTabList() {
	const UsageChartData = {
		data: [38, 52, 83, 23, 83, 45, 82, 70, 96, 23, 96, 36, 65],
		categories: [
			'2023-07-24T01:41:13Z',
			'2023-07-24T02:41:13Z',
			'2023-07-24T03:41:13Z',
			'2023-07-24T04:41:13Z',
			'2023-07-24T05:41:13Z',
			'2023-07-24T06:41:13Z',
			'2023-07-24T07:41:13Z',
			'2023-07-24T08:41:13Z',
			'2023-07-24T09:41:13Z',
			'2023-07-24T10:41:13Z',
			'2023-07-24T11:41:13Z',
			'2023-07-24T12:41:13Z'
		]
	};

	const revenueChartData = {
		series: [23, 11, 54, 72],
		labels: ['ibm_kolkata_2', 'ibm_kolkata_4', 'ibm_kolkata_3', 'ibm_kolkata_1'],
		colors: ['#8B31FF', '#6D7CFF', '#AD7BFF', '#41418D']
	};

	return (
		<Box sx={{ my: 3 }}>
			<Grid container spacing="20px">
				<Grid item xs={3}>
					<Box className="utilCtr" sx={{ bgcolor: '#1C1C4699' }}>
						<Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1 }}>
							<Box className="utilizationHeaderIcon">
								<Icon type="static" src={utilizationIcon} />
							</Box>
							<Box>
								<Typography
									className="utilzationLabel"
									color={theme => theme.palette.text.secondary}
								>
									Users
								</Typography>
							</Box>
						</Stack>
						<Box>
							<Typography className="costTitle-1" sx={{ mt: 3, mb: 2 }}>
								450
							</Typography>
							<Stack direction="row" spacing={1} alignItems="end">
								<Typography
									sx={{
										color: '#55D899',
										fontSize: '20px',
										fontWeight: 500,
										position: 'relative',
										top: '3px'
									}}
								>
									320
								</Typography>
								<Typography sx={{ color: '#CBCBD7', fontSize: '14px', fontWeight: 500 }}>
									Active Users
								</Typography>
							</Stack>
						</Box>
					</Box>
				</Grid>
				<Grid item xs={3}>
					<Box className="utilCtr" sx={{ bgcolor: '#1C1C4699' }}>
						<Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1 }}>
							<Box className="utilizationHeaderIcon">
								<Icon type="static" src={costIcon} />
							</Box>
							<Box>
								<Typography
									className="utilzationLabel"
									color={theme => theme.palette.text.secondary}
								>
									Revenue
								</Typography>
							</Box>
						</Stack>
						<Box sx={{ mt: 5 }}>
							<Stack direction="row" spacing={1}>
								<Box>
									<Typography className="costTitle-1">$99,297</Typography>
									<BorderLinearProgress variant="determinate" value={50} sx={{ mt: 2 }} />
								</Box>
								<Box>
									<Stack direction="row" spacing={1}>
										<Box>
											<Icon type="static" src={costDownIcon} />
										</Box>
										<Box>
											<Typography className="costTitle-2">-22%</Typography>
										</Box>
									</Stack>
								</Box>
							</Stack>
						</Box>
					</Box>
				</Grid>
				<Grid item xs={3}>
					<Box className="utilCtr" sx={{ bgcolor: '#1C1C4699' }}>
						<Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1 }}>
							<Box className="utilizationHeaderIcon">
								<Icon type="static" src={costIcon} />
							</Box>
							<Box>
								<Typography
									className="utilzationLabel"
									color={theme => theme.palette.text.secondary}
								>
									Hardware Requests
								</Typography>
							</Box>
						</Stack>
						<Box sx={{ mt: 5 }}>
							<Typography className="costTitle-1" sx={{ mt: 3 }}>
								109
							</Typography>
						</Box>
					</Box>
				</Grid>
				<Grid item xs={3}>
					<Box className="utilCtr" sx={{ bgcolor: '#1C1C4699' }}>
						<Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1 }}>
							<Box className="utilizationHeaderIcon">
								<Icon type="static" src={costIcon} />
							</Box>
							<Box>
								<Typography
									className="utilzationLabel"
									color={theme => theme.palette.text.secondary}
								>
									Total Hardware
								</Typography>
							</Box>
						</Stack>
						<Box sx={{ mt: 5 }}>
							<Typography className="costTitle-1" sx={{ mt: 3 }}>
								15
							</Typography>
						</Box>
					</Box>
				</Grid>
			</Grid>
			<Box sx={{ my: 5 }}>
				<Grid container spacing="20px">
					<Grid
						item
						xs={6}
						sx={{ height: '100%', display: 'flex', alignItems: 'center', width: '100%' }}
					>
						<Box className="utilCtr" sx={{ width: '100%' }}>
							<Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1 }}>
								<Box className="utilizationHeaderIcon">
									<Icon type="static" src={utilizationIcon} />
								</Box>
								<Box>
									<Typography
										color={theme => theme.palette.text.secondary}
										className="utilzationLabel"
									>
										Usage
									</Typography>
								</Box>
							</Stack>
							<Box py={{ xs: 0, xl: 3 }}>
								<AreaChart UsageChartData={UsageChartData} height={215} />
							</Box>
						</Box>
					</Grid>
					<Grid item xs={6}>
						<Box className="utilCtr">
							<Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1 }}>
								<Box className="utilizationHeaderIcon">
									<Icon type="static" src={costIcon} />
								</Box>
								<Box>
									<Typography
										color={theme => theme.palette.text.secondary}
										className="utilzationLabel"
									>
										Hardware Revenue Breakdown
									</Typography>
								</Box>
							</Stack>
							<Box>
								<PieChart revenueChartData={revenueChartData} height={215} />
							</Box>
						</Box>
					</Grid>
				</Grid>
			</Box>
		</Box>
	);
}

export default HardwareOverviewTabList;
