import React from 'react';
import { Box } from '@mui/material';
import UserTable from './UserRequests';

function UserComponent(props) {
	const {
		selected,
		searchValue,
		sort,
		startDate,
		endDate,
		setSelected,
		setSort,
		toFilter,
		setToFilter
	} = props;

	return (
		<Box>
			<Box>
				<UserTable
					selected={selected}
					searchValue={searchValue}
					sort={sort}
					startDate={startDate}
					endDate={endDate}
					setSelected={setSelected}
					setSort={setSort}
					toFilter={toFilter}
					setToFilter={setToFilter}
				/>
			</Box>
		</Box>
	);
}

export default UserComponent;
