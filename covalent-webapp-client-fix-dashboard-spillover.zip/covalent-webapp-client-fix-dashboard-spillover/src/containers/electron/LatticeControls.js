/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
/* eslint-disable react/jsx-props-no-spreading */
/* eslint-disable consistent-return */

import React from 'react';
import { Grid, ToggleButton, ToggleButtonGroup, Tooltip, Typography } from '@mui/material';
import { useReactFlow } from 'reactflow';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import Grow from '@mui/material/Grow';
import Paper from '@mui/material/Paper';
import Popper from '@mui/material/Popper';
import MenuItem from '@mui/material/MenuItem';
import MenuList from '@mui/material/MenuList';
import DashboardIcon from '@mui/icons-material/Dashboard';
import { ArrowBack, ArrowDownward, ArrowForward, ArrowUpward } from '@mui/icons-material';
import Icon from '../../components/icon/index';
import parameterIcon from '../../assets/controlIcons/parameter.svg';
import parameterSelect from '../../assets/controlIcons/parameterSelect.svg';
import postProcessIcon from '../../assets/controlIcons/postProcess.svg';
import postProcessSelect from '../../assets/controlIcons/postProcessSelect.svg';
import magicWandIcon from '../../assets/controlIcons/magicWand.svg';
import magicWandSelect from '../../assets/controlIcons/magicWandSelect.svg';
import dataSetIcon from '../../assets/controlIcons/dataSet.svg';
import dataSetSelect from '../../assets/controlIcons/dataSetSelect.svg';
import logicalPartitionIcon from '../../assets/controlIcons/logicalPartition.svg';
import logicalPartitionSelect from '../../assets/controlIcons/logicalPartitionSelect.svg';
import cameraIcon from '../../assets/controlIcons/camera.svg';
import fitScreenIcon from '../../assets/controlIcons/fitScreen.svg';
import contentViewIcon from '../../assets/controlIcons/contentView.svg';
import contentViewSelect from '../../assets/controlIcons/contentViewSelect.svg';
import unlockedIcon from '../../assets/controlIcons/unlocked.svg';
import addIcon from '../../assets/actions/add.svg';
import minusIcon from '../../assets/minus.svg';
import LockOutlinedIcon from '../../assets/controlIcons/lock.svg';
import FunctionIcon from '../../assets/legend/function.svg';
import BashIcon from '../../assets/legend/terminal.svg';
import ParamIcon from '../../assets/legend/parameter.svg';
import JuliaIcon from '../../assets/legend/julia.svg';
import CPPIcon from '../../assets/legend/C++.svg';
import PythonIcon from '../../assets/legend/python.svg';
import SublatticeIcon from '../../assets/legend/tree.svg';
import OperationIcon from '../../assets/legend/calculation.svg';
import ElectronDictIcon from '../../assets/legend/book.svg';
import ElectronListIcon from '../../assets/legend/roadmap.svg';
import GeneratedIcon from '../../assets/legend/chartRose.svg';
import AttributeIcon from '../../assets/legend/shapeIntersect.svg';
import ArgIcon from '../../assets/legend/chartMedian.svg';
import { LayoutOptions } from './LayoutOptions';

function LatticeControls({
	showParams,
	showPostProcess,
	toggleParams,
	togglePostProcess,
	nodesDraggable,
	toggleNodesDraggable,
	zoomPercentage,
	handleHideLabels,
	toggleScreenShot,
	showMinimap,
	toggleMinimap,
	togglePrettify,
	prettify,
	hideLabels,
	anchorEl,
	open,
	setDirection,
	direction,
	algorithm,
	handleClick,
	handleClose,
	handleChangeAlgorithm,
	triggerFitView
}) {
	const { zoomIn, zoomOut, fitView } = useReactFlow();
	const [openLegend, setOpen] = React.useState(false);
	const anchorRef = React.useRef(null);

	const handleCloseLegend = event => {
		if (anchorRef.current && anchorRef.current.contains(event.target)) {
			return;
		}

		setOpen(false);
	};

	function handleListKeyDown(event) {
		if (event.key === 'Tab') {
			event.preventDefault();
			setOpen(false);
		} else if (event.key === 'Escape') {
			setOpen(false);
		}
	}

	// return focus to the button when we transitioned from !open -> open
	const prevOpen = React.useRef(openLegend);

	const handleToggle = () => {
		// eslint-disable-next-line no-shadow
		setOpen(prevState => !prevState);
	};
	React.useEffect(() => {
		if (prevOpen.current === true && openLegend === false) {
			anchorRef.current.focus();
		}

		prevOpen.current = openLegend;
	}, [openLegend]);

	React.useEffect(() => {
		fitView();
	}, [triggerFitView]);

	const postLayout = value => {
		handleChangeAlgorithm(value);
	};

	const parameterProcessFn = () => {
		toggleParams();
	};

	const postProcessFn = () => {
		togglePostProcess();
	};

	const checkOrientation = () => {
		switch (direction) {
			case 'UP':
				return setDirection('RIGHT');
			case 'DOWN':
				return setDirection('LEFT');
			case 'LEFT':
				return setDirection('UP');
			case 'RIGHT':
				return setDirection('DOWN');
			default:
		}
	};

	return (
		<>
			<Popper
				open={openLegend}
				anchorEl={anchorRef.current}
				role={undefined}
				placement="left-end"
				transition
				disablePortal
				style={{ zIndex: 5 }}
			>
				{({ TransitionProps }) => (
					<Grow
						{...TransitionProps}
						style={
							{
								// transformOrigin: placement === 'top-start' ? 'left top' : 'left bottom',
								// marginRight: '3.1rem'
							}
						}
					>
						<Paper
							sx={{
								borderRadius: '10px !important',
								overflow: 'hidden'
							}}
						>
							<ClickAwayListener onClickAway={handleCloseLegend}>
								<MenuList
									sx={{
										width: '10rem'
									}}
									autoFocusItem={openLegend}
									id="composition-menu"
									aria-labelledby="composition-button"
									// eslint-disable-next-line react/jsx-no-bind
									onKeyDown={handleListKeyDown}
								>
									<MenuItem onClick={handleCloseLegend}>
										<Grid container direction="row" alignItems="center">
											<Icon src={FunctionIcon} padding="0rem 0rem 0rem 0rem" />
											<Typography variant="h2" pl={1}>
												Function
											</Typography>
										</Grid>
									</MenuItem>
									<MenuItem onClick={handleCloseLegend}>
										<Grid container direction="row" alignItems="center">
											<Icon src={ParamIcon} padding="0rem 0rem 0rem 0rem" />
											<Typography variant="h2" pl={1}>
												Parameter
											</Typography>
										</Grid>
									</MenuItem>
									<MenuItem onClick={handleCloseLegend}>
										<Grid container direction="row" alignItems="center">
											<Icon src={BashIcon} padding="0rem 0rem 0rem 0rem" />
											<Typography variant="h2" pl={1}>
												Bash
											</Typography>
										</Grid>
									</MenuItem>
									<MenuItem onClick={handleCloseLegend}>
										<Grid container direction="row" alignItems="center">
											<Icon src={JuliaIcon} padding="0rem 0rem 0rem 0rem" />
											<Typography variant="h2" pl={1}>
												Julia
											</Typography>
										</Grid>
									</MenuItem>
									<MenuItem onClick={handleCloseLegend}>
										<Grid container direction="row" alignItems="center">
											<Icon src={CPPIcon} padding="0rem 0rem 0rem 0rem" />
											<Typography variant="h2" pl={1}>
												C++
											</Typography>
										</Grid>
									</MenuItem>
									<MenuItem onClick={handleCloseLegend}>
										<Grid container direction="row" alignItems="center">
											<Icon src={PythonIcon} padding="0rem 0rem 0rem 0rem" />
											<Typography variant="h2" pl={1}>
												Python
											</Typography>
										</Grid>
									</MenuItem>
									<MenuItem onClick={handleCloseLegend}>
										<Grid container direction="row" alignItems="center">
											<Icon src={SublatticeIcon} padding="0rem 0rem 0rem 0rem" />
											<Typography variant="h2" pl={1}>
												Sublattice
											</Typography>
										</Grid>
									</MenuItem>
									<MenuItem onClick={handleCloseLegend}>
										<Grid container direction="row" alignItems="center">
											<Icon src={OperationIcon} padding="0rem 0rem 0rem 0rem" />
											<Typography variant="h2" pl={1}>
												Operation
											</Typography>
										</Grid>
									</MenuItem>
									<MenuItem onClick={handleCloseLegend}>
										<Grid container direction="row" alignItems="center">
											<Icon src={ElectronListIcon} padding="0rem 0rem 0rem 0rem" />
											<Typography variant="h2" pl={1}>
												Electron List
											</Typography>
										</Grid>
									</MenuItem>
									<MenuItem onClick={handleCloseLegend}>
										<Grid container direction="row" alignItems="center">
											<Icon src={ElectronDictIcon} padding="0rem 0rem 0rem 0rem" />
											<Typography variant="h2" pl={1}>
												Electron Dict
											</Typography>
										</Grid>
									</MenuItem>
									<MenuItem onClick={handleCloseLegend}>
										<Grid container direction="row" alignItems="center">
											<Icon src={GeneratedIcon} padding="0rem 0rem 0rem 0rem" />
											<Typography variant="h2" pl={1}>
												Generated
											</Typography>
										</Grid>
									</MenuItem>
									<MenuItem onClick={handleCloseLegend}>
										<Grid container direction="row" alignItems="center">
											<Icon src={AttributeIcon} padding="0rem 0rem 0rem 0rem" />
											<Typography variant="h2" pl={1}>
												Attribute
											</Typography>
										</Grid>
									</MenuItem>
									<MenuItem onClick={handleCloseLegend}>
										<Grid container direction="row" alignItems="center">
											<Icon src={ArgIcon} padding="0rem 0rem 0rem 0rem" />
											<Typography variant="h2" pl={1}>
												Arg
											</Typography>
										</Grid>
									</MenuItem>
								</MenuList>
							</ClickAwayListener>
						</Paper>
					</Grow>
				)}
			</Popper>
			<ToggleButtonGroup
				orientation="vertical"
				size="small"
				sx={{
					position: 'absolute',
					top: { xs: 0, lg: 10, xl: 15 },
					right: { sm: '0.8%', md: '2%', lg: '0.8%', xl: '1%' },
					zIndex: 5,
					opacity: 0.8,
					border: 'none',
					width: '50px',
					background: theme => theme.palette.background.default,

					'.MuiToggleButton-root': {
						border: '1px solid transparent '
					}
				}}
			>
				<Hint title="Parameters">
					<ToggleButton
						className="iconButtonCtr"
						value=""
						sx={{ height: '40px', color: 'white' }}
						onClick={parameterProcessFn}
						selected={showParams}
					>
						<img src={showParams ? parameterSelect : parameterIcon} alt="Parameters" />
					</ToggleButton>
				</Hint>
				<Hint title="Postprocess">
					<ToggleButton
						className="iconButtonCtr"
						value=""
						sx={{ height: '40px', color: 'white' }}
						onClick={postProcessFn}
						selected={showPostProcess}
					>
						<img src={showPostProcess ? postProcessSelect : postProcessIcon} alt="Postprocess" />
					</ToggleButton>
				</Hint>
				<Hint title="Prettify">
					<ToggleButton
						value=""
						sx={{ height: '40px' }}
						className="iconButtonCtr"
						onClick={togglePrettify}
						selected={prettify}
					>
						<img src={prettify ? magicWandSelect : magicWandIcon} alt="Prettify" />
					</ToggleButton>
				</Hint>
				<Hint title="Node numbers">
					<ToggleButton
						value=""
						onClick={() => handleHideLabels()}
						sx={{ height: '40px' }}
						className="iconButtonCtr"
						selected={!hideLabels}
					>
						<img src={!hideLabels ? dataSetSelect : dataSetIcon} alt="Node numbers" />
					</ToggleButton>
				</Hint>
				<Hint title="Legend">
					<ToggleButton
						ref={anchorRef}
						value=""
						sx={{ height: '40px' }}
						className="iconButtonCtr"
						onClick={handleToggle}
						selected={openLegend}
					>
						<img src={openLegend ? logicalPartitionSelect : logicalPartitionIcon} alt="Legend" />
					</ToggleButton>
				</Hint>
				<Hint title="Screenshot">
					<ToggleButton
						value=""
						sx={{ height: '40px' }}
						onClick={toggleScreenShot}
						className="iconButtonCtr"
					>
						<img src={cameraIcon} alt="screenShot" />
					</ToggleButton>
				</Hint>
			</ToggleButtonGroup>

			<ToggleButtonGroup
				orientation="vertical"
				size="small"
				sx={{
					'@media(min-height: 760px)': {
						bottom: '-0.5%'
					},
					'@media(min-height: 767px)': {
						bottom: '22px'
					},
					'@media(min-height: 860px)': {
						bottom: '2.5%'
					},
					'@media(min-height: 940px)': {
						bottom: '0%'
					},
					'@media(min-height: 980px)': {
						bottom: '0.5%'
					},
					'@media(min-height: 1070px)': {
						bottom: '3%'
					},
					position: 'absolute',
					bottom: '0%',
					right: { sm: '0.8%', md: '2%', lg: '0.8%', xl: '1%' },
					zIndex: 5,
					opacity: 0.8,
					border: 'none',
					width: '50px',
					background: theme => theme.palette.background.default,

					'.MuiToggleButton-root': {
						border: '1px solid transparent '
					}
				}}
			>
				<Hint title="Toggle draggable nodes">
					<ToggleButton
						data-testid="toggledragablenode"
						sx={{ height: '40px' }}
						className="iconButtonCtr"
						onClick={toggleNodesDraggable}
						value=""
						selected={nodesDraggable}
					>
						{nodesDraggable ? (
							<img src={unlockedIcon} alt="unlockedIcon" />
						) : (
							<img src={LockOutlinedIcon} alt="LockOutlinedIcon" />
						)}
					</ToggleButton>
				</Hint>

				<Hint title="Fit to screen">
					<ToggleButton
						value=""
						className="iconButtonCtr"
						sx={{ height: '40px' }}
						onClick={() => {
							fitView();
						}}
					>
						<img src={fitScreenIcon} alt="fitScreenIcon" />
					</ToggleButton>
				</Hint>
				<Hint title="Change layout">
					<ToggleButton data-testid="tooglebuttonclick" onClick={e => handleClick(e)} value="">
						<DashboardIcon
							// fontSize="small"
							sx={{
								color: theme => theme.palette.text.primary,
								width: '17px',
								height: '24px'
							}}
						/>
					</ToggleButton>
				</Hint>
				<LayoutOptions
					algorithm={algorithm}
					open={open}
					anchorEl={anchorEl}
					handleClick={handleClick}
					handleClose={handleClose}
					handleChangeAlgorithm={postLayout}
				/>
				<Hint title="Change orientation">
					<ToggleButton
						data-testid="changeorientation"
						onClick={() => {
							checkOrientation();
						}}
						value=""
					>
						{
							{
								DOWN: (
									<ArrowDownward
										sx={{
											color: theme => theme.palette.text.primary,
											width: '17px',
											height: '24px'
										}}
									/>
								),
								UP: (
									<ArrowUpward
										sx={{
											color: theme => theme.palette.text.primary,
											width: '17px',
											height: '24px'
										}}
									/>
								),
								RIGHT: (
									<ArrowForward
										sx={{
											color: theme => theme.palette.text.primary,
											width: '17px',
											height: '24px'
										}}
									/>
								),
								LEFT: (
									<ArrowBack
										sx={{
											color: theme => theme.palette.text.primary,
											width: '17px',
											height: '24px'
										}}
									/>
								)
							}[direction]
						}
					</ToggleButton>
				</Hint>
				<Hint title="Mini map">
					<ToggleButton
						onClick={toggleMinimap}
						value=""
						selected={showMinimap}
						data-testid="tooglebuttonclick"
						className="iconButtonCtr"
						sx={{ height: '40px' }}
					>
						<img src={showMinimap ? contentViewSelect : contentViewIcon} alt="contentViewIcon" />
					</ToggleButton>
				</Hint>
				<Hint title="Zoom in">
					<ToggleButton
						value=""
						onClick={() => zoomIn(300)}
						className="iconButtonCtr"
						sx={{ height: '40px' }}
					>
						<img src={addIcon} alt="addIcon" />
					</ToggleButton>
				</Hint>

				<Hint title="Zoom out">
					<ToggleButton
						value=""
						onClick={() => zoomOut(300)}
						className="iconButtonCtr"
						sx={{ height: '40px' }}
					>
						<img src={minusIcon} alt="minusIcon" />
					</ToggleButton>
				</Hint>

				<Hint title="Percentage">
					<ToggleButton value="" sx={{ height: '40px', color: 'white' }} className="iconButtonCtr">
						<Typography sx={{ fontSize: '12px' }}>{zoomPercentage}%</Typography>
					</ToggleButton>
				</Hint>
			</ToggleButtonGroup>
		</>
	);
}

function Hint(props) {
	return <Tooltip arrow placement="right" {...props} />;
}

export default LatticeControls;
