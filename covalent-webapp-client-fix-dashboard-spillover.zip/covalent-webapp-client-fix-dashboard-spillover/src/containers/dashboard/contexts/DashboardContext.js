/* eslint-disable react/jsx-no-constructed-context-values */
/* eslint-disable react/function-component-definition */
/* eslint-disable no-unused-vars */
import React, { createContext, useState } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import { getLatticeBatchByCount } from '../../../api/dashboard/dashboardApi';
import { getLatticesBatch } from '../../../api/experiments/dispatchApi';

export const DashboardContext = createContext();

const DashboardProvider = ({ children }) => {
	const [dashboardLatticeCount, setDashboardLatticeCount] = useState(null);
	const [latticesBatchData, setLatticesBatchdata] = useState({});
	const [dispatchesData, setDispatchesData] = useState({});
	const [recentDispatchesLoader, setRecentDispatchesLoader] = useState(true);

	const getLatticesData = (requireLoader = true) => {
		if (requireLoader) {
			setRecentDispatchesLoader(true);
		}

		getLatticesBatch({ count: 5, sortColumn: 'created_at', sortOrder: 'DESC', urls: true })
			.then(response => {
				if (!response?.metadata?.total_count) setDashboardLatticeCount('-');
				else setDashboardLatticeCount(response?.metadata?.total_count);
				setLatticesBatchdata(response);
				if (requireLoader) {
					setRecentDispatchesLoader(false);
				}
			})
			.catch(error => {
				if (requireLoader) {
					setRecentDispatchesLoader(false);
				}
				setDashboardLatticeCount('-');
				console.error(error);
			});
	};

	const getDispatchesData = count => {
		getLatticeBatchByCount(count)
			.then(response => {
				setDispatchesData(response);
			})
			.catch(error => {
				console.error(error);
			});
	};

	return (
		<DashboardContext.Provider
			value={{
				getLatticesData,
				dashboardLatticeCount,
				getDispatchesData,
				dispatchesData,
				latticesBatchData,
				recentDispatchesLoader
			}}
		>
			{children}
		</DashboardContext.Provider>
	);
};

export default DashboardProvider;
