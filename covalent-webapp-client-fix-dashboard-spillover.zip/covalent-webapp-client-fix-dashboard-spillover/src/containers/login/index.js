/* eslint-disable no-unused-vars */
/* eslint-disable react/jsx-boolean-value */
/* eslint-disable import/no-unused-modules */
import React, { useMemo, useState, useContext, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Backdrop from '@mui/material/Backdrop';
import { Grid, Box, Typography, Link } from '@mui/material';
import { withStyles } from '@mui/styles';
import { compose } from 'redux';
import WithMediaQuery from '../../utils/useMediaQuery';
import logoLogin from '../../assets/login/logoLogin.svg';
import Icon from '../../components/icon';
import checkmarkLogin from '../../assets/checkmarks/checkmarkLogin.svg';
import covLoader from '../../assets/loaders/covLoader.svg';
import RegisterComponent from './register';
import LoginWithEmail from './loginWithEmail';
import ConfirmationCode from './confirmationCode';
import SetNewPassword from './setNewPassword';
import CustomisedSnackbar from '../../components/snackbar/projects';
import { LoginContext } from './loginContext';
import ResetPassword from './resetPassword';
import ForgotPassword from './forgotPassword';
import './style.css';
// import TCPopupMenu from '../../components/menu/projects/t&CPopupMenu';

const styles = theme => ({
	container: {
		height: '100vh',
		minHeight: '100%',
		display: 'flex',
		justifyContent: 'center'
	}
});

function ListItems({ message }) {
	return (
		<Box
			display="flex"
			direction="row"
			sx={{
				'@media (min-width: 1780px)': {
					mt: '2rem'
				}
			}}
		>
			<Icon src={checkmarkLogin} />
			<Typography
				sx={{
					marginTop: '20px',
					'@media (min-width: 1780px)': {
						marginTop: '0.2rem'
					},
					fontSize: '20px',
					marginLeft: '4px',
					color: '#ffffff'
				}}
			>
				{message}
			</Typography>
		</Box>
	);
}

function LoginScreen(props) {
	const { path, isMobile } = props;
	const [email, setEmail] = useState('');
	const [username, setUsername] = useState('');
	const [mode, setMode] = useState('login');
	const [registerMode, setRegisterMode] = useState('register');
	const [cognitoUser, setCognitoUser] = useState({});
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState('');
	const [openLoader, setOpenLoader] = useState(false);
	const navigate = useNavigate();
	const [password, setPassword] = useState('');
	const [rePassword, setRePassword] = useState('');
	const [announcements, setAnnouncements] = useState(true);
	const [location, setLocation] = useState(useLocation());
	const [firstName, setFirstName] = useState('');
	const [lastName, setLastName] = useState('');
	const [organisation, setOrganisation] = useState(true);
	const [organisationName, setOrganisationName] = useState('');

	useEffect(() => {
		if (mode === 'register') {
			navigate('/register', { replace: true });
		}
	}, [mode]);

	const contextValues = useMemo(
		() => ({
			setMode,
			setOpenSnackbar,
			setSnackbarMessage,
			setOpenLoader,
			cognitoUser,
			setCognitoUser,
			setEmail,
			email,
			username,
			setUsername,
			mode,
			openSnackbar,
			snackbarMessage,
			openLoader,
			setRegisterMode,
			registerMode,
			password,
			setPassword,
			rePassword,
			setRePassword,
			announcements,
			setAnnouncements,
			location,
			setLocation,
			firstName,
			lastName,
			organisation,
			organisationName,
			setFirstName,
			setLastName,
			setOrganisation,
			setOrganisationName
		}),
		[
			mode,
			openSnackbar,
			snackbarMessage,
			setOpenLoader,
			openLoader,
			cognitoUser,
			setCognitoUser,
			email,
			username,
			registerMode,
			setRegisterMode,
			password,
			setPassword,
			rePassword,
			setRePassword,
			announcements,
			setAnnouncements,
			location,
			setLocation,
			firstName,
			lastName,
			organisation,
			organisationName,
			setFirstName,
			setLastName,
			setOrganisation,
			setOrganisationName
		]
	);
	return (
		<LoginContext.Provider value={contextValues}>
			{path === 'login' && <LoginComponents isMobile={isMobile} />}
			{path === 'register' && <RegisterComponent isMobile={isMobile} />}
		</LoginContext.Provider>
	);
}

function LoginComponents(props) {
	const loginContext = useContext(LoginContext);
	const {
		setOpenSnackbar,
		mode,
		openSnackbar,
		cognitoUser,
		snackbarMessage,
		openLoader,
		setLocation
	} = loginContext;
	const { isMobile } = props;
	// const [openTC, setOpenTC] = React.useState(false);
	const bottomToTop = element => {
		element?.scrollTo({
			top: 0,
			behavior: 'smooth'
		});
	};
	const newLocation = useLocation();
	useEffect(() => {
		const element = document.querySelector('.scroll-container');
		bottomToTop(element);
		// This is to set the current location for login page
		if (mode === 'login') {
			setLocation(newLocation);
		}
	}, [mode]);

	return (
		<Grid
			container
			height="100%"
			width="100%"
			margin={0}
			alignContent="center"
			sx={{
				backgroundImage: 'linear-gradient(107deg, #1C1C46 24.17%, #0B0B11 69.19%)',
				boxShadow: '0px 5px 9px 0px rgba(0, 0, 0, 0.45)'
			}}
		>
			{/* <TCPopupMenu open={openTC} setOpen={setOpenTC} /> */}
			<CustomisedSnackbar
				testId="projectSnackbar"
				action="addItem"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			<Backdrop open={openLoader} sx={{ zIndex: 5, backgroundColor: 'rgba(0,0,0,0.7)' }}>
				<Icon type="pointer" src={covLoader} />
			</Backdrop>
			<Grid
				item
				xs={12}
				display={{ xs: 'none', sm: 'flex', height: '120px', position: 'absolute' }}
			>
				<Box sx={{ padding: '20px 0px 0px 20px' }}>
					<a href={process.env.REACT_APP_COVALENT_URL} target="_blank" rel="noopener noreferrer">
						<Icon src={logoLogin} alt="logo" height="56px" width="101px" />
					</a>
				</Box>
			</Grid>
			<Grid
				item
				xs={12}
				sx={{
					display: 'flex',
					flexDirection: 'column',
					justifyContent: 'center',
					alignItems: 'center',
					padding: '0px !important',
					maxHeight: '700px',
					order: { xs: 1, sm: 2 }
				}}
			>
				<Box sx={{ display: { xs: 'grid', sm: 'none' }, textAlign: 'center' }}>
					<Icon type="static" src={logoLogin} alt="logo" />
				</Box>
				{(mode === 'login' || mode === 'loginEmail') && <LoginWithEmail />}
				{mode === 'verifyUser' && <ConfirmationCode />}
				{mode === 'setNewPassword' && <SetNewPassword users={cognitoUser} />}
				{mode === 'forgotPassword' && <ForgotPassword />}
				{mode === 'resetPassword' && <ResetPassword />}

				<Grid
					item
					xs={12}
					sx={{
						display: 'flex',
						justifySelf: 'flex-end',
						alignItems: 'center',
						maxHeight: '100px'
					}}
					md={4}
				>
					<Box
						sx={{
							display: 'flex',
							justifyContent: 'space-between',
							width: '200px',
							height: '50px'
						}}
					>
						<Link
							href={process.env.REACT_APP_TERMS_AND_CONDITIONS_URL}
							underline="none"
							target="_blank"
							sx={{
								paddingLeft: '8px',
								color: '#6473FF',
								cursor: 'pointer',
								display: 'flex',
								alignItems: 'center',
								'&:hover': {
									textDecoration: 'underline'
								},
								fontSize: '14px'
							}}
						>
							Terms
						</Link>
						<Link
							sx={{
								paddingLeft: '8px',
								color: '#6473FF',
								cursor: 'pointer',
								display: 'flex',
								alignItems: 'center',
								'&:hover': {
									textDecoration: 'underline'
								},
								fontSize: '14px'
							}}
							href={process.env.REACT_APP_PRIVACY_URL}
							underline="none"
							target="_blank"
						>
							Privacy
						</Link>
					</Box>
				</Grid>
			</Grid>
		</Grid>
	);
}

export default compose(
	withStyles(styles, {
		name: 'Login'
	}),
	WithMediaQuery([['isMobile', theme => theme.breakpoints.down('sm')]])
)(LoginScreen);
