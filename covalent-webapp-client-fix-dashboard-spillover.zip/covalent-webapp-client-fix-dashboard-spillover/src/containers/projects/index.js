//* eslint-disable import/named */
/* eslint-disable react/jsx-no-useless-fragment */

/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useEffect, useMemo, useState } from 'react';
import { useDebounce } from 'use-debounce';
import { useSelector } from 'react-redux';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import Slide from '@mui/material/Slide';
// import Backdrop from '@mui/material/Backdrop';
import Chip from '@mui/material/Chip';
import Modal from '@mui/material/Modal';
import { Tooltip } from '@mui/material';
import {
	addEditExperiment,
	addEditProject,
	allItemsList,
	hierarchyList,
	moveListItems,
	pinDispatches,
	unPinDispatches,
	addEditDeleteTags,
	deleteOrArchiveItems,
	editDispatchTitle
} from '../../api/experiments/dispatchApi';
import useDidMountEffect from '../../utils/useDidMountEffect';
import covLoader from '../../assets/loaders/covLoader.svg';
import searchIcon from '../../assets/actions/search.svg';
import closeIcon from '../../assets/actions/close.svg';
import DispatchCard from '../../components/card/projects/dispatchCard';
import Icon from '../../components/icon';
import SearchInput from '../../components/inputBase/projects/searchInput';
import AllListView from '../../components/list/projects/allListView';
import DispatchesListView from '../../components/list/projects/dispatchesListView';
import ExperimentsListView from '../../components/list/projects/experimentsListView';
import AddItemsMenu from '../../components/menu/projects/addItemsMenu';
import ShowItemsMenu from '../../components/menu/projects/showItemsMenu';
import ProjectsSideBar from '../../components/sidebar/projects';
import ProjectsTab from '../../components/tab/projects';
import CustomisedSnackbar from '../../components/snackbar/projects';
import DeletableTags from '../../components/tags/projects/deletableTags';
import { arrayCommonCompare, arrayCompare } from '../../utils/utils';
import { ProjectContext } from './projectContext';
import {
	getPositionIndex,
	getStatusPostDeleteOrArchive,
	getElectronsPostDeleteOrArchive,
	getTimePostDeleteOrArchive
} from './helpers';
import './style.css';
import useSocketConnection from '../../socketHooks/useSocketConnection';

export default function Projects() {
	useSocketConnection();
	// Live refresh
	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);
	// all items state variables.
	const [allItems, setAllItems] = useState([]);
	// common actions state variables.
	const [isEdit, setIsEdit] = useState(false);
	const [projectAdded, setProjectAdded] = useState(false);
	const [isAction, setIsAction] = useState(false);
	const [openLoader, setOpenLoader] = useState(true);
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [openProjectSnackbar, setOpenProjectSnackbar] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState('');
	const [allSelected, setAllSelected] = useState(false);
	const [isMoved, setIsMoved] = useState(false);
	const [searchResults, setSearchResults] = useState(false);
	const [showArchived, setShowArchived] = useState(false);
	const [addMode, setAddMode] = useState(false);
	// state for scroll
	const [isVisible, setIsVisible] = useState(true);
	// state to store multiple dispatches for context actions.
	const [multipleSelectedItems, setMultipleItems] = useState([]);
	// pagination state variables
	const [page, setPage] = useState(1);
	const [offset, setOffset] = useState(0);
	const [totalRecords, setTotalRecords] = useState(0);
	const [openSidebar, setOpenSidebar] = useState(false);
	const [sidebarActions, setSidebarActions] = useState(false);
	const [sidebarId, setSidebarId] = useState('');
	const [sidebarType, setSidebarType] = useState('');

	const handlePageChanges = (_event, pageValue) => {
		setAllSelected(false);
		setMultipleItems([]);
		setPage(pageValue);
		const offsetValue = pageValue === 1 ? 0 : pageValue * 10 - 10;
		setOffset(offsetValue);
	};
	// handle sort and search
	const [searchKey, setSearchKey] = useState('');
	const [searchValue] = useDebounce(searchKey, 2000);
	const [sortColumn, setSortColumn] = useState('lastUpdated');
	const [sortOrder, setSortOrder] = useState('desc');
	// filter tab state variables.
	const [value, setValue] = useState('all');

	// handle tab changes
	const handleTabChange = (_event, newValue) => {
		setMultipleItems([]);
		setAllItems([]);
		setPage(1);
		setOffset(0);
		setTotalRecords(0);
		setSortOrder('desc');
		setSortColumn('lastUpdated');
		setProjectAdded(false);
		setAllSelected(false);
		setValue(newValue);
		setAddMode(false);
	};

	const sidebarHandler = (id, type) => {
		setOpenSidebar(true);
		setSidebarId(id);
		setSidebarType(type);
	};

	const closeSidebar = () => {
		setOpenSidebar(false);
		setSidebarId('');
	};
	// handle tags actions
	const [tagsToFilter, setTagsToFilter] = useState([]);
	const [editableText, setEditableText] = React.useState('');

	const catchError = () => {
		setOpenProjectSnackbar(true);
		setSnackbarMessage('Something went wrong,please contact the administrator!');
		setOpenLoader(false);
	};

	const itemsListApi = () => {
		const bodyParameters = {
			count: 10,
			filterBy: value,
			offset,
			direction: sortOrder,
			sort: sortColumn,
			search: searchKey,
			tags: tagsToFilter,
			showArchived
		};
		if (searchValue?.length === 0 || searchValue?.length >= 1) {
			setOpenLoader(true);
			allItemsList(bodyParameters)
				.then(response => {
					const list = response?.items.map(e => {
						return {
							...e,
							isChecked: false
						};
					});
					setAllItems(list);
					setAllSelected(false);
					setTotalRecords(response.count);
					if (searchValue) {
						setSearchResults(true);
					}
					setOpenLoader(false);
				})
				.catch(() => {
					setAllItems([]);
					catchError();
				});
		}
	};

	const itemsListApiLiveRefresh = () => {
		const bodyParameters = {
			count: 10,
			filterBy: value,
			offset,
			direction: sortOrder,
			sort: sortColumn,
			search: searchKey,
			tags: tagsToFilter,
			showArchived
		};
		if (searchValue?.length === 0 || searchValue?.length >= 3) {
			allItemsList(bodyParameters)
				.then(response => {
					const list = response?.items.map(e => {
						return {
							...e,
							isChecked: false
						};
					});
					setAllItems(list);
					setAllSelected(false);
					setTotalRecords(response.count);
					if (searchValue) {
						setSearchResults(true);
					}
				})
				.catch(() => {
					setAllItems([]);
					catchError();
				});
		}
	};

	const filterTags = tags => {
		setPage(1);
		setOffset(0);
		const filteredTags = tagsToFilter;
		if (filteredTags.indexOf(tags) === -1) {
			filteredTags.push(tags);
			setTagsToFilter([...filteredTags]);
		}
		setMultipleItems([]);
		setAllSelected(false);
	};

	const deleteTags = tags => {
		const filteredTags = tagsToFilter;
		const index = filteredTags.indexOf(tags);
		if (index !== -1) {
			filteredTags.splice(index, 1);
		}
		setTagsToFilter([...filteredTags]);
	};

	const addTags = (item, tags) => {
		const editData = allItems;
		const { index, secondaryIndex, tertiaryIndex } = getPositionIndex(item, allItems, value);
		const parentData = editData.filter(e => e.isAddTag === true);
		const hierarchyFilter = editData.filter(
			e => e.hierarchyListItems && e.hierarchyListItems.some(f => f.isAddTag === true)
		);
		const filteredData = parentData.concat(hierarchyFilter).length;
		if (filteredData > 0) {
			// check if any item is added/edited
			setOpenProjectSnackbar(true);
			setSnackbarMessage('Please add/edit one item at a time');
		} else if (secondaryIndex !== null && tertiaryIndex === null) {
			// edit experiment inside hierarchy
			editData[index].hierarchyListItems[secondaryIndex].isAddTag = true;
			if (tags) setEditableText(tags);
			setIsEdit(true);
			setAllItems([...editData]);
		} else if (secondaryIndex !== null && tertiaryIndex !== null) {
			// edit experiment inside hierarchy
			editData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].isAddTag = true;
			if (tags) setEditableText(tags);
			setIsEdit(true);
			setAllItems([...editData]);
		} else {
			// edit experiment/project
			editData[index].isAddTag = true;
			if (tags) setEditableText(tags);
			setIsEdit(true);
			setAllItems([...editData]);
		}
	};

	const postTagAddition = (currentValue, tagsArray, action) => {
		const { index, secondaryIndex, tertiaryIndex } = getPositionIndex(
			currentValue,
			allItems,
			value
		);
		const addData = allItems;
		if (index !== null && secondaryIndex === null && tertiaryIndex === null) {
			addData[index].tags =
				action !== 'save' ? [...tagsArray] : [...new Set([...addData[index].tags, ...tagsArray])];
			addData[index].isAddTag = false;
		} else if (secondaryIndex !== null && tertiaryIndex !== null) {
			addData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].tags =
				action !== 'save'
					? [...tagsArray]
					: [
							...new Set([
								...addData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].tags,
								...tagsArray
							])
					  ];
			addData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].isAddTag = false;
		} else if (secondaryIndex !== null && tertiaryIndex === null) {
			addData[index].hierarchyListItems[secondaryIndex].tags =
				action !== 'save'
					? [...tagsArray]
					: [...new Set([...addData[index].hierarchyListItems[secondaryIndex].tags, ...tagsArray])];
			addData[index].hierarchyListItems[secondaryIndex].isAddTag = false;
		}
		setAllItems([...addData]);
		setOpenProjectSnackbar(true);
		let message = '';
		if (action === 'delete') message = 'Tag deleted successfully';
		else if (action === 'edit') message = 'Tag edited successfully';
		else message = 'Tag added successfully';
		setSnackbarMessage(message);
		setOpenLoader(false);
	};

	const deleteListTags = (currentValue, tags) => {
		const deleteData = allItems;
		const { index, secondaryIndex, tertiaryIndex } = getPositionIndex(
			currentValue,
			allItems,
			value
		);
		let finalTags = [];
		let parameter = null;
		if (index !== null && secondaryIndex === null && tertiaryIndex === null) {
			finalTags = deleteData[index].tags?.filter(item => item !== tags);
			parameter = {
				id: deleteData[index].id,
				tags: [...finalTags]
			};
		} else if (secondaryIndex !== null && tertiaryIndex !== null) {
			finalTags = deleteData[index].hierarchyListItems[secondaryIndex].dispatches[
				tertiaryIndex
			].tags.filter(item => item !== tags);
			parameter = {
				id: deleteData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].id,
				tags: [...finalTags]
			};
		} else if (secondaryIndex !== null && tertiaryIndex === null) {
			finalTags = deleteData[index].hierarchyListItems[secondaryIndex].tags.filter(
				item => item !== tags
			);
			parameter = {
				id: deleteData[index].hierarchyListItems[secondaryIndex].id,
				tags: [...finalTags]
			};
		}
		setOpenLoader(true);
		addEditDeleteTags(parameter)
			.then(() => {
				postTagAddition(currentValue, finalTags, 'delete');
			})
			.catch(() => {
				catchError();
			});
	};

	const saveTags = (text, action, type, currentValue, crudAction) => {
		const addData = allItems;
		let finalTagsArray = [];
		const { index, secondaryIndex, tertiaryIndex } = getPositionIndex(
			currentValue,
			allItems,
			value
		);
		if (action === 'save') {
			let parameter = null;
			let tagsArray = text?.trim().replace(/ + /g, ' ').toLowerCase().split(/,+/);
			tagsArray = tagsArray.filter(e => e !== '');
			tagsArray = tagsArray.map(e => e.trim());
			const stringLength = tagsArray.map(w => w.length);
			if (stringLength.filter(e => e > 25).length > 0) {
				setOpenProjectSnackbar(true);
				setSnackbarMessage('Tags should be less than 25 chars');
			} else if (tagsArray.filter(e => e === ' ' || e === undefined).length > 0) {
				setOpenProjectSnackbar(true);
				setSnackbarMessage('Tags cannot be empty strings');
			} else {
				if (index !== null && secondaryIndex === null && tertiaryIndex === null) {
					if (crudAction === 'edit') {
						const editIndex = addData[index].tags?.indexOf(editableText);
						addData[index].tags?.splice(editIndex, 1);
					}
					finalTagsArray = [...new Set([...addData[index].tags, ...tagsArray])];
					parameter = {
						id: addData[index].id,
						tags: [...new Set([...addData[index].tags, ...tagsArray])]
					};
				} else if (secondaryIndex !== null && tertiaryIndex !== null) {
					if (crudAction === 'edit') {
						const editIndex =
							addData[index].hierarchyListItems[secondaryIndex].dispatches[
								tertiaryIndex
							].tags?.indexOf(editableText);
						addData[index].hierarchyListItems[secondaryIndex].dispatches[
							tertiaryIndex
						].tags?.splice(editIndex, 1);
					}
					finalTagsArray = [
						...new Set([
							...addData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].tags,
							...tagsArray
						])
					];
					parameter = {
						id: addData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].id,
						tags: [
							...new Set([
								...addData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].tags,
								...tagsArray
							])
						]
					};
				} else if (secondaryIndex !== null && tertiaryIndex === null) {
					if (crudAction === 'edit') {
						const editIndex =
							addData[index].hierarchyListItems[secondaryIndex].tags?.indexOf(editableText);
						addData[index].hierarchyListItems[secondaryIndex].tags?.splice(editIndex, 1);
					}
					finalTagsArray = [
						...new Set([...addData[index].hierarchyListItems[secondaryIndex].tags, ...tagsArray])
					];
					parameter = {
						id: addData[index].hierarchyListItems[secondaryIndex].id,
						tags: [
							...new Set([...addData[index].hierarchyListItems[secondaryIndex].tags, ...tagsArray])
						]
					};
				}
				setOpenLoader(true);
				addEditDeleteTags(parameter)
					.then(() => {
						postTagAddition(currentValue, finalTagsArray, crudAction);
						setEditableText('');
					})
					.catch(() => {
						setOpenProjectSnackbar(true);
						setSnackbarMessage('Something went wrong,please contact the administrator!');
						setOpenLoader(false);
						setEditableText('');
					});
			}
		} else {
			if (type === 'dispatch' || type === 'experiment') {
				addData[index].isAddTag = false;
			} else if (type === 'projectExperimentDispatch') {
				addData[index].hierarchyListItems[secondaryIndex].dispatches[
					tertiaryIndex
				].isAddTag = false;
			} else {
				addData[index].hierarchyListItems[secondaryIndex].isAddTag = false;
			}
			setEditableText('');
			setAllItems([...addData]);
		}
	};

	// handle sort and search
	const onSort = column => {
		setMultipleItems([]);
		setAllSelected(false);
		setPage(1);
		setOffset(0);
		const isAsc = sortColumn === column && sortOrder === 'asc';
		setSortOrder(isAsc ? 'desc' : 'asc');
		setSortColumn(column);
	};

	// state to store last dispatch action performed to use for undo operations.
	const [currentDispatchData, setCurrentDispatchData] = useState(null);

	useEffect(() => {
		itemsListApi();
	}, [value, page, sortOrder, sortColumn, searchValue, isMoved, tagsToFilter, showArchived]);

	useDidMountEffect(() => {
		itemsListApiLiveRefresh();
	}, [liveRefresh]);

	// cancel search
	const cancelSearch = () => {
		setAllSelected(false);
		setSearchKey('');
		setSearchResults(false);
		setMultipleItems([]);
		setOpenLoader(true);
	};

	// search
	const onSearch = e => {
		setAllSelected(false);
		setMultipleItems([]);
		setSearchKey(e.target.value);
		if (e.target.value.length === 0) setSearchResults(false);
		else setOffset(0);
	};

	// handles projects opened in all filter.
	const handleOpenAllProjects = (mainIndex, type, open, secondaryIndex, from, count, setIsOpen) => {
		const data = allItems;
		if (type === 'allItems') {
			if (open === true) {
				if (from === 'list') {
					data[mainIndex].isLoader = true;
				}
				data[mainIndex].isAdd = false;
				data[mainIndex].isOpen = open;
				setAllItems([...data]);
				hierarchyList(
					data[mainIndex].id,
					'project',
					sortOrder,
					sortColumn,
					searchKey,
					count,
					showArchived
				)
					.then(response => {
						data[mainIndex].isChecked = false;
						setAllSelected(false);
						const multipleDispatchDataChecked = multipleSelectedItems.filter(
							e => e.id !== data[mainIndex].id
						);
						// remove the current open item from the selected items list
						setMultipleItems([...multipleDispatchDataChecked]);
						if (from === 'showmore') {
							let uncommonElements = arrayCompare(
								response?.items,
								data[mainIndex].hierarchyListItems
							);
							uncommonElements = uncommonElements?.map(e => {
								return { ...e, isOpen: false, isChecked: false };
							});
							data[mainIndex].hierarchyListItems.push(...uncommonElements);
							setIsOpen(false);
						} else {
							const hierarchyListItems = response?.items.map(e => {
								return {
									...e,
									isOpen: false,
									isChecked: false
								};
							});
							data[mainIndex].hierarchyListItems = hierarchyListItems;
						}
						data[mainIndex].hierarchyListItemsTotalCount = response?.count;
						data[mainIndex].isLoader = false;
						setAllItems([...data]);
					})
					.catch(() => {
						data[mainIndex].isLoader = false;
						data[mainIndex].isOpen = false;
						setOpenProjectSnackbar(true);
						setSnackbarMessage('Something went wrong,please contact the administrator!');
					});
			} else {
				// compare close items selected list and current selected list and remove the close itens selected items
				const filteredArray = arrayCompare(
					multipleSelectedItems,
					data[mainIndex].hierarchyListItems
				);
				data[mainIndex].isOpen = open;
				data[mainIndex].hierarchyListItems = [];
				data[mainIndex].isChecked = false;
				const multiSelectedItemsInProject = filteredArray.filter(
					e => e.id !== data[mainIndex].id && e.masterId !== data[mainIndex].id
				);
				setMultipleItems([...multiSelectedItemsInProject]);
				data[mainIndex].hierarchyListItemsTotalCount = 0;
				setAllItems([...data]);
				const allCheckedData = allItems.filter(e => e.isChecked === true && !e.isOpen);
				if (allCheckedData.length === allItems.length) setAllSelected(true);
				else setAllSelected(false);
			}
		} else if (type === 'allProjectExperiments') {
			data[mainIndex].hierarchyListItems[secondaryIndex].isOpen = open;
			if (open === true) {
				if (from === 'list') {
					data[mainIndex].hierarchyListItems[secondaryIndex].isLoader = true;
				}
				data[mainIndex].hierarchyListItems[secondaryIndex].isAdd = false;
				setAllItems([...data]);
				hierarchyList(
					data[mainIndex].hierarchyListItems[secondaryIndex].id,
					'experiment',
					sortOrder,
					sortColumn,
					searchKey,
					count,
					showArchived
				)
					.then(response => {
						data[mainIndex].hierarchyListItems[secondaryIndex].isChecked = false;
						data[mainIndex].isChecked = false;
						setAllSelected(false);
						// remove the current open item from the selected items list
						const multipleDispatchDataChecked = multipleSelectedItems.filter(
							e =>
								e.id !== data[mainIndex].hierarchyListItems[secondaryIndex].id &&
								e.id !== data[mainIndex].id
						);
						setMultipleItems([...multipleDispatchDataChecked]);
						if (from === 'showmore') {
							let uncommonElements = arrayCompare(
								response?.items,
								data[mainIndex].hierarchyListItems[secondaryIndex].dispatches
							);
							uncommonElements = uncommonElements?.map(e => {
								return { ...e, isChecked: false };
							});
							data[mainIndex].hierarchyListItems[secondaryIndex].dispatches.push(
								...uncommonElements
							);
							setIsOpen(false);
						} else {
							const dispatchList = response?.items.map(item => {
								return {
									...item,
									isChecked: false
								};
							});

							data[mainIndex].hierarchyListItems[secondaryIndex].dispatches = dispatchList;
						}
						data[mainIndex].hierarchyListItems[secondaryIndex].dispatchesTotalCount =
							response?.count;
						data[mainIndex].hierarchyListItems[secondaryIndex].isLoader = false;
						setAllItems([...data]);
					})
					.catch(() => {
						data[mainIndex].hierarchyListItems[secondaryIndex].isLoader = false;
						data[mainIndex].hierarchyListItems[secondaryIndex].isOpen = false;
						setOpenProjectSnackbar(true);
						setSnackbarMessage('Something went wrong,please contact the administrator!');
					});
			} else {
				// compare close items selected list and current selected list and remove the close itens selected items
				const filteredArray = arrayCompare(
					multipleSelectedItems,
					data[mainIndex].hierarchyListItems[secondaryIndex].dispatches
				);
				data[mainIndex].hierarchyListItems[secondaryIndex].isOpen = open;
				data[mainIndex].hierarchyListItems[secondaryIndex].dispatches = [];
				data[mainIndex].hierarchyListItems[secondaryIndex].isChecked = false;
				data[mainIndex].isChecked = false;
				const multiSelectedItemsInProjectExperiments = filteredArray.filter(
					e =>
						e.id !== data[mainIndex].hierarchyListItems[secondaryIndex].id &&
						e.id !== data[mainIndex].id
				);
				setMultipleItems([...multiSelectedItemsInProjectExperiments]);
				data[mainIndex].hierarchyListItems[secondaryIndex].dispatchesTotalCount = 0;
				setAllItems([...data]);
				const allCheckedData = allItems.filter(e => e.isChecked === true && !e.isOpen);
				if (allCheckedData.length === allItems.length) setAllSelected(true);
				else setAllSelected(false);
			}
		}
	};

	// handles experiment filter changes.
	const handleOpenExperiments = (mainIndex, open, from, count, setIsOpen) => {
		const data = allItems;
		if (open === true) {
			if (from === 'list') {
				data[mainIndex].isLoader = true;
			}
			data[mainIndex].isAdd = false;
			data[mainIndex].isOpen = open;
			setAllItems([...data]);
			hierarchyList(
				data[mainIndex].id,
				'experiment',
				sortOrder,
				sortColumn,
				searchKey,
				count,
				showArchived
			)
				.then(response => {
					data[mainIndex].isChecked = false;
					setAllSelected(false);
					// remove the current open item from the selected items list
					const multipleDispatchDataChecked = multipleSelectedItems.filter(
						e => e.id !== data[mainIndex].id
					);
					setMultipleItems([...multipleDispatchDataChecked]);
					if (from === 'showmore') {
						let uncommonElements = arrayCompare(
							response?.items,
							data[mainIndex].hierarchyListItems
						);
						uncommonElements = uncommonElements?.map(e => {
							return { ...e, isChecked: false };
						});
						data[mainIndex].hierarchyListItems.push(...uncommonElements);
						setIsOpen(false);
					} else {
						const dispatchList = response?.items.map(item => {
							return {
								...item,
								isChecked: false
							};
						});
						data[mainIndex].hierarchyListItems = dispatchList;
					}
					data[mainIndex].hierarchyListItemsTotalCount = response?.count;
					data[mainIndex].isLoader = false;
					setAllItems([...data]);
				})
				.catch(() => {
					data[mainIndex].isLoader = false;
					data[mainIndex].isOpen = false;
					setOpenProjectSnackbar(true);
					setSnackbarMessage('Something went wrong,please contact the administrator!');
				});
		} else {
			// compare close items selected list and current selected list and remove the close itens selected items
			const filteredArray = arrayCompare(multipleSelectedItems, data[mainIndex].hierarchyListItems);
			data[mainIndex].isOpen = open;
			data[mainIndex].hierarchyListItems = [];
			data[mainIndex].isChecked = false;
			const multiSelectedItemsInExperiments = filteredArray.filter(
				e => e.id !== data[mainIndex].id
			);
			setMultipleItems([...multiSelectedItemsInExperiments]);
			data[mainIndex].hierarchyListItemsTotalCount = 0;
			setAllItems([...data]);
			const allCheckedData = allItems.filter(e => e.isChecked === true && !e.isOpen);
			if (allCheckedData.length === allItems.length) setAllSelected(true);
			else setAllSelected(false);
		}
	};

	// adding of a project/experiment
	const addItem = type => {
		setAllSelected(false);
		setAddMode(true);
		const data = allItems;
		// check if parent project/experiment is being added/edited
		const parentData = data.filter(e => e.isAdd === true);
		// check if experiment inside project is in edit mode
		const hierarchyFilter = data.filter(
			e => e.hierarchyListItems && e.hierarchyListItems.some(f => f.isAdd === true)
		);
		const filteredData = parentData.concat(hierarchyFilter).length;
		if (filteredData > 0) {
			// check if any project/experiment is already being added/edited
			setOpenProjectSnackbar(true);
			setSnackbarMessage('Please add/edit one item at a time');
		} else {
			const entry = {
				completedElectrons: '0',
				count: 0,
				id: Math.random(),
				lastUpdated: new Date().toISOString().slice(0, -1),
				name: '',
				runTime: null,
				startTime: null,
				status: 'NEW',
				tags: '',
				totalElectrons: '0',
				type,
				isAdd: true,
				isChecked: false,
				...(type === 'Experiment' && { parentId: null })
			};
			data.unshift(entry);
			setProjectAdded(true);
			setAllItems([...data]);
		}
	};

	const postAddEditItem = (_type, text, response, currentValue, addData = allItems) => {
		const { index, secondaryIndex, tertiaryIndex } = getPositionIndex(
			currentValue,
			allItems,
			value
		);
		if (secondaryIndex !== null && tertiaryIndex !== null) {
			addData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].id = response.id;
			addData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].title = text;
			addData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].isAdd = false;
			addData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].lastUpdated =
				new Date().toISOString().slice(0, -1);
		} else if (secondaryIndex !== null && tertiaryIndex === null) {
			addData[index].hierarchyListItems[secondaryIndex].id = response.id;
			addData[index].hierarchyListItems[secondaryIndex].title = text;
			addData[index].hierarchyListItems[secondaryIndex].isAdd = false;
			addData[index].hierarchyListItems[secondaryIndex].lastUpdated = new Date()
				.toISOString()
				.slice(0, -1);
		} else if (index !== null) {
			addData[index].id = response.id;
			addData[index].title = text;
			addData[index].isAdd = false;
			addData[index].lastUpdated = new Date().toISOString().slice(0, -1);
		}
		setAllItems([...addData]);
		setIsEdit(false);
		setProjectAdded(false);
	};

	const editDispatchName = (text, action, _type, currentValue, location) => {
		const { index, secondaryIndex, tertiaryIndex } = getPositionIndex(
			currentValue,
			allItems,
			value
		);
		let parameter = null;
		const addData = allItems;
		if (action === 'save' && text !== null && text !== '') {
			parameter = {
				id: currentValue.id,
				title: text
			};
			setOpenLoader(true);
			editDispatchTitle(parameter)
				.then(response => {
					if (response.status) {
						if (location === 'expSidebar') {
							setSidebarActions(prevState => !prevState);
						}
						postAddEditItem('dispatch', text, response, currentValue, addData);
						setIsAction(prevState => !prevState);
					} else {
						setOpenLoader(false);
					}
					setAddMode(false);
					setOpenProjectSnackbar(true);
					setSnackbarMessage(response.message);
				})
				.catch(() => {
					catchError();
				});
		} else if (action === 'close') {
			setOpenLoader(true);
			if (location === 'expSidebar') {
				setSidebarActions(prevState => !prevState);
			} else {
				if (secondaryIndex !== null && tertiaryIndex !== null)
					addData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].isAdd = false;
				else if (secondaryIndex !== null && tertiaryIndex === null)
					addData[index].hierarchyListItems[secondaryIndex].isAdd = false;
				else if (index !== null) addData[index].isAdd = false;
			}
			setIsAction(prevState => !prevState);
			setAddMode(false);
			setAllItems([...addData]);
			setIsEdit(false);
		}
	};

	// eslint-disable-next-line no-unused-vars
	const addListItem = (text, action, type, currentValue, _location) => {
		const { index, secondaryIndex } = getPositionIndex(currentValue, allItems, value);
		const actionType = currentValue?.isEdit ? 'edit' : 'add';
		let parameter = null;
		let addData = allItems;
		// save project and experiment
		if (
			(type === 'project' || type === 'experiment') &&
			action === 'save' &&
			(text !== null || text !== '')
		) {
			parameter = {
				id: actionType === 'edit' ? addData[index].id : null,
				title: text
			};
		} else if (
			// edit experiments inside a project hierarchy
			type === 'experimentProject' &&
			action === 'save' &&
			(text !== null || text !== '')
		) {
			addData[index].hierarchyListItems[secondaryIndex].title = text;
			parameter = {
				id: actionType === 'edit' ? addData[index].hierarchyListItems[secondaryIndex].id : null,
				title: text
			};
		} else if (
			// Cancel adding of a project
			(type === 'project' || type === 'experiment') &&
			action === 'close' &&
			actionType === 'add'
		) {
			addData = addData.filter(e => e.id !== currentValue.id);
			// checking if all items are selected and subsequently selecting the all selected checkbox on the header
			const allCheckedData = addData.filter(e => e.isChecked === true && !e.isOpen);
			if (allCheckedData.length === allItems.length - 1) setAllSelected(true);
			else setAllSelected(false);
			setOpenProjectSnackbar(true);
			setSnackbarMessage(`Adding ${type} cancelled`);
		} else if (
			// cancel editing of a project/experiment
			(type === 'project' || type === 'experiment') &&
			action === 'close' &&
			actionType === 'edit'
		) {
			addData[index].isAdd = false;
		} else if (type === 'experimentProject' && action === 'close' && actionType === 'edit') {
			addData[index].hierarchyListItems[secondaryIndex].isAdd = false;
		} else {
			addData = addData[index].hierarchyListItems.filter(e => e.id !== currentValue.id);
		}
		// api call
		if (action === 'save') {
			let addItems = null;
			// choose API based on project/experiment
			addItems = type === 'project' ? addEditProject : addEditExperiment;
			setOpenLoader(true);
			addItems(parameter)
				.then(response => {
					if (response.status) {
						postAddEditItem(type, text, response, currentValue, addData);
					}
					setAddMode(false);
					setOpenProjectSnackbar(true);
					setSnackbarMessage(response.message);
					setOpenLoader(false);
				})
				.catch(() => {
					catchError();
				});
		} else {
			setAddMode(false);
			setProjectAdded(false);
			setAllItems([...addData]);
			setIsEdit(false);
		}
	};

	// edit project/experiment/dispatch
	const editListItem = item => {
		const editData = allItems;
		const { index, secondaryIndex, tertiaryIndex } = getPositionIndex(item, allItems, value);
		const parentData = editData.filter(e => e.isAdd === true);
		const hierarchyFilter = editData.filter(
			e => e.hierarchyListItems && e.hierarchyListItems.some(f => f.isAdd === true)
		);
		const dispatchFilter = [];
		editData.forEach(i => {
			if (i?.hierarchyListItems) {
				const arr = i.hierarchyListItems.filter(
					e => e.dispatches && e.dispatches.some(f => f.isAdd === true)
				);
				if (arr.length > 0) dispatchFilter.push(arr);
			}
		});
		const filteredData = parentData.concat(hierarchyFilter, dispatchFilter).length;
		if (filteredData > 0) {
			// check if any item is added/edited
			setOpenProjectSnackbar(true);
			setSnackbarMessage('Please add/edit one item at a time');
		} else if (secondaryIndex !== null && tertiaryIndex !== null) {
			// edit dispatch inside experiment inside project
			editData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].isAdd = true;
			editData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].isEdit = true;
			setIsEdit(true);
			setAllItems([...editData]);
		} else if (tertiaryIndex === null && secondaryIndex !== null) {
			// edit experiment/project
			editData[index].hierarchyListItems[secondaryIndex].isAdd = true;
			editData[index].hierarchyListItems[secondaryIndex].isEdit = true;
			setIsEdit(true);
			setAllItems([...editData]);
		} else if (index !== null) {
			// edit experiment/project
			editData[index].isAdd = true;
			editData[index].isEdit = true;
			setIsEdit(true);
			setAllItems([...editData]);
		}
	};

	const unCheckSelectedItems = () => {
		const data = multipleSelectedItems;
		const allItemsData = allItems;
		data.forEach(item => {
			const { index, secondaryIndex, tertiaryIndex } = getPositionIndex(item, allItems, value);
			if (secondaryIndex !== null && tertiaryIndex !== null) {
				allItemsData[index].hierarchyListItems[secondaryIndex].dispatches[
					tertiaryIndex
				].isChecked = false;
			} else if (secondaryIndex !== null && tertiaryIndex === null) {
				allItemsData[index].hierarchyListItems[secondaryIndex].isChecked = false;
			} else if (index !== null) {
				allItemsData[index].isChecked = false;
			}
		});
		setMultipleItems([]);
		setAllSelected(false);
		setAllItems(allItemsData);
	};

	// change pin status on the UI without calling API
	const onPinStatusChange = item => {
		const { index, secondaryIndex, tertiaryIndex } = getPositionIndex(item, allItems, value);
		const pinnedData = allItems;
		// selection of items inside a project/experiment
		if (secondaryIndex !== null && tertiaryIndex === null) {
			pinnedData[index].hierarchyListItems[secondaryIndex].isPinned =
				!pinnedData[index].hierarchyListItems[secondaryIndex].isPinned;
			pinnedData[index].hierarchyListItems[secondaryIndex].isChecked = false;
			// selection of items inside an experiment which is inside a project
		} else if (secondaryIndex !== null && tertiaryIndex !== null) {
			pinnedData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].isPinned =
				!pinnedData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].isPinned;
			pinnedData[index].hierarchyListItems[secondaryIndex].dispatches[
				tertiaryIndex
			].isChecked = false;
			// selection of items at the root level
		} else if (index !== null) {
			pinnedData[index].isPinned = !pinnedData[index].isPinned;
			pinnedData[index].isChecked = false;
		}
		setAllItems([...pinnedData]);
	};

	// handle context menu actions.
	const onPin = dispatch => {
		let pinAction = null;
		const params = {
			id: dispatch.id
		};
		// set last pinned dispatch value for undo feature
		setCurrentDispatchData({
			id: dispatch.id,
			isPinned: !dispatch.isPinned,
			name: dispatch.title,
			parentId: dispatch.parentId,
			type: 'Dispatch',
			masterId: dispatch.masterId ? dispatch.masterId : null
		});
		pinAction = !dispatch.isPinned ? pinDispatches : unPinDispatches;
		setOpenLoader(true);
		pinAction(params)
			.then(response => {
				onPinStatusChange(dispatch);
				setIsAction(prevState => !prevState);
				unCheckSelectedItems();
				setSnackbarMessage(response);
				setOpenSnackbar(true);
				setSidebarActions(prevState => !prevState);
			})
			.catch(() => {
				catchError();
			});
	};

	const itemsToMove = (moveType, items, destination, view) => {
		let itemsToBeMoved = null;
		if (view === 'grid') itemsToBeMoved = items;
		// if moved from grid only move one item
		else if (allSelected) {
			// all values are selected
			const filterNonShared = allItems.filter(e => !e?.shared);
			itemsToBeMoved = filterNonShared.map(e => e.id);
		} else {
			// check if selected value is single or multiselected
			const multipleItems = multipleSelectedItems.map(({ id }) => id);
			const arrayComp = arrayCommonCompare(items, multipleItems);
			itemsToBeMoved = arrayComp ? multipleItems : items;
		}
		const requestBody = {
			items: itemsToBeMoved,
			destination: moveType !== 'dispatches' ? destination[0].id : null
		};
		setOpenLoader(true);
		moveListItems(moveType, requestBody)
			.then(message => {
				setAllSelected(false);
				setMultipleItems([]);
				setOpenProjectSnackbar(true);
				setSnackbarMessage(message);
				setIsMoved(prevState => !prevState);
				setSidebarActions(prevState => !prevState);
			})
			.catch(() => {
				catchError();
			});
	};

	// Multi select dispatches feature
	const onCheckboxChecked = (evt, item) => {
		const checkedData = allItems;
		const isChecked = evt.target.checked;
		let data = multipleSelectedItems;
		const { index, secondaryIndex, tertiaryIndex } = getPositionIndex(item, allItems, value);
		// selection of items inside a project/experiment
		if (secondaryIndex !== null && tertiaryIndex === null) {
			checkedData[index].hierarchyListItems[secondaryIndex].isChecked = isChecked;
			if (!isChecked) {
				checkedData[index].isChecked = false;
			}
			// selection of items inside an experiment which is inside a project
		} else if (secondaryIndex !== null && tertiaryIndex !== null) {
			checkedData[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].isChecked =
				isChecked;
			if (!isChecked) {
				checkedData[index].hierarchyListItems[secondaryIndex].isChecked = false;
				checkedData[index].isChecked = false;
			}
			// selection of items at the root level
		} else {
			checkedData[index].isChecked = isChecked;
		}
		// set state of the selected items;deleteTags
		setAllItems([...checkedData]);
		// storing checked items in an array for easier comparison
		if (isChecked) {
			data.push(item);
			setMultipleItems(data);
		} else {
			setAllSelected(false);
			data = data.filter(e => e.id !== item.id && e.id !== item.parentId && e.id !== item.masterId);
			setMultipleItems(data);
		}
		// checking if all items are selected and subsequently selecting the all selected checkbox on the header
		const allCheckedData = checkedData.filter(e => e.isChecked === true && !e.isOpen);
		if (allCheckedData.length === allItems.length) setAllSelected(true);
		else setAllSelected(false);
	};

	// selection of all items form the table header
	const onAllSelected = e => {
		const isChecked = e.target.checked;
		setAllSelected(isChecked);
		const checkedData = allItems.map(f => {
			if (f?.shared) {
				return {
					...f
				};
			}
			return {
				...f,
				isChecked
			};
		});
		// remove those with isChecked false - to remove the shared dispatches
		const filteredCheckedData = checkedData.filter(f => f.isChecked);
		const multiHieItems = [];
		checkedData.forEach(item => {
			if (item.isOpen === true && item.hierarchyListItems && item.hierarchyListItems.length !== 0) {
				item.hierarchyListItems.forEach(level1 => {
					level1.isChecked = isChecked;
					if (isChecked) {
						multiHieItems.push(level1);
					}
					if (level1.isOpen && level1.dispatches && level1.dispatches.length !== 0) {
						level1.dispatches.forEach(level2 => {
							level2.isChecked = isChecked;
							if (isChecked) {
								multiHieItems.push(level2);
							}
						});
					}
				});
			}
		});
		if (isChecked) setMultipleItems([...filteredCheckedData, ...multiHieItems]);
		else setMultipleItems([]);
		setAllItems(checkedData);
	};

	const prepareInputForDeleteOrArchive = (items, view, location) => {
		const data = allItems;
		const projects = [];
		const experiments = [];
		const dispatches = [];
		if (allSelected && view !== 'grid' && location !== 'expSidebar') {
			items = data.filter(f => !f?.shared);
		}
		items.forEach(item => {
			if (item.type === 'Project') {
				projects.push(item.id);
			} else if (
				item.type === 'Experiment' &&
				items.findIndex(i => i.id === item.parentId) === -1
			) {
				experiments.push(item.id);
			} else if (item.type === 'Dispatch' && items.findIndex(i => i.id === item.parentId) === -1) {
				dispatches.push(item.id);
			}
		});
		return { projects, experiments, dispatches };
	};

	const postDeleteArchive = (
		view,
		successItems,
		itemsToBeDeletedOrArchived,
		location,
		dispatchList = []
	) => {
		let data = allItems;
		if (allSelected && view !== 'grid' && location !== 'expSidebar') {
			setAllItems([]);
			setAllSelected(false);
			data = [];
		} else {
			successItems.forEach(i => {
				const item = itemsToBeDeletedOrArchived.filter(e => e.id === i)[0];
				const { index, secondaryIndex, tertiaryIndex } = getPositionIndex(item, allItems, value);
				if (tertiaryIndex !== null && secondaryIndex !== null) {
					if (
						data[index].hierarchyListItems[secondaryIndex].dispatches[tertiaryIndex].id === item.id
					) {
						data[index].hierarchyListItems[secondaryIndex].dispatches.splice(tertiaryIndex, 1);
						data[index].hierarchyListItems[secondaryIndex].count =
							data[index].hierarchyListItems[secondaryIndex].dispatches.length;
						data[index].hierarchyListItems[secondaryIndex].dispatchesTotalCount =
							data[index].hierarchyListItems[secondaryIndex].dispatches.length;
						data[index].hierarchyListItems[secondaryIndex].status = getStatusPostDeleteOrArchive(
							data[index].hierarchyListItems[secondaryIndex].dispatches
						);
						const { completedElectrons, totalElectrons } = getElectronsPostDeleteOrArchive(
							data[index].hierarchyListItems[secondaryIndex].dispatches
						);
						data[index].hierarchyListItems[secondaryIndex].completedElectrons = completedElectrons;
						data[index].hierarchyListItems[secondaryIndex].totalElectrons = totalElectrons;
						const { runTime, startTime, lastUpdated } = getTimePostDeleteOrArchive(
							data[index].hierarchyListItems[secondaryIndex].dispatches
						);
						data[index].hierarchyListItems[secondaryIndex].runTime = runTime;
						data[index].hierarchyListItems[secondaryIndex].startTime = startTime;
						data[index].hierarchyListItems[secondaryIndex].lastUpdated = lastUpdated;
					}
				} else if (tertiaryIndex === null && secondaryIndex !== null) {
					if (data[index].hierarchyListItems[secondaryIndex].id === item.id) {
						data[index].hierarchyListItems.splice(secondaryIndex, 1);
						data[index].count = data[index].hierarchyListItems.length;
						data[index].hierarchyListItemsTotalCount = data[index].hierarchyListItems.length;
						if (data[index].type === 'Experiment') {
							data[index].status = getStatusPostDeleteOrArchive(data[index].hierarchyListItems);
							const { completedElectrons, totalElectrons } = getElectronsPostDeleteOrArchive(
								data[index].hierarchyListItems
							);
							data[index].completedElectrons = completedElectrons;
							data[index].totalElectrons = totalElectrons;
							const { runTime, startTime, lastUpdated } = getTimePostDeleteOrArchive(
								data[index].hierarchyListItems
							);
							data[index].runTime = runTime;
							data[index].startTime = startTime;
							data[index].lastUpdated = lastUpdated;
						}
					}
				} else if (index !== null) {
					if (data[index].id === item.id) {
						data.splice(index, 1);
					} else if (data[index].id === item.parentId) {
						if (data[index].count > 0) {
							data[index].count--;
						}
					}
				} else if (
					index === null &&
					secondaryIndex === null &&
					tertiaryIndex === null &&
					(view === 'grid' || location === 'expSidebar')
				) {
					let priIndex = -1;
					let secIndex = -1;
					if (item.masterId !== null && item.parentId !== null && value === 'all') {
						// eslint-disable-next-line eqeqeq
						priIndex = data?.findIndex(e => e.id === item?.masterId);
						if (priIndex !== -1) {
							secIndex = data[priIndex].hierarchyListItems?.findIndex(e => e.id === item?.parentId);
						}
						if (
							priIndex !== -1 &&
							secIndex !== -1 &&
							!data[priIndex].hierarchyListItems[secIndex].isOpen
						) {
							if (data[priIndex].hierarchyListItems[secIndex].count > 0) {
								data[priIndex].hierarchyListItems[secIndex].count--;
								data[priIndex].hierarchyListItems[secIndex].dispatchesTotalCount--;
							}
							if (location === 'expSidebar' && item.type === 'Dispatch') {
								const dispatches = dispatchList.filter(e => e.id !== i);
								data[priIndex].hierarchyListItems[secIndex].status =
									getStatusPostDeleteOrArchive(dispatches);
								const { completedElectrons, totalElectrons } =
									getElectronsPostDeleteOrArchive(dispatches);
								data[priIndex].hierarchyListItems[secIndex].completedElectrons = completedElectrons;
								data[priIndex].hierarchyListItems[secIndex].totalElectrons = totalElectrons;
								const { runTime, startTime, lastUpdated } = getTimePostDeleteOrArchive(dispatches);
								data[priIndex].hierarchyListItems[secIndex].runTime = runTime;
								data[priIndex].hierarchyListItems[secIndex].startTime = startTime;
								data[priIndex].hierarchyListItems[secIndex].lastUpdated = lastUpdated;
							}
						}
					} else if (
						(item.masterId === null && item.parentId !== null && value !== 'dispatches') ||
						value === 'experiments'
					) {
						priIndex = data.findIndex(e => e.id === item?.parentId);
						if (priIndex !== -1 && !data[priIndex].isOpen) {
							if (data[priIndex].count > 0) {
								data[priIndex].count--;
								data[priIndex].hierarchyListItemsTotalCount--;
							}
							if (data[priIndex].type === 'Experiment' && location === 'expSidebar') {
								const dispatches = dispatchList.filter(e => e.id !== i);
								data[priIndex].status = getStatusPostDeleteOrArchive(dispatches);
								const { completedElectrons, totalElectrons } =
									getElectronsPostDeleteOrArchive(dispatches);
								data[priIndex].completedElectrons = completedElectrons;
								data[priIndex].totalElectrons = totalElectrons;
								const { runTime, startTime, lastUpdated } = getTimePostDeleteOrArchive(dispatches);
								data[priIndex].runTime = runTime;
								data[priIndex].startTime = startTime;
								data[priIndex].lastUpdated = lastUpdated;
							}
						}
					}
				}
				setAllItems([...data]);
			});
			unCheckSelectedItems();
		}
		if (searchResults || tagsToFilter.length > 0) {
			setTotalRecords(data.length);
		}
		return data.length;
	};

	const onDeleteOrArchive = (type, currentItem, view, action, location, dispatchList = []) => {
		let itemsToBeDeletedOrArchived =
			multipleSelectedItems.length !== 0 ? multipleSelectedItems : [currentItem];
		if (view === 'grid' || location === 'expSidebar') {
			itemsToBeDeletedOrArchived = [currentItem];
		}
		const { projects, experiments, dispatches } = prepareInputForDeleteOrArchive(
			itemsToBeDeletedOrArchived,
			view,
			location
		);
		const promises = [];
		const requestBody = {};
		let recordsLength = allItems.length;
		setOpenLoader(true);
		if (projects.length > 0) {
			promises.push(
				new Promise(resolve => {
					requestBody.items = projects;
					deleteOrArchiveItems('project', requestBody, action)
						.then(response => {
							if (response.success_items.length !== 0) {
								const projLength = postDeleteArchive(
									view,
									response.success_items,
									itemsToBeDeletedOrArchived,
									location
								);
								recordsLength = projLength === 0 ? projLength : recordsLength;
							}
							setOpenProjectSnackbar(true);
							setSnackbarMessage(response.message);
							return resolve();
						})
						.catch(() => {
							catchError();
						});
				})
			);
		}
		if (experiments.length > 0) {
			promises.push(
				new Promise(resolve => {
					requestBody.items = experiments;
					deleteOrArchiveItems('experiment', requestBody, action)
						.then(response => {
							if (response.success_items.length !== 0) {
								const expLength = postDeleteArchive(
									view,
									response.success_items,
									itemsToBeDeletedOrArchived,
									location
								);
								recordsLength = expLength === 0 ? expLength : recordsLength;
							}
							setOpenProjectSnackbar(true);
							setSnackbarMessage(response.message);
							return resolve();
						})
						.catch(() => {
							catchError();
						});
				})
			);
		}
		if (dispatches.length > 0) {
			promises.push(
				new Promise(resolve => {
					requestBody.items = dispatches;
					deleteOrArchiveItems('dispatches', requestBody, action)
						.then(response => {
							if (response.success_items.length !== 0) {
								const disLength = postDeleteArchive(
									view,
									response.success_items,
									itemsToBeDeletedOrArchived,
									location,
									dispatchList
								);
								recordsLength = disLength === 0 ? disLength : recordsLength;
							}
							setOpenProjectSnackbar(true);
							setSnackbarMessage(response.message);
							return resolve();
						})
						.catch(() => {
							catchError();
						});
				})
			);
		}
		Promise.all(promises)
			.then(() => {
				setIsAction(prevState => !prevState);
				if (location === 'expSidebar' && type !== 'dispatch') {
					closeSidebar();
				} else if (location === 'expSidebar' && type === 'dispatch') {
					setSidebarActions(prevState => !prevState);
				}
				if (recordsLength === 0) {
					itemsListApi();
				}
			})
			.catch(() => {
				catchError();
			});
	};

	// Context API values to pass to child components
	const contextValues = useMemo(
		() => ({
			allItems,
			multipleSelectedItems,
			page,
			totalRecords,
			isAction,
			isMoved,
			handlePageChanges,
			onPin,
			onCheckboxChecked,
			onSort,
			addListItem,
			sortColumn,
			sortOrder,
			projectAdded,
			isEdit,
			editListItem,
			itemsToMove,
			onAllSelected,
			allSelected,
			sidebarHandler,
			closeSidebar,
			filterTags,
			deleteTags,
			addTags,
			saveTags,
			onDeleteOrArchive,
			value,
			openLoader,
			handleOpenExperiments,
			handleOpenAllProjects,
			postTagAddition,
			setIsEdit,
			setOpenProjectSnackbar,
			setSnackbarMessage,
			postAddEditItem,
			sidebarActions,
			setSidebarActions,
			searchValue,
			tagsToFilter,
			showArchived,
			sidebarId,
			openSidebar,
			addMode,
			setEditableText,
			editableText,
			deleteListTags,
			setOpenLoader,
			editDispatchName
		}),
		[
			allItems,
			multipleSelectedItems,
			page,
			totalRecords,
			sortColumn,
			sortOrder,
			projectAdded,
			isEdit,
			allSelected,
			isAction,
			sidebarActions,
			showArchived,
			sidebarId,
			openSidebar,
			addMode,
			editableText,
			deleteListTags,
			onPin
		]
	);

	const listenToScroll = () => {
		const heightToHideFrom = 2;
		const winScroll = document.body.scrollTop || document.documentElement.scrollTop;

		if (winScroll > heightToHideFrom) {
			// eslint-disable-next-line no-unused-expressions
			isVisible && setIsVisible(false);
		} else {
			setIsVisible(true);
		}
	};

	useEffect(() => {
		window.addEventListener('scroll', listenToScroll);
		return () => window.removeEventListener('scroll', listenToScroll);
	}, []);

	return (
		<ProjectContext.Provider value={contextValues}>
			<Grid container data-testid="projectContainer" sx={{ mb: 4 }}>
				<Modal open={openSidebar} onClose={closeSidebar}>
					<Slide direction="left" in={openSidebar} mountOnEnter unmountOnExit timeout={500}>
						<div style={{ outline: 'none' }}>
							<ProjectsSideBar sidebarId={sidebarId} sidebarType={sidebarType} />
						</div>
					</Slide>
				</Modal>
				<CustomisedSnackbar
					testId="projectSnackbar"
					action="addItem"
					open={openProjectSnackbar}
					message={snackbarMessage}
					clickHandler={() => setOpenProjectSnackbar(false)}
					onClose={() => setOpenProjectSnackbar(false)}
					multipleSelectedItems={multipleSelectedItems}
				/>
				<CustomisedSnackbar
					testId="pinSnackbar"
					action="pin"
					open={openSnackbar}
					message={snackbarMessage}
					multipleSelectedItems={multipleSelectedItems}
					onClick={() => onPin(currentDispatchData)}
					clickHandler={() => setOpenSnackbar(false)}
					onClose={() => setOpenSnackbar(false)}
				/>
				{/* <Backdrop  open={openLoader} sx={{width:'90%', zIndex: 2000, backgroundColor: 'rgba(0,0,0,0.85)' }}>
				</Backdrop> */}
				{openLoader && (
					<Grid
						sx={{
							height: '70vh',
							width: '100%',
							display: 'flex',
							alignItems: 'center',
							justifyContent: 'center'
						}}
					>
						<Icon type="pointer" src={covLoader} />
					</Grid>
				)}
				{/* {!openLoader && ( */}
				<Grid container direction="row" sx={{ height: 'auto', display: openLoader && 'none' }}>
					<DispatchCard
						onPin={onPin}
						setMultipleItems={setMultipleItems}
						setOpenLoader={setOpenLoader}
					/>
				</Grid>
				{/* )}
				{!openLoader && ( */}
				<Grid container mt={4} sx={{ display: openLoader && 'none' }}>
					<Grid item xs={6}>
						<ProjectsTab value={value} onChange={handleTabChange} />
					</Grid>
					<Grid item xs={3} className="buttonGrid">
						<Grid style={{ paddingRight: '10px' }}>
							<ShowItemsMenu
								setShowArchived={setShowArchived}
								showArchived={showArchived}
								setMultipleItems={setMultipleItems}
								setAllSelected={setAllSelected}
							/>
						</Grid>
						<Grid>
							<AddItemsMenu
								currentTab={value}
								addItem={addItem}
								showArchived={showArchived}
								searchValue={searchValue}
								tagsToFilter={tagsToFilter}
							/>
						</Grid>
					</Grid>
					<Grid item xs={3} className="searchGrid">
						<SearchInput
							sx={{
								border: '1px solid #303067',
								borderRadius: '20px',
								height: '32.69px',
								'&.Mui-focused ': {
									border: '1px solid #6473ff'
								}
							}}
							value={searchKey || ''}
							onChange={e => onSearch(e)}
							cancelSearch={cancelSearch}
						/>
					</Grid>
				</Grid>
				{/* )} */}
				{(searchResults || tagsToFilter.length > 0) && (
					<Grid
						item
						xs={12}
						sx={{ display: openLoader ? 'none' : 'flex', paddingTop: '5px', paddingLeft: '5px' }}
					>
						<Icon type="static" src={searchIcon} />
						<Typography sx={{ paddingLeft: '2px', paddingRight: '5px', fontWeight: '700' }}>
							Search results
						</Typography>
						<Chip
							label={totalRecords}
							variant="outlined"
							size="small"
							sx={{
								minWidth: '24px',
								height: '24px',
								fontSize: '0.75rem',
								borderRadius: '8px',
								backgroundColor: '#1C1C46',
								'& .MuiChip-label': {
									overflow: 'visible'
								}
							}}
						/>
					</Grid>
				)}
				{tagsToFilter && (
					<Grid
						item
						xs={12}
						sx={{ display: openLoader ? 'none' : 'flex', paddingTop: '5px', paddingLeft: '5px' }}
					>
						<DeletableTags tags={tagsToFilter} />
						{tagsToFilter.length > 0 ? (
							<Tooltip title="Clear all filtered tags" placement="right">
								<Grid
									sx={{
										display: 'flex',
										backgroundColor: '#303067',
										marginLeft: '5px',
										borderRadius: '8px',
										pt: 0.3
									}}
								>
									<Icon src={closeIcon} clickHandler={() => setTagsToFilter([])} />
								</Grid>
							</Tooltip>
						) : (
							<></>
						)}
					</Grid>
				)}
				{/* {!openLoader && ( */}
				<Grid
					item
					xs={12}
					className="containerSpacing"
					mt={1}
					sx={{ display: openLoader && 'none' }}
				>
					{value === 'all' && <AllListView />}
					{value === 'experiments' && <ExperimentsListView />}
					{value === 'dispatches' && <DispatchesListView />}
				</Grid>
				{/* )} */}
			</Grid>
		</ProjectContext.Provider>
	);
}
