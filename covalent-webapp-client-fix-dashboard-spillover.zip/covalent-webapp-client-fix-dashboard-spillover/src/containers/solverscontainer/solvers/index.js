/* eslint-disable no-unused-vars */
import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { Box, Grid, SvgIcon, Select, MenuItem, Button, Typography } from '@mui/material';
import SearchInput from '../../../components/inputBase/projects/searchInput';
import ascending from '../../../assets/marketplace/ascending.svg';
import './style.css';
import SolversTabList from './solversList';

function CustomIcon(props) {
	return (
		// eslint-disable-next-line react/jsx-props-no-spreading
		<SvgIcon {...props} style={{ transform: 'translateY(20%)' }}>
			<svg
				width="16"
				height="16"
				viewBox="0 0 16 22"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					d="M8 10.9998L3 5.9998L3.7 5.2998L8 9.59981L12.3 5.2998L13 5.9998L8 10.9998Z"
					fill="#CBCBD7"
				/>
			</svg>
		</SvgIcon>
	);
}

function CustomArrow(props) {
	return (
		// eslint-disable-next-line react/jsx-props-no-spreading
		<SvgIcon {...props} style={{ transform: 'translateY(20%)' }}>
			<svg
				width="16"
				height="16"
				viewBox="0 0 16 16"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					d="M8 5.9998L3 10.9998L3.7 11.6998L8 7.39981L12.3 11.6998L13 10.9998L8 5.9998Z"
					fill="#CBCBD7"
				/>
			</svg>
		</SvgIcon>
	);
}

function SolversTabContainer() {
	const [searchKey, setSearchKey] = useState('');
	const [selected, setSelected] = useState('last_updated');
	const { allMySolvers } = useSelector(state => state.solver);
	const [sort, setSort] = useState('asc');

	const prepareSolversData = () => {
		const allData = [...allMySolvers];
		const preparedData = allData?.map(e => {
			return {
				...e,
				last_status_count: 10,
				last_status_total: 20,
				total_api_calls: 300,
				total_api_count: 200,
				total_cost: 300,
				total_cost_count: 200,
				dispatch_id: 'e99ba33e-b827-46c6-9987-db7c113c0af2',
				total_paramerter: 300,
				total_parameter_count: 200,
				utilsation: '70%',
				status: 'FAILED'
			};
		});
		return preparedData;
	};

	const [sortedData, setSortedData] = useState(prepareSolversData());
	// cancel search
	const cancelSearch = () => {
		setSearchKey('');
	};

	React.useEffect(() => {
		let data = prepareSolversData();
		if (searchKey) {
			const filteredData = data.filter(item =>
				item?.name.toLowerCase().includes(searchKey.toLowerCase())
			);
			data = filteredData;
		}
		setSortedData(data);
	}, [searchKey]);

	const selectionChangeHandler = event => {
		setSelected(event.target.value);

		const sortOption = event.target.value;

		// Sort the data based on the selected option
		// eslint-disable-next-line array-callback-return, consistent-return
		const sorted = [...sortedData].sort((a, b) => {
			const dateA = new Date(a.headData.last_build.split('-').reverse().join('-'));
			const dateB = new Date(b.headData.last_build.split('-').reverse().join('-'));

			if (sortOption === 'popular') {
				return a.downloads - b.downloads;
			} else if (sortOption === 'last_updated') {
				return dateA - dateB; // Sort in descending order of last_build date
			}
		});
		setSortedData(sorted);
	};

	// Sort the data based on the selected column and sort order
	const handleSortClick = () => {
		setSort(sort === 'asc' ? 'dsc' : 'asc');
		const sorted = [...sortedData].sort((a, b) => {
			if (sort === 'asc') {
				return b.downloads - a.downloads;
			}
			return a.downloads - b.downloads;
		});
		setSortedData(sorted);
	};

	return (
		<Box>
			<Grid
				container
				direction="row"
				justifyContent="space-between"
				alignItems="center"
				pt={4}
				width="100%"
			>
				<SearchInput
					sx={{
						border: '1px solid #303067',
						borderRadius: '20px',
						width: '260px',
						height: '32px',
						'&.Mui-focused ': {
							border: '1px solid #6473ff'
						},
						'& ::placeholder': {
							color: '#CBCBD7'
						}
						// mt:'10rem'
					}}
					value={searchKey || ''}
					onChange={e => setSearchKey(e.target.value)}
					cancelSearch={cancelSearch}
				/>
				<Box sx={{ display: 'flex' }}>
					<Box sx={{ paddingRight: '0px' }} display="flex" direction="row" spacing={3}>
						<Select
							IconComponent={CustomIcon}
							value={selected}
							onChange={selectionChangeHandler}
							sx={{
								fontSize: '14px',
								background: '#08081A',
								borderRadius: '200px',
								padding: '0rem 1rem',
								width: selected.length > 8 ? '9.5rem' : selected.length < 6 ? '6rem' : '8rem',
								height: '32px',
								color: '#BEBEBE',
								'.MuiOutlinedInput-notchedOutline': {
									borderColor: '#6473FF'
								},
								'&.Mui-focused .MuiOutlinedInput-notchedOutline': {
									borderColor: '#6473FF'
								},
								'&:hover .MuiOutlinedInput-notchedOutline': {
									borderColor: '#6473FF'
								},
								'.MuiSvgIcon-root ': {
									fill: 'transparent !important'
								}
							}}
						>
							<MenuItem sx={{ fontSize: '14px' }} value="last_updated">
								Last Updated{' '}
							</MenuItem>
							<MenuItem sx={{ fontSize: '14px' }} value="popular">
								Popular{' '}
							</MenuItem>
						</Select>
						<Button
							variant="outlined"
							sx={{
								'&:hover': {
									backgroundColor: theme => theme.palette.background.covalentPurple,
									color: '#FFFFFF',
									borderRadius: '25px',
									borderColor: theme => theme.palette.background.blue05
								},
								display: 'flex',
								justifyContent: 'center',
								borderRadius: '25px',
								height: '32px',
								width: '121px',
								marginLeft: '2rem'
							}}
							endIcon={
								<img
									src={ascending}
									alt={sort}
									style={{ transform: sort === 'dsc' ? 'rotate(180deg)' : '' }}
								/>
							}
							onClick={handleSortClick}
						>
							<Typography variant="h2" pt={0}>
								{sort === 'asc' ? 'Ascending' : 'Descending'}
							</Typography>
						</Button>
					</Box>
				</Box>
			</Grid>
			{/* <Grid container direction="row" justifyContent="space-between" alignItems="center"
        pt={12} width={'100%'}>
        <SearchInput
          sx={{
            border: '1px solid #303067',
            borderRadius: '20px',
            width: '258px',
            height: '32.69px',
            '&.Mui-focused ': {
              border: '1px solid #6473ff'
            },
          }}
          value={searchKey || ''}
          onChange={e => setSearchKey(e.target.value)}
          cancelSearch={cancelSearch}
        />
        <Box sx={{ display: 'flex' }}>
          <Box sx={{ paddingRight: '37px' }}>
            <Select
              IconComponent={CustomIcon}
              value={selected}
              onChange={selectionChangeHandler}
              sx={{
                background: theme => theme.palette.background.paper,
                borderRadius: '200px',
                padding: '0rem 1rem',
                width: selected.length > 8 ? '9.5rem' : selected.length < 6 ? '6rem' : '8rem',
                height: '40px',
                color: 'white',
                '.MuiOutlinedInput-notchedOutline': {
                  borderColor: theme => theme.palette.background.blue05
                },
                '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                  borderColor: theme => theme.palette.background.blue05
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  borderColor: theme => theme.palette.background.blue05
                },
                '.MuiSvgIcon-root ': {
                  fill: 'transparent !important'
                }
              }}
            >
              <MenuItem value="Last Updated">Last Updated </MenuItem>
              <MenuItem value="Last month">Last month</MenuItem>
              <MenuItem value="This month">This month</MenuItem>
            </Select>
          </Box>
          <Select
            IconComponent={CustomArrow}
            value={sortColumn}
            onChange={onSort}
            sx={{
              background: theme => theme.palette.background.paper,
              borderRadius: '200px',
              padding: '0rem 1rem',
              width: selected.length > 8 ? '9.5rem' : selected.length < 6 ? '6rem' : '8rem',
              height: '40px',
              color: 'white',
              '.MuiOutlinedInput-notchedOutline': {
                borderColor: theme => theme.palette.background.blue05
              },
              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                borderColor: theme => theme.palette.background.blue05
              },
              '&:hover .MuiOutlinedInput-notchedOutline': {
                borderColor: theme => theme.palette.background.blue05
              },
              '.MuiSvgIcon-root ': {
                fill: 'transparent !important'
              }
            }}
          >
            <MenuItem value="Ascending">Ascending</MenuItem>
            <MenuItem value="Descending">Descending</MenuItem>
          </Select>
        </Box>
      </Grid> */}
			{sortedData?.length === 0 && (
				<Typography color="textPrimary" mt={5} ml={1.5} variant="subtitle2">
					No records found
				</Typography>
			)}
			<Box>
				<SolversTabList solversData={sortedData} />
			</Box>
		</Box>
	);
}

export default SolversTabContainer;
