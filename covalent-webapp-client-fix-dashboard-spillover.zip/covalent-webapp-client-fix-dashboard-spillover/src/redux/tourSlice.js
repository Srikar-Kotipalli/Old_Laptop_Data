/* eslint-disable import/no-unused-modules */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { createSlice } from '@reduxjs/toolkit';

export const tourSlice = createSlice({
	name: 'tour',
	initialState: {
		run: false,
		steps: [],
		stepIndex: 0,
		isCompleted: true,
		tourActive: false,
		dispatches: 0,
		runTour: false,
		dispatchID: null,
		isOverview: false,
		isRecent: false
	},
	reducers: {
		setTourActive: (state, action) => {
			const { tourActive } = action.payload;
			state.tourActive = tourActive;
		},
		setTourState: (state, action) => {
			const { run, steps, stepIndex, isCompleted, runTour } = action.payload;
			state.run = run;
			state.steps = steps;
			state.stepIndex = stepIndex;
			state.isCompleted = isCompleted;
			state.runTour = runTour;
		},
		setDispatches: (state, action) => {
			const { dispatches } = action.payload;
			state.dispatches = dispatches;
		},
		setDispatchID: (state, action) => {
			const { dispatchID } = action.payload;
			state.dispatchID = dispatchID;
		},
		setTourRun: (state, action) => {
			const { run } = action.payload;
			state.run = run;
		},
		setIsOverview: (state, action) => {
			const { isOverview } = action.payload;
			state.isOverview = isOverview;
		},
		setIsRecent: (state, action) => {
			const { isRecent } = action.payload;
			state.isRecent = isRecent;
		},
		setTourSteps: (state, action) => {
			const { steps } = action.payload;
			state.steps = steps;
		}
	}
});

export const {
	setTourActive,
	setTourState,
	setDispatchID,
	setDispatches,
	setTourRun,
	setIsOverview,
	setIsRecent,
	setTourSteps
} = tourSlice.actions;
