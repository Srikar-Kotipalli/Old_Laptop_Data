/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
	isOpen: true,
	sharePopupEnable: false, // Initially navbar is closed
	enableSharing: false,
	shareUserList: []
};

export const navbarSlice = createSlice({
	name: 'navbar',
	initialState,
	reducers: {
		openNavbar: state => {
			state.isOpen = true;
		},
		closeNavbar: state => {
			state.isOpen = false;
		},
		toggleNavbar: state => {
			state.isOpen = !state.isOpen;
		},
		openShare: state => {
			state.sharePopupEnable = !state.sharePopupEnable;
		},
		enableShare: (state, action) => {
			state.enableSharing = action.payload;
		},
		updateShareUserList: (state, action) => {
			state.shareUserList = action.payload;
		}
	}
});

export const {
	openNavbar,
	closeNavbar,
	toggleNavbar,
	openShare,
	enableShare,
	updateShareUserList
} = navbarSlice.actions;

export const selectNavbarState = state => state.navbar.isOpen;
export const navbarShareState = state => state.navbar.sharePopupEnable;
export const enableShareState = state => state.navbar.enableSharing;
export const sharedUserList = state => state.navbar.shareUserList;

export default navbarSlice.reducer;
