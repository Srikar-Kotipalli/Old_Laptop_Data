/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import api from '../customAxios';

// userId, fromDate, toDate, page, sort, direction, count
// eslint-disable-next-line import/prefer-default-export
export const getDispatchesCharges = (userId, fromDate, toDate, count) => {
	return api
		.get(
			`${process.env.REACT_APP_ENDPOINT_URL_AQ_BACKEND}/v2/users/${userId}/lattices/charges?date_from=${fromDate}&date_to=${toDate}&page=0&sort=completed_at&direction=ASC&count=${count}`
		)
		.then(payload => {
			return payload;
		});
};

export const getLatticeBatchByCount = count => {
	return api
		.get(`${process.env.REACT_APP_ENDPOINT_URL_AQ_BACKEND}/v2/lattices?count=${count}`)
		.then(payload => {
			return payload;
		});
};

// donut chart api
export const getHardwareData = (userId, from, to) => {
	return api
		.get(
			`${process.env.REACT_APP_ENDPOINT_URL_AQ_BACKEND}/v2/users/${userId}/hardware/charges?date_from=${from}&date_to=${to}`
		)
		.then(payload => {
			return payload;
		});
};

// refresh api key
export const refreshApiKey = (userId, apiKey) => {
	return api
		.post(
			`${process.env.REACT_APP_ENDPOINT_URL_AQ_BACKEND}/v2/users/${userId}/api_key/${apiKey}/rotate`
		)
		.then(payload => {
			return payload;
		});
};
