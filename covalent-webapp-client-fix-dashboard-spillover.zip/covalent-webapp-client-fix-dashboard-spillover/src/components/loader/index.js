import React from 'react';
import Backdrop from '@mui/material/Backdrop';
import covLoader from '../../assets/loaders/covLoader.svg';
import Icon from '../icon';

function Loader({ isFetching, width, height, position, background, zIndex }) {
	return (
		<Backdrop
			open={isFetching}
			sx={{
				zIndex: zIndex || 70000,
				position: position || 'absolute',
				background: background || 'transparent',
				width: width || '',
				height: height || ''
			}}
		>
			<Icon type="pointer" src={covLoader} />
		</Backdrop>
	);
}

export default Loader;
