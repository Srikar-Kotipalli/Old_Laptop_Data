import React, { useContext } from 'react';
import { Box, Typography, Button, Skeleton } from '@mui/material';
import TotalElectron from '../../../assets/graph/totalElectron.svg';
import AvgRuntime from '../../../assets/graph/avgRuntime.svg';
import { GraphContext } from '../../../containers/graph/contexts/GraphContext';

const NodeDetailBox = ({
	setNodeBoxVisible,
	handleNodeMouseLeave,
	popupNode,
	foundObject,
	subLatticeElectron,
	subLatticeRuntime,
	isFetching
}) => {
	const { setSelectedNodeId, setSublatticeId, setTabValue } = useContext(GraphContext);

	// const [subLatticeElectron, setSublatticeElectron] = useState(0);
	// const [subLatticeRuntime, setSublatticeRuntime] = useState(null);

	function formatTime(seconds) {
		const totalMinutes = Math.floor(seconds / 60);
		const remainingSeconds = seconds % 60;
		const totalHours = Math.floor(totalMinutes / 60);
		const remainingMinutes = totalMinutes % 60;

		const formattedTime =
			totalHours > 0
				? `${totalHours}h ${remainingMinutes}m ${remainingSeconds.toFixed(0)}s`
				: remainingMinutes > 0
				? `${remainingMinutes}m ${remainingSeconds.toFixed(0)}s`
				: `${remainingSeconds.toFixed(0)}s`;

		return formattedTime;
	}
	// const [isFetching, setIsFetching] = useState(false);

	// useEffect(() => {
	// 	if (foundObject?.type === 'sublattice') {
	// 		setIsFetching(true);
	// 		getLatticeByDispatchID(popupNode?.data?.dispatchID)
	// 			.then(res => {
	// 				setSublatticeElectron(res?.task_num);
	// 				console.log('from hover1', foundObject);
	// 				getElectronByNode(res?.dispatch_id, foundObject?.node_id)
	// 					.then(response => {
	// 						console.log('from hover card', response);
	// 						setSublatticeRuntime(response?.runtime);
	// 						setIsFetching(false);
	// 					})
	// 					.catch(err => {
	// 						setSublatticeRuntime(0);
	// 						setIsFetching(false);
	// 					});
	// 			})
	// 			.catch(error => {
	// 				setSublatticeElectron(0);
	// 				setIsFetching(false);
	// 			});
	// 	}
	// }, [foundObject]);

	return (
		<Box
			// container
			sx={{
				position: 'absolute',
				// marginTop: popupNode?.position?.y - 400,
				// marginLeft: popupNode?.position?.x,
				// ml: '200px',
				// mt: '30%',
				// position: 'relative',
				// zIndex: 1,
				// zIndex: -1,
				// marginLeft: '0px',
				// marginTop: `-${popupNode?.position?.y}px`,
				// top: mousePosition.y - 10 + popupNode.height,
				// left: mousePosition.x - popupNode.width / 2,
				ml: '-50px',
				zIndex: 1000,
				mt: '10px',
				backgroundColor: '#10102C',
				width: '300px',
				padding: '20px 10px 20px 10px',
				borderRadius: '8px',
				border: '1px solid #303067',
				boxShadow: '0px 0px 10px 0px rgba(0,0,0,0.3)'
			}}
			// // onMouseEnter={e => e.stopPropagation()}
			// // onMouseEnter={(ev, node) => setHoveredNode(node)}
			// // onMouseLeave={() => setHoveredNode(null)}
			onMouseEnter={() => setNodeBoxVisible(true)}
			onMouseLeave={handleNodeMouseLeave}
		>
			{foundObject && foundObject?.type === 'sublattice' && (
				<Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
					<Box
						// item
						// xs={12}
						// lg={6}
						// sm={6}
						// md={6}
						sx={{ display: 'flex', gap: '10px', alignItems: 'center' }}
					>
						<img src={TotalElectron} alt="total electron" />
						<Box>
							{!isFetching ? (
								<Typography
									sx={{
										fontWeight: 600,
										fontSize: '16px',
										fontFamily: 'DM Sans',
										color: '#CBCBD7'
									}}
								>
									{/* {popupNode?.data?.node_id} */}
									{/* {foundObject && foundObject?.type !== 'sublattice' */}
									{/* ? 0 */}
									{subLatticeElectron || subLatticeElectron === 0 ? subLatticeElectron : '-'}
									{/* || '0'} */}
								</Typography>
							) : (
								<Skeleton variant="text" width={30} />
							)}
							<Typography
								sx={{ color: '#86869A', fontSize: '12px', fontFamily: 'DM Sans', fontWeight: 400 }}
							>
								Total Electron
							</Typography>
						</Box>
					</Box>
					<Box
						// item
						// xs={12}
						// lg={6}
						// sm={6}
						// md={6}
						sx={{ display: 'flex', gap: '10px', alignItems: 'center' }}
					>
						<img src={AvgRuntime} alt="Avg. Runtime" />
						<Box>
							{!isFetching ? (
								<Typography
									sx={{
										fontWeight: 600,
										fontSize: '16px',
										fontFamily: 'DM Sans',
										color: '#CBCBD7'
									}}
								>
									{subLatticeRuntime && subLatticeRuntime >= 0
										? formatTime(
												// foundObject &&
												// 	foundObject?.type === 'sublattice' &&
												// 	popupNode?.data?.sublattices_id !== null
												subLatticeRuntime
												// : foundObject?.runtime
										  )
										: '-'}
								</Typography>
							) : (
								<Skeleton variant="text" width={30} />
							)}
							<Typography
								sx={{ color: '#86869A', fontSize: '12px', fontFamily: 'DM Sans', fontWeight: 400 }}
							>
								Runtime
							</Typography>
						</Box>
					</Box>
				</Box>
			)}
			<Box
				// item
				// xs={12} lg={12} sm={12} md={12}
				sx={{ mt: foundObject && foundObject?.type === 'sublattice' ? '20px' : '0px' }}
			>
				<Button
					sx={{
						width: '100%',
						bgcolor: '#08081A',
						border: '1px solid #6473FF',
						borderRadius: '70px',
						height: '26px',
						color: '#CBCBD7',
						padding: '8px 16px 8px 16px'
					}}
					onClick={() => {
						setSelectedNodeId(popupNode?.data?.node_id);
						setSublatticeId(popupNode?.data?.dispatchID);
						setTabValue('Detail View');
						// setIsSelected(!isSelected);
					}}
				>
					View More
				</Button>
			</Box>
		</Box>
	);
};

export default NodeDetailBox;
