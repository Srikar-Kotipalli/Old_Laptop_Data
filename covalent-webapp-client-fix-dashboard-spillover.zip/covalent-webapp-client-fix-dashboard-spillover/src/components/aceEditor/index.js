/* eslint-disable import/no-unused-modules */
import React, { useRef, useEffect } from 'react';
import AceEditor from 'react-ace';
import 'ace-builds/webpack-resolver';
import 'ace-builds/src-noconflict/mode-yaml';
import 'ace-builds/src-noconflict/theme-merbivore_soft';
import './style.css';

function YamlEditor({
	value,
	readOnly,
	style,
	height,
	color,
	onChange,
	backgroundColor,
	isEnvLogs
}) {
	const editorRef = useRef(null);
	let interval;

	const handleUserInteraction = () => {
		if (interval) {
			clearInterval(interval);
			interval = null;
		}
	};

	useEffect(() => {
		if (editorRef?.current && isEnvLogs) {
			const aceInstance = editorRef.current.editor;
			// aceInstance.scrollToLine(Infinity, true, true);
			const lastLineNumber = aceInstance.getSession().getLength() - 1;
			const steps = 10; // Number of steps for smooth scrolling

			// Attach click event listener to the Ace Editor
			aceInstance.container.addEventListener('click', handleUserInteraction);

			// aceInstance.container.addEventListener('click', () => {
			// 	isSelectionActive = true;
			// 	handleUserInteraction();
			//   });

			let currentRow = aceInstance.getFirstVisibleRow();

			interval = setInterval(() => {
				currentRow += (lastLineNumber - currentRow) / steps;
				aceInstance.scrollToRow(currentRow);

				if (currentRow + 2 >= lastLineNumber) {
					clearInterval(interval);
				}
			}, 132);
			// Adjust the duration in milliseconds
		}
	}, [value]);

	return (
		<AceEditor
			ref={editorRef}
			mode="yml"
			theme="merbivore_soft"
			readOnly={readOnly}
			className={readOnly ? 'custom-editor' : ''}
			value={value}
			onChange={onChange}
			editorProps={{ $blockScrolling: true }}
			style={{
				width: 'auto',
				height: height || 'auto',
				color: color || '#CBCBD7',
				overflow: 'hidden',
				// fontFamily: 'DM Sans !important',
				backgroundColor: backgroundColor || '#0B0B11',
				...style // Merge the provided style props
			}}
		/>
	);
}

export default YamlEditor;
