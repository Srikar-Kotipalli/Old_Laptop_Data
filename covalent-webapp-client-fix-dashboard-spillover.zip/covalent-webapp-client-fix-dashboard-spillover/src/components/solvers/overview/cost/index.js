import { Stack, Box, Typography } from '@mui/material';
import React from 'react';
import LinearProgress, { linearProgressClasses } from '@mui/material/LinearProgress';
import { styled } from '@mui/material/styles';
import Icon from '../../../icon';
import costIcon from '../../../../assets/costIcon.svg';
import costDownIcon from '../../../../assets/costDownIcon.svg';
import './style.css';

const BorderLinearProgress = styled(LinearProgress)(() => ({
	height: '2px',
	borderRadius: '8px',
	[`&.${linearProgressClasses.colorPrimary}`]: {
		backgroundColor: '#303067'
	},
	[`& .${linearProgressClasses.bar}`]: {
		borderRadius: 5,
		backgroundColor: '#5552FF'
	}
}));

const BorderLinearProgress1 = styled(LinearProgress)(() => ({
	height: '5px',
	width: '90px',
	borderRadius: '30px',
	[`&.${linearProgressClasses.colorPrimary}`]: {
		backgroundColor: 'transparent'
	},
	[`& .${linearProgressClasses.bar}`]: {
		borderRadius: 5,
		backgroundColor: '#5552FF'
	}
}));

function Cost() {
	return (
		<Box className="utilCtr">
			<Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1 }}>
				<Box className="utilizationHeaderIcon">
					<Icon type="static" src={costIcon} height="14px" width="14px" />
				</Box>
				<Box>
					<Typography className="utilzationLabel" sx={{ color: '#FFF' }}>
						Cost
					</Typography>
				</Box>
			</Stack>
			<Box sx={{ my: 3 }}>
				<Stack direction="row" spacing={1}>
					<Box>
						<Typography className="costTitle-1">$50,124</Typography>
						<BorderLinearProgress variant="determinate" value={50} sx={{ mt: 2 }} />
					</Box>
					<Box>
						<Stack direction="row" spacing={1}>
							<Box>
								<Icon type="static" src={costDownIcon} />
							</Box>
							<Box>
								<Typography className="costTitle-2">-22%</Typography>
							</Box>
						</Stack>
					</Box>
				</Stack>
			</Box>
			<Box>
				<Typography sx={{ color: '#CBCBD7', fontSize: '12px', lineHeight: '16px', mb: 2 }}>
					Project
				</Typography>
				<Stack direction="row" spacing={2} alignItems="center">
					<Typography className="pbarHead" sx={{ width: '70px' }}>
						Budget
					</Typography>
					<Box>
						<BorderLinearProgress1 variant="determinate" value={80} />
					</Box>
					<Typography>$154,690</Typography>
				</Stack>
				<Stack direction="row" spacing={2} alignItems="center" sx={{ my: 2 }}>
					<Typography className="pbarHead" sx={{ width: '70px' }}>
						Cost
					</Typography>
					<Box>
						<BorderLinearProgress1 variant="determinate" value={40} />
					</Box>
					<Typography>$87,480</Typography>
				</Stack>
			</Box>
		</Box>
	);
}

export default Cost;
