import { Stack, Box, Typography } from '@mui/material';
import React from 'react';
import Icon from '../../../icon';
import utilizationIcon from '../../../../assets/utilizationIcon.svg';
import './style.css';
import AreaChart from '../../../chart/areaChart';

function Utilization() {
	const UsageChartData = {
		data: [38, 52, 20, 58, 18, 75, 40, 85, 19, 45, 34, 96, 22],
		categories: [
			'2023-07-24T01:41:13Z',
			'2023-07-24T02:41:13Z',
			'2023-07-24T03:41:13Z',
			'2023-07-24T04:41:13Z',
			'2023-07-24T05:41:13Z',
			'2023-07-24T06:41:13Z',
			'2023-07-24T07:41:13Z',
			'2023-07-24T08:41:13Z',
			'2023-07-24T09:41:13Z',
			'2023-07-24T10:41:13Z',
			'2023-07-24T11:41:13Z',
			'2023-07-24T12:41:13Z'
		]
	};
	return (
		<Box className="utilCtr">
			<Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1 }}>
				<Box className="utilizationHeaderIcon">
					<Icon type="static" src={utilizationIcon} />
				</Box>
				<Box>
					<Typography className="utilzationLabel" sx={{ color: '#FFF' }}>
						Utilization
					</Typography>
				</Box>
			</Stack>
			<Box>
				<AreaChart UsageChartData={UsageChartData} height={180} style={{ width: '10px' }} />
			</Box>
		</Box>
	);
}

export default Utilization;
