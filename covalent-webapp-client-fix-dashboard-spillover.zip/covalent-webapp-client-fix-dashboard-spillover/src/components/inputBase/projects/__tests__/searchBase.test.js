/* eslint-disable react/jsx-no-constructed-context-values */
/* eslint-disable testing-library/no-node-access */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
import SearchInput from '../searchInput';

describe('Search Input Base', () => {
	const handleClick = jest.fn();
	test('renders search input base', () => {
		render(<SearchInput />);
		const element = screen.getByTestId('searchInputBase');
		expect(element).toBeInTheDocument();
	});
	test('renders searchIcon accordingly', () => {
		render(<SearchInput alt="searchIcon" />);
		const element = screen.getByAltText('searchIcon');
		expect(element).toBeInTheDocument();
	});

	test('renders appropriate value', () => {
		render(<SearchInput value="User" />);
		const element = screen.getByDisplayValue('User');
		expect(element).toBeInTheDocument();
	});
	test('Call cancel on clicking close icon', () => {
		render(<SearchInput value="User" cancelSearch={handleClick} />);
		const element = screen.getByAltText('closeIcon');
		expect(element).toBeInTheDocument();
		fireEvent.click(element);
		expect(handleClick).toBeCalledTimes(1);
	});
});
