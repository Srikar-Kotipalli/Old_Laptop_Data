/* eslint-disable import/no-unused-modules */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import InputBase from '@mui/material/InputBase';
import Grid from '@mui/material/Grid';
import Icon from '../../icon';
import closeIcon from '../../../assets/actions/close.svg';
import searchIcon from '../../../assets/actions/search.svg';

export default function SearchInput(props) {
	const { value, onChange, cancelSearch, sx, disabled } = props;
	return (
		<InputBase
			disabled={disabled}
			data-testid="searchInputBase"
			name="noAutoFill"
			id="search-jha"
			placeholder="Search"
			className="inputSearch"
			fullWidth
			value={value || ''}
			inputProps={{
				autoComplete: 'off'
			}}
			sx={sx}
			onChange={onChange}
			startAdornment={
				<Grid sx={{ paddingLeft: '5px' }}>
					<Icon src={searchIcon} type="static" alt="searchIcon" />
				</Grid>
			}
			endAdornment={
				<Grid sx={{ paddingRight: '5px' }}>
					{value ? (
						<Icon
							clickHandler={() => {
								cancelSearch();
							}}
							src={closeIcon}
							type="pointer"
							alt="closeIcon"
						/>
					) : (
						''
					)}
				</Grid>
			}
		/>
	);
}
