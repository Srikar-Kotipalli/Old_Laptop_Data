/* eslint-disable react/jsx-props-no-spreading */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState } from 'react';
import { Drawer, Grid, Typography, Box, Skeleton } from '@mui/material';
import Divider from '@mui/material/Divider';
// import { Auth } from 'aws-amplify';
import { useSelector } from 'react-redux';
import Icon from '../icon';
import CloseIcon from '../../assets/icons/close.svg';
import Running from '../../assets/dispatch/dispatchRunningDashboard.svg';
import Error from '../../assets/errorIcon.svg';
import SampleDispatchIcon from '../../assets/dispatches/sampleDispatch/dispatchIcon.svg';
import Launch from '../../assets/actions/launch.svg';
import Arrow from '../../assets/arrows/arrowRight.svg';
import Graph from '../../assets/graph/graph.svg';
import RunDispatch from '../../assets/runDispatch.svg';
import Button from '../primaryButton/index';
import DispatchParameters from './dispatchParameters';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import DispatchCard from '../card/dashboard/dispatchcard/dispatchCard';
import {
	getDispatchCode,
	createDispatch,
	getTutorial
} from '../../api/sampleDispatch/sampleDispatchApi';
// import { getUserAPIKey } from '../../api/users/apiKey';
import DispatchCode from './dispatchCode';
import Carousel from '../carousel';
import useUpdateEffect from '../../utils/useUpdateEffect';
import Loader from '../loader';
import routes from '../../constants/routes.json';

function Tutorials(props) {
	const { tutorialsOpen, setTutorialsOpen } = props;
	const [tutorialsData, setTutorialsData] = useState([]); // Stores all the data from Sample Dispatch initial API CAll
	const [textFieldValue, setTextFieldValue] = useState(4); // To Store Values from text field from the SIN Curves
	// eslint-disable-next-line no-unused-vars
	const [textFieldValueX, setTextFieldValueX] = useState('null');
	const [buttonClicked, setButtonClicked] = useState(false);
	const [sourceCode, setSourceCode] = useState('');
	const [sourceCopyCode, setSourceCopyCode] = useState('');
	const [statusMessage, setStatusMessage] = useState('');
	const [dispatchId, setDispatchID] = useState('');
	const { userToken: apiKey } = useSelector(state => state.dashboard);

	// Grid divider
	// eslint-disable-next-line react/no-unstable-nested-components
	function StyledDivider() {
		return (
			<Divider
				sx={{ borderColor: theme => theme.palette.background.blue03 }}
				orientation="horizontal"
				variant="middle"
				flexItem
			/>
		);
	}

	// Card Carousel settings

	const settings = {
		className: 'center',
		dots: true, // Navigation dotes
		infinite: true,
		speed: 500,
		slidesToShow: 1, // No of Hero cards in carousel
		slidesToScroll: 1,
		autoplay: true,
		centerMode: true,
		centerPadding: '60px',
		autoplaySpeed: 2200 // Speed of carousel
	};

	// Carousel Card Content

	const guides = [
		{
			img: Launch,
			heading: 'Install',
			code: 'pip install covalent-cloud --upgrade ',
			step: 'Step 1',
			goto: process.env.REACT_APP_AQ_DOC_PORTAL_URL_INSTALLATION,
			description: 'Install covalent cloud from PyPi',
			banner: ''
		},
		{
			img: Launch,
			heading: 'Code Locally',
			// eslint-disable-next-line max-len
			code: 'def workflow(num_curves):\nx = np.linspace(0, 2 * np.pi)\nfig = None\nfor i in range(num_curves):\ny = rand_sin_func(x) y_spline = get_spline(x, y)\nfig = plot_interpolation(x, y, y_spline, fig=fig, label_i=i + 1)\nreturn fig',
			step: 'Step 2',
			goto: process.env.REACT_APP_AQ_DOC_PORTAL_URL_QUICKSTART,
			description: 'Copy the code and run it in your local python IDE/Notebook',
			banner: ''
		},
		{
			img: Arrow,
			heading: 'Browse through the',
			heading2: ' dispatch page',
			step: 'Step 3',
			code: '',
			goto: routes?.DISPATCHES,
			description: '',
			banner: Graph
		}
	];

	// Function to update the text field values of the SIN Curves
	// eslint-disable-next-line no-unused-vars
	const handleTextFieldChangeX = e => {
		const inputValue = e?.target?.value?.replace(/[^0-9]/g, '');
		setTextFieldValueX(inputValue);
	};

	const handleTextFieldChangeY = e => {
		const inputValue = e?.target?.value?.replace(/[^0-9]/g, '');
		setTextFieldValue(inputValue);
	};

	// Initial API Call to get all the details in Run Dispatch Sidebar

	function getTutorialData(val) {
		getTutorial(val)
			.then(_res => {
				if (_res) {
					setTutorialsData(_res?.tutorials);
					Promise.all(
						_res?.tutorials?.map(tutorial => {
							return getDispatchCode(tutorial?.source?.href, val)
								.then(_code => {
									setSourceCopyCode(_code);
									setSourceCode(_code?.substring(_code?.indexOf('@ct.lattice')));
								})
								.catch(error => {
									console.error('Error getting Source Code:', error);
									return tutorial; // Fallback to original record on error
								});
						})
					);
				}
			})
			.catch(err => {
				console.log('error from Sample Dispatch ', err);
			});
	}

	// Create dispatch API body Parameters
	const bodyParameters = {
		args: [],
		kwargs: { num_curves: parseInt(textFieldValue, 10) }
	};

	// API call to create a Sample Dispatch

	function handleClick(submitPath) {
		// submitPath is a parameter coming from the above GET API
		setButtonClicked(true);
		setStatusMessage('Dispatching');
		createDispatch(bodyParameters, submitPath, apiKey)
			.then(_res => {
				if (_res) {
					// once a dispatch is crated it will be redirected to that particular Dispatch Graph
					setButtonClicked(false);
					setDispatchID(_res?.dispatch_id);
					setStatusMessage('Dispatched Successfully');
					window.open(`/graph/${_res?.dispatch_id}`, '_blank');
				}
			})
			.catch(err => {
				console.log('error at running dispatch ', err);
				setStatusMessage('Failed to Dispatch');
				setButtonClicked(false);
			});
	}

	function viewDispatch() {
		window.open(`/graph/${dispatchId}`, '_blank');
	}

	// useEffect(() => {
	// 	Auth.currentAuthenticatedUser().then(user => {
	// 		const res = user?.attributes;
	// 		const userID = res && res['custom:userID'];
	// 		getUserAPIKey(userID)
	// 			.then(payload => {
	// 				if (payload && Array.isArray(payload) && payload?.length !== 0) {
	// 					setApiKey(payload[payload.length - 1]?.api_key);
	// 				} else setApiKey('API key yet to be generated,please contact administrator');
	// 			})
	// 			.catch(() => {
	// 				setApiKey('API key yet to be generated,please contact administrator');
	// 			});
	// 	});
	// }, []);

	useUpdateEffect(() => {
		if (apiKey !== null) {
			getTutorialData(apiKey);
		}
	}, [apiKey]);

	return (
		// Drawer Component
		<Drawer
			anchor="right"
			open={tutorialsOpen}
			onClose={() => setTutorialsOpen(false)}
			sx={{
				width: '470px',
				'& .MuiDrawer-paper': {
					height: 'calc(100% - 40px)',
					width: '470px',
					margin: '20px 20px 20px 0px',
					padding: '25px',
					backgroundColor: theme => theme.palette.background.covalentPurple,
					borderRadius: '10px'
				}
			}}
		>
			<Grid container sx={{ padding: '10px 0 10px 0' }} spacing={2}>
				<Grid item xs={11} sx={{ display: 'flex' }}>
					<>
						<Icon
							margin="0px 8px 0px 0px"
							src={SampleDispatchIcon}
							type="static"
							alt="sampleDispatchLogo"
						/>
						<Box display="flex" justifyContent="space-between">
							<Typography>Try dispatching the </Typography>
							<Box
								sx={{
									color: theme => theme.palette.background.blue05,
									textDecoration: 'underline',
									padding: '0 4px 0 4px',
									cursor: 'pointer'
								}}
								onClick={() =>
									window.open(
										'https://docs.covalent.xyz/docs/cloud/cloud_quickstart/#step-6-create-your-workflow',
										'_blank'
									)
								}
							>
								Getting Started
							</Box>
							<Typography>example</Typography>
						</Box>
					</>
				</Grid>
				<Grid item xs={1}>
					<Icon
						height={10}
						width={10}
						src={CloseIcon}
						alt="sampleDispatchLogo"
						clickHandler={() => setTutorialsOpen(false)}
					/>
				</Grid>
			</Grid>
			<Grid container>
				{/* // Mapping the all the Data from the Initial API call to individual component */}
				{tutorialsData.length > 0 ? (
					tutorialsData?.map(tutorial => (
						<Grid
							key={tutorial}
							container
							direction="column"
							sx={{
								border: '1px solid #303067',
								borderRadius: '8px',
								padding: '10px 0 5px 0',
								m: '.5rem 0 2rem 0'
							}}
						>
							<Grid item>
								<Box display="flex" justifyContent="space-between" p="5px 10px 5px 10px">
									<Typography
										sx={{
											color: theme => theme.palette.text.secondary,
											fontWeight: 'bold',
											fontSize: '14px'
										}}
									>
										{tutorial.name}
									</Typography>
									<Typography sx={{ color: theme => theme.palette.text.primary, fontSize: '14px' }}>
										~ $0.01/ computation
									</Typography>
								</Box>
							</Grid>
							<StyledDivider />
							<Grid item sx={{ p: '5px 10px 5px 10px' }}>
								<Box>
									<Typography sx={{ fontSize: '14px' }}>{tutorial?.description}</Typography>
									<Box p="10px 0 10px 0">
										{/* // Pass the path from the initial API call to get the Sample dispatch Code */}
										{sourceCode.length > 0 ? (
											<DispatchCode
												code={sourceCode}
												copyCode={sourceCopyCode}
												n={204}
												goto={process.env.REACT_APP_AQ_DOC_PORTAL_URL_QUICKSTART}
												placement="top"
											/>
										) : (
											<Box
												p="22px 0 32px 0px"
												bgcolor={theme => theme.palette.background.paper}
												borderRadius="8px"
											>
												<Box pl="12px">
													<Skeleton width={300} />
													<Skeleton width={200} />
													<Skeleton width={100} />
												</Box>
											</Box>
										)}
									</Box>
								</Box>
								<Grid container>
									{/* <Grid item xs={6}>
										<DispatchParameters
											name="x :"
											description="Plot the states at the end"
											textFieldValue={textFieldValueX}
											handleTextFieldChange={handleTextFieldChangeX}
											notEditable
										/>
									</Grid> */}
									<Grid item xs={6}>
										<DispatchParameters
											name="num_curves:"
											description="Number of sin curves to simulate"
											textFieldValue={textFieldValue}
											handleTextFieldChange={handleTextFieldChangeY}
											notEditable
										/>
									</Grid>
								</Grid>
							</Grid>
							<StyledDivider />
							<Grid item p="10px 15px 10px 10px">
								<Box sx={{ display: 'flex', alignItems: 'center' }}>
									<Button
										title="Run Dispatch"
										variant="contained"
										bgColor={theme => theme.palette.background.blue03}
										img={RunDispatch}
										hoverColor={theme => theme.palette.background.paper}
										color={theme => theme.palette.text.gray04}
										// On click of this button a sample dispatch will be ran and the path comes from initial API call
										// eslint-disable-next-line react/jsx-no-bind
										handler={() => handleClick(tutorial?.submit?.href)}
										disabled={buttonClicked} // Disable the button if it has been clicked}
									/>
									{statusMessage === 'Dispatched Successfully' ? (
										<Box sx={{ pl: '1rem' }}>
											<Button
												title="View Dispatch"
												variant="contained"
												bgColor={theme => theme.palette.background.paper}
												borderisPresent="1px solid #6473FF"
												img={Arrow}
												sx={{
													'&:hover': {
														backgroundColor: theme => theme?.palette?.background?.covalentPurple,
														borderRadius: '25px',
														borderColor: theme => theme?.palette?.background?.blue05
													}
												}}
												handler={() => viewDispatch()}
												disabled={buttonClicked}
											/>
										</Box>
									) : (
										<Box display="flex" alignItems="center">
											<Box ml="25px">
												{statusMessage === 'Dispatching' && (
													<Icon status="circleRunningStatus" src={Running} />
												)}

												{statusMessage === '' && ''}

												{statusMessage === 'Failed to Dispatch' && <Icon src={Error} />}
											</Box>
											<Box alignItems="center">
												<Typography fontSize="12px" color={theme => theme.palette.text.running}>
													{statusMessage}
												</Typography>
											</Box>
										</Box>
									)}
								</Box>
							</Grid>
						</Grid>
					))
				) : (
					<Box
						sx={{
							borderRadius: '8px',
							padding: '10px  420px 320px 0'
						}}
					>
						<Loader isFetching="true" width="100%" height="calc(100% - 400px)" />
					</Box>
				)}
			</Grid>
			<Grid container direction="column">
				<Grid item>
					<Typography color="#AEB6FF" fontSize="16px">
						Run your first dispatch
					</Typography>
				</Grid>
				<Grid item>
					<Typography fontSize="14px">
						3 step guide on how to run your first dispatch from laptop to Covalent cloud
					</Typography>
				</Grid>
			</Grid>
			{/* // Card Carousel Component*/}
			<Box mt="25px" className="dispatchCard">
				<Carousel sliderSettings={settings}>
					{Array.from(guides).map(guide => (
						<Grid item key={guide} xs={12} padding="7px" overflow="auto">
							<DispatchCard
								img={guide?.img}
								heading={guide?.heading}
								heading2={guide?.heading2}
								code={guide?.code}
								step={guide?.step}
								description={guide?.description}
								banner={guide?.banner}
								goto={guide?.goto}
							/>
						</Grid>
					))}
				</Carousel>
			</Box>
		</Drawer>
	);
}

export default Tutorials;
