/* eslint-disable no-unused-vars */
/* eslint-disable quotes */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useEffect, useContext } from 'react';

import { Box, Grid, Typography, Tooltip, InputAdornment, IconButton, Input } from '@mui/material';
import { withStyles } from '@mui/styles';
import { Auth } from 'aws-amplify';
import { useDispatch, useSelector } from 'react-redux';
import { dispatchOverview } from '../../api/experiments/dispatchApi';
import { setDispatches, setIsOverview } from '../../redux/tourSlice';

import { SummaryCard } from '../card/dashboard/revampedcards';
import SummaryToken from './summaryToken';
import Icon from '../icon';
import CostImage from '../../assets/cost.svg';
import TotalDispatchesImage from '../../assets/dashboard/totalDispatches.svg';
import ApiKeyImage from '../../assets/dashboard/apiKey.svg';
import Refresh from '../../assets/tokenReset.svg';
import SettingsCopyButton from '../copyButton/settings';
import CopyIcon from '../../assets/copyIcon.svg';
import CopiedIcon from '../../assets/checkmarks/checkmark.svg';
import VisibilityOff from '../../assets/hardware/visibilityOff.svg';
import VisibilityOn from '../../assets/hardware/visibilityOn.svg';
import { getUserCharges } from '../../api/billing/billingApi';
import { getUserAPIKey } from '../../api/users/apiKey';
import { refreshApiKey } from '../../api/dashboard/dashboardApi';
import { setUserToken } from '../../redux/dashboardSlice';
import { DashboardContext } from '../../containers/dashboard/contexts/DashboardContext';

const DisabledInput = withStyles({
	root: {
		'& .MuiInput-input.Mui-disabled': {
			color: '#CBCBD7',
			WebkitTextFillColor: '#CBCBD7'
		}
	}
})(Input);

function Summary() {
	const [isRefreshing, setIsRefreshing] = useState(false);
	const [charges, setCharges] = useState(0);
	const [userID, setUserID] = useState('');
	const [overviewData, setOverviewData] = useState({});
	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);
	const dispatch = useDispatch();
	const [openChargesLoader, setOpenChargesLoader] = useState(false);
	const [openLoader, setOpenLoader] = useState(false);
	const { getLatticesData, dashboardLatticeCount, recentDispatchesLoader } =
		useContext(DashboardContext);
	const dashboardAction = useDispatch();
	const { userToken } = useSelector(state => state.dashboard);
	const summaryData = [
		{
			heading: 'Compute Cost',
			value: charges?.billing_periods?.current?.display_price || '$0.00 USD',
			isLoading: openChargesLoader,
			type: 'cost',
			subContent: charges?.from_date
		},
		{
			heading: 'Total Dispatches',
			// value: overviewData?.dispatches,
			// value: latticeBatch?.metadata?.total_count,
			value: dashboardLatticeCount,
			type: 'dispatches',
			isLoading: recentDispatchesLoader
		}
	];
	const [visible, setVisible] = useState(false);
	const [apiExpired, setApiExpired] = useState(false);
	// eslint-disable-next-line no-unused-vars
	const [token, setToken] = useState('');

	const getValueForInputField = () => {
		if (visible) return token;
		return '*********************************';
	};

	const checkExpired = expiryDate => {
		const expiry = new Date(expiryDate);
		if (expiry < new Date()) return true;
		return false;
	};

	const refreshFunc = () => {
		setIsRefreshing(true);
		refreshApiKey(userID, userToken)
			.then(res => {
				setToken(res?.api_key);
				dashboardAction(setUserToken({ userToken: res?.api_key }));
				setIsRefreshing(false);
			})
			.catch(error => {
				console.error(error);
				setIsRefreshing(false);
			});
	};

	useEffect(() => {
		getLatticesData(false);
	}, [liveRefresh]);

	useEffect(() => {
		setOpenLoader(true);
		// getLatticesData();
		// dispatchOverview('', '')
		// 	.then(response => {
		// 		setOverviewData(response);
		// 		dispatch(setDispatches({ dispatches: response?.dispatches || 0 }));
		// 		dispatch(setIsOverview({ isOverview: true }));
		// 	})
		// 	.catch(error => {
		// 		console.error(error);
		// 		dispatch(setDispatches({ dispatches: 0 }));
		// 		dispatch(setIsOverview({ isOverview: true }));
		// 	})
		// 	.finally(() => {
		// 		setOpenLoader(false);
		// 	});

		Auth.currentAuthenticatedUser()
			.then(user => {
				setOpenChargesLoader(true);
				const res = user?.attributes;
				setUserID(res && res['custom:userID']);
				getUserAPIKey(res && res['custom:userID'])
					.then(payload => {
						if (payload) {
							const isAPIKeyExpired = checkExpired(payload[payload.length - 1]?.expiry);
							setApiExpired(isAPIKeyExpired);
							setToken(payload[payload.length - 1]?.api_key);
							dashboardAction(setUserToken({ userToken: payload[payload.length - 1]?.api_key }));
							// setTokenValue(payload[payload.length - 1].api_key);
						} else {
							setToken('API key yet to be generated,please contact administrator');
							dashboardAction(
								setUserToken({
									userToken: 'API key yet to be generated,please contact administrator'
								})
							);
						}
					})
					.catch(() => {
						setToken('API key yet to be generated,please contact administrator');
						dashboardAction(
							setUserToken({
								userToken: 'API key yet to be generated,please contact administrator'
							})
						);
					});
				// getUserCharges(userID)
				getUserCharges(res && res['custom:userID'])
					.then(payload => {
						if (payload) {
							setCharges(payload);
						}
						setOpenChargesLoader(false);
					})
					.catch(() => {
						setCharges({ display_price: '$0.00', from_date: new Date() });
						setOpenChargesLoader(false);
					});
			})
			.catch(() => {
				setToken('API key yet to be generated,please contact administrator');
				dashboardAction(
					setUserToken({
						userToken: 'API key yet to be generated,please contact administrator'
					})
				);
				setCharges({ display_price: '$0.00', from_date: new Date() });
				setOpenChargesLoader(false);
			});
	}, []);
	return (
		<Box
			sx={{
				border: theme => `1px solid ${theme.palette.background.blue03}`,
				borderRadius: '8px',
				padding: '20px',
				display: 'flex',
				height: '141px'
			}}
		>
			<Grid container>
				<Grid item xs={8}>
					<Box sx={{ display: 'flex', width: '90%' }}>
						{/* {openLoader && <Loader isFetching={openLoader} width="100%" position="relative" height="8.95rem" />} */}
						{summaryData?.map(item => {
							return (
								<Box sx={{ width: '50%', height: '100%' }} key={item.heading}>
									<SummaryCard
										heading={item?.heading?.toString()}
										value={item?.value?.toString()}
										isLoading={item?.isLoading}
										subContent={item?.subContent}
										type={item?.type}
										imgSrc={
											item?.heading?.toString() === 'Compute Cost'
												? CostImage
												: TotalDispatchesImage
										}
									/>
								</Box>
							);
						})}
					</Box>
				</Grid>
				<Grid item xs={4}>
					{/* <Box
						sx={{
							borderRadius: '8px',
							padding: '10px',
							background: theme => theme.palette.background.dashboardCard,
							boxShadow: '0px 4px 7px 0px rgba(0, 0, 0, 0.35);',
							height: '100%',
							border:'1px solid red'
						}}
					>
						<Box sx={{ display: 'flex' }}>
							<Icon src={CostImage} />
							<Typography
								sx={{
									marginLeft: '5px',
									display: 'flex',
									alignItems: 'center',
									color: theme => theme.palette.text.blue01,
									fontWeight: '700',
									fontSize: '14px'
								}}
							>
								Token
							</Typography>
						</Box>
						<Box sx={{ display: 'flex', marginTop: '20px' }}>
							<DisabledInput
								sx={{
									display: 'flex',
									alignItems: 'center',
									justifyContent: 'center',
									textAlign: 'center',
									marginRight: '4px',
									padding: '8px 12px',
									pt: 1.5,
									width: '320px',
									height: '32px',
									background: theme => theme.palette.background.default,
									border: theme => `1px solid ${theme.palette.background.blue03}`,
									borderRadius: '60px',
									fontSize: visible ? '12px' : '14px',
									color: theme => theme.palette.text.primary,
									'&MuiInput-input.Mui-disabled': {}
								}}
								// disabled={isDisabled}
								disabled={false}
								disableUnderline
								value={getValueForInputField()}
								onChange={e => console.log(e)}
								// startAdornment={
								// 	// isStartAdornReqd ? (
								// 	<InputAdornment position="start">
								// 		<IconButton size="small">
								// 			<img src={Refresh} alt="reactIcon" role="presentation" />
								// 		</IconButton>
								// 	</InputAdornment>
								// 	// ) : null
								// }
								endAdornment={
									<InputAdornment position="end">
										<Tooltip title={visible ? 'Hide' : 'Unhide'} placement="top">
											<Grid>
												<Icon
													src={visible ? VisibilityOn : VisibilityOff}
													alt="visibilityOff"
													type="pointer"
													clickHandler={() => setVisible(prev => !prev)}
												/>
											</Grid>
										</Tooltip>
									</InputAdornment>
								}
							/>

							<Box
								sx={{
									padding: '6px',
									border: theme => `1px solid ${theme.palette.background.blue03}`,
									borderRadius: '8px',
									width: '32px',
									height: '32px',
									display: 'flex',
									alignItems: 'center'
								}}
							>
								<SettingsCopyButton
									content={token}
									copyIcon={CopyIcon}
									copiedIcon={CopiedIcon}
									title="Copy"
								/>
							</Box>
						</Box>
					</Box> */}
					<SummaryToken
						headingImg={CostImage}
						heading={apiExpired ? 'API Key expired, Please refresh your key' : 'API Key'}
						value={userToken}
						type="dashboard"
						CopyIcon={CopyIcon}
						CopiedIcon={CopiedIcon}
						isStartAdornReqd
						startAdornFunction={refreshFunc}
						isLoading={isRefreshing}
						tokenExpired={apiExpired}
						imgSrc={ApiKeyImage}
					/>
				</Grid>
			</Grid>
		</Box>
	);
}

export default Summary;
