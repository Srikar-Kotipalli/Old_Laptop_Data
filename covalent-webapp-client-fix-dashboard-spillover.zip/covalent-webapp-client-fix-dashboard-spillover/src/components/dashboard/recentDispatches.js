/* eslint-disable no-unused-vars */
/* eslint-disable quotes */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useEffect, useState, useContext } from 'react';

import { Box, Typography, Grid, Divider } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import CustomScrollbars from '../customScroll/v2';
import useDidMountEffect from '../../utils/useDidMountEffect';
import { highlightedDispatchesList, getLatticesBatch } from '../../api/experiments/dispatchApi';
import { setDispatchID, setIsRecent } from '../../redux/tourSlice';
import { RecentDispatchCard, SeeAll } from '../card/dashboard/revampedcards';
import { getStatus, statusIcons } from '../../utils/utils';
import recentDispatch from '../../assets/dispatch/recent_dispatch.svg';
import Loader from '../loader';
import Icon from '../icon';
import { DashboardContext } from '../../containers/dashboard/contexts/DashboardContext';
import routes from '../../constants/routes.json';
import useLength from '../../utils/useLength';

function RecentDispatches() {
	const [recentDispatches, setRecentDispatches] = useState([]);
	const [fetchRecents, setFetchRecents] = useState(false);
	const [openLoader, setOpenLoader] = useState(false);
	const [statuses, setStatuses] = useState([]);
	const dispatchAction = useDispatch();
	const lengthVal = useLength({ xs: 3, s: 3, m: 4, l: 4, xl: 4 });
	// Live refresh
	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);
	const { latticesBatchData, recentDispatchesLoader } = useContext(DashboardContext);

	useEffect(() => {
		if (latticesBatchData?.metadata?.status_count) {
			setRecentDispatches(latticesBatchData?.records);
			const latticeData = Object.entries(latticesBatchData?.metadata?.status_count)?.map(
				([status, count]) => ({
					status: getStatus(status),
					count
				})
			);
			latticeData?.forEach(obj => {
				obj.img =
					obj.status === 'Pending' ? recentDispatch : statusIcons(obj?.status?.toUpperCase());
			});

			setStatuses(latticeData);
		}
	}, [latticesBatchData]);

	const singleStatus = (img, dispatchStatus, count) => {
		return (
			<Box>
				<Box sx={{ display: 'flex' }}>
					<Icon src={img} width="10px" height="10px" />
					<Typography
						sx={{
							color: theme => theme.palette.text.gray03,
							fontSize: '12px',
							marginLeft: '4px',
							display: 'grid',
							placeItems: 'center',
							textAlign: 'center'
						}}
					>
						{dispatchStatus}
					</Typography>
				</Box>
				<Typography
					sx={{ color: theme => theme.palette.text.primary, fontSize: '14px', pl: '3px' }}
				>
					{count}
				</Typography>
			</Box>
		);
	};

	return (
		<Box
			sx={{
				width: '100%',
				border: theme => `1px solid ${theme.palette.background.blue03}`,
				borderRadius: '8px'
			}}
		>
			<CustomScrollbars>
				<Box
					sx={{
						padding: '16px 16px 8px 16px',
						height: '467px',
						width: '100%',
						display: 'flex',
						justifyContent: 'flex-start',
						flexDirection: 'column'
						// overflow: 'auto'
					}}
				>
					<Box sx={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
						<Typography sx={{ color: theme => theme.palette.text.secondary, fontSize: '16px' }}>
							Recent Dispatches
						</Typography>
						<SeeAll goto={routes?.DISPATCHES} haveSeeall />
					</Box>
					<Grid container sx={{ margin: '14px 0' }}>
						{statuses?.map((item, index) => {
							return (
								<Grid item xs={4} md={3} key={item.img} sx={{ display: 'flex', padding: '2px 0' }}>
									<Grid container>
										<Grid item xs={11.5}>
											{singleStatus(item?.img, item?.status, item?.count)}
										</Grid>
										<Grid item xs={0.5}>
											{index === statuses.length - 1 || (index + 1) % lengthVal === 0 ? null : (
												<Divider
													sx={{
														width: '1px',
														height: '42px',
														backgroundColor: theme => theme.palette.background.blue03
													}}
												/>
											)}
										</Grid>
									</Grid>
								</Grid>
							);
						})}
					</Grid>
					{recentDispatchesLoader && (
						<Loader
							isFetching={recentDispatchesLoader}
							position="relative"
							width="100%"
							height="calc(100% - 80px)"
						/>
					)}
					{/* {!recentDispatchesLoader &&
				(recentDispatches.length !== 0 ? (
					recentDispatches?.map(item => {
						return (
							<RecentDispatchCard
								key={item?.dispatch_id}
								name={item?.name}
								status={item?.status}
								time={{ startTime: item?.started_at, endTime: item?.completed_at }}
								dispatchid={item?.dispatch_id}
								inputUrl={item?.inputs?.url}
							/>
						);
					})
				) : (
					<Box
						sx={{ display: 'flex', justifyContent: 'center', height: '100%', alignItems: 'center' }}
					>
						No records found
					</Box>
				))} */}
					{!recentDispatchesLoader &&
						recentDispatches.length !== 0 &&
						recentDispatches?.map(item => {
							return (
								<RecentDispatchCard
									key={item?.dispatch_id}
									name={item?.name}
									status={item?.status}
									time={{ startTime: item?.started_at, endTime: item?.completed_at }}
									dispatchid={item?.dispatch_id}
									inputUrl={item?.inputs?.url}
								/>
							);
						})}

					{!recentDispatchesLoader && !recentDispatches && (
						<Box
							sx={{
								display: 'flex',
								justifyContent: 'center',
								height: '100%',
								alignItems: 'center'
							}}
						>
							No Dispatches found
						</Box>
					)}
				</Box>
			</CustomScrollbars>
		</Box>
	);
}

export default RecentDispatches;
