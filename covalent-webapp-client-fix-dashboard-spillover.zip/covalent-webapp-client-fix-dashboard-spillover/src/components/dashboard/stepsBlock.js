/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 *
 *
 */ import React from 'react';
import { Grid, Typography } from '@mui/material';
import CopyButton from '../copyButton';
import Sync from '../syntaxHiglighter';

function StepsBlock({ code, step, description, copyVal }) {
	return (
		<Grid
			container
			item
			direction="column"
			xs={10}
			mt={2}
			px={3}
			py={1}
			sx={{
				border: '1px solid',
				borderRadius: '6px',
				borderColor: theme => theme.palette.background.blue05
			}}
		>
			<Typography variant="status" sx={{ fontWeight: 'bold' }}>
				{step}
			</Typography>
			<Typography variant="h2" my={2}>
				{description}
			</Typography>
			<Grid
				mb={1}
				container
				sx={{
					background: theme => theme.palette.background.covalentPurple,
					borderRadius: '8px'
				}}
			>
				<Grid item xs={11} py={2} pl={2}>
					<Sync code={code} />
				</Grid>
				<Grid item xs={1} pt={2}>
					<Grid
						m="auto"
						pl={0.5}
						pt={0.4}
						sx={{
							width: '2rem',
							border: '1px solid',
							borderColor: theme => theme.palette.background.blue05,
							borderRadius: '8px'
						}}
					>
						<CopyButton content={copyVal || code} />
					</Grid>
				</Grid>
			</Grid>
		</Grid>
	);
}

export default StepsBlock;
