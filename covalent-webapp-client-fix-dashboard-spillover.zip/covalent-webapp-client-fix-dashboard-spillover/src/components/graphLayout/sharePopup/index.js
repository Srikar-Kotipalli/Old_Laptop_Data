/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
/* eslint-disable import/no-unused-modules */
/* eslint-disable react/no-array-index-key */
/* eslint-disable no-unused-vars */

import React, { useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import TextField from '@mui/material/TextField';
import DialogContent from '@mui/material/DialogContent';
import { Tooltip } from '@mui/material';
import userAvatarIcon from '../../../assets/icons/userAvatar.svg';
import closeIcon from '../../../assets/actions/close.svg';
import linkIcon from '../../../assets/icons/link.svg';
import Icon from '../../icon';
import './style.css';
import Loader from '../../loader';
import GraphDialogBox from '../../dialogBox/graph';
import ShareIcon from '../../../assets/shareIcon.svg';
import CustomisedSnackbar from '../../snackbar/projects';
import { shareDispatch, unShareDispatch } from '../../../api/shared/sharedApi';
import { capitalizeName } from '../../../utils/utils';

function StyledDivider() {
	return <Divider sx={{ bgcolor: '#1C1C46' }} />;
}

function SharePopup(props) {
	const [openDialogBox, setOpenDialogBox] = useState(false);
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [copied, setCopied] = useState(false);
	const [shareToUser, setShareToUser] = useState([]);
	const [unshareToUser, setUnshareToUser] = useState([]);
	const [inviteEmail, setInviteEmail] = useState('');
	const [unInviteEmail, setUnInviteEmail] = useState('');
	const [unInviteMember, setUnInviteMember] = useState('');
	const [errorInviteEmail, setErrorInviteEmail] = React.useState(false);
	const [disable, setDisable] = useState(true);
	const [type, setType] = useState('');
	const [snackbarMessage, setSnackbarMessage] = useState('');
	const {
		sharePopupEnable,
		sharePopupClose,
		openShareLoader,
		userList,
		dispatchID,
		userEmail,
		setOpenShareLoader,
		setTriggerShare
	} = props;

	useEffect(() => {
		let val = !inviteEmail;
		setErrorInviteEmail(inviteEmail ? '' : inviteEmail);
		if (inviteEmail !== '' && !inviteEmail.match(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]+$/i)) {
			setErrorInviteEmail('Invalid Email format!');

			val = true;
		}
		const isEmailInArray = userList.some(item => item.sharedWithEmail === inviteEmail);
		if (isEmailInArray) {
			setErrorInviteEmail('Shared already to this user !');
		}

		setDisable(val);
	}, [inviteEmail]);

	function handleCopyClick() {
		const url = window.location.href;
		navigator.clipboard
			.writeText(url)
			.then(() => {
				setCopied(true);
				setTimeout(() => setCopied(false), 2000); // Reset to false after 2 seconds
			})
			.catch(() => setCopied(false));
	}

	const shareDispatchToEmail = () => {
		setOpenShareLoader(true);
		setOpenDialogBox(false);
		shareToUser.push(inviteEmail);
		const bodyParameters = {
			dispatch_id: dispatchID,
			users: shareToUser
		};
		shareDispatch(bodyParameters)
			.then(res => {
				setTriggerShare(prev => !prev);
				setSnackbarMessage(res.trace[0]);
				setOpenSnackbar(true);
			})
			.catch(error => {
				setSnackbarMessage(`Inviting ${inviteEmail} failed`);
				setOpenSnackbar(true);
				setOpenShareLoader(false);
				console.log(error);
			})
			.finally(() => {
				setShareToUser([]);
				setInviteEmail('');
			});
	};

	const validateInput = () => {
		if (!disable) shareDispatchToEmail();
	};

	const unshareOpen = (member, mail) => {
		setOpenDialogBox(true);
		setUnInviteEmail(member);
		setUnInviteMember(mail);
		setType('unShare');
	};

	const openSharePopupConfirmation = () => {
		if (inviteEmail === userEmail) {
			setInviteEmail('');
			setSnackbarMessage('You already have access to this dispatch!');
			setOpenSnackbar(true);
			setOpenDialogBox(false);
		} else {
			setType('share');
			setOpenDialogBox(true);
		}
	};

	const unShare = () => {
		setOpenShareLoader(true);
		setOpenDialogBox(false);
		unshareToUser.push(unInviteEmail);
		const bodyParameters = {
			dispatch_id: dispatchID,
			users: unshareToUser
		};
		unShareDispatch(bodyParameters)
			.then(res => {
				setSnackbarMessage(res.message);
				setOpenSnackbar(true);
				setTriggerShare(prev => !prev);
			})
			.catch(error => {
				console.log(error);
				setOpenShareLoader(false);
				setOpenSnackbar(true);
				setSnackbarMessage('contact administrator');
			})
			.finally(() => {
				setUnshareToUser([]);
			});
	};

	return (
		<Dialog open={sharePopupEnable} onClose={sharePopupClose}>
			<CustomisedSnackbar
				open={openSnackbar}
				message={snackbarMessage}
				onClose={() => setOpenSnackbar(false)}
				clickHandler={() => setOpenSnackbar(false)}
			/>
			<GraphDialogBox
				openDialogBox={openDialogBox}
				title={type === 'unShare' ? 'Uninvite' : 'Invite'}
				message={
					type === 'unShare'
						? `Are you sure you want to unshare this dispatch with ${unInviteMember}`
						: `Are you sure about inviting ${inviteEmail}?`
				}
				setOpenDialogBox={setOpenDialogBox}
				icon={ShareIcon}
				handler={type !== 'unShare' ? validateInput : unShare}
			/>
			<div style={{ background: '#1C1C46' }}>
				<Box width={520} padding={4}>
					<Typography
						sx={{ fontSize: '14px', fontWeight: 700 }}
					>{`Share ${dispatchID}`}</Typography>
					<Grid container alignItems="center" spacing={2} mt="3px">
						<Grid item container direction="row" xs={12}>
							<TextField
								// inputProps={{ style: { textAlign: 'start' ,paddingLeft:'1rem !important'} }}
								sx={{
									mt: 0.9,
									pr: 2,
									width: '300px',
									height: '32px',
									border: '1px solid #303067',
									backgroundColor: '#08081A',
									borderRadius: '60px',
									fontSize: '14px',
									color: !errorInviteEmail ? theme => theme.palette.text.secondary : 'error',
									'& .MuiOutlinedInput-notchedOutline': {
										border: 'none',
										width: '300px',
										height: '40px'
									},
									'& input::placeholder': {
										fontSize: '14px',
										paddingLeft: '4px'
									},
									'& .MuiFormHelperText-root': {
										marginTop: '5px',
										marginLeft: '0px'
									},
									'& .MuiOutlinedInput-root': {
										paddingRight: '10px',
										paddingLeft: '10px',
										paddingTop: '5px'
									}
								}}
								helperText={errorInviteEmail}
								error={!!errorInviteEmail}
								disabled={false}
								autoComplete="off"
								name="temp"
								onChange={e => setInviteEmail(e.target.value)}
								value={inviteEmail}
								placeholder="Email"
								onKeyPress={event => {
									if (event.key === 'Enter') {
										validateInput();
									}
								}}
								type="text"
							/>
							<Button
								variant="contained"
								disableElevation
								disabled={disable || errorInviteEmail}
								onClick={() => openSharePopupConfirmation()}
								sx={{
									'&:disabled': {
										background: theme => theme.palette.background.covalentPurple,
										color: theme => theme.palette.text.secondary,
										border: '1px solid',
										borderColor: theme => theme.palette.background.blue04,
										borderRadius: '70px'
									},
									backgroundColor: '#5552FF !important',
									borderRadius: '70px',
									marginLeft: '7px',
									height: '26px',
									margin: '8px 0 0 50px'
								}}
							>
								Invite
							</Button>
						</Grid>
					</Grid>
					<Box sx={{ background: '#303067', height: '1px', margin: '24px 0 0 0' }} />

					<Typography
						sx={{ color: '#FFF', fontWeight: '700', fontSize: '14px', margin: '28px 0 0 0' }}
					>
						Users with Access
					</Typography>

					{openShareLoader && (
						<Grid py={10}>
							<Loader isFetching={openShareLoader} width="100%" height="100%" />
						</Grid>
					)}
					{!openShareLoader && (
						<DialogContent sx={{ p: 0, mt: 1 }}>
							{userList?.length === 0 && (
								<Grid container direction="row" justifyContent="flexStart" mt={3}>
									No users found
								</Grid>
							)}
							{userList?.map((value, i) => {
								return value?.sharedWithEmail !== unInviteEmail ? (
									<Box key={i}>
										<Grid container className="popupBody" spacing={1}>
											<Grid item xs={1}>
												<Icon src={userAvatarIcon} alt="userAvatarIcon" type="static" />
											</Grid>
											<Grid item xs={10}>
												<Typography sx={{ color: '#CBCBD7', fontSize: '14px' }}>
													{capitalizeName(value?.memberName)}
												</Typography>
												<Typography sx={{ color: '#86869A', fontSize: '12px' }}>
													{value?.sharedWithEmail}
												</Typography>
											</Grid>
											<Grid item xs={1} sx={{ mt: 1, cursor: 'pointer' }}>
												<Icon
													src={closeIcon}
													alt="closeIcon"
													clickHandler={() =>
														unshareOpen(value?.sharedWith, value?.sharedWithEmail)
													}
												/>
											</Grid>
										</Grid>
									</Box>
								) : null;
							})}
						</DialogContent>
					)}

					<Box sx={{ display: 'flex', justifyContent: 'space-between', margin: '40px 0 0 0' }}>
						<Box
							className="imgWithIcon"
							sx={{
								cursor: 'pointer',
								border: '1px solid #6473FF',
								borderRadius: '70px',
								padding: '5px 16px 16px 16px',
								height: '32px'
							}}
							onClick={() => handleCopyClick()}
						>
							<Tooltip title={copied ? 'Copied!' : 'Copy link'}>
								<Typography sx={{ color: '#FFF', fontSize: '14px' }}>
									<img src={linkIcon} alt="linkIcon" />
									Copy link
								</Typography>
							</Tooltip>
						</Box>

						<Box
							sx={{
								cursor: 'pointer',
								border: '1px solid #6473FF',
								borderRadius: '70px',
								padding: '5px 14px 16px 15px',
								width: '110px',
								display: 'grid',
								placeItems: 'center',
								height: '32px'
							}}
							onClick={() => sharePopupClose()}
						>
							<Typography sx={{ color: '#FFF', fontSize: '14px', width: '50%' }}>Done</Typography>
						</Box>
					</Box>
				</Box>
			</div>
		</Dialog>
	);
}

export default SharePopup;
