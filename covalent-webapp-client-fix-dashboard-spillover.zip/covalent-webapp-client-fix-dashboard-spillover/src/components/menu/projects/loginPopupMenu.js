import * as React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import { Grid, Stack } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import { Auth } from 'aws-amplify';
import Backdrop from '@mui/material/Backdrop';
import Icon from '../../icon';
import PrimaryButton from '../../primaryButton';
import LoginInput from '../../inputBase/projects/loginInput';
import { ProjectContext } from '../../../containers/projects/projectContext';
import checkbox from '../../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../../assets/checkboxes/checkboxChecked.svg';
import { hubSpotLink } from '../../../api/signup/signUpApi';
import HubspotPayload from '../../../utils/payloadBuilder';
import covLoader from '../../../assets/loaders/covLoader.svg';

/* eslint-disable import/no-unused-modules */
export default function LoginPopupMenu() {
	const projectContext = React.useContext(ProjectContext);
	const { setOpenProjectSnackbar, setSnackbarMessage } = projectContext;
	const [firstName, setFirstName] = React.useState('');
	const [email] = React.useState('');
	const [openLoader, setOpenLoader] = React.useState(false);
	const [lastName, setLastName] = React.useState('');
	const [openDialogBox, setOpenDialogBox] = React.useState(false);
	// eslint-disable-next-line no-unused-vars
	const [organisation, setOrganisation] = React.useState(true);
	const [organisationName, setOrganisationName] = React.useState('');
	const [disable, setDisable] = React.useState(true);
	const [errorOrganisation, setErrorOrganisation] = React.useState('');
	const [errorFirstname, setErrorFirstname] = React.useState('');
	const [errorLastname, setErrorLastname] = React.useState('');
	const [announcements, setAnnouncements] = React.useState(true);
	const [userDetails, setUserDetails] = React.useState('');

	function preparePayloadForUpdate() {
		const payload = {};
		if (!userDetails?.given_name) {
			payload['given_name'] = firstName;
		}
		if (!userDetails?.email) {
			payload['email'] = firstName;
		}
		if (!userDetails?.family_name) {
			payload['family_name'] = lastName;
		}
		if (
			// userDetails['custom:isOrganisation'] === 'True' &&
			!userDetails['custom:organisationName']
		) {
			payload['custom:organisationName'] = organisationName;
		}
		// if (!userDetails['custom:isOrganisation']) {
		// 	payload['custom:isOrganisation'] = organisation ? 'True' : 'False';
		// 	if (organisation) {
		// 		payload['custom:organisationName'] = organisationName;
		// 	}
		// }
		if (!userDetails['custom:isPromotions']) {
			payload['custom:isPromotions'] = announcements ? 'True' : 'False';
		}
		return payload;
	}
	function getUserAttributes() {
		const payload = HubspotPayload(
			firstName || userDetails?.given_name,
			lastName || userDetails?.family_name,
			email || userDetails?.email,
			organisation ? 'Organization' : 'Individual',
			announcements,
			organisationName,
			firstName || userDetails?.given_name
		);
		hubSpotLink(payload);
	}
	function update() {
		setOpenLoader(true);
		Auth.currentAuthenticatedUser().then(user => {
			Auth.updateUserAttributes(user, preparePayloadForUpdate())
				.then(() => {
					setOpenProjectSnackbar(true);
					setSnackbarMessage('User info updated successfully!');
					setOpenDialogBox(false);
					Auth.currentAuthenticatedUser().then(() => {
						getUserAttributes();
					});
				})
				.catch(error => {
					setOpenProjectSnackbar(true);
					setSnackbarMessage(error?.message);
				})
				.finally(() => setOpenLoader(false));
		});
	}

	React.useEffect(() => {
		const val = !(
			(userDetails?.given_name || firstName?.trim()) &&
			(userDetails?.family_name || lastName?.trim()) &&
			(userDetails['custom:organisationName'] || organisationName?.trim())
		);
		// if (
		// 	(!userDetails['custom:isOrganisation'] && organisation && organisationName?.trim() === '') ||
		// 	(userDetails['custom:isOrganisation'] === 'True' &&
		// 		!userDetails['custom:organisationName'] &&
		// 		organisationName?.trim() === '')
		// )
		// 	val = true;
		setErrorFirstname(firstName?.trim() ? '' : errorFirstname);
		setErrorLastname(lastName?.trim() ? '' : errorLastname);
		setErrorOrganisation(organisationName?.trim() || !organisation ? '' : errorOrganisation);
		setDisable(val);
	}, [firstName, lastName, organisation, organisationName, announcements, userDetails]);

	const validateInput = () => {
		if (!userDetails?.given_name && !firstName?.trim()) {
			setDisable(true);
			setErrorFirstname('Firstname is mandatory!');
		}
		if (!userDetails?.family_name && !lastName?.trim()) {
			setDisable(true);
			setErrorLastname('Lastname is mandatory!');
		}
		if (
			// (!userDetails['custom:isOrganisation'] && organisation && organisationName?.trim() === '') ||
			// (userDetails['custom:isOrganisation'] === 'True' &&
			// 	!userDetails['custom:organisationName'] &&
			// 	organisationName?.trim() === '')
			!userDetails['custom:organisationName'] &&
			!organisationName?.trim()
		) {
			setDisable(true);
			setErrorOrganisation('Organization/Affiliation name is mandatory!');
		}
		if (!disable) update();
	};

	React.useEffect(() => {
		(async () => {
			const user = await Auth.currentAuthenticatedUser();
			const res = user?.attributes;
			if (
				res?.given_name &&
				res?.family_name &&
				res['custom:organisationName'] &&
				res['custom:isPromotions']
			) {
				setOpenDialogBox(false);
			}
			// } else {
			// 	setOpenDialogBox(true);
			// }
			setUserDetails({ ...res });
		})();

		return () => {};
	}, []);

	return (
		<Modal
			open={openDialogBox}
			aria-labelledby="modal-modal-title"
			aria-describedby="modal-modal-description"
			data-testid="dialogBox"
		>
			<div>
				<Box
					sx={{
						position: 'absolute',
						top: '50%',
						left: '50%',
						transform: 'translate(-50%, -50%)',
						minWidth: 500,
						bgcolor: 'background.paper',
						border: '1px solid #6473FF',
						borderRadius: '24px',
						boxShadow: 24,
						p: 2
					}}
				>
					<Backdrop
						open={openLoader}
						sx={{
							zIndex: 1,
							border: 'inherit',
							borderRadius: 'inherit',
							backgroundColor: 'rgba(0, 0, 0, 0.7)'
						}}
					>
						<Icon type="pointer" src={covLoader} />
					</Backdrop>
					<Grid sx={{ display: 'flex', justifyContent: 'space-between' }}>
						<Stack spacing={2.8} sx={{ width: '100%' }}>
							{!userDetails?.given_name && (
								<LoginInput
									name="firstNameInput"
									autoComplete="landingFirstName"
									id="firstNameInput"
									fieldName="First name"
									value={firstName}
									handleChange={setFirstName}
									placeholderTxt="Enter first name"
									type="field"
									error={errorFirstname}
									handleEnter={validateInput}
								/>
							)}
							{!userDetails?.family_name && (
								<LoginInput
									name="lastNameInput"
									autoComplete="landingLastName"
									id="lastNameInput"
									fieldName="Last name"
									value={lastName}
									handleChange={setLastName}
									placeholderTxt="Enter last name"
									type="field"
									error={errorLastname}
									handleEnter={validateInput}
								/>
							)}
							{/* {!userDetails['custom:isOrganisation'] && (
								<LoginInput
									fieldName="Are you..."
									name="landingOrg"
									id="landingOrgs"
									autoComplete="organization"
									value={organisation}
									handleChange={e => {
										setOrganisationName('');
										setOrganisation(e);
									}}
									type="select"
									width="57%"
								/>
							)} */}
							{/* {((!userDetails['custom:isOrganisation'] && organisation) ||
								(userDetails['custom:isOrganisation'] === 'True' &&
									!userDetails['custom:organisationName'] &&
									organisation)) && ( */}
							{!userDetails['custom:organisationName'] && (
								<LoginInput
									name="organizationNamePopUpInput"
									id="organizationNamePopUpInput"
									autoComplete="organizationName"
									fieldName="Organization name"
									value={organisationName}
									handleChange={setOrganisationName}
									placeholderValue="Enter Organization/Affiliation Name"
									type="field"
									error={errorOrganisation}
									width="263px"
									handleEnter={validateInput}
								/>
							)}
							{/* )} */}
							{!userDetails['custom:isPromotions'] && (
								<Box display="flex" flexDirection="row">
									<Checkbox
										data-testid="dispatchCheckbox"
										disableRipple
										size="small"
										value={announcements}
										checked={announcements}
										onChange={() => setAnnouncements(!announcements)}
										icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
										checkedIcon={
											<Icon src={checkboxChecked} alt="checkboxChecked" type="pointer" />
										}
									/>
									<Typography
										sx={{
											color: 'textPrimary',
											fontSize: '12px',
											paddingTop: '4px',
											display: 'flex',
											alignItems: 'center'
										}}
									>
										Would you like to receive product updates and announcements via email?
									</Typography>
								</Box>
							)}
							<Grid
								container
								display="flex"
								justifyContent="flex-end"
								spacing={1}
								mt={2}
								sx={{ maxWidth: '100%' }}
							>
								<Grid item>
									<PrimaryButton
										handler={validateInput}
										title="Submit"
										bgColor="#5552FF"
										hoverColor="#403cff"
										className="submit"
									/>
								</Grid>
							</Grid>
						</Stack>
					</Grid>
				</Box>
			</div>
		</Modal>
	);
}
