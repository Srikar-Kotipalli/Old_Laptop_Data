/* eslint-disable import/extensions */
/* eslint-disable react/jsx-no-constructed-context-values */
/* eslint-disable testing-library/no-node-access */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
import MoveItemsMenu from '../moveItemsMenu';
import * as Api from '../../../../api/experiments/dispatchApi';
import { ProjectContext } from '../../../containers/projects/projectContext';

jest.mock('axios');

jest.mock('../../../../api/experiments/dispatchApi');

beforeEach(() => jest.clearAllMocks());
afterEach(() => jest.clearAllMocks());

describe('move items menu', () => {
	const mockAnchorEl = document.createElement('button');
	const open = Boolean(mockAnchorEl);
	const loader = false;
	const experiment = {
		completedElectrons: 29,
		count: 4,
		id: '854c5de8-b13e-4fab-854d-3596704ds5d20',
		lastUpdated: '2022-01-11 13:04:00',
		title: 'Yellow Viper',
		runTime: 1590600,
		startTime: '2022-01-12 20:22:00',
		status: 'FAILED',
		tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
		totalElectrons: 41,
		type: 'Experiment',
		isOpen: false
	};
	const dispatch = {
		completedElectrons: 29,
		count: 4,
		id: '854c5de8-b13e-4fab-854d-3596704ds5d20',
		lastUpdated: '2022-01-11 13:04:00',
		title: 'Yellow Gaand',
		runTime: 1590600,
		startTime: '2022-01-12 20:22:00',
		status: 'FAILED',
		tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
		totalElectrons: 41,
		type: 'Dispatch',
		isOpen: false
	};

	const mockValue = {
		count: 2,
		items: [
			{
				completedElectrons: 29,
				count: 4,
				id: '854c5de8-b13e-4fab-854d-3596704ds5d20',
				lastUpdated: '2022-01-11 13:04:00',
				title: 'Yellow Viper',
				runTime: 1590600,
				startTime: '2022-01-12 20:22:00',
				status: 'FAILED',
				tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
				totalElectrons: 41,
				type: 'Experiment',
				isOpen: false,
				isAdd: true
			},
			{
				completedElectrons: 29,
				count: 4,
				id: '854c5de8-b13e-4fab-854d-35236704ds5d20',
				lastUpdated: '2022-01-11 13:04:00',
				title: 'Project Det Viper',
				runTime: 1590600,
				startTime: '2022-01-12 20:22:00',
				status: 'FAILED',
				tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
				totalElectrons: 41,
				type: 'Project',
				isOpen: false
			}
		]
	};

	test('returns the items list', async () => {
		Api.allItemsList.mockResolvedValue(mockValue);
		render(
			<MoveItemsMenu
				open={open}
				experiment={experiment}
				dispatch={dispatch}
				type="dispatch"
				value="experiment"
				openLoader={loader}
			/>
		);
		expect(Api.allItemsList).toBeCalledTimes(1);
	});

	test('renders move items menu', () => {
		Api.allItemsList.mockResolvedValue(mockValue);
		render(
			<MoveItemsMenu
				open={open}
				experiment={experiment}
				dispatch={dispatch}
				type="dispatch"
				value="experiment"
				openLoader={loader}
			/>
		);
		const element = screen.getByTestId('moveItemsMenu');
		expect(element).toBeInTheDocument();
	});

	test('renders Projects tab', async () => {
		Api.allItemsList.mockResolvedValue(mockValue);
		render(
			<MoveItemsMenu
				open={open}
				experiment={experiment}
				dispatch={dispatch}
				type="experiment"
				openLoader={loader}
			/>
		);
		const element = await screen.findByTestId('projectsTab');
		expect(element).toBeInTheDocument();
	});

	test('no records found', async () => {
		Api.allItemsList.mockResolvedValue({
			count: 2,
			items: []
		});
		render(
			<MoveItemsMenu open={open} experiment={experiment} dispatch={dispatch} type="dispatch" />
		);
		const element = await screen.findByText('No records found');
		expect(element).toBeInTheDocument();
	});

	test('renders Experiments and Project tab', async () => {
		Api.allItemsList.mockResolvedValue(mockValue);
		render(
			<MoveItemsMenu
				open={open}
				experiment={experiment}
				dispatch={dispatch}
				type="dispatch"
				openLoader={loader}
			/>
		);
		const element = await screen.findByTestId('experimentsTab');
		expect(element).toBeInTheDocument();
		const element2 = await screen.findByTestId('projectsTab');
		expect(element2).toBeInTheDocument();
	});

	test('renders move button and call function when clicked', async () => {
		const handleClick = jest.fn();
		const moveClick = jest.fn();
		Api.allItemsList.mockResolvedValue(mockValue);
		render(
			<ProjectContext.Provider value={{ itemsToMove: handleClick, multipleSelectedItems: [] }}>
				<MoveItemsMenu
					open={open}
					experiment={experiment}
					dispatch={dispatch}
					setMoveMenu={moveClick}
					type="dispatch"
				/>
			</ProjectContext.Provider>
		);
		const addExpButton = await screen.findByTestId('moveButton');
		expect(addExpButton).toBeInTheDocument();
		fireEvent.click(addExpButton);
		const dialog = screen.getByTestId('dialogBox');
		expect(dialog).toBeInTheDocument();
	});

	test('renders no records found text', async () => {
		Api.allItemsList.mockResolvedValue({
			count: 2,
			items: []
		});
		render(
			<MoveItemsMenu
				open={open}
				experiment={experiment}
				dispatch={dispatch}
				type="experiment"
				openLoader={loader}
			/>
		);
		const element = await screen.findByText('No records found');
		expect(element).toBeInTheDocument();
	});

	test('renders add button and call function when clicked', async () => {
		Api.allItemsList.mockResolvedValue(mockValue);
		render(
			<MoveItemsMenu
				open={open}
				experiment={experiment}
				dispatch={dispatch}
				type="dispatch"
				openLoader={loader}
			/>
		);
		const addExpButton = await screen.findByTestId('addButton');
		expect(addExpButton).toBeInTheDocument();
	});
	test('renders input base when adding an experiment', async () => {
		const handleClick = jest.fn();
		Api.addEditExperiment.mockResolvedValue({
			id: '854c5de8-b13e-4fab-854d-35236704ds225d20',
			title: 'yellow'
		});
		Api.allItemsList.mockResolvedValue(mockValue);
		render(
			<ProjectContext.Provider value={{ addListItem: handleClick, multipleSelectedItems: [] }}>
				<MoveItemsMenu
					open={open}
					experiment={experiment}
					dispatch={dispatch}
					openLoader={loader}
					type="dispatch"
					clickHandler={handleClick}
				/>
			</ProjectContext.Provider>
		);
		const addExpButton = await screen.findByTestId('inputBase');
		expect(addExpButton).toBeInTheDocument();
		const tickIcon = await screen.findByAltText('tickIcon');
		expect(tickIcon).toBeInTheDocument();
		fireEvent.click(tickIcon);
		const snackbar = await screen.findByTestId('moveSnackbar');
		expect(snackbar).toBeInTheDocument();
		const snackbarCloseButton = screen.getByTestId('closeSnackbar');
		expect(snackbarCloseButton).toBeInTheDocument();
	});

	test('renders input base and cancel adding an experiment', async () => {
		const handleClick = jest.fn();
		Api.allItemsList.mockResolvedValue(mockValue);
		render(
			<ProjectContext.Provider
				value={{ addItems: handleClick, addListItem: handleClick, multipleSelectedItems: [] }}
			>
				<MoveItemsMenu
					open={open}
					experiment={experiment}
					dispatch={dispatch}
					openLoader={loader}
					type="dispatch"
				/>
			</ProjectContext.Provider>
		);
		const addExpButton = await screen.findByTestId('inputBase');
		expect(addExpButton).toBeInTheDocument();
		const closeIcon = await screen.findByAltText('closeIcon');
		expect(closeIcon).toBeInTheDocument();
		fireEvent.click(closeIcon);
	});

	test('handle tab change', async () => {
		Api.allItemsList.mockResolvedValue({
			count: 2,
			items: []
		});
		render(
			<MoveItemsMenu
				open={open}
				experiment={experiment}
				dispatch={dispatch}
				type="experiment"
				openLoader={loader}
			/>
		);
		const tab = screen.getByRole('tab', { name: 'Projects' });
		fireEvent.click(tab);
		expect(screen.getByRole('tab', { selected: true })).toHaveTextContent('Projects');
	});

	test('renders search input', async () => {
		const handleClick = jest.fn();
		Api.allItemsList.mockResolvedValue(mockValue);
		render(
			<ProjectContext.Provider
				value={{ addItems: handleClick, addListItem: handleClick, multipleSelectedItems: [] }}
			>
				<MoveItemsMenu
					open={open}
					experiment={experiment}
					dispatch={dispatch}
					openLoader={loader}
					type="dispatch"
					value="User"
				/>
			</ProjectContext.Provider>
		);
		const searchInputBase = await screen.findByTestId('searchInputBase');
		expect(searchInputBase).toBeInTheDocument();
	});
});
