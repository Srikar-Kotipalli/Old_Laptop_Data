/* eslint-disable react/jsx-no-constructed-context-values */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { render, fireEvent, cleanup, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
import ContextMenu from '../contextMenu';
import { ProjectContext } from '../../../../containers/projects/projectContext';

describe('add context menu', () => {
	afterEach(() => {
		cleanup();
	});

	test('the context menu available', () => {
		render(<ContextMenu type="dispatch" />);
		const element = screen.getByRole('button');
		expect(element).toBeTruthy();
	});
	test('the context menu has pin icon', () => {
		render(<ContextMenu type="dispatch" view="grid" />);
		const button = screen.getByRole('button');
		fireEvent.click(button);
		const icon = screen.queryByText('Pin');
		const text = screen.queryByAltText('pinIcon');
		expect(icon).toBeInTheDocument();
		expect(text).toBeInTheDocument();
	});

	const dispatchCases = [
		['Restart', 'searchIcon', 'restartAction'],
		['Pin', 'pinIcon', 'pinAction'],
		['Edit', 'editIcon', 'editAction'],
		['Move to', 'moveIcon', 'moveAction'],
		['Archive', 'archiveIcon', 'archiveAction'],
		['Delete', 'deleteIcon', 'deleteAction']
	];
	const projectCases = [
		['Edit', 'editIcon'],
		['Archive', 'archiveIcon'],
		['Delete', 'deleteIcon']
	];
	const experimentCases = [
		['Edit', 'editIcon'],
		['Move to', 'moveIcon'],
		['Archive', 'archiveIcon'],
		['Delete', 'deleteIcon']
	];

	const disabledDispatchActions = ['restartAction'];

	test('calls function when edit action is clicked', () => {
		const handleClick = jest.fn();
		render(
			<ProjectContext.Provider value={{ editListItem: handleClick }}>
				<ContextMenu />
			</ProjectContext.Provider>
		);
		const button = screen.getByRole('button');
		fireEvent.click(button);
		expect(button).toBeInTheDocument();
		const element = screen.getByTestId('editAction');
		fireEvent.click(element);
		expect(handleClick).toBeCalledTimes(1);
	});

	test('calls function when pin action is clicked', () => {
		const handleClick = jest.fn();
		render(
			<ProjectContext.Provider value={{ onPin: handleClick }}>
				<ContextMenu type="dispatch" view="grid" />
			</ProjectContext.Provider>
		);
		const button = screen.getByRole('button');
		fireEvent.click(button);
		expect(button).toBeInTheDocument();
		const element = screen.getByTestId('pinAction');
		fireEvent.click(element);
		expect(handleClick).toBeCalledTimes(1);
	});

	test('edit action disabled when type is dispatch', () => {
		render(<ContextMenu type="dispatch" view="grid" />);
		const button = screen.getByRole('button');
		fireEvent.click(button);
		expect(button).toBeInTheDocument();
		const element = screen.getByTestId('editAction');
		expect(element).toHaveAttribute('aria-disabled');
	});

	test.each(disabledDispatchActions)(
		'the context menu has %p disabled type is dispatch',
		firstArg => {
			render(<ContextMenu type="dispatch" view="grid" />);
			const button = screen.getByRole('button');
			fireEvent.click(button);
			expect(button).toBeInTheDocument();
			const element = screen.getByTestId(firstArg);
			expect(element).toHaveAttribute('aria-disabled');
		}
	);

	test.each(dispatchCases)(
		'the context menu has %p menu when type is dispatch',
		(firstArg, secondArg) => {
			const clickHandler = jest.fn();
			render(
				<ContextMenu
					type="dispatch"
					view="grid"
					handleClose={clickHandler}
					editListItem={clickHandler}
					onPin={clickHandler}
				/>
			);
			const button = screen.getByRole('button');
			fireEvent.click(button);
			const icon = screen.queryByText(firstArg);
			const text = screen.queryByAltText(secondArg);
			expect(icon).toBeInTheDocument();
			expect(text).toBeInTheDocument();
		}
	);
	test.each(projectCases)(
		'the context menu has %p menu when type is projects',
		(firstArg, secondArg) => {
			render(<ContextMenu type="project" />);
			const button = screen.getByRole('button');
			fireEvent.click(button);
			const icon = screen.queryByText(firstArg);
			const text = screen.queryByAltText(secondArg);
			expect(icon).toBeInTheDocument();
			expect(text).toBeInTheDocument();
		}
	);
	test.each(experimentCases)(
		'the context menu has %p menu when type is experiment',
		(firstArg, secondArg) => {
			render(<ContextMenu type="experiment" />);
			const button = screen.getByRole('button');
			fireEvent.click(button);
			const icon = screen.queryByText(firstArg);
			const text = screen.queryByAltText(secondArg);
			expect(icon).toBeInTheDocument();
			expect(text).toBeInTheDocument();
		}
	);

	test('calls function when move action is clicked', () => {
		const handleClick = jest.fn();
		render(
			<ProjectContext.Provider value={{ onPin: handleClick, multipleSelectedItems: [] }}>
				<ContextMenu
					type="dispatch"
					view="grid"
					experiment={{
						completedElectrons: 29,
						count: 4,
						id: '854c5de8-b13e-4fab-854d-3596704ds5d20',
						lastUpdated: '2022-01-11 13:04:00',
						title: 'Yellow Viper',
						runTime: 1590600,
						startTime: '2022-01-12 20:22:00',
						status: 'FAILED',
						tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
						totalElectrons: 41,
						type: 'Experiment',
						isOpen: false
					}}
					dispatch={{
						completedElectrons: 29,
						count: 4,
						id: '854c5de8-b13e-4fab-854d-3596704ds5d20',
						lastUpdated: '2022-01-11 13:04:00',
						title: 'Yellow Gaand',
						runTime: 1590600,
						startTime: '2022-01-12 20:22:00',
						status: 'FAILED',
						tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
						totalElectrons: 41,
						type: 'Dispatch',
						isOpen: false
					}}
				/>
			</ProjectContext.Provider>
		);
		const button = screen.getByRole('button');
		fireEvent.click(button);
		expect(button).toBeInTheDocument();
		const element = screen.getByTestId('moveAction');
		fireEvent.click(element);
		const moveMenu = screen.getByTestId('moveItemsMenu');
		expect(moveMenu).toBeInTheDocument();
	});
});
