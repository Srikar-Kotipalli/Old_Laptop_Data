/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import Divider from '@mui/material/Divider';

function StyledDivider({ dividerMargin = '0' }) {
	return (
		<Divider
			sx={{ borderColor: '#303067', margin: dividerMargin, height: '27px' }}
			orientation="vertical"
			variant="middle"
			flexItem
		/>
	);
}
function MarketPlaceTab(props) {
	const { value, onChange } = props;
	return (
		<TabContext value={value}>
			<TabList
				onChange={onChange}
				TabIndicatorProps={{
					style: {
						display: 'none'
					}
				}}
			>
				<Tab label="All" value="All" />
				<StyledDivider dividerMargin="10px 0 0 -15px" />
				<Tab label="Hardware" value="Hardware" />
				<StyledDivider dividerMargin="10px 0 0 0px" />
				<Tab label="Solvers" value="Solvers" />
			</TabList>
		</TabContext>
	);
}

export default MarketPlaceTab;
