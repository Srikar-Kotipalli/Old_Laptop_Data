/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import Divider from '@mui/material/Divider';

function StyledDivider() {
	return (
		<Divider
			sx={{ borderColor: '#303067', height: '20px', marginTop: '14px' }}
			orientation="vertical"
		/>
	);
}
function SolverAdminTab(props) {
	const { value, onChange } = props;
	return (
		<TabContext value={value}>
			<TabList
				onChange={onChange}
				TabIndicatorProps={{
					style: {
						display: 'none'
					}
				}}
			>
				<Tab label="Overview" value="Overview" sx={{ marginRight: '-5px' }} />
				<StyledDivider />
				<Tab label="Solvers" value="Solvers" sx={{ margin: '0 -10px 0 -10px' }} />
				<StyledDivider />
				<Tab label="Earnings" value="Earnings" sx={{ margin: '0 -5px 0 -5px' }} />
				<StyledDivider />
				<Tab label="Access Requests" value="Access Requests" sx={{ margin: '0 -5px 0 -5px' }} />
				<StyledDivider />
				<Tab label="Biling" value="Billing" sx={{ margin: '0 0 0 -15px' }} />
			</TabList>
		</TabContext>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default SolverAdminTab;
