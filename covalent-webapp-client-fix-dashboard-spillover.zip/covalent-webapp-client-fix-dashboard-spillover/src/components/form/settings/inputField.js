/* eslint-disable react/jsx-boolean-value */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import Input from '@mui/material/Input';
import { withStyles } from '@mui/styles';

function InputField(props) {
	const { label, name, widthStyle, value, disabled } = props;
	const DisabledInput = withStyles({
		root: {
			'& .MuiInput-input.Mui-disabled': {
				color: '#CBCBD7',
				WebkitTextFillColor: '#CBCBD7'
			}
		}
	})(Input);
	return (
		<DisabledInput
			sx={{
				padding: '8px 12px',
				width: widthStyle,
				height: '32px',
				border: '1px solid #303067',
				borderRadius: '60px',
				fontSize: '14px',
				color: '#CBCBD7',
				background: '#08081A'
			}}
			value={value || 'vader'}
			name={name}
			disableUnderline
			placeholder={label}
			disabled={disabled || false}
		/>
	);
}

export default InputField;
