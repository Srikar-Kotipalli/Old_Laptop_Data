import React, { useRef, useEffect, useState } from 'react';
import Grid from '@mui/material/Grid';
import { Tooltip } from '@mui/material';

function PackagesTooltip({ chip, onClick, width, maxWidth }) {
	// Define state and function to update the value
	const [hoverStatus, setHover] = useState(false);
	// Create Ref
	const textElementRef = useRef();

	const compareSize = () => {
		const compare = textElementRef?.current?.scrollWidth > textElementRef?.current?.clientWidth;
		setHover(compare);
	};

	// compare once and add resize listener on "componentDidMount"
	useEffect(() => {
		compareSize();
		window.addEventListener('resize', compareSize);
	}, []);

	// remove resize listener again on "componentWillUnmount"
	useEffect(
		() => () => {
			window.removeEventListener('resize', compareSize);
		},
		[]
	);

	return (
		<Tooltip title={chip} disableHoverListener={!hoverStatus}>
			<Grid
				ref={textElementRef}
				width={width}
				sx={{
					maxWidth: { maxWidth },
					cursor: 'pointer',
					whiteSpace: 'nowrap',
					textOverflow: 'ellipsis',
					overflow: 'hidden'
				}}
				onClick={onClick}
			>
				{chip}
			</Grid>
		</Tooltip>
	);
}

export default PackagesTooltip;
