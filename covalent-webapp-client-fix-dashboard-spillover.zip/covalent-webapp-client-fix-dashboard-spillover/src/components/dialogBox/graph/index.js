/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import { Grid } from '@mui/material';
import Icon from '../../icon';
import closeIcon from '../../../assets/actions/close.svg';
import PrimaryButton from '../../primaryButton';

function GraphDialogBox(props) {
	const { openDialogBox, setOpenDialogBox, icon, title, handler, message, paddingBottom, width } =
		props;
	const handleClose = () => setOpenDialogBox(false);

	return (
		<Modal
			open={openDialogBox}
			onClose={handleClose}
			aria-labelledby="modal-modal-title"
			aria-describedby="modal-modal-description"
			data-testid="dialogBox"
		>
			<Box
				sx={{
					position: 'absolute',
					top: '50%',
					left: '50%',
					transform: 'translate(-50%, -50%)',
					minWidth: width || 500,
					bgcolor: 'background.paper',
					border: '1px solid',
					borderColor: theme => theme.palette.background.blue05,
					borderRadius: '24px',
					boxShadow: 24,
					p: 2
				}}
			>
				<Grid sx={{ display: 'flex', justifyContent: 'space-between' }}>
					<Grid sx={{ display: 'flex' }}>
						<Icon src={icon} type="static" alt="arrowRightAltIcon" padding="0px 3px 6px 3.5px" />
						<Typography
							sx={{
								paddingBottom: paddingBottom || '5px',
								paddingLeft: '4px',
								fontWeight: 'bold'
							}}
							color="textSecondary"
							variant="subtitle2"
							data-testid="messageTitle"
						>
							{title}
						</Typography>
					</Grid>
					<Grid>
						<Icon
							src={closeIcon}
							type="pointer"
							alt="arrowRightAltIcon"
							clickHandler={handleClose}
						/>
					</Grid>
				</Grid>
				<Grid sx={{ display: 'flex' }} mt={2}>
					{message}
				</Grid>
				<Grid
					container
					display="flex"
					justifyContent="flex-end"
					spacing={1}
					mt={2}
					sx={{ maxWidth: '100%' }}
				>
					<Grid item>
						<PrimaryButton
							handler={handleClose}
							title="Cancel"
							bgColor={theme => theme.palette.background.default}
							hoverColor={theme => theme.palette.background.blue06}
							className="cancelButton"
						/>
					</Grid>
					<Grid item>
						<PrimaryButton
							handler={handler}
							title={title}
							bgColor={theme => theme.palette.background.blue06}
							hoverColor={theme => theme.palette.background.blue07}
						/>
					</Grid>
				</Grid>
			</Box>
		</Modal>
	);
}

export default GraphDialogBox;
