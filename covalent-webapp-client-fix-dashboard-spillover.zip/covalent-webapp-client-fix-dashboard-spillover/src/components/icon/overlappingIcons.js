import React from 'react';
import { Grid } from '@mui/material';

import IconButton from '@mui/material/IconButton';
import { dpexpStatusIcons, dpexpMainIcons } from '../../utils/statusIcons';

function overlappingIcons({ type, status }) {
	return (
		<IconButton
			sx={{
				'&.MuiButtonBase-root:hover': {
					bgcolor: 'transparent'
				},
				cursor: 'default'
			}}
			size="small"
		>
			<Grid
				container
				direction="row"
				alignItems="center"
				justifyContent="center"
				sx={{
					width: '24px',
					height: '24px',
					position: 'relative',
					background: theme => theme.palette.background.blue03,
					borderRadius: '8px'
				}}
			>
				<Grid pt={0.5}> {dpexpMainIcons(type)}</Grid>
				<Grid sx={{ display: 'inline-block', position: 'absolute', bottom: -5, right: -5 }}>
					{' '}
					{dpexpStatusIcons(status)}
				</Grid>
			</Grid>
		</IconButton>
	);
}

export default overlappingIcons;
