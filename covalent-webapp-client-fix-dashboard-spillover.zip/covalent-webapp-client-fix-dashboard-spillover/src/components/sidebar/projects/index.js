/* eslint-disable react/jsx-no-useless-fragment */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React, { useState, useEffect } from 'react';
import { Paper, Grid, Skeleton } from '@mui/material';
import Icon from '../../icon';
import ExperimentIcon from '../../../assets/sidebar/experiment.svg';
import CloseIcon from '../../../assets/actions/close.svg';
import closeDisabled from '../../../assets/actions/closeDisabled.svg';
import ExperimentCustomTab from '../../tab/projects/experimentsSidebar';
import Overview from './overview';
import Notes from '../../notes/projects';
import DispatchesList from './dispatchList';
import ContextMenu from '../../menu/projects/contextMenu';
import { experimentsOverview, addEditExperiment } from '../../../api/experiments/dispatchApi';
import { getActivityListByExperiment } from '../../../api/activity/activityApi';
import { ProjectContext } from '../../../containers/projects/projectContext';
import Loader from '../../loader';
import CustomInputBase from '../../inputBase/projects';
import OverflowTooltip from '../../tooltip/overflowTooltip';

function ProjectsSideBar({ sidebarId, sidebarType }) {
	const [value, setValue] = useState('overview');
	const [sortOrder, setSortOrder] = useState('desc');
	const projectContext = React.useContext(ProjectContext);
	const {
		closeSidebar,
		setIsEdit,
		setOpenProjectSnackbar,
		setSnackbarMessage,
		postAddEditItem,
		sidebarActions
	} = projectContext;

	const [isFetching, setIsFetching] = useState(true);
	const [addExperimentLoader, setAddExperimentLoader] = useState(false);
	const [experimentData, setExperimentData] = useState({});
	const [activityList, setActivityList] = useState([]);

	useEffect(() => {
		if (value === 'overview' && sidebarId) {
			experimentsOverview(sidebarId)
				.then(res => {
					if (res) {
						const expInfo = Object.assign(res, { type: 'Experiment' });
						setExperimentData({ ...expInfo });
					}
				})
				.catch(error => {
					closeSidebar();
					setIsFetching(false);
					setOpenProjectSnackbar(true);
					setSnackbarMessage(error?.detail);
					setExperimentData({});
					console.error(error);
				})
				.finally(() => {
					setIsFetching(false);
				});
		}
	}, [sidebarId, sidebarActions, value]);

	useEffect(() => {
		if (value === 'overview' && sidebarId) {
			getActivityListByExperiment(sidebarId, 20)
				.then(payload => {
					const activityListPayload = payload?.items?.map(e => {
						return { ...e, sub_category: e.sub_category || 'Blank' };
					});
					setActivityList(activityListPayload);
				})
				.catch(error => {
					if (error?.detail === 'No matching records for requested experiment ID') {
						setActivityList([]);
					} else {
						closeSidebar();
						setIsFetching(false);
						setOpenProjectSnackbar(true);
						setSnackbarMessage(error.detail);
						setActivityList({});
						console.error(error);
					}
				})
				.finally(() => {
					setIsFetching(false);
				});
		}
	}, [sidebarId, value]);

	const overviewData = {
		experiment_info: {
			experiment_status: 'FAILED',
			total_electrons: 11,
			completed_electrons: 5,
			dispatches: [
				{
					title: 'Dispatch Zeta',
					status: 'failed',
					duration: '30s'
				},
				{
					title: 'Dispatch Meta',
					status: 'failed',
					duration: '30s'
				},
				{
					title: 'Dispatch Meta',
					status: 'failed',
					duration: '30s'
				},
				{
					title: 'Dispatch Meta',
					status: 'failed',
					duration: '30s'
				}
			]
		},
		tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
		token_info: {
			token: '2323232322323fdfdffd',
			total_devices: 3
		},
		hardware: [
			{
				title: 'AQ Cluster',
				status: 'ONLINE'
			}
		],
		cost: 'Free',
		activity: [
			{
				title: 'Jazzy JellyBean',
				status: 'ONLINE',
				duration: '30s',
				type: 'HARDWARE'
			},
			{
				title: 'Dispatch Meta',
				status: 'RUNNING',
				duration: '30s',
				type: 'DISPATCH'
			},
			{
				title: 'Jazzy JellyBean',
				status: 'ONLINE',
				duration: '30s',
				type: 'HARDWARE'
			},
			{
				title: 'Dispatch Meta',
				status: 'RUNNING',
				duration: '30s',
				type: 'DISPATCH'
			},
			{
				title: 'Jazzy JellyBean',
				status: 'ONLINE',
				duration: '30s',
				type: 'HARDWARE'
			},
			{
				title: 'Dispatch Meta',
				status: 'RUNNING',
				duration: '30s',
				type: 'DISPATCH'
			},
			{
				title: 'Jazzy JellyBean',
				status: 'ONLINE',
				duration: '30s',
				type: 'HARDWARE'
			},
			{
				title: 'Dispatch Meta',
				status: 'RUNNING',
				duration: '30s',
				type: 'DISPATCH'
			},
			{
				title: 'Dispatch Meta',
				status: 'RUNNING',
				duration: '30s',
				type: 'DISPATCH'
			},
			{
				title: 'Dispatch Meta',
				status: 'RUNNING',
				duration: '30s',
				type: 'DISPATCH'
			},
			{
				title: 'Dispatch Meta',
				status: 'RUNNING',
				duration: '30s',
				type: 'DISPATCH'
			},
			{
				title: 'Dispatch Meta',
				status: 'RUNNING',
				duration: '30s',
				type: 'DISPATCH'
			},
			{
				title: 'Dispatch Meta',
				status: 'RUNNING',
				duration: '30s',
				type: 'DISPATCH'
			},
			{
				title: 'Dispatch Meta',
				status: 'RUNNING',
				duration: '30s',
				type: 'DISPATCH'
			},
			{
				title: 'Dispatch Meta',
				status: 'RUNNING',
				duration: '30s',
				type: 'DISPATCH'
			},
			{
				title: 'Dispatch Meta',
				status: 'RUNNING',
				duration: '30s',
				type: 'DISPATCH'
			}
		]
	};

	const editExperimentNameSidebar = (text, action) => {
		let parameter = null;
		const addData = experimentData;
		// save project and experiment
		if (action === 'save' && (text !== null || text !== '')) {
			parameter = {
				id: addData.id,
				title: text
			};
		} else if (action === 'close') {
			addData.isEdit = false;
		}
		// api call
		if (action === 'save') {
			setAddExperimentLoader(true);
			addEditExperiment(parameter)
				.then(response => {
					if (response.status) {
						postAddEditItem('experimentProject', text, response, addData);
						addData.title = text;
						addData.isEdit = false;
						setExperimentData({ ...addData });
						setIsEdit(false);
						setOpenProjectSnackbar(true);
						setSnackbarMessage(response.message);
						setAddExperimentLoader(false);
					}
				})
				.catch(() => {
					setAddExperimentLoader(false);
					setOpenProjectSnackbar(true);
					setSnackbarMessage('Something went wrong,please contact the administrator!');
				});
		} else {
			setExperimentData({ ...addData });
			setIsEdit(false);
		}
	};

	return (
		<Grid
			sx={{
				zIndex: '50',
				width: '420px',
				position: 'absolute',
				right: 10,
				top: 10
			}}
		>
			<Paper
				sx={{
					height: '100%',
					background: theme => theme.palette.background.covalentSidebar
				}}
			>
				<Grid container>
					{addExperimentLoader || isFetching ? (
						<Grid pt={2} ml={2}>
							<Skeleton variant="text" sx={{ fontSize: '1rem' }} width={264} />
						</Grid>
					) : (
						<Grid container item direction="row" xs={8} pt={2} pl={2}>
							{experimentData?.isEdit ? (
								<CustomInputBase
									location="expSidebar"
									type="experiment"
									listItem={experimentData}
									editExperimentNameSidebar={editExperimentNameSidebar}
								/>
							) : (
								<>
									<Icon
										className="iconProp"
										src={ExperimentIcon}
										padding="2px 0px 0px 0px"
										xs
										alt="covalentExperimentsIcon"
									/>
									<Grid pl={1} sx={{ width: '90%' }}>
										<OverflowTooltip
											title={experimentData?.title}
											length={25}
											fontSize="20px"
											color="#FFFFFF"
										/>
									</Grid>
								</>
							)}
						</Grid>
					)}
					<Grid container item xs={4} justifyContent="flex-end" alignItems="center" pt={2} pr={2}>
						<Grid mr={2}>
							{!experimentData?.isEdit && (
								<ContextMenu
									experiment={experimentData}
									type="experiment"
									rowType="experimentRow"
									location="expSidebar"
									setExperimentData={setExperimentData}
									setIsFetching={setIsFetching}
									disabled={!!isFetching}
								/>
							)}
						</Grid>
						<Icon
							src={!isFetching ? CloseIcon : closeDisabled}
							alt="CloseIcon"
							clickHandler={() => closeSidebar()}
							padding="0px"
							disabled={isFetching}
						/>
					</Grid>
					<Grid item xs={12} py={2} sx={{ height: '55px' }}>
						<ExperimentCustomTab value={value} setValue={setValue} type={sidebarType} />
					</Grid>
					{value === 'overview' ? (
						<Grid
							sx={{
								height: '83.5vh',
								'@media (min-height: 840px)': {
									height: '85.5vh'
								},
								'@media (min-height: 920px)': {
									height: '87vh'
								},
								'@media (min-height: 1000px)': {
									height: '89vh'
								},
								width: '100%',
								background: theme => theme.palette.background.covalentPurple,
								borderBottomLeftRadius: '15px',
								borderBottomRightRadius: '15px'
							}}
						>
							<Loader isFetching={isFetching} width="100%" height="90vh" />
							{!isFetching &&
								Object.keys(overviewData).length > 0 &&
								Object.keys(experimentData).length > 0 && (
									<Overview
										overviewData={overviewData}
										experimentData={experimentData}
										setValue={setValue}
										sidebarId={sidebarId}
										setSortOrder={setSortOrder}
										sidebarType={sidebarType}
										setExperimentData={setExperimentData}
										activityList={activityList}
									/>
								)}
						</Grid>
					) : null}
					<Grid
						mt={0}
						sx={{
							zIndex: 12111,
							height: '100%',
							width: '100%',
							background: theme => theme.palette.background.covalentPurple,
							borderBottomLeftRadius: '15px',
							borderBottomRightRadius: '15px'
						}}
					>
						{value === 'notes' ? (
							<Grid
								sx={{
									height: '83.5vh',
									'@media (min-height: 840px)': {
										height: '85.5vh'
									},
									'@media (min-height: 920px)': {
										height: '87vh'
									},
									'@media (min-height: 1000px)': {
										height: '89vh'
									},
									width: '100%',
									background: theme => theme.palette.background.covalentPurple,
									borderBottomLeftRadius: '15px',
									borderBottomRightRadius: '15px'
								}}
							>
								<Notes sidebarId={sidebarId} name="experiment" />
							</Grid>
						) : null}
						{value === 'dispatches' ? (
							<Grid
								sx={{
									height: '81.3vh',
									'@media (min-height: 850px)': {
										height: '83.7vh'
									},
									'@media (min-height: 920px)': {
										height: '85.3vh'
									},
									'@media (min-height: 1000px)': {
										height: '87.5vh'
									},
									width: '100%',
									background: theme => theme.palette.background.covalentPurple,
									borderBottomLeftRadius: '15px',
									borderBottomRightRadius: '15px'
								}}
							>
								<DispatchesList
									id={sidebarId}
									type={sidebarType}
									sortOrder={sortOrder}
									setSortOrder={setSortOrder}
								/>
							</Grid>
						) : null}
						{sidebarType === 'Dispatch' && value === 'output' ? (
							<Grid
								sx={{
									height: '83.5vh',
									'@media (min-height: 840px)': {
										height: '85.5vh'
									},
									'@media (min-height: 920px)': {
										height: '87vh'
									},
									'@media (min-height: 1000px)': {
										height: '89vh'
									},
									width: '100%',
									background: theme => theme.palette.background.covalentPurple,
									borderBottomLeftRadius: '15px',
									borderBottomRightRadius: '15px'
								}}
							>
								Output
							</Grid>
						) : null}
					</Grid>
				</Grid>
			</Paper>
		</Grid>
	);
}

export default ProjectsSideBar;
