/* eslint-disable react/no-array-index-key */
/* eslint-disable react/jsx-boolean-value */
import React from 'react';
import { Typography, Box, Grid, Skeleton } from '@mui/material';
import Divider from '@mui/material/Divider';
import Icon from '../../../icon';
// import img from '../../../../assets/actions/add.svg';
import sucess from '../../../../assets/SuccessIcon.svg';
import theme from '../../../../theme';
import covalent from '../../../../assets/icons/covalent-tag.svg';
import nvidia from '../../../../assets/nvidia.svg';
import CopyButton from '../../../copyButton/index';

function StyledDivider() {
	return (
		<Divider
			sx={{ borderColor: theme.palette.background.blue03, mr: '7%' }}
			orientation="vertical"
			variant="middle"
			flexItem
		/>
	);
}

function HardwareCard({ data, hardwareTitle, isFetching, status, GpuVendor, GpuNum }) {
	return (
		<Grid
			container
			sx={{
				border: '1px solid rgba(48, 48, 103, 1)',
				bgcolor: 'rgba(28, 28, 70, 0.4)',
				padding: '10px 0px 10px 0px',
				borderRadius: '8px',
				transition: 'transform 0.2s ease',
				'&:hover': {
					background: theme.palette.background.blue0380,
					transform: 'scale(1.02)'
				}
			}}
		>
			<Grid item xs={6} md={6} lg={6} sm={6} sx={{ display: 'grid', placeItems: 'center' }}>
				<Box>
					<Box sx={{ display: 'flex', justifyContent: 'center' }}>
						{isFetching ? (
							<Skeleton variant="text" sx={{ fontSize: '12px' }} width={100} />
						) : (
							<Typography
								sx={{
									fontSize: '16px',
									fontWeight: 500,
									color: '#FFFFFF'
									// width:"100px"
								}}
							>
								{hardwareTitle}
							</Typography>
						)}
						<Box sx={{ display: 'flex' }}>
							{status === 'ACTIVE' && (
								<Box sx={{ padding: '0px 4px 0px 4px' }}>
									<Icon src={sucess} alt="sucess" />
								</Box>
							)}
							<CopyButton
								content={hardwareTitle}
								borderEnable={false}
								placement="top"
								bgColor={theme.palette.background.blue14}
								padding="4px"
							/>
						</Box>
					</Box>
					<Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
						<Icon
							src={covalent}
							alt="nvidia"
							backgroundColor="rgba(28, 28, 70, 0.7)"
							border="0.5px solid rgba(48, 48, 103, 1)"
							padding="4px 6px 4px 6px"
							margin="0px 5px 0px 0px"
						/>
						{GpuNum > 0 && GpuVendor === 'nvidia' && (
							<Icon
								src={nvidia}
								alt="nvidia"
								backgroundColor="rgba(28, 28, 70, 0.7)"
								border="0.5px solid rgba(48, 48, 103, 1)"
								padding="2px 6px 2px 6px"
								margin="0px 5px 0px 0px"
							/>
						)}
						<Typography
							fontSize="12px"
							// fontWeight="bold"
							mt="2px"
							p="1px"
							sx={{
								bgcolor: 'rgba(28, 28, 70, 0.7)',
								border: '0.5px solid rgba(48, 48, 103, 1)',
								borderRadius: '4px',
								padding: '2px 6px 0px 6px'
							}}
						>
							GPU
						</Typography>
					</Box>
				</Box>
			</Grid>
			<StyledDivider sx={{}} />
			<Grid item xs={4} md={4} lg={4} sm={4}>
				{data &&
					data.map((item, index) => (
						<Grid container key={index}>
							<Grid item xs={7} lg={7} md={7} sm={7} mr="10px">
								{isFetching ? (
									<Skeleton variant="text" sx={{ fontSize: '12px' }} width={60} />
								) : (
									<Typography sx={{ fontSize: '12px', color: '#86869A', whiteSpace: 'nowrap' }}>
										{item.heading}
									</Typography>
								)}
							</Grid>
							{/* <Grid item xs={1} lg={1} md={1} sm={1}></Grid> */}
							<Grid item xs={3} lg={3} md={3} sm={3}>
								{isFetching ? (
									<Skeleton variant="text" sx={{ fontSize: '14px' }} width={40} />
								) : (
									<Typography sx={{ fontSize: '14px', fontWeight: 400 }}>{item.value}</Typography>
								)}
							</Grid>
						</Grid>
					))}
			</Grid>
		</Grid>

		// <>
		// 	{/* {type === 'hardware' ? ( */}
		// 		<Grid container spacing={2}>
		// 			{data.map((item, index) => (
		// 				<Grid item  xs={6} sm={6} md={4} lg={3}>
		// 					<Box
		// 						sx={{
		// 							bgcolor: '#1C1C4666',
		// 							border: '1px solid #303067',
		// 							padding: '10px',
		// 							borderRadius: '8px'
		// 						}}
		// 					>
		// 						<Grid
		// 							container
		// 							display="flex"
		// 							justifyContent="space-between"
		// 							alignSelf="center"
		// 							padding="10px 20px 10px 20px"
		// 						>
		// 							{/* First Part */}
		// 							<Grid item xs={5.5} alignItems="center">
		// 								<Box display="flex" pb="6px">
		// 									<Typography
		// 										fontWeight="bold"
		// 										color={theme.palette.text.secondary}
		// 										fontSize="16px"
		// 									>
		// 										A100 GPU
		// 									</Typography>
		// 									<Box sx={{ padding: '0px 4px 0px 4px' }}>
		// 										<Icon src={sucess} alt="sucess" />
		// 									</Box>
		// 									<CopyButton
		// 										content={item.heading}
		// 										borderEnable={false}
		// 										placement="top"
		// 										bgColor={theme.palette.background.blue14}
		// 										padding="4px"
		// 									/>
		// 								</Box>
		// 								<Grid container display="flex" justifyContent="space-between">
		// 									{/* {item.tags.map((tag, tagIndex) => ( */}
		// 										<Box
		// 											// key={tagIndex}
		// 											bgcolor="#1C1C46B2"
		// 											border="0.5px solid #303067"
		// 											borderRadius="4px"
		// 										>
		// 											{console.log('tag type', tag)}
		// 											<Grid item padding="0px 1px 0px 1px">
		// 												{/* <Icon src={tag} alt={`Tag ${tagIndex + 1}`} /> */}
		// 												{tag === 'covalent' && <Icon src={covalent} alt="nvidia" />}
		// 												{tag === 'nvidia' && <Icon src={nvidia} alt="nvidia" />}
		// 												{tag === 'GPU' && (
		// 													<Typography fontSize="14px" fontWeight="bold" mt="2px" p="1px">
		// 														GPU
		// 													</Typography>
		// 												)}
		// 											</Grid>
		// 										</Box>
		// 									{/* ))} */}
		// 								</Grid>

		// 								{/* Cost */}
		// 								{/* <Box mt={1}>
		// 									<Typography
		// 										sx={{
		// 											color: theme.palette.text.blue01,
		// 											fontWeight: 'bold',
		// 											fontSize: '16px'
		// 										}}
		// 									>
		// 										{item.cost}
		// 									</Typography>
		// 								</Box> */}
		// 							</Grid>

		// 							{/* Divider */}
		// 							<StyledDivider />

		// 							{/* Second Part */}
		// 							<Grid item pt="5px" xs={4} alignSelf="center" >
		// 								{/* {Object.entries(item.parameters).map(([key, value], paramIndex) => ( */}
		// 									<Grid
		// 										container
		// 										key={index}
		// 										justifyContent="space-between"
		// 										// spacing={2}
		// 										// pb="5px"
		// 										sx={{border:"1px solid yellow"}}
		// 									>
		// 										<Grid item xs={6} sm={6} lg={6} md={6}>
		// 											<Typography  sx={{ color: theme.palette.text.gray03, fontSize: '12px',whiteSpace:"nowrap" }}>
		// 												{/* {key} */}
		// 												{item.heading}
		// 											</Typography>
		// 										</Grid>
		// 										<Grid item xs={6} sm={6} lg={6} md={6}>
		// 											<Typography fontSize="14px">{item.value}</Typography>
		// 										</Grid>
		// 									</Grid>
		// 								{/* ))} */}
		// 							</Grid>
		// 						</Grid>
		// 					</Box>
		// 				</Grid>
		// 			))}
		// 		</Grid>
		// 	{/* )} */}
	);
}

export default HardwareCard;
