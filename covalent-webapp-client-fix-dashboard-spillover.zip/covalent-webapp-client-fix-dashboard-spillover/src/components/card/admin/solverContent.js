/* eslint-disable no-shadow */
/* eslint-disable react/jsx-boolean-value */
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Icon from '../../icon';
import MarketplaceChip from '../../marketplace/chip/marketplaceChip';
import statusImage from '../../../assets/marketplace/online.svg';
import Edit from '../../../assets/marketplace/edit.svg';
import RightArrow from '../../../assets/marketplace/arrow.svg';
import OverflowTooltip from '../../tooltip/overflowTooltip';

function SolverContent({
	solverImage,
	name,
	apiCalls,
	revenue,
	chipData,
	borderRadius,
	width,
	from,
	handlePublishToMarketplace,
	solverId
}) {
	const { solverdata } = useSelector(state => state.marketplace);
	const [published, setPublished] = useState(
		solverdata?.details?.findIndex(e => e?.solverId === solverId) !== -1
	);
	useEffect(() => {
		setPublished(solverdata?.details?.findIndex(e => e?.solverId === solverId) !== -1);
	}, [solverdata]);
	return (
		// width: '382px' ,
		<Box
			sx={{
				height: '100%',
				width: { width },
				background: theme => theme.palette.background.blue08,
				padding: '14px 4px 14px 0px',
				borderTopLeftRadius: borderRadius[0],
				borderTopRightRadius: borderRadius[1],
				borderBottomLeftRadius: borderRadius[2],
				borderBottomRightRadius: borderRadius[3]
			}}
		>
			<Box
				sx={{
					display: 'flex',
					justifyContent: 'space-between'
				}}
			>
				<Box sx={{ paddingLeft: '11px' }}>
					<Box
						sx={{
							display: 'flex'
						}}
					>
						<Box sx={{ marginRight: '8px' }}>
							{from === 'hardware' ? (
								<img src={solverImage} alt="hardware" />
							) : (
								<img src={solverImage} alt="solver" />
							)}
						</Box>
						<Box sx={{ marginRight: '2px' }}>
							<OverflowTooltip title={name} length={22} />
						</Box>

						<Icon padding="0px 0px 11px 11px" src={statusImage} alt="status" />
						<Box sx={{ marginLeft: '8px', display: 'flex', placeItems: 'center' }}>
							{from === 'hardware' ? (
								<Icon padding="0px 0px 11px 0px" src={Edit} alt="edit" />
							) : null}
						</Box>
					</Box>
				</Box>
				<Box
					sx={{
						display: 'flex',
						allignItems: 'center',
						gap: '4px',
						width: '42px',
						height: '16px',
						marginTop: '5px'
					}}
				>
					{from === 'hardware' ? (
						<Typography
							sx={{
								fontSize: '10px',
								color: theme => theme.palette.text.secondary,
								fontWeight: '500',
								paddingLeft: '5px'
							}}
						>
							INUSE
						</Typography>
					) : (
						<Box
							sx={{
								fontSize: '10px',
								fontWeight: '100',
								color: theme => theme.palette.text.secondary,
								width: '100%',
								display: 'grid',
								placeItems: 'end',
								paddingRight: '10px'
							}}
						>
							<img src={Edit} alt="edit" />
						</Box>
					)}
				</Box>
			</Box>
			{chipData?.tags?.length > 0 ? (
				<MarketplaceChip items={chipData} isExpandable={false} />
			) : (
				<Box sx={{ height: '44px' }} />
			)}
			<Box sx={{ display: 'grid', placeItems: 'center' }}>
				<Box
					sx={{
						display: 'flex',
						justifyContent: 'space-between',
						marginTop: '8px',
						width: '100%',
						padding: '0 10px 0 10px'
					}}
				>
					<Box>
						<Box
							sx={{
								color: theme => theme.typography.sidebarTitle.color
							}}
						>
							<Typography variant="h3" fontWeight="400">
								{from === 'hardware' ? 'Total Usage' : 'Total API Calls'}
							</Typography>
						</Box>
						<Typography variant="h3" sx={{ mt: 0.5 }}>
							{apiCalls}
						</Typography>
					</Box>
					<Box>
						<Box
							sx={{
								color: theme => theme.typography.sidebarTitle.color
							}}
						>
							<Typography variant="h3">Revenue</Typography>
						</Box>
						<Typography variant="h3" sx={{ mt: 0.5 }}>
							${revenue}
						</Typography>
					</Box>
				</Box>
			</Box>
			{from === 'solverTab' && published && (
				<Button
					color="primary"
					variant="outlined"
					sx={{
						background: '#55D89910',
						border: '1px solid #55D899',
						cursor: 'auto',
						':hover': {
							background: '#55D89910',
							border: '1px solid #55D899'
						},
						borderRadius: '8px',
						fontSize: '12px',
						height: '22px',
						marginTop: '1.2rem',
						marginBottom: '0.5rem',
						padding: '3px 10px 3px 10px',
						marginLeft: '10px',
						mb: 0
					}}
				>
					Published to Marketplace
				</Button>
			)}
			{from === 'solverTab' && !published && (
				<Button
					endIcon={<Icon src={RightArrow} />}
					className="requestBtn"
					color="primary"
					variant="contained"
					sx={{
						background: '#5552FF',
						':hover': {
							background: '#3633ff'
						},
						fontSize: '12px',
						height: '22px',
						marginTop: '1.2rem',
						// marginBottom: '0.5rem',
						// padding: '3px 10px 3px 3px',
						marginLeft: '10px'
					}}
					onClick={handlePublishToMarketplace}
				>
					Publish to Marketplace
				</Button>
			)}
		</Box>
	);
}
export default SolverContent;
