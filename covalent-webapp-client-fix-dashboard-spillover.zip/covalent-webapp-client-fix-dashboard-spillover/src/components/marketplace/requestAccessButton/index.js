import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Grid, Typography } from '@mui/material';
import Icon from '../../icon';
import ArrowRightWhite from '../../../assets/arrowRightWhite.svg';

function RequestAccessButton({ handleClick, solverId, hardwareId, type }) {
	const { allMySolvers } = useSelector(state => state.solver);
	const { allMyHardwares } = useSelector(state => state.hardware);
	const { accessRequests } =
		type === 'solver'
			? useSelector(state => state.solverAdmin)
			: useSelector(state => state.hardwareAdmin);
	const [showRequestButton, setShowRequestButton] = useState(true);

	const isDisabled = () => {
		if (type === 'solver') {
			const alreadyInSolvers = allMySolvers?.findIndex(e => e?.solverId === parseInt(solverId, 10));
			const inRequests = accessRequests?.findIndex(
				e => e?.solverId === parseInt(solverId, 10) && !e?.isDenied
			);
			if (alreadyInSolvers !== -1 || inRequests !== -1) return true;
			return false;
		}
		const alreadyInHardwares = allMyHardwares?.findIndex(
			e => e?.hardwareId === parseInt(hardwareId, 10)
		);
		const inRequests = accessRequests?.findIndex(
			e => e?.hardwareId === parseInt(hardwareId, 10) && !e?.isDenied
		);
		if (alreadyInHardwares !== -1 || inRequests !== -1) return true;
		return false;
	};

	useEffect(() => {
		if (isDisabled()) {
			setShowRequestButton(false);
		} else {
			setShowRequestButton(true);
		}
	});

	return (
		<Grid
			container
			className="requestBtn"
			color="primary"
			variant="contained"
			sx={{
				display: !showRequestButton ? 'none' : null,
				width: '200px',
				background: '#5552FF',
				':hover': {
					background: '#3633ff'
				},
				'&:disabled': {
					background: theme => theme.palette.background.covalentPurple,
					color: theme => theme.palette.text.secondary,
					border: '1px solid',
					borderColor: theme => theme.palette.background.blue04,
					borderRadius: '70px'
				}
			}}
			onClick={handleClick}
			disabled={isDisabled()}
		>
			<Typography>Request Access</Typography>
			<Icon src={ArrowRightWhite} padding="1.5px 0px 0px 8px" />
		</Grid>
	);
}

export default RequestAccessButton;
