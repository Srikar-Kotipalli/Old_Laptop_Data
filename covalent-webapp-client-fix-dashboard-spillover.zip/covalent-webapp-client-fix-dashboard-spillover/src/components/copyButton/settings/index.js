/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React, { useState } from 'react';
import copy from 'copy-to-clipboard';
import Tooltip from '@mui/material/Tooltip';
import Icon from '../../icon';

function SettingsCopyButton(props) {
	const { content, copyIcon, copiedIcon, title } = props;
	const [copied, setCopied] = useState(false);

	return (
		<Tooltip title={copied ? 'Copied!' : title} placement="top">
			<span>
				{copied ? (
					<Icon src={copiedIcon} alt="tickIcon" type="static" />
				) : (
					<Icon
						clickHandler={() => {
							copy(content);
							setCopied(true);
							setTimeout(() => setCopied(false), 1200);
						}}
						alt="copyIcon"
						type="pointer"
						src={copyIcon}
						testId="copyIcon"
					/>
				)}
			</span>
		</Tooltip>
	);
}

export default SettingsCopyButton;
