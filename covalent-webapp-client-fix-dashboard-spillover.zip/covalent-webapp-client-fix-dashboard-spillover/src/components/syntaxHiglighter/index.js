/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
/* eslint-disable react/jsx-props-no-spreading */

import React from 'react';
import { Light } from 'react-syntax-highlighter';
import ReactJson from 'react-json-view';
import python from 'react-syntax-highlighter/dist/cjs/languages/hljs/python';
import yaml from 'react-syntax-highlighter/dist/cjs/languages/hljs/yaml';
import json from 'react-syntax-highlighter/dist/cjs/languages/hljs/json';
import style from 'react-syntax-highlighter/dist/cjs/styles/hljs/androidstudio';

Light.registerLanguage('python', python);
Light.registerLanguage('yaml', yaml);
Light.registerLanguage('json', json);

function SyntaxHighlighter({ src, className, ...props }) {
	const isSrcObject = typeof src === 'object';
	const isSrcUndefined = typeof src === 'undefined';

	return isSrcObject ? (
		<ReactJson
			enableClipboard={false}
			theme="monokai"
			style={{ background: 'transparent', fontSize: '12px' }}
			src={src}
		/>
	) : (
		<Light
			data-testid="syntax"
			language="python"
			className={className}
			style={style}
			customStyle={{
				margin: 0,
				maxHeight: 'auto',
				fontSize: 12,
				backgroundColor: 'transparent'
			}}
			{...props}
		>
			{isSrcUndefined ? src : src.toString()}
		</Light>
	);
}

export default SyntaxHighlighter;
