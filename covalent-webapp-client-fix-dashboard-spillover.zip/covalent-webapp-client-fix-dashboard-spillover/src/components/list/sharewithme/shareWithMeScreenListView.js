/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import Grid from '@mui/material/Grid';
import Tooltip from '@mui/material/Tooltip';
import Pagination from '@mui/material/Pagination';
import ScrollToTopButton from '../../scrollToTopButton';
import DispatchRow from './dispatchRow';
import DispatchTableHeader from './tableheader';
import './style.css';

export default function ShareWithMeScreenListView(props) {
	const {
		header,
		order,
		orderBy,
		onSelectAllClick,
		shareWithTableData,
		onSort,
		handlePageChanges,
		page,
		totalRecords,
		showArchived,
		filterTags
	} = props;

	return (
		<>
			<Table>
				<DispatchTableHeader
					header={header}
					onSelectAllClick={onSelectAllClick}
					order={order}
					orderBy={orderBy}
					onSort={onSort}
				/>
				<TableBody>
					{shareWithTableData &&
						shareWithTableData.map((dispatch, index) => (
							<TableRow key={dispatch.id} data-testid="dispatchListView">
								<DispatchRow
									dispatch={dispatch}
									index={index}
									hierarchyType="dispatch"
									showArchived={showArchived}
									filterTags={filterTags}
								/>
							</TableRow>
						))}
					{shareWithTableData && shareWithTableData.length === 0 && (
						<TableRow data-testid="noDispatchesFound">
							<TableCell colSpan={8} sx={{ pl: 2 }}>
								No workflows shared
							</TableCell>
						</TableRow>
					)}
				</TableBody>
			</Table>
			<Grid container className="footer" data-testid="tableFooter">
				<Pagination
					color="primary"
					shape="rounded"
					variant="outlined"
					count={totalRecords && totalRecords > 10 ? Math.ceil(totalRecords / 10) : 1}
					page={page}
					onChange={handlePageChanges}
					showFirstButton
					showLastButton
					siblingCount={2}
					boundaryCount={2}
					data-testid="paginationItem"
				/>
				<Tooltip title="Scroll to top">
					<Grid>
						<ScrollToTopButton data-testid="scrollToTopButton" />
					</Grid>
				</Tooltip>
			</Grid>
		</>
	);
}
