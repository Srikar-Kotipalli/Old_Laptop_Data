import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import { Box } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import Icon from '../../icon';
import loader from '../../../assets/loaders/loader.svg';
import caretDown from '../../../assets/arrows/caretDown.svg';
import caretRight from '../../../assets/arrows/caretRight.svg';
import caretRightDisabled from '../../../assets/arrows/caretRightDisabled.svg';
import checkbox from '../../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../../assets/checkboxes/checkboxChecked.svg';
import checkboxDisabled from '../../../assets/checkboxes/checkboxdisabled.svg';
import checkboxCheckedDisabled from '../../../assets/checkboxes/checkboxCheckedDisabled.svg';
import ContextMenu from '../../menu/projects/contextMenu';
import './style.css';
import EllipsisDefaultTooltip from '../../tooltip/ellipsisTooltip';
import CustomInputBase from '../../inputBase/projects';
import { ProjectContext } from '../../../containers/projects/projectContext';

export default function ProjectRow(props) {
	const { list, allListIndex } = props;
	const projectContext = React.useContext(ProjectContext);
	const { handleOpenAllProjects, showArchived, onCheckboxChecked, searchValue } = projectContext;
	return (
		<>
			<TableCell
				align="left"
				sx={{
					width: '7%'
				}}
			>
				<Box display="flex" flexDirection="row">
					<Box>
						<Checkbox
							icon={
								<Icon
									src={!showArchived && !list?.isOpen && !list?.isAdd ? checkbox : checkboxDisabled}
									alt="checkbox"
									type="pointer"
								/>
							}
							checkedIcon={
								<Icon
									src={list.isOpen ? checkboxCheckedDisabled : checkboxChecked}
									alt="checkboxChecked"
									type="pointer"
								/>
							}
							size="small"
							value={list.id}
							disabled={list.isOpen || showArchived || list?.isAdd}
							checked={list.isChecked}
							onChange={e => onCheckboxChecked(e, list)}
							data-testid="allExperimentCheckbox"
						/>
					</Box>
					<Box
						align="left"
						sx={{
							paddingLeft: '0.3rem',
							paddingTop: '3px'
						}}
					>
						{searchValue?.length < 3 ? (
							<>
								{list?.isOpen && !list?.isLoader && (
									<Icon
										src={caretDown}
										alt="caretDown"
										clickHandler={() =>
											handleOpenAllProjects(allListIndex, 'allItems', false, '', 'list', 5)
										}
										type="pointer"
										testId="projectCaretDown"
										padding="5px 3px 3.5px 3px"
									/>
								)}
								{list?.isOpen && list?.isLoader && (
									<Icon src={loader} alt="runningIcon" type="static" padding="5px 3px 3.5px 3px" />
								)}
								{!list?.isOpen && !list?.isLoader && (
									<Icon
										src={list?.isAdd ? caretRightDisabled : caretRight}
										clickHandler={() =>
											handleOpenAllProjects(allListIndex, 'allItems', true, '', 'list', 5)
										}
										type="pointer"
										alt="caretRight"
										disabled={list?.isAdd}
										padding="5px 3px 3.5px 3px"
									/>
								)}
							</>
						) : (
							// eslint-disable-next-line react/jsx-no-useless-fragment
							<></>
						)}
					</Box>
				</Box>
			</TableCell>
			<TableCell width="20%" align="left" data-testid="projectRow">
				{list?.isAdd === true ? (
					<CustomInputBase secondaryIndex={null} type="project" listItem={list} />
				) : (
					<EllipsisDefaultTooltip
						variant="subtitle1"
						value={list?.title}
						subValue={list?.count}
						type="project"
						paddingLeft="0.08rem"
					/>
				)}
			</TableCell>
			<TableCell width="8%" />
			<TableCell width="28%" />
			<TableCell width="9%" />
			<TableCell width="12%" />
			<TableCell width="12%" />
			<TableCell width="2%" />
			<TableCell align="left" width="2%" />
			<TableCell width="2%" align="left">
				<ContextMenu
					project={list}
					type="project"
					rowType="experimentRow"
					disabled={list.isOpen}
					margin={1}
				/>
			</TableCell>
		</>
	);
}
