/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React, { useState, useEffect } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableRow from '@mui/material/TableRow';
import Backdrop from '@mui/material/Backdrop';
import DispatchRow from './solverDispatchRow';
import SolverTableHeader from './solverTableHeader';
import covLoader from '../../../assets/loaders/covLoader.svg';
import Icon from '../../icon';
import '../projects/style.css';
import NoRecordsFound from '../projects/noRecordsFound';
import CustomisedSnackbar from '../../snackbar/projects/index';
import { getPositionIndex } from '../../../containers/projects/helpers';

// eslint-disable-next-line import/no-unused-modules
export default function SolversListView({ dispatchesList, orderBy, order, onSort }) {
	const [selectAll, setSelectAll] = useState(false);
	// all items state variables.
	const [allItems, setAllItems] = React.useState(dispatchesList || []);
	// common actions state variables.
	// state to store multiple dispatches for context actions.
	const [openSnackbar, setOpenSnackbar] = React.useState(false);

	useEffect(() => {
		setAllItems(dispatchesList);
	}, [dispatchesList]);

	const checkAllHandler = e => {
		const isChecked = e.target.checked;
		setSelectAll(isChecked);
	};

	const onCheckboxChecked = (evt, item) => {
		const checkedData = allItems;
		const isChecked = evt.target.checked;
		const { index } = getPositionIndex(item, allItems);
		checkedData[index].isChecked = isChecked;
		setAllItems([...checkedData]);
		if (!isChecked) setSelectAll(isChecked);
	};

	useEffect(() => {
		const checkedData = allItems.map(f => {
			return {
				...f,
				isChecked: selectAll
			};
		});
		setAllItems(checkedData);
	}, [selectAll]);

	return (
		<>
			<CustomisedSnackbar
				testId="solversSnackbar"
				open={openSnackbar}
				message="message"
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			<Table width="100%" className="tabComponentTable">
				<SolverTableHeader
					headerCellHeight="32px"
					checkAllHandler={checkAllHandler}
					selectAll={selectAll}
					order={order}
					orderBy={orderBy}
					onSort={onSort}
				/>
				<TableBody>
					{allItems &&
						allItems.map((dispatch, index) => (
							<TableRow key={dispatch.id} data-testid="dispatchListView">
								<DispatchRow
									dispatch={dispatch}
									index={index}
									hierarchyType="dispatch"
									cellheight="36px"
									onCheckboxChecked={onCheckboxChecked}
								/>
							</TableRow>
						))}
					{allItems.length === 0 && <NoRecordsFound />}
				</TableBody>
			</Table>
			<Backdrop open={false} sx={{ zIndex: 2000, backgroundColor: 'rgba(0,0,0,0.85)' }}>
				<Icon type="pointer" src={covLoader} />
			</Backdrop>
			{/* <TableFooter /> */}
		</>
	);
}
