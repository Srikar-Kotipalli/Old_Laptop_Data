/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import PropTypes from 'prop-types'; // Import PropTypes
// import { motion } from 'framer-motion'; // Add this import
import Fade from '@mui/material/Fade';
import Tooltip from '@mui/material/Tooltip';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Icon from '../../icon';

function CustomList({
	open,
	activeIcon,
	inActiveIcon,
	title,
	linkHandler = () => {},
	iconPadding = '0.5px 0px 0px 0px',
	selected,
	path,
	buttonHandler = () => {},
	type = 'link',
	isMenuOpen = false
}) {
	// props doc
	// ------------------------------------------------------------------------------------
	// open: State indicates whether the navbar drawer is open or closed.
	// activeIcon: Icon displayed when the navbar is in the open state.
	// inActiveIcon: Icon displayed when the navbar is in the closed state.
	// title: Title for the navbar icon when it's in the open state.
	// type: Type of the navbar item - 'link', 'button', or 'menu'.
	// iconPadding: Padding for the navbar icon.
	// selected: The selected route for the navbar.
	// path: The path for the route.
	// linkHandler: Handler function for the 'link' type.
	// buttonHandler: Handler function for the 'button' type.
	// isMenuOpen: State indicating whether the menu is open or closed.
	// -------------------------------------------------------------------------------------

	// const textVariants = {
	// 	open: { opacity: 1, transition: { duration: 1 } },
	// 	closed: { opacity: 0, transition: { duration: 1 } }
	// };

	const containerRef = React.useRef(null);

	const checkSelected = page => {
		const pageText = page?.slice(1);
		const isSelected =
			page === '/'
				? (() => {
						return selected === pageText;
				  })()
				: (() => {
						return selected === pageText || selected?.startsWith(pageText);
				  })();
		return isSelected;
	};

	return (
		<ListItem
			key={title}
			disablePadding
			sx={{
				display: 'block',
				background: 'transparent',
				'&:hover': {
					backgroundColor: 'transparent'
				}
			}}
		>
			<ListItemButton
				ref={containerRef}
				onClick={type === 'link' ? () => linkHandler() : event => buttonHandler(event)}
				sx={{
					height: '32px',
					margin: 1,
					width: !open ? '30px' : '145px',
					display: 'flex',
					alignItems: 'center',
					borderRadius: '8px',
					justifyContent: open ? 'initial' : 'center',
					px: 1.5,
					ml: open ? null : 2.35,
					background: 'transparent',
					color: theme =>
						(type === 'link' && checkSelected(path)) || (type === 'menu' && isMenuOpen)
							? theme.palette.background.violet01
							: theme.palette.text.gray03,
					'&:hover': {
						backgroundColor: '#30306799'
					}
					// '&:hover': {
					// 	color: theme => theme.palette.text.primary,
					// 	backgroundColor:
					// 		title === 'Covalent' ? 'transparent' : theme => theme.palette.background.blue16,
					// 	transition: 'background-color 0.4s ease-in-out'
					// }
				}}
			>
				<Tooltip title={open ? '' : title} placement="right">
					<ListItemIcon
						sx={{
							minWidth: '28px',
							height: '28px',
							mr: open ? 1 : 'auto',
							justifyContent: 'center',
							border:
								type === 'link'
									? checkSelected(path)
										? title !== 'Covalent'
											? '1px solid'
											: '1px solid transparent'
										: null
									: type === 'menu'
									? isMenuOpen
										? '1px solid'
										: null
									: null,
							background:
								type === 'link'
									? checkSelected(path) || isMenuOpen
										? title !== 'Covalent'
											? theme => theme.palette.background.blue03
											: ' transparent'
										: null
									: type === 'menu'
									? isMenuOpen
										? theme => theme.palette.background.blue03
										: null
									: null,
							borderRadius: title !== 'Covalent' ? '6px' : null,
							borderColor: theme => theme.palette.background.blue06,
							transition: 'background 0.3s ease-in-out,border 0.3s ease-in-out',
							display: 'flex',
							alignItems: 'center'
							// '&:hover': {
							// 	background:
							// 		title !== 'Covalent' ? theme => theme.palette.background.blue03 : ' transparent'
							// }
						}}
					>
						<Icon
							src={
								type === 'button' || type === 'menu'
									? open
										? isMenuOpen
											? activeIcon
											: inActiveIcon
										: activeIcon
									: open && !checkSelected(path)
									? inActiveIcon
									: activeIcon
							}
							padding={iconPadding}
						/>
					</ListItemIcon>
				</Tooltip>
				{/* <motion.div variants={textVariants} initial={false} animate={open ? 'open' : 'closed'}> */}
				{open && (
					<Fade
						in={open}
						unmountOnExit
						timeout={{
							enter: 700,
							exit: 300
						}}
						transitiontimingfunction="cubic-bezier(0.4, 0, 0.2, 1)"
					>
						<ListItemText
							primaryTypographyProps={{
								fontSize: '14px',
								paddingTop: '3px',
								fontWeight:
									(type === 'link' && checkSelected(path)) || (type === 'menu' && isMenuOpen)
										? 'bold'
										: null
							}}
							primary={title !== 'Covalent' ? title : ''}
							sx={{
								// opacity: open ? 1 : 0,fontWeight: (type === 'link' && checkSelected(path)) || (type === 'menu' && isMenuOpen)?'bold':null,
								background: 'transparent',
								fontSize: '0.75rem'
							}}
						/>
					</Fade>
				)}
				{/* </motion.div> */}
			</ListItemButton>
		</ListItem>
	);
}

CustomList.propTypes = {
	open: PropTypes.bool.isRequired,
	activeIcon: PropTypes.string.isRequired,
	inActiveIcon: PropTypes.string.isRequired,
	title: PropTypes.string.isRequired,
	linkHandler: PropTypes.func,
	iconPadding: PropTypes.string,
	selected: PropTypes.string,
	path: PropTypes.string,
	buttonHandler: PropTypes.func,
	type: PropTypes.oneOf(['link', 'button', 'menu']),
	isMenuOpen: PropTypes.bool
};

CustomList.defaultProps = {
	linkHandler: () => {},
	iconPadding: '0.5px 0px 0px 0px',
	buttonHandler: () => {},
	type: 'link',
	isMenuOpen: false,
	selected: '',
	path: ''
};

export default CustomList;
