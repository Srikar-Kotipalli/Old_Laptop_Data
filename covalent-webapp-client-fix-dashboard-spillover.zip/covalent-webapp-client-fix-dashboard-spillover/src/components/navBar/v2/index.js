/* eslint-disable react/jsx-no-bind */
/* eslint-disable no-unsafe-optional-chaining */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { Auth } from 'aws-amplify';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import MuiDrawer from '@mui/material/Drawer';
import Skeleton from '@mui/material/Skeleton';
import Grid from '@mui/material/Grid';
import List from '@mui/material/List';
import Tooltip from '@mui/material/Tooltip';
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import useMediaQuery from '@mui/material/useMediaQuery';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Menu from '@mui/material/Menu';
import Fade from '@mui/material/Fade';
import ListItemIcon from '@mui/material/ListItemIcon';
// import { motion } from 'framer-motion';
import MenuItem from '@mui/material/MenuItem';
import covalentExperimentsIcon from '../../../assets/navbar/active/dispatches.svg';
import covalentSharedIcon from '../../../assets/navbar/active/share.svg';
import covalentHardwareIcon from '../../../assets/hardware/hardware.svg';
import HomeIcon from '../../../assets/navbar/active/home.svg';
import EnvironmentsIcon from '../../../assets/logos/environmentsV2.svg';
import SettingsIcon from '../../../assets/navbar/active/settings.svg';
import BillingIcon from '../../../assets/navbar/active/billing.svg';
import AlertIcon from '../../../assets/navbar/active/alert.svg';
import LogoutIcon from '../../../assets/navbar/active/logout.svg';
import HomeIconInactive from '../../../assets/navbar/home.svg';
import ProjectsIconInactive from '../../../assets/navbar/dispatches.svg';
import EnvironmentIconInactive from '../../../assets/navbar/environment.svg';
import SharedIconInactive from '../../../assets/navbar/shared.svg';
import ComputeIconInactive from '../../../assets/navbar/compute.svg';
import AlertIconInactive from '../../../assets/navbar/alert.svg';
import SettingsIconInactive from '../../../assets/navbar/settings.svg';
import BillingIconInactive from '../../../assets/navbar/billing.svg';
import LogOutIconInactive from '../../../assets/navbar/logout.svg';
import CashIcon from '../../../assets/navbar/cash.svg';
import ActiveCash from '../../../assets/navbar/active/cash.svg';
import CaretLeft from '../../../assets/arrows/caretLeft.svg';
import CaretRight from '../../../assets/arrows/caretRight.svg';
import CovalentLogo from '../../../assets/logos/covalentLogo.svg';
import CovalentLogoText from '../../../assets/logos/covalentLogoText.svg';
import { setUser } from '../../../redux/commonSlice';
import routes from '../../../constants/routes.json';
import CustomList from '../../list/navbar';
import { getActivityList } from '../../../api/activity/activityApi';
import { getUserCharges } from '../../../api/billing/billingApi';
import Icon from '../../icon';
import OverflowTooltip from '../../tooltip/overflowTooltip';
import { statusTitle } from '../../../utils/statusIcons';
import Loader from '../../loader';
import { getTimeDifference } from '../../../utils/utils';
import useDidMountEffect from '../../../utils/useDidMountEffect';
import { toggleNavbar } from '../../../redux/navbarSlice';
import CustomScrolls from '../../customScroll/v2';

const drawerWidth = 160;

const openedMixin = theme => ({
	width: drawerWidth,
	transition: theme.transitions.create('width', {
		easing: theme.transitions.easing.easeInOut, // Change to ease-in-out
		duration: theme.transitions.duration.enteringScreen * 2
	}),
	overflowX: 'hidden'
});

const closedMixin = theme => ({
	transition: theme.transitions.create('width', {
		easing: theme.transitions.easing.easeInOut, // Change to ease-in-out
		duration: theme.transitions.duration.leavingScreen * 2
	}),
	overflowX: 'hidden',
	width: `calc(${theme.spacing(8)} + 1px)`,
	[theme.breakpoints.up('sm')]: {
		width: `calc(${theme.spacing(9)} + 1px)`
	}
});

const Drawer = styled(MuiDrawer, { shouldForwardProp: prop => prop !== 'open' })(
	({ theme, open }) => ({
		width: drawerWidth,
		flexShrink: 0,
		whiteSpace: 'nowrap',
		boxSizing: 'border-box',

		...(open && {
			...openedMixin(theme),
			'& .MuiDrawer-paper': {
				...openedMixin(theme),
				background: theme.palette.background.blue10,
				marginTop: 16,
				marginLeft: 16,
				height: '95vh',
				borderRadius: '10px',
				transitions: 'borderRadius 0.3s ease-in-out'
			}
		}),
		...(!open && {
			...closedMixin(theme),
			'& .MuiDrawer-paper': {
				...closedMixin(theme),
				background: theme.palette.background.blue10,
				marginTop: 16,
				marginLeft: 16,
				height: '95vh',
				borderRadius: '20px',
				transitions: 'borderRadius 0.3s ease-in-out'
			}
		})
	})
);

function MiniDrawer({ open }) {
	// props doc
	// ------------------------------------------------------------------------------------
	// open :  navbar open or close state variable
	// setOpen : It is set state function for open
	// -------------------------------------------------------------------------------------

	const loc = useLocation();
	const navigate = useNavigate();
	const dispatch = useDispatch();
	const liveRefresh = useSelector(({ socket }) => socket?.canCallAPI);

	const styledRoute = window?.localStorage?.getItem('path');
	const [picture, setPicture] = useState(null);
	const [selected, setSelected] = useState(styledRoute);
	const [anchorEl, setAnchorEl] = useState(null);
	const [avatar, setAvatar] = useState('');
	const [userDetails, setUserDetails] = useState({});
	const [avatarNameTooltip, setAvatarNameTooltip] = useState('');
	const containerRef = useRef(null);
	const [activityList, setActivityList] = useState([]);
	const [openActivityLoader, setOpenActivityLoader] = useState(false);
	const [charges, setCharges] = useState(null);
	const [isChargesLoading, setIsChargesLoading] = useState(true);

	const opend = Boolean(anchorEl);

	const navigationItems = [
		{
			title: 'Home',
			activeIcon: HomeIcon,
			inActiveIcon: HomeIconInactive,
			path: routes?.DASHBOARD
		},
		{
			title: 'Dispatches',
			activeIcon: covalentExperimentsIcon,
			inActiveIcon: ProjectsIconInactive,
			path: routes?.DISPATCHES
		},
		{
			title: 'Shared',
			activeIcon: covalentSharedIcon,
			inActiveIcon: SharedIconInactive,
			path: routes?.SHARED
		},
		{
			title: 'Env & Secrets',
			activeIcon: EnvironmentsIcon,
			inActiveIcon: EnvironmentIconInactive,
			path: routes?.ENVIRONMENTS
		},
		{
			title: 'Compute',
			activeIcon: covalentHardwareIcon,
			inActiveIcon: ComputeIconInactive,
			path: routes?.HARDWARE
		}
	];

	const handleDrawer = () => {
		setAnchorEl(null);
		// setOpen(prev => !prev);
		dispatch(toggleNavbar());
	};

	const onClickHandler = path => {
		// setIsMenuOpen(false);
		navigate(path);
		if (path === '/settings') setAnchorEl(null);
	};

	const handleClose = () => {
		setAnchorEl(null);
	};

	const handleClick = event => {
		setAnchorEl(event.currentTarget);
	};

	// const creditBalance = (payableAmountMicrodollars, totalCredits) => {
	// 	let finalAmount;
	// 	if (payableAmountMicrodollars > totalCredits) {
	// 		finalAmount = '$0.00 USD';
	// 		console.log('balance', Math.abs(totalCredits - payableAmountMicrodollars));
	// 	} else {
	// 		const creditsLeft = (totalCredits - payableAmountMicrodollars) / 1000000;
	// 		finalAmount = creditsLeft.toString();
	// 	}
	// 	return finalAmount;
	// };

	const handleSignout = () => {
		Auth.signOut()
			.then(() => {
				localStorage.setItem('AUTH_ACCESS_TOKEN', null);
				localStorage.setItem('AUTH_ID_TOKEN', null);
				window.localStorage.setItem('path', null);
				sessionStorage.clear();
				localStorage.setItem('api_key', null);
				navigate(routes?.LOGIN);
			})
			.catch(() => {
				console.log('Error signing out');
			});
	};

	useEffect(() => {
		window?.localStorage.setItem('path', loc?.pathname?.slice(1));
		// if (loc?.pathname?.slice(1)?.includes('graph')) {
		// 	window.localStorage.setItem('path', 'graph');
		// 	setSelected('');
		// } else {
		setSelected(window?.localStorage?.getItem('path'));
		// }
	}, [loc]);

	useEffect(() => {
		setOpenActivityLoader(true);
		getActivityList(20)
			.then(payload => {
				const activityListPayload = payload?.items?.map(e => {
					return { ...e, sub_category: e.sub_category || 'Blank' };
				});
				setOpenActivityLoader(false);
				setActivityList(activityListPayload);
			})
			.catch(error => {
				setOpenActivityLoader(false);
				console.log(error);
			});

		Auth.currentAuthenticatedUser().then(user => {
			setUserDetails(user?.attributes);
			setIsChargesLoading(true);
			dispatch(setUser({ user }));
			const res =
				user?.attributes?.given_name || user?.attributes?.family_name || user?.attributes?.email;
			setAvatarNameTooltip(res?.charAt(0)?.toUpperCase() + res?.slice(1));
			const initial = res?.charAt(0)?.toUpperCase();
			setAvatar(initial);
			const pictureAttribute = user?.attributes?.picture;
			setPicture(pictureAttribute);
			const response = user?.attributes;
			const userID = response && response['custom:userID'];
			getUserCharges(userID)
				.then(payload => {
					if (payload) {
						setCharges(payload);
					}
					setIsChargesLoading(false);
				})
				.catch(() => {
					setCharges('null');
					setIsChargesLoading(false);
				});
		});
	}, []);

	useDidMountEffect(() => {
		getActivityList(20)
			.then(payload => {
				const activityListPayload = payload?.items?.map(e => {
					return { ...e, sub_category: e.sub_category || 'Blank' };
				});
				setActivityList(activityListPayload);
			})
			.catch(error => {
				console.log(error);
			});
	}, [liveRefresh]);

	const isWideScreen = useMediaQuery('(min-height: 1000px)');
	const isMediumScreen = useMediaQuery('(min-height: 900px)');
	const isMediumScreen2 = useMediaQuery('(min-height: 850px)');
	const isSmallScreen = useMediaQuery('(max-height: 600px)');

	const getHeightByScreenHeight = () => {
		if (isWideScreen) {
			return '89%';
		} else if (isMediumScreen) {
			return '88%';
		} else if (isMediumScreen2) {
			return '86%';
		}
		return '84%';
	};

	return (
		<Box sx={{ display: 'flex', position: 'relative' }}>
			<Box
				id="expandIcon"
				sx={{
					display: 'flex',
					position: 'fixed',
					background: theme => theme?.palette?.background?.blue03,
					width: '20px',
					height: '20px',
					left: open ? 165 : 80,
					top: 49,
					borderRadius: '46px',
					zIndex: 1500,
					transition: 'left 0.3s ease-in-out'
				}}
			>
				<Icon
					src={open ? CaretLeft : CaretRight}
					padding={open ? '0px 1px 5px 1px' : '0px 1px 5px 2px'}
					clickHandler={handleDrawer}
				/>
			</Box>
			<Drawer variant="permanent" open={open}>
				<List sx={{ background: 'transparent', height: '100%' }}>
					<Grid mb={4} mt={3} ref={containerRef}>
						{open && (
							<Fade
								in={open}
								direction="right"
								container={containerRef.current}
								timeout={{
									enter: 500,
									exit: 300
								}}
								transitiontimingfunction="cubic-bezier(0.4, 0, 0.2, 1)"
							>
								<ListItemIcon
									sx={{
										minWidth: '30px',
										height: '30px',
										mr: open ? 1 : 'auto',
										justifyContent: 'center',
										display: 'flex',
										alignItems: 'center'
									}}
								>
									<Icon
										type="static"
										src={CovalentLogoText}
										// padding={iconPadding}
									/>
								</ListItemIcon>
							</Fade>
						)}
						{!open && (
							<Fade
								in={!open}
								direction="left"
								container={containerRef?.current}
								timeout={{
									enter: 700,
									exit: 300
								}}
								transitiontimingfunction="cubic-bezier(0.4, 0, 0.2, 1)"
							>
								<ListItemIcon
									sx={{
										minWidth: '30px',
										height: '30px',
										mr: open ? 1 : 'auto',
										justifyContent: 'center',
										display: 'flex',
										alignItems: 'center'
									}}
								>
									<Icon type="static" src={CovalentLogo} />
								</ListItemIcon>
							</Fade>
						)}
					</Grid>
					{/* Main grid component */}
					<Grid
						container
						direction="column"
						justifyContent="space-between"
						sx={{ height: getHeightByScreenHeight() }}
					>
						{/* First grid component */}
						<Grid item sx={{ height: isSmallScreen ? '30%' : null }}>
							{navigationItems?.map(item => (
								<CustomList
									key={item?.title}
									inActiveIcon={item?.inActiveIcon}
									activeIcon={item?.activeIcon}
									title={item?.title}
									open={open}
									selected={selected}
									path={item?.path}
									linkHandler={() => onClickHandler(item?.path)}
								/>
							))}
						</Grid>
						{/* Second grid component */}
						<Grid item sx={{ height: isSmallScreen ? '30%' : null }}>
							<CustomList
								open={open}
								activeIcon={AlertIcon}
								inActiveIcon={AlertIconInactive}
								title="Alerts"
								type="menu"
								buttonHandler={handleClick}
								isMenuOpen={opend}
							/>

							<Menu
								variant="menu"
								anchorEl={anchorEl}
								open={opend}
								onClose={handleClose}
								keepMounted={false}
								anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
								transformOrigin={{ vertical: 'bottom', horizontal: 'left' }}
								PaperProps={{
									style: {
										maxHeight: '244px',
										width: '171px',
										transform: open
											? 'translateX(118px) translateY(25px)'
											: 'translateX(60px) translateY(25px)'
									}
								}}
							>
								<CustomScrolls variant="light">
									<Box sx={{ height: '244px' }}>
										{openActivityLoader && (
											<Box sx={{ height: '244px', width: '171px' }}>
												<Loader
													isFetching={openActivityLoader}
													height="100%"
													width="100%"
													position="position"
												/>
											</Box>
										)}
										{!openActivityLoader && activityList?.length < 0 && (
											<Box
												sx={{
													height: '244px',
													width: '171px',
													display: 'flex',
													alignItems: 'center',
													justifyContent: 'center'
												}}
											>
												<Typography
													sx={{ fontSize: '12px', color: theme => theme?.palette?.text?.secondary }}
												>
													No Alerts to display
												</Typography>
											</Box>
										)}
										{!openActivityLoader &&
											activityList?.length > 0 &&
											activityList?.map(item => (
												<MenuItem
													key={`${item?.item_id}-${item?.sub_category}`}
													sx={{
														display: 'flex',
														flexDirection: 'column',
														alignItems: 'start',
														borderBottom: '1px solid',
														borderColor: theme => theme?.palette?.background?.covalentPurple
													}}
													onClick={() => navigate(`${routes?.GRAPH}/${item?.item_id}`)}
												>
													<Box sx={{ display: 'flex', alignItems: 'center' }}>
														<OverflowTooltip
															title={`${item?.category} ${item?.title} `}
															length={item?.sub_category?.toLowerCase() === 'completed' ? 9 : 12}
															fontSize="12px"
															color={theme => theme?.palette?.text?.secondary}
														/>
														<Typography
															variant="h3"
															sx={{
																color: theme => theme?.palette?.text?.secondary,
																margin: '0 4px'
															}}
														>
															is
														</Typography>
														{statusTitle(
															item?.sub_category,
															item?.sub_category?.toLowerCase(),
															'',
															'',
															'h3'
														)}
													</Box>
													<Typography sx={{ fontSize: '8px' }}>
														{getTimeDifference(item?.created_at)}
													</Typography>
												</MenuItem>
											))}
									</Box>
								</CustomScrolls>
							</Menu>
							<CustomList
								open={open}
								handleDrawer={handleDrawer}
								activeIcon={BillingIcon}
								inActiveIcon={BillingIconInactive}
								title="Billing"
								selected={selected}
								path={routes?.BILLING}
								linkHandler={() => onClickHandler(routes?.BILLING)}
							/>
							<CustomList
								open={open}
								handleDrawer={handleDrawer}
								activeIcon={SettingsIcon}
								inActiveIcon={SettingsIconInactive}
								title="Settings"
								selected={selected}
								path={routes?.SETTINGS}
								linkHandler={() => onClickHandler(routes?.SETTINGS)}
							/>
							<CustomList
								open={open}
								handleDrawer={handleDrawer}
								activeIcon={LogoutIcon}
								inActiveIcon={LogOutIconInactive}
								title="Logout"
								buttonHandler={() => handleSignout()}
								type="button"
							/>
							<Grid
								py={2}
								sx={{ display: 'flex', justifyContent: 'center', width: open ? '160px' : '70px' }}
							>
								<Divider
									style={{
										backgroundColor: '#86869A66',
										height: '0.5px',
										width: open ? '130px' : '34px',
										transition: 'width 0.5s ease-in-out'
									}}
								/>
							</Grid>

							{open ? (
								<Stack direction="row" spacing={1} px={2.5} mt={2}>
									{picture ? (
										<Tooltip title={avatarNameTooltip}>
											<Grid sx={{ cursor: 'pointer' }}>
												<img
													src={picture}
													alt="Avatar Placeholder"
													style={{
														width: '32px',
														height: '32px',
														borderRadius: '50%',
														cursor: 'pointer'
													}}
												/>
											</Grid>
										</Tooltip>
									) : (
										<Avatar style={{ width: 32, height: 32 }}>{avatar}</Avatar>
									)}
									<Fade
										in={open}
										direction="left"
										timeout={{
											enter: 500,
											exit: 300
										}}
										transitiontimingfunction="cubic-bezier(0.4, 0, 0.2, 1)"
									>
										<Box>
											<OverflowTooltip
												title={userDetails?.name}
												length={9}
												fontSize="15px"
												color={theme => theme?.palette?.text?.primary}
												open={open}
											/>
											<OverflowTooltip
												position="right"
												title={userDetails?.email}
												length={15}
												fontSize="10px"
												color={theme => theme?.palette?.text?.gray03}
												open={open}
											/>
										</Box>
									</Fade>
								</Stack>
							) : (
								<Stack direction="row" spacing={1} px={2.5} mt={2}>
									{/* these are dummy created to maintain navbar alignments */}
									<Tooltip title={userDetails?.name} placement="top">
										<Avatar style={{ width: 32, height: 32 }}>{avatar}</Avatar>
									</Tooltip>
									<Box>
										<OverflowTooltip title="a" length={12} fontSize="15px" color="transparent" />
										<OverflowTooltip title="a" length={12} fontSize="10px" color="transparent" />
									</Box>
								</Stack>
							)}
							{open ? (
								<Grid container spacing={1.5} px={2.5} mt={1.5}>
									<Grid item mt={0.5}>
										<Icon src={CashIcon} alt="cash" type="static" />
									</Grid>
									<Fade
										in={open}
										direction="left"
										timeout={{
											enter: 500,
											exit: 300
										}}
										transitiontimingfunction="cubic-bezier(0.4, 0, 0.2, 1)"
									>
										<Grid item>
											<Box>
												{!isChargesLoading ? (
													<OverflowTooltip
														fontSize="12px"
														length={10}
														color={theme => theme.palette.text.success}
														title={charges?.discounts?.remaining_display_price || '-'}
													/>
												) : (
													<Skeleton variant="text" sx={{ fontSize: '12px' }} />
												)}
												<Typography color={theme => theme.palette.text.gray03} fontSize="10px">
													Credit balance
												</Typography>
											</Box>
										</Grid>
									</Fade>
								</Grid>
							) : (
								<Grid container spacing={1.5} px={2.5} mt={1.5}>
									<Grid item mt={0.5}>
										<Icon
											src={ActiveCash}
											alt="cash"
											type="static"
											title={
												`Credit Balance: ${charges?.discounts?.remaining_display_price}` || '-'
											}
											placement="right"
										/>
									</Grid>
									<Grid item>
										<Box>
											<OverflowTooltip title="a" length={12} fontSize="12px" color="transparent" />
											<OverflowTooltip title="a" length={12} fontSize="10px" color="transparent" />
										</Box>
									</Grid>
								</Grid>
							)}
						</Grid>
					</Grid>
				</List>
				{/* <Divider /> */}
			</Drawer>
			{/* </DrawerContainer> */}
		</Box>
	);
}

export default MiniDrawer;
