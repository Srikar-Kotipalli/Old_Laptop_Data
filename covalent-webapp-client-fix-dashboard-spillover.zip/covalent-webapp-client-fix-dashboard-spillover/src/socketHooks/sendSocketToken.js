/* eslint-disable import/prefer-default-export */
import { useEffect, useRef, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { socketConnection } from '../redux/socketSlice';

export const sendSocketToken = () => {
	const socket = useRef(WebSocket);
	console.log('Socket val: ', socket);
	const dispatch = useDispatch();
	const SERVICE_URL = process.env.REACT_APP_ENDPOINT_URL_WEBSOCKET;

	// Event listener to when the socket opens
	const onSocketOpen = useCallback(() => {
		if (socket?.current?.readyState) {
			console.log('Socket ready: ', socket?.current?.readyState);
			socket.current?.send(
				JSON.stringify({
					action: 'connectionMapper',
					token: localStorage.getItem('AUTH_ACCESS_TOKEN')
				})
			);
			dispatch(socketConnection());
		}
	}, []);

	useEffect(() => {
		console.log('Socket in env details: ', socket.current);
		if (socket.current?.readyState !== WebSocket.OPEN) {
			socket.current = new WebSocket(SERVICE_URL);
			socket.current.addEventListener('open', onSocketOpen);
		}
	}, []);
};
