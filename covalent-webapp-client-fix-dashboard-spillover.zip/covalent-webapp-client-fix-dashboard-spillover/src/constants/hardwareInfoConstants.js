/* eslint-disable import/prefer-default-export */
/* eslint-disable import/no-unused-modules */

export const sampleInput = [
	{
		id: 0,
		name: 'IBM Quantum',
		status: 'online',
		amount: '$1234',
		core: '##',
		memory: '###',
		type: 'Classical',
		key: 'd2d8bf3f-2a02-4408-bb21-ffaab7'
	},
	{
		id: 10,
		name: 'IonQ',
		status: 'offline',
		amount: '$1234',
		core: '##',
		memory: '###',
		type: 'Classical',
		key: ''
	},
	{
		id: 11,
		name: 'Rigetti',
		status: 'NA',
		amount: '$1234',
		core: '##',
		memory: '###',
		type: 'Classical',
		key: ''
	},
	// {
	// 	id: 12,
	// 	name: 'Toshiba',
	// 	status: 'NA',
	// 	amount: '$1234',
	// 	core: '##',
	// 	memory: '###',
	// 	type: 'Classical',
	// 	key: ''
	// },
	{
		id: 13,
		name: 'Azure',
		status: 'NA',
		amount: '$1234',
		core: '##',
		memory: '###',
		type: 'Classical',
		key: ''
	},
	{
		id: 14,
		name: 'AWS',
		status: 'NA',
		amount: '$1234',
		core: '##',
		memory: '###',
		type: 'Classical',
		key: ''
	},
	{
		id: 15,
		name: 'Nvidia',
		status: 'NA',
		amount: '$1234',
		core: '##',
		memory: '###',
		type: 'Classical',
		key: ''
	},
	// {
	// 	id: 16,
	// 	name: 'Dwave',
	// 	status: 'NA',
	// 	amount: '$1234',
	// 	core: '##',
	// 	memory: '###',
	// 	type: 'Classical',
	// 	key: ''
	// },
	{
		id: 17,
		name: 'Google cloud',
		status: 'NA',
		amount: '$1234',
		core: '##',
		memory: '###',
		type: 'Classical',
		key: ''
	}
];

export const hardwareInfoSettings = [
	{
		id: 1,
		name: 'Dapper Dachshund',
		status: 'NA',
		amount: '$1234',
		core: '##',
		memory: '###',
		type: 'Classical',
		key: ''
	},
	{
		id: 2,
		name: 'Handcrafted Habanero',
		status: 'NA',
		amount: '$1234',
		core: '##',
		memory: '###',
		type: 'Classical',
		key: ''
	},
	{
		id: 3,
		name: 'Jazzy Jellybean',
		status: 'NA',
		amount: '$1234',
		core: '##',
		memory: '###',
		type: 'Classical',
		key: ''
	}
];
