/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
export const DISPATCH_HEADER = [
	{ label: 'Title', align: 'left', width: '20%', id: 'title' },
	{ label: 'Status', align: 'left', width: '8%', id: 'status' },
	{ label: 'Tags', align: 'left', width: '28%', id: 'tags' },
	{ label: 'Runtime', align: 'left', width: '9%', id: 'runTime' },
	{ label: 'Start time', align: 'left', width: '12%', id: 'startTime' },
	{ label: 'Last updated', align: 'left', width: '12%', id: 'lastUpdated' },
	{ label: '', align: 'left', width: '2%', id: 'copy' },
	{ label: '', align: 'left', width: '2%', id: 'contextmenu' }
];

export const SUBLATTICE_HEADER = [
	{ label: 'Title', align: 'left', width: '30%', id: 'name', paddingLeft: '1.1rem' },
	{ label: 'Runtime', align: 'left', width: '5%', id: 'runtime' },
	{ label: 'Status', align: 'left', width: '5%', id: 'completed_task_num' }
];

export const BILLING_HEADER = [
	{ label: 'Invoice No.', align: 'left', width: '18%', id: 'id' },
	{ label: 'Payment Status', align: 'left', width: '15%', id: 'payment_status' },
	{ label: 'Date', align: 'left', width: '15%', id: 'issued_date' },
	{ label: 'Issue Type', align: 'left', width: '15%', id: 'external_issuing_type' },
	{ label: 'Amount', align: 'left', width: '15%', id: 'total_amount_currency' }
	// { label: '', align: 'left', width: '5%', id: 'actionsmenu' }
];

export const SOLVERS_HEADER = [
	{ label: 'Title', align: 'left', width: '20%', id: 'title' },
	{ label: 'Status', align: 'left', width: '8%', id: 'status' },
	{ label: 'Tags', align: 'left', width: '28%', id: 'tags' },
	{ label: 'Runtime', align: 'left', width: '9%', id: 'runTime' },
	{ label: 'Start time', align: 'left', width: '12%', id: 'startTime' },
	{ label: 'Cost', align: 'left', width: '12%', id: 'cost' },
	{ label: '', align: 'left', width: '2%', id: 'copy' },
	{ label: '', align: 'left', width: '2%', id: 'contextmenu' }
];

export const JOBQUEUE_HEADER = [
	{ label: 'Job Id', align: 'left', width: '12%', id: 'job_id' },
	{ label: 'Status', align: 'center', width: '6%', id: 'status' },
	{ label: 'User', align: 'left', id: 'user' },
	{ label: 'Organization', align: 'left', id: 'organization' },
	{ label: 'Hardware', align: 'left', id: 'hardware' },
	{ label: 'Started', align: 'left', id: 'started' },
	{ label: 'Completed', align: 'left', id: 'completed' },
	{ label: 'Pricing', align: 'left', id: 'pricing' }
];
