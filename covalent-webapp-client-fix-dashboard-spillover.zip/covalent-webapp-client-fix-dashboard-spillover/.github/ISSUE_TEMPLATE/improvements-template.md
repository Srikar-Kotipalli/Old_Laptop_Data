---
name: Improvements template
about: Any feature improvements to be recorded
title: IMP-
labels: improvements
assignees: ''

---

**Description**

**Current implementation**

**Expected output**

**Additional information**