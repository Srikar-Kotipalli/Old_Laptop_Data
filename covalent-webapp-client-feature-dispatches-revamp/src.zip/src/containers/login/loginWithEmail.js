/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable react/jsx-no-bind */
/* eslint-disable no-unused-vars */

/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useContext, useEffect } from 'react';
import { CognitoHostedUIIdentityProvider } from '@aws-amplify/auth';
import { useNavigate } from 'react-router-dom';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { withStyles } from '@mui/styles';
import { Box, Divider, Grid, Link } from '@mui/material';
import { compose } from 'redux';
import { Auth } from 'aws-amplify';
import LoginInput from '../../components/inputBase/projects/loginInput';
import WithMediaQuery from '../../utils/useMediaQuery';
import { LoginContext } from './loginContext';
import googleLogin from '../../assets/login/googleColorLogo.svg';
import './style.css';
import ArrowRightIcon from '../../assets/arrows/arrowRightLogin.svg';
import Icon from '../../components/icon';

const styles = theme => ({
	container: {
		height: '100vh',
		minHeight: '100%',
		display: 'flex',
		justifyContent: 'center'
	}
});

function LoginWithEmail(props) {
	const loginContext = useContext(LoginContext);
	const {
		setMode,
		setOpenSnackbar,
		setSnackbarMessage,
		setOpenLoader,
		setCognitoUser,
		email,
		setEmail,
		setUsername,
		setRegisterMode
	} = loginContext;
	const [password, setPassword] = useState('');
	const disableInfo = useState(true);
	const setDisable = disableInfo[1];
	const forgotPasswordInfo = useState(true);
	const setForgotPasswordDisable = forgotPasswordInfo[1];
	const [errorUsername, setErrorUserName] = useState('');
	const [errorPassword, setErrorPassword] = useState('');
	const { isMobile } = props;
	const navigate = useNavigate();

	window.onpopstate = () => {
		setMode('login');
	};

	const signIn = () => {
		setOpenLoader(true);
		Auth.signIn(email?.trim(), password)
			.then(user => {
				if (user && user.challengeName === 'NEW_PASSWORD_REQUIRED') {
					setCognitoUser(user);
					setOpenLoader(false);
					setMode('setNewPassword');
				} else if (user && user.challengeName !== 'NEW_PASSWORD_REQUIRED') {
					setOpenSnackbar(true);
					setOpenLoader(false);
					setSnackbarMessage('User logged in successfully!');
					navigate('/');
				}
			})
			.catch(error => {
				setOpenLoader(false);
				if (error?.message === 'User is disabled.') {
					// eslint-disable-next-line react/no-unescaped-entities
					error.message = (
						<Typography fontSize="14px">
							We&apos;re almost there! We&apos;re currently finalizing the setup of your account. If
							you need urgent access, please contact us at{' '}
							<Link
								href="mailto:support@agnostiq.ai"
								sx={{
									color: '#6473FF !important',
									fontSize: '14px',
									textDecorationColor: '#6473FF',
									cursor: 'pointer'
								}}
							>
								{process.env.REACT_APP_AQ_SUPPORT_EMAIL}
							</Link>
						</Typography>
					);
				} else if (error?.code === 'InvalidParameterException') {
					error.message = 'Invalid fields.';
				}
				setSnackbarMessage(error?.message);
				setOpenSnackbar(true);
			});
	};

	useEffect(() => {
		if (errorUsername) {
			setErrorUserName(email ? '' : errorUsername);
		}
		if (errorPassword) {
			setErrorPassword(password ? '' : errorPassword);
		}
		setDisable(!(email && !/\s/.test(email?.trim()) && password));
		setForgotPasswordDisable(!(email && !/\s/.test(email?.trim())));
	}, [email, password]);

	const validateInput = () => {
		if (!email) {
			setDisable(false);
			setErrorUserName('Email/ Username is mandatory!');
			return;
		}
		if (!password) {
			setDisable(false);
			setErrorPassword('Password is mandatory!');
			return;
		}
		signIn();
	};

	async function googleLoginCode() {
		await Auth.federatedSignIn({ provider: CognitoHostedUIIdentityProvider.Google });
	}

	return (
		<Grid container display={!isMobile && 'contents'} justifyContent="center">
			<Typography className="head-label-requestAccess" fontSize={!isMobile ? '27px' : '20px'}>
				Login to your account
			</Typography>
			<Grid item xs={12} mb={!isMobile ? '42px' : '20px'} maxHeight="32px">
				<Box>
					<Typography
						display="flex"
						alignItems="center"
						justifyContent="center"
						variant="h2"
						sx={{
							height: '32px',
							'@media (max-width: 430px)': {
								height: '40px'
							}
						}}
					>
						Don&apos;t have an account?
						<Typography
							component="div"
							sx={{
								paddingLeft: '8px',
								color: '#6473FF',
								cursor: 'pointer',
								display: 'flex',
								alignItems: 'center',
								fontSize: '14px',
								'&:hover': {
									textDecoration: 'underline'
								}
							}}
							onClick={() => {
								setEmail('');
								setUsername('');
								setRegisterMode('register');
								navigate('/register');
							}}
						>
							Sign up
							<Icon rowType="experimentRow" src={ArrowRightIcon} alt="ArrowRightIcon" />
						</Typography>
					</Typography>
				</Box>
			</Grid>
			<Grid
				item
				className="scroll-container"
				sx={{
					justifyContent: 'center',
					border: '1px solid #303067',
					borderRadius: '8px',
					maxHeight: isMobile ? '100vh' : '420px',
					// overflowY: isMobile && 'scroll',
					// minHeight: !isMobile && '550px',
					// paddingTop: isMobile ? '25px' : '0px',
					// position: 'absolute',
					// top: '50%',
					width: !isMobile && '468px',
					maxWidth: '468px',
					margin: isMobile && '0px 10px',
					background: 'linear-gradient(309deg, #08081A -0.75%, rgba(8, 8, 26, 0.00) 108.66%)',
					boxShadow: '0px 5px 9px 0px rgba(0, 0, 0, 0.45)'
					// transform: 'translate(0%, -50%)'
				}}
				xs={12}
				md={4}
			>
				<div style={{ padding: !isMobile ? '34px 83px 58px' : '20px' }}>
					{/* <Grid container spacing={2} mb={3}>
						<Grid item xs={12}>
							<Button
								variant="outlined"
								disableElevation
								startIcon={<img src={googleLogin} alt="google" />}
								sx={{
									height: '32px',
									fontSize: '14px',
									'@media (max-width: 430px)': {
										height: '40px',
										fontSize: '14px'
									},
									width: '100%',
									borderRadius: '8px',
									border: '1px solid #86869A',
									background: 'var(--base-black, #08081A)',
									color: '#CBCBD7',
									':hover': {}
								}}
								onClick={googleLoginCode}
							>
								Google
							</Button>
						</Grid>
					</Grid>
					<Divider className="auth-divider">or continue with email</Divider> */}
					<Box>
						<Box sx={{ mb: 3, mt: 1 }}>
							<LoginInput
								name="loginusername"
								autoComplete="email"
								id="loginusername"
								value={email !== null ? email : ''}
								handleChange={setEmail}
								type="field"
								error={errorUsername}
								placeholderTxt="Email/ Username"
								width="100%"
								handleEnter={validateInput}
							/>
						</Box>
						<Box>
							<LoginInput
								name="loginPassword"
								id="loginPassword"
								autoComplete="new-password"
								value={password !== null ? password : ''}
								handleChange={setPassword}
								type="field"
								typeInput="password"
								placeholderTxt="Password"
								error={errorPassword}
								width="100%"
								handleEnter={validateInput}
							/>
						</Box>
						<Typography
							sx={{
								padding: '24px 0px 10px',
								color: '#ffff',
								textDecoration: 'underline',
								cursor: 'pointer',
								fontSize: '12px',
								width: 'fit-content'
							}}
							onClick={() => setMode('forgotPassword')}
						>
							Forgot password?
						</Typography>
						<Button
							variant="outlined"
							disableElevation
							sx={{
								width: '100%',
								height: '32px',
								backgroundColor: theme => theme.palette.background.default,
								'&:hover': {
									backgroundColor: theme => theme.palette.background.covalentPurple,
									color: theme => theme.palette.text.secondary,
									borderRadius: '25px',
									borderColor: theme => theme.palette.background.blue05
								},
								color: 'white',
								marginTop: '25px'
							}}
							onClick={() => validateInput()}
						>
							Login
						</Button>
					</Box>
					<Box>
						<Grid container spacing={1} sx={{ mt: 1.8 }}>
							<Grid item xs={12}>
								<Box>
									<Typography
										display="flex"
										alignItems="center"
										justifyContent="center"
										variant="h2"
										sx={{
											height: '32px',
											'@media (max-width: 430px)': {
												height: '40px'
											}
										}}
									>
										Already Signed Up?
										<Typography
											component="div"
											sx={{
												paddingLeft: '10px',
												color: '#6473FF',
												cursor: 'pointer',
												display: 'flex',
												alignItems: 'center',
												fontSize: '14px',
												'&:hover': {
													textDecoration: 'underline'
												}
											}}
											onClick={() => setMode('verifyUser')}
										>
											Verify User
											<Icon rowType="experimentRow" src={ArrowRightIcon} alt="ArrowRightIcon" />
										</Typography>
									</Typography>
								</Box>
							</Grid>
						</Grid>
					</Box>
				</div>
			</Grid>
		</Grid>
	);
}

export default compose(
	withStyles(styles, {
		name: 'Login'
	}),
	WithMediaQuery([['isMobile', theme => theme.breakpoints.down('sm')]])
)(LoginWithEmail);
