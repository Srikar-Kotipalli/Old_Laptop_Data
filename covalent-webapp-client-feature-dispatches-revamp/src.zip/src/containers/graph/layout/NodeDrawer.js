/* eslint-disable react/no-array-index-key */
/* eslint-disable no-unused-vars */
import React, { useContext } from 'react';
import { Box, Typography, Grid, Button, Skeleton, Tooltip } from '@mui/material';
import NodeData from './NodeData';
import CodeAccordion from './CodeAccordion';
import ElectronCount from '../../../assets/graph/electronCount.svg';
import Runtime from '../../../assets/graph/runtime.svg';
import RunningIcon from '../../../assets/graph/accordion/status.svg';
import NodeParameter from './NodeParameter';
import { Prettify, timeFormatter } from '../../../utils/utils';
import { GraphContext } from '../contexts/GraphContext';
import Container from '../../../assets/graph/container.svg';
import Folder from '../../../assets/graph/folder.svg';
import Cost from '../../../assets/graph/accordion/CostImg.svg';
import nodeRunning from '../../../assets/graph/nodeRunning.svg';
import nodeComplete from '../../../assets/graph/nodeComplete.svg';
import nodeFailed from '../../../assets/graph/nodeFailed.svg';
import nodeNew from '../../../assets/graph/nodeNew.svg';
import noStatus from '../../../assets/dispatch/noStatus.svg';

import Timer from '../../../assets/graph/accordion/Runtime.svg';

import spcCpuIcon from '../../../assets/specifications/spc-cpu.svg';
import spcMemoryIcon from '../../../assets/specifications/spc-memory.svg';
import spcTimerIcon from '../../../assets/specifications/spc-timer.svg';
import spcGatewayIcon from '../../../assets/specifications/spec-gateway-api.svg';
import spcGpuIcon from '../../../assets/specifications/spec-gpu.svg';
import spcEnvIcon from '../../../assets/specifications/spec-env.svg';

function NodeDrawer({ isSublattice, isSelected = false, nodeData }) {
	const {
		setTabValue,
		latticeDetails,
		errorFunctions,
		sublatticeDetails,
		selectedNodeResult,
		selectedNodeResultCopy,
		GraphPreview,
		isFetchingNodeData,
		isFetchingGraph,
		nodeCost
	} = useContext(GraphContext);

	const getStatusIcon = status => {
		if (status === 'COMPLETED') return nodeComplete;
		else if (status === 'RUNNING') return nodeRunning;
		else if (status === 'FAILED') return nodeFailed;
		else if (status === 'NEW_OBJECT') return nodeNew;
		return noStatus;
	};

	const calculateRuntime = (details, mode) => {
		if (details?.length > 0) {
			const data = details?.filter(e => e?.type !== 'parameter');
			data?.sort((a, b) => {
				const dateA = new Date(a?.runtime);
				const dateB = new Date(b?.runtime);
				if (mode === 'min') {
					return dateA - dateB;
				}
				return dateB - dateA;
			});
			if (data?.length && (data[0]?.runtime || data[0]?.runtime === 0))
				return `${data[0]?.runtime?.toFixed(2)}s`;
			return '-';
		}
		return '-';
	};

	const metrics = [
		{
			heading: 'Total Electrons',
			value: isSublattice ? sublatticeDetails?.task_num : latticeDetails?.task_num,
			imgSrc: ElectronCount
		},
		{
			heading: 'Avg Runtime',
			value: isSublattice
				? (sublatticeDetails?.runtime || sublatticeDetails?.runtime === 0) &&
				  timeFormatter(sublatticeDetails?.runtime)
				: (latticeDetails?.runtime || latticeDetails?.runtime === 0) &&
				  timeFormatter(latticeDetails?.runtime),
			imgSrc: Runtime
		}
	];
	const electronMetrics = [
		{ heading: 'Status', value: nodeData?.status, imgSrc: getStatusIcon(nodeData?.status) },
		// {
		// 	heading: 'qelectrons',
		// 	value: nodeData?.qelectrons ? nodeData?.qelectrons : '-',
		// 	imgSrc: Qelectron
		// },
		{
			heading: 'Cost',
			value: nodeCost || '-',
			imgSrc: Cost
		},
		{
			heading: 'Start Time',
			value: nodeData?.started_at
				? nodeData?.started_at?.substring(0, nodeData?.started_at?.indexOf('T'))
				: '-',
			imgSrc: RunningIcon
		},
		{
			heading: 'Runtime',
			value: nodeData?.runtime ? `${nodeData?.runtime}s` : nodeData?.runtime,
			imgSrc: Timer,
			started_at: nodeData?.started_at,
			completed_at: nodeData?.completed_at
		}
	];
	const nodeParameters = [
		{
			heading: 'Shortest Runtime',
			time: calculateRuntime(GraphPreview?.nodes, 'min'),
			imgSrc: spcTimerIcon
		},
		{
			heading: 'Longest Runtime',
			time: calculateRuntime(GraphPreview?.nodes, 'max'),
			imgSrc: spcTimerIcon
		},
		{
			heading: 'Total Errors in Graph',
			time: errorFunctions?.metadata?.total_count,
			imgSrc: Container
		}
	];
	const electronSelectedData = [
		{ heading: 'CPU Shares', value: nodeData?.executor?.cpu_shares, imgSrc: spcCpuIcon },
		{ heading: 'Memory', value: nodeData?.executor?.memory, imgSrc: spcMemoryIcon },
		{ heading: 'GPUs', value: nodeData?.executor?.num_gpus, imgSrc: spcGpuIcon },
		{ heading: 'GPU Type', value: nodeData?.executor?.gpu_type, imgSrc: spcGatewayIcon },
		{ heading: 'Time Limit', value: nodeData?.executor?.time_limit, imgSrc: spcTimerIcon },
		{ heading: 'Environment', value: nodeData?.executor?.environment_name, imgSrc: spcEnvIcon }
	];

	const getHeader = (sublattice, selected) => {
		if (sublattice) {
			return (
				<Box
					sx={{
						display: 'flex',
						background: '#303067',
						padding: '20px 0px 20px 20px',
						marginBottom: '-20px',
						width: '100%',
						alignItems: 'center'
					}}
				>
					<img src={Folder} alt="folder" />
					<Typography variant="graphNodeDrawer" sx={{ marginLeft: '11px', cursor: 'default' }}>
						Sub Lattice Information
					</Typography>
					<Box sx={{ padding: '0px 0px 0 16px' }}>
						<Button
							variant="contained"
							sx={{
								height: '24px',
								color: '#CBCBD7',
								backgroundColor: '#5552FF',
								borderRadius: '70px',
								':hover': {
									background: '#3633ff'
								}
							}}
							onClick={() => setTabValue('Detail View')}
						>
							View More
						</Button>
					</Box>
				</Box>
			);
		} else if (selected) {
			return (
				<>
					<Box sx={{ padding: '20px 16px 0 16px' }}>
						{isFetchingNodeData ? (
							<Skeleton variant="rounded" width={90} height={26} />
						) : (
							<div style={{ overflow: 'hidden', textOverflow: 'ellipsis', width: '8rem' }}>
								<Tooltip title={Prettify(nodeData?.name)} placement="top">
									<Typography
										variant="graphNodeDrawer"
										noWrap
										sx={{
											marginBottom: '5px',
											cursor: 'default'
										}}
									>
										{nodeData?.name && Prettify(nodeData?.name)}
									</Typography>
								</Tooltip>
							</div>
						)}
					</Box>
					{!isFetchingNodeData && (
						<Box sx={{ padding: '20px 10px 0 16px' }}>
							<Button
								variant="contained"
								sx={{
									height: '24px',
									color: '#CBCBD7',
									backgroundColor: '#5552FF',
									borderRadius: '70px',
									':hover': {
										background: '#3633ff'
									}
								}}
								onClick={() => setTabValue('Detail View')}
							>
								View More
							</Button>
						</Box>
					)}
				</>
			);
		}
		return (
			<>
				<Box sx={{ padding: '20px 16px 0 16px' }}>
					<Typography variant="graphNodeDrawer" sx={{ cursor: 'default' }}>
						Overview
					</Typography>
				</Box>
				<Box sx={{ padding: '20px 10px 0 16px' }}>
					<Button
						variant="contained"
						sx={{
							height: '24px',
							color: '#CBCBD7',
							backgroundColor: '#5552FF',
							borderRadius: '70px',
							':hover': {
								background: '#3633ff'
							}
						}}
						onClick={() => setTabValue('Detail View')}
					>
						View More
					</Button>
				</Box>
			</>
		);
	};

	return (
		<Box sx={{ border: '1px solid #303067', borderRadius: '8px' }}>
			<Box display="flex" flexDirection="row" justifyContent="space-between">
				{getHeader(isSublattice, isSelected)}
			</Box>
			<Box sx={{ padding: '20px 16px 20px 16px' }}>
				{isSelected ? null : (
					<Typography
						sx={{
							margin: '5px 0 24px 0',
							color: theme => theme.palette.text.primary,
							fontSize: '14px',
							fontWeight: '400',
							padding: '0px 10px 10px 0px',
							cursor: 'default'
						}}
					>
						Please click on an electron within the graph to view detailed information such as
						description, inputs, outputs, runtime, errors, and code.
					</Typography>
				)}
				<Grid container rowSpacing={3} sx={{ marginBottom: '54px' }}>
					{isSelected && !isSublattice
						? electronMetrics?.map((info, index) => (
								<Grid item xs={6} sx={{ display: 'flex' }} key={index}>
									<Box sx={{ marginLeft: '3px' }}>
										<NodeData
											heading={info?.heading}
											value={info?.value}
											imgSrc={info?.imgSrc}
											type="titleValue"
											isLoading={isFetchingNodeData}
											started_at={info?.started_at}
											completed_at={info?.completed_at}
											fontSize="16px"
											sklHeight={25}
										/>
									</Box>
								</Grid>
						  ))
						: metrics?.map((info, index) => (
								<Grid item xs={6} sx={{ display: 'flex' }} key={index}>
									<Box sx={{ marginLeft: index === 0 ? '0px' : '30px' }}>
										<NodeData
											heading={info?.heading}
											value={info?.value}
											imgSrc={info?.imgSrc}
											type="titleValue"
											fontSize="16px"
											isLoading={isFetchingNodeData}
											sklHeight={26}
											sklWidth={25}
										/>
									</Box>
								</Grid>
						  ))}
				</Grid>
				{isSelected && !isSublattice && nodeData?.status === 'COMPLETED' ? (
					<Box sx={{ marginBottom: '24px' }}>
						<CodeAccordion
							containerWidth="100%"
							heading="Result"
							code={selectedNodeResult}
							codeCopy={selectedNodeResultCopy}
							forValue="node"
						/>
					</Box>
				) : null}
				<Box>
					<Typography
						sx={{
							color: theme => theme.palette.text.gray03,
							fontSize: '12px',
							fontWeight: '400',
							marginBottom: '15px',
							cursor: 'default'
						}}
					>
						{isSelected && !isSublattice ? 'Specifications' : 'Quick Facts'}
					</Typography>
					{isSelected && !isSublattice
						? electronSelectedData.map((info, index) => (
								<Box sx={{ marginBottom: '19px' }} key={index}>
									<NodeParameter
										heading={info?.heading}
										time={info?.value}
										imgSrc={info?.imgSrc}
										isFetching={isFetchingNodeData}
										backgroundColor="rgba(28, 28, 70, 0.40)"
									/>
								</Box>
						  ))
						: nodeParameters.map((info, index) => (
								<Box sx={{ marginBottom: '19px' }} key={index}>
									<NodeParameter
										heading={info?.heading}
										time={info?.time}
										imgSrc={info?.imgSrc}
										isFetching={isFetchingGraph}
										backgroundColor="rgba(28, 28, 70, 0.40)"
									/>
								</Box>
						  ))}
				</Box>
			</Box>
		</Box>
	);
}

export default NodeDrawer;
