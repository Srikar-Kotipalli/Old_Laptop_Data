/* eslint-disable react/no-array-index-key */
import React, { useState } from 'react';
import { Box, Grid, IconButton, Input, Typography } from '@mui/material';
import { RemoveCircleOutline } from '@mui/icons-material';
import Icon from '../../../components/icon';
import ViewOff from '../../../assets/actions/showOff.svg';
import View from '../../../assets/actions/show.svg';
import Add from '../../../assets/actions/addKey.svg';

// eslint-disable-next-line no-unused-vars
function KeyValueInput({ initialPairs, visible = true, setContent }) {
	const [pairs, setPairs] = useState(initialPairs || [{ name: '', value: '', sensitive: false }]);
	const [inputTypes, setInputTypes] = useState(initialPairs.map(() => visible));
	const [newKey, setNewKey] = useState('');
	const [newValue, setNewValue] = useState('');
	// const [keyVisible, setKeyVisible] = useState(false);
	const [inputValidation, setInputValidation] = useState({
		name: '',
		value: ''
	});
	const handleInputChange = (index, name, value) => {
		const updatedPairs = [...pairs];
		updatedPairs[index] = { name, value, sensitive: inputTypes[index] };
		setPairs(updatedPairs);
		setContent(updatedPairs);
	};

	const toggleVisibility = index => {
		const updatedInputTypes = [...inputTypes];
		updatedInputTypes[index] = !updatedInputTypes[index];
		setInputTypes(updatedInputTypes);
		const updatedPairs = [...pairs];
		updatedPairs[index].sensitive = updatedInputTypes[index];
		setPairs(updatedPairs);
		setContent(updatedPairs);
	};

	const handleAddPair = () => {
		if (newKey?.trim() === '') {
			setInputValidation(prevState => ({
				...prevState,
				name: 'Variable name cannot be empty'
			}));
			setTimeout(
				() =>
					setInputValidation({
						name: '',
						value: ''
					}),
				3000
			);
			return;
		}
		if (newValue?.trim() === '') {
			setInputValidation(prevState => ({
				...prevState,
				value: 'Variable value cannot be empty'
			}));
			setTimeout(
				() =>
					setInputValidation({
						name: '',
						value: ''
					}),
				3000
			);
			return;
		}
		if (newKey.trim() !== '' && newValue.trim() !== '') {
			const newPair = { name: newKey, value: newValue, sensitive: false };
			setPairs([...pairs, newPair]);
			setContent([...pairs, newPair]);
			setInputTypes([...inputTypes, false]);
			setNewKey('');
			setNewValue('');
		}
	};
	// setContent(pairs);

	const handleKeyEnter = event => {
		if (event.key === 'Enter') handleAddPair();
	};

	const handleRemovePair = index => {
		const updatedPairs = [...pairs];
		const updatedInputTypes = [...inputTypes];
		updatedPairs?.splice(index, 1);
		updatedInputTypes?.splice(index, 1);
		setPairs(updatedPairs);
		setContent(updatedPairs);
		setInputTypes(updatedInputTypes);
	};

	return (
		<Grid container spacing={2}>
			<Grid item xs={6} ml={3} pb={1}>
				<Box display="flex" justifyContent="space-between">
					<Typography fontSize="12px" fontWeight="700">
						Key
					</Typography>
					<Typography> </Typography>
					<Typography fontSize="12px" fontWeight="700">
						Value
					</Typography>
					<Typography fontSize="12px" fontWeight="700">
						Hidden
					</Typography>
					<Typography> </Typography>
				</Box>
			</Grid>
			<Grid item xs={6} ml={2} sx={{ position: 'relative' }}>
				<Box
					sx={{
						borderRadius: '7px',
						textAlign: 'center',
						display: 'flex',
						justifyContent: 'space-between',
						paddingRight: '2px'
					}}
				>
					<Box>
						<Input
							placeholder="Add Name"
							value={newKey}
							onChange={e => setNewKey(e?.target?.value)}
							disableUnderline
							autoComplete="new-password"
							onKeyDown={handleKeyEnter}
							sx={{
								border: inputValidation?.name ? '1px solid #FF6464' : '1px solid #303067',
								borderRadius: '7px',
								height: '32px',
								width: '114px',
								padding: '0px 12px',
								'& input::placeholder': {
									textAlign: 'center !important',
									fontSize: '14px !important'
								}
							}}
						/>
						<Typography sx={{ color: '#FF6464', fontSize: '12px', height: '20px' }}>
							{inputValidation?.name && 'Name is mandatory'}
						</Typography>
					</Box>
					<Box>
						<Input
							placeholder="Add Value"
							value={newValue}
							onChange={e => setNewValue(e?.target?.value)}
							disableUnderline
							onKeyDown={handleKeyEnter}
							autoComplete="off"
							sx={{
								border: inputValidation?.value ? '1px solid #FF6464' : '1px solid #303067',
								borderRadius: '7px',
								height: '32px',
								width: '114px',
								padding: '0px 12px',
								'& input::placeholder': {
									textAlign: 'center !important',
									fontSize: '14px !important'
								}
							}}
						/>
						<Typography sx={{ color: '#FF6464', fontSize: '12px' }}>
							{inputValidation?.value && 'Value is mandatory'}
						</Typography>
					</Box>
					<Box sx={{ height: '32px' }}>
						{/* Icon hidden */}
						{/* <Icon
							clickHandler={() => setKeyVisible(prev => !prev)}
							src={keyVisible ? View : ViewOff}
							title={keyVisible ? 'Hide' : 'Show'}
						/> */}
					</Box>
					<Grid sx={{ width: '47px' }} />
					<Grid sx={{ position: 'absolute', right: -10 }}>
						<Icon src={Add} clickHandler={handleAddPair} title="Add" />
					</Grid>
				</Box>
			</Grid>
			<Grid
				item
				xs={6}
				ml={1}
				mt={2}
				className="keyValue"
				sx={{ maxHeight: '250px', overflowY: 'auto' }}
			>
				{pairs?.map((pair, index) => (
					<Box key={index}>
						<Box
							sx={{
								borderRadius: '7px',
								textAlign: 'center',
								padding: '10px',
								display: 'flex',
								justifyContent: 'space-between'
							}}
						>
							<Input
								placeholder="Key Name"
								disableUnderline
								autoComplete="new-password"
								sx={{
									border: '1px solid #303067',
									borderRadius: '7px',
									height: '32px',
									padding: '0px 12px',
									width: '114px',
									'& input::placeholder': {
										textAlign: 'center !important',
										fontSize: '14px !important'
									}
								}}
								value={pair.name}
								onChange={e => handleInputChange(index, e.target.value, pair.value)}
							/>
							<Input
								placeholder="Key Value"
								disableUnderline
								sx={{
									border: '1px solid #303067',
									borderRadius: '7px',
									height: '32px',
									width: '114px',
									'& input::placeholder': {
										textAlign: 'center !important',
										fontSize: '14px !important'
									},
									padding:
										!inputTypes[index] && pair?.value ? '6px 12px 0px 12px' : '0px 12px 0px 12px'
								}}
								readOnly={!inputTypes[index]}
								value={inputTypes[index] ? pair?.value : '*'.repeat(pair?.value?.length)}
								onChange={e => handleInputChange(index, pair.name, e.target.value)}
							/>
							<IconButton onClick={() => toggleVisibility(index)}>
								{inputTypes[index] ? (
									<Icon src={View} title="Hide" />
								) : (
									<Icon src={ViewOff} title="Show" />
								)}
							</IconButton>
							<IconButton onClick={() => handleRemovePair(index)}>
								<RemoveCircleOutline color="error" fontSize="small" />
							</IconButton>
						</Box>
					</Box>
				))}
			</Grid>
		</Grid>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default KeyValueInput;
