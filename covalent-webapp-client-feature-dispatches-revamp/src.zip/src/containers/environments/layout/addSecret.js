import React, { useState, useEffect, useRef } from 'react';
import {
	Box,
	Typography,
	InputBase,
	FormControl,
	Button,
	Grid,
	FormHelperText
} from '@mui/material';
import WarningIcon from '../../../assets/environments/redWarning.svg';
import Icon from '../../../components/icon';

function AddSecret(props) {
	const {
		count,
		mode,
		setMode,
		setOpenDialogBox,
		setDeleteSecret,
		setSecretName,
		setLabel,
		setError,
		error,
		editSecretName,
		fetchApi,
		setEditSecretName,
		storedData
	} = props;

	const [sname, setSname] = useState(editSecretName);
	const [slabel, setSlabel] = useState('');
	const inputRef = useRef();

	useEffect(() => {
		setSlabel('');
		setSname('');
	}, [fetchApi]);

	useEffect(() => {
		if (mode === 'edit') {
			inputRef?.current?.focus();
		}
	}, [mode]);

	useEffect(() => {
		setSname(editSecretName);
		setSlabel('');
	}, [editSecretName]);

	const handleSaveChanges = () => {
		setSecretName(sname);
		setLabel(slabel);

		setDeleteSecret(false);
		if (!sname && !slabel) {
			setError('all');
		} else {
			if (!sname) {
				setError('secretName');
			} else if (!slabel) {
				setError('secret');
			}
		}
		if (sname && slabel) {
			if (storedData?.includes(sname) && mode === 'create') {
				setError('available');
			} else if (sname?.length > 32) {
				setError('limit');
			} else if (!slabel?.trim()) {
				setError('empty');
			} else {
				setOpenDialogBox(true);
			}
		}
	};

	const handleCancel = () => {
		// Add logic to handle cancel
		setSname('');
		setSlabel('');
		setMode('create');
		setError('');
		setEditSecretName('');
	};

	return (
		<Grid sx={{ display: 'flex', flexDirection: 'column' }}>
			<>
				<Typography mb={2} sx={{ color: theme => theme?.palette?.text?.secondary }}>
					{mode === 'create' ? 'Create New Secret' : 'Edit Secret'}
				</Typography>
				{count >= 100 && mode === 'create' ? (
					<Box sx={{ display: 'flex', width: '60%' }}>
						<Icon src={WarningIcon} />
						<Typography ml={2} variant="h2" sx={{ color: theme => theme?.palette?.text?.failed }}>
							Limit of 100 secrets has been reached. Delete some secrets to create new ones
						</Typography>
					</Box>
				) : (
					<>
						<Box sx={{ display: 'flex', flexDirection: 'column' }}>
							<Box sx={{ height: '55px' }}>
								<InputBase
									readOnly={mode === 'edit'}
									data-testid="secretsInputBase"
									name="noAutoFill"
									id="secretsName"
									placeholder="Your_secret_name"
									className="secretInput"
									fullWidth
									value={sname}
									onChange={e => {
										setError('');
										// Validate against the regex
										const newValue = e?.target?.value;
										if (!/^[A-Za-z0-9_-]*$/?.test(newValue)) {
											setError('invalidChars');
											setTimeout(() => {
												setError('');
											}, 3000);
										} else {
											setSname(newValue);
										}
									}}
									inputProps={{
										autoComplete: 'off'
									}}
									sx={{
										border: theme => `1px solid ${theme.palette.background.blue03}`,
										padding: '8px 12px',
										borderRadius: '20px',
										color: mode === 'edit' ? '#5a5a69' : '#F1F1F6',
										height: '32px',
										width: '300px',
										'&:hover': {
											border: theme => `1px solid ${theme.palette.text.gray04}`,
											padding: '8px 12px'
										},
										'&.Mui-focused ': {
											border:
												mode === 'create' &&
												(theme => `1px solid ${theme.palette.background.blue05}`),
											padding: '8px 12px'
										}
									}}
								/>

								<FormHelperText
									sx={{
										color: theme => theme.palette.text.failed,
										marginLeft: '15px',
										marginTop: 0
									}}
								>
									{error === 'available' && 'This secret name already exists.'}
									{(error === 'all' || error === 'secretName') && 'This field cannot be empty'}
									{error === 'limit' && 'Secret name must not be greater than 32 characters long'}
									{error === 'invalidChars' &&
										'Only letters, numbers, underscores, and hyphens are allowed.'}
								</FormHelperText>
							</Box>

							<Box sx={{ marginTop: '5px', height: '110px' }}>
								<FormControl>
									{/* No need for TextareaAutosize, use InputBase for multiline */}
									<InputBase
										multiline
										inputRef={inputRef}
										rows={3} // Set the number of rows to 3
										placeholder={
											mode === 'create' ? 'Enter your Secret value' : 'Enter your new Secret value'
										}
										value={slabel}
										onChange={e => {
											setError('');
											setSlabel(e?.target?.value);
										}}
										sx={{
											border: theme =>
												mode === 'create'
													? `1px solid ${theme?.palette?.background?.blue03}`
													: `1px solid ${theme.palette.background.blue05}`,
											backgroundColor: theme => theme?.palette?.background?.default,
											padding: '8px 12px',
											borderRadius: '7px',
											width: '390px',
											'&:hover': {
												border: theme => `1px solid ${theme.palette.text.gray04}`,
												padding: '8px 12px'
											},
											'&.Mui-focused ': {
												border: theme => `1px solid ${theme?.palette?.background?.blue05}`
											}
										}}
									/>
									<FormHelperText sx={{ color: theme => theme?.palette?.text?.failed }}>
										{(error === 'all' || error === 'secret' || error === 'empty') &&
											'This field cannot be empty'}
									</FormHelperText>
								</FormControl>
							</Box>
						</Box>
						<Box mt={2}>
							<Button
								variant="contained"
								color="primary"
								// disabled={!secretName || !label}
								sx={{
									background: '#5552FF',
									fontSize: '14px',
									padding: '8px 16px',
									height: '32px',
									minWidth: '163px',
									color: 'white',
									borderRadius: '70px',
									marginRight: '20px',
									'&:disabled': {
										background: theme => theme?.palette?.background?.covalentPurple,
										color: theme => theme?.palette?.text?.secondary,
										border: '1px solid',
										borderColor: theme => theme?.palette?.background?.blue04,
										borderRadius: '70px'
									},
									'&:hover': {
										background: '#3633ff'
									}
								}}
								onClick={handleSaveChanges}
							>
								Save Changes
							</Button>
							<Button
								variant="contained"
								onClick={handleCancel}
								sx={{
									background: '#08081A',
									fontSize: '14px',
									padding: '8px 16px',
									height: '32px',
									color: 'white',
									borderRadius: '70px',
									'&:hover': {
										backgroundColor: '#2A2A5C'
									},
									'&:disabled': {
										color: theme => theme?.palette?.text?.gray03
									}
								}}
							>
								Cancel
							</Button>
						</Box>
					</>
				)}
			</>
		</Grid>
	);
}

export default AddSecret;
