/* eslint-disable no-unused-vars */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useEffect, forwardRef, useCallback, useRef } from 'react';
import { useDebounce } from 'use-debounce';
import { Grid, Typography, useMediaQuery, Box } from '@mui/material';
import YAML from 'yaml';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import { VirtuosoGrid } from 'react-virtuoso';
import OverviewHeader from '../../components/overviewHeader';
import Breadcrumb from '../../components/breadcrumb';
import SubHeaderControls from '../../components/subHeaderControls';
import {
	deleteEnivronment,
	getBatchEnvironments,
	getDefaultEnvironment,
	getYamlFile,
	getEnvironment,
	setDefaultEnvironment
} from '../../api/environments/environmentsApi';
import Icon from '../../components/icon';
import covLoader from '../../assets/loaders/covLoader.svg';
import Warning from '../../assets/environments/warning.svg';
import EnvironmentImage from '../../assets/environments/overviewIcon.svg';
import './style.css';
import CovalentCard from '../../components/card';
import EnvCardOverviewLayout from '../../components/card/layouts/environments/environments';
import CustomisedSnackbar from '../../components/snackbar/projects';
import useUpdateEffect from '../../utils/useUpdateEffect';
import CommonTab from '../../components/tab/graph';
import Secrets from './layout/secrets';
import urls from '../../constants/routes.json';
import EnvironmentProvider from './contexts/EnivironmentsContext';
import { setEnvPage } from '../../redux/environmentSlice';

const gridComponents = {
	List: forwardRef(({ style, children }, ref) => (  // List is the container.
		<Grid container
			ref={ref}
			style={{
				display: 'flex',
				flexWrap: 'wrap',
				...style
			}}
		>
			{children}
		</Grid>
	)),
	Item: ({ children }) => (  		// Each individual item
		<Grid item xs={12} sm={6} md={4} lg={4} xl={3}
			style={{
				padding: '12px'
			}}
		>
			{children}
		</Grid>
	)
};

const FooterComponent = () => (
	< Grid
		xs={12}
		container
		item
		height="10rem"
		direction="row"
		justifyContent="center"
		alignSelf="center"
	>
		<Icon type="pointer" src={covLoader} display="flex" />
	</Grid >
);

// Layout for all the items in the grid
const ItemWrapper = ({ children }) => (
	<Box
		style={{
			display: 'flex',
			width: '100%'
		}}
	>
		{children}
	</Box>
);

function Environments() {
	const [envData, setEnvData] = useState({});
	const [appendedEnvData, setAppendedEnvData] = useState([]);
	const [dataFetched, setDataFetched] = useState(false);
	const [openLoader, setOpenLoader] = useState(true);
	const [sort, setSort] = useState('asc');
	const [sortBy, setSortBy] = useState('status');
	const [searchKey, setSearchKey] = React.useState('');
	const [searchValue] = useDebounce(searchKey, 1000);
	const [reloadBatch, setReloadBatch] = useState(true);
	const [deleteId, setDeleteId] = useState(0);
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState('');
	const [isDefaultEnvPresent, setIsDefaultEnvPresent] = React.useState(true);
	const [cName, setCName] = useState('');
	const [value, setValue] = useState('Environments');
	const environmentAction = useDispatch();
	const { envPage } = useSelector(state => state.environment);
	const data = {
		name: 'Environments',
		desc: 'Manage & Create your compute environments'
	};
	const location = useLocation();

	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);
	const socketData = useSelector(({ socket }) => socket.socketData);

	const secretData = {
		name: 'Environment Management',
		desc: 'Manage & Create your environments secrets'
	};

	const updateEnvRecordFromSocket = id => {
		// update the environment which is received from socket
		getEnvironment(id).then(res => {
			const indexToUpdate = envData?.records?.findIndex(e => e.id === id) ?? -1;
			const envResponseData = { ...envData };
			const envRecords = envResponseData?.records;
			const recordToUpdate = envRecords?.find(e => e.id === id);
			// update the package data along with the status
			getYamlFile(res?.definition)
				.then(file => {
					const parsedData = YAML.parse(file?.data);
					if (recordToUpdate && (indexToUpdate ?? -1) !== -1 && envRecords?.length > 0) {
						recordToUpdate.status = res?.status;
						recordToUpdate.parsedData = parsedData;
						envResponseData['records'] = envRecords;
						setEnvData(envResponseData);
					}
				})
				.catch(error => {
					console.error('Error parsing YAML:', error);
					return res;
				});
		});
	};

	useUpdateEffect(() => {
		if (socketData?.message === 'environment') {
			const envIdVal = socketData?.env_id;
			if (Object.keys(envData)?.length !== 0) {
				updateEnvRecordFromSocket(envIdVal);
			}
		}
	}, [liveRefresh]);

	const [page, setPage] = useState(1);
	const [ceiledPage, setCeiledPage] = useState();
	const [totalRecords, setTotalRecords] = useState(0);
	const [offset, setOffset] = useState(0);
	const [isNoRecords, setIsNoRecords] = useState(false);
	const extraSmallScreen = useMediaQuery('(max-height: 599px)');
	const smallScreen = useMediaQuery('(min-height:600px) and (max-height: 899px)');
	const mediumScreen = useMediaQuery('(min-height:900px) and (max-height: 1199px)');
	const largeHeight = useMediaQuery('(min-height: 1200px) and (max-height: 1439px)');
	const extraLargeHeight = useMediaQuery('(min-height: 1400px)');
	// console.log('media query', extraSmallScreen, smallScreen, mediumScreen, largeHeight, extraLargeHeight);
	const handleScreenHeight = () => {
		if (extraSmallScreen) {
			return 8;
		} else if (smallScreen) {
			return 12;
		} else if (mediumScreen) {
			return 16;
		} else if (largeHeight) {
			return 20;
		} else if (extraLargeHeight) {
			return 32;
		}
		return 12;
	};
	const recordsPerPage = handleScreenHeight();

	const handlePageChanges = (_event, pageValue) => {
		setPage(pageValue);
		environmentAction(setEnvPage({ envPage: pageValue }));
		const offsetValue = pageValue === 1 ? 0 : (pageValue - 1) * recordsPerPage;
		setOffset(offsetValue);
	};

	const LoadNextPage = () => {
		if (totalRecords > recordsPerPage) {
			setPage(prevOffset => prevOffset + 1);
		}
	};

	// const handleAppendEnvdata = (newEnvData) => {
	// 	console.log('isDataAppended', isDataAppended);
	// 	if (!isDataAppended && newEnvData) {
	// 		setIsNoRecords(false);
	// 		setOpenLoader(false);
	// 	}
	// 	console.log('isDataAppended after', isDataAppended);
	// };

	const onDelete = id => {
		deleteEnivronment(id)
			.then(() => {
				// After successful deletion, update the UI by reloading the data
				setDeleteId(id);
				setReloadBatch(!reloadBatch); // Toggle reloadBatch to trigger a re-fetch
				setSnackbarMessage(`Environment ${cName} has been deleted successfully`);
				setOpenSnackbar(true);
			})
			.catch(error => {
				// Handle error if the delete operation fails
				// console.error('Error deleting environment:', error);
				setSnackbarMessage(
					error?.detail ? error?.detail : 'Something went wrong please contact the administrator'
				);
				setOpenSnackbar(true);
			});
	};

	const setDefault = name => {
		setDefaultEnvironment(name)
			.then(_res => {
				setReloadBatch(!reloadBatch);
			})
			.finally(() => {
				setSnackbarMessage(`Environment ${cName} set as default.`);
				setOpenSnackbar(true);
			})
			.catch(err => {
				setSnackbarMessage(
					err?.detail ? err.detail : 'Something went wrong, contact administrator'
				);
				setOpenSnackbar(true);
			});
	};

	const postGetBatch = response => {
		getDefaultEnvironment()
			.then(resDefault => {
				const indexDefault = response?.records?.findIndex(e => e.id === resDefault?.environment_id);
				if (!resDefault?.environment_id) setIsDefaultEnvPresent(false);
				if (indexDefault !== -1) {
					const records = response?.records;
					records[indexDefault]['default'] = true;
					response.records = records;
					setEnvData(response);
					setTotalRecords(response?.metadata?.total_count);
					setDataFetched(true);
				} else {
					setEnvData(response);
					setTotalRecords(response?.metadata?.total_count);
					setDataFetched(true);
				}
			})
			.catch(() => {
				setEnvData(response);
				setTotalRecords(response?.metadata?.total_count);
			})
			.finally(() => {
				console.log('response', response);
				let ceiledValue = 0;
				if (response && response?.metadata) {
					ceiledValue = Math.ceil((response.metadata.total_count) / recordsPerPage);
					setCeiledPage(ceiledValue);
				}
				if (page >= ceiledValue)
					setIsNoRecords(true);
				if (page > 1) {
					if (response && response?.records) {
						setAppendedEnvData(existingData => [...existingData, ...response.records]);
					}
				} else {
					setAppendedEnvData(response?.records);
				}
				setOpenLoader(false);
				console.log('ceiledPage', ceiledPage);
				console.log('page', page);
			});
	};

	const fetchEnvData = () => {
		const pageVal = searchValue ? 0 : page - 1;
		const apiSearchVal = searchKey === '' ? '' : searchValue;
		console.log('api params', recordsPerPage, pageVal, apiSearchVal, sortBy, sort);
		getBatchEnvironments(recordsPerPage, pageVal, apiSearchVal, sortBy, sort)
			.then(response => {
				Promise.all(
					response?.records?.map(record => {
						return getYamlFile(record?.definition)
							.then(file => {
								const parsedData = YAML.parse(file?.data);
								return { ...record, parsedData };
							})
							.catch(error => {
								console.error('Error parsing YAML:', error);
								return record; // Fallback to original record on error
							});
					})
				)
					.then(parsedRecords => {
						const updatedResponse = {
							...response,
							records: parsedRecords
						};
						postGetBatch(updatedResponse);
					})
					.catch(() => {
						postGetBatch({});
					});
			})
			.catch(() => {
				postGetBatch({});
			});
	};

	// useEffect(() => {
	// 	if (envData?.records?.length > 0) {
	// 		handleAppendEnvdata(envData?.records);
	// 		let ceiledPage = 0;
	// 		if (envData && envData?.metadata)
	// 			ceiledPage = Math.ceil((envData.metadata.total_count) / recordsPerPage);
	// 		if (ceiledPage && (page >= ceiledPage)) {
	// 			setIsNoRecords(true);
	// 		}
	// 	}
	// }, [envData]);

	const prevSearchValue = useRef(searchValue);
	const prevSortValue = useRef(sort);
	const prevSortByValue = useRef(sortBy);
	useEffect(() => {
		if (value === 'Environments') {
			if (prevSearchValue.current !== searchValue || prevSortValue.current !== sort || prevSortByValue.current !== sortBy) {
				setPage(1);
				setIsNoRecords(false);
				setAppendedEnvData([]);
				setOpenLoader(true);
				prevSearchValue.current = searchValue;
				prevSortValue.current = sort;
				prevSortByValue.current = sortBy;
				console.log('ceiledPage', ceiledPage);
				if (ceiledPage && ceiledPage === 1) {
					fetchEnvData();
					console.log('calling page1');
					return;
				}
			}
			console.log('calling fn');
			fetchEnvData();
		}
	}, [reloadBatch, deleteId, value, page, searchValue, sort, sortBy]);

	// useUpdateEffect(() => {
	// 	setAppendedEnvData([]);
	// 	setIsDataAppended(false);
	// 	if (value === 'Environments') {
	// 		setOpenLoader(true);
	// 		if (searchValue === '') {
	// 			setPage(1);
	// 		}
	// 	}
	// }, [searchValue]);

	// useUpdateEffect(() => {
	// 	if (value === 'Environments') {
	// 		setAppendedEnvData([]);
	// 		setIsDataAppended(false);
	// 		setOpenLoader(true);
	// 		if (page === 1) {
	// 			fetchEnvData();
	// 		} else setPage(1);
	// 	}
	// }, [sort, sortBy]);

	const onTabChange = (_e, val) => {
		setValue(val);
		setSearchKey('');
	};
	// eslint-disable-next-line react/no-unstable-nested-components
	const CustomCovalentCard = (dataEnv) => (
		<ItemWrapper>
			<EnvCardOverviewLayout
				key={dataEnv?.id}
				envData={dataEnv}
				onDelete={onDelete}
				onDefault={setDefault}
				setCName={setCName}
			/>{' '}
		</ItemWrapper>
	);
	return (
		<>
			<CustomisedSnackbar
				testId="envSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			{/* // Commenting this as this is dummy data and can be uncomment to check this placeholder data. */}
			{/* <Breadcrumb secondary="Organization" name="Environments" to="/environments" /> */}
			<OverviewHeader data={value !== 'Secrets' ? data : secretData} image={EnvironmentImage} />
			<Box mt={3}>
				<CommonTab
					firstValue="Environments"
					secondValue="Secrets"
					value={value}
					onChange={onTabChange}
				/>
			</Box>
			<Grid container maxWidth="90%">
				{value === 'Environments' && (
					<SubHeaderControls
						width="102.2%"
						filterComponent
						sortComponenet={value === 'Environments'}
						sort={sort}
						setSort={setSort}
						sortBy={sortBy}
						setSortBy={setSortBy}
						searchValue={searchKey}
						setSearchValue={setSearchKey}
						placement={value !== 'Secrets' ? 'add' : null}
						isDisable={openLoader}
					/>
				)}
				{value === 'Secrets' && (
					<EnvironmentProvider>
						<Secrets searchKey={searchKey} setSearchKey={setSearchKey} />
					</EnvironmentProvider>
				)}
				{value === 'Environments' && !isDefaultEnvPresent && !envData?.records?.length < 1 && (
					<Grid
						mt={5}
						item
						sx={{
							background: theme => theme?.palette?.background?.paper,
							borderRadius: '8px',
							border: '1px solid',
							padding: '10px 18px 10px 15px',
							borderColor: theme => theme?.palette?.background?.blue03
						}}
					>
						<Typography fontSize={14}>
							<Icon type="default" src={Warning} />
							There is no user default environment set up
						</Typography>
					</Grid>
				)}
				{value === 'Environments' && (
					<Grid
						container
						mt={5}
						ml={0.8}
						className="envcardContainer"
						sx={{ borderColor: theme => theme?.palette?.background?.blue03 }}
						spacing={3}
					>
						{openLoader && (
							<Grid
								xs={12}
								container
								item
								height="47.5vh"
								direction="row"
								justifyContent="center"
								alignSelf="center"
							>
								<Icon type="pointer" src={covLoader} display="flex" />
							</Grid>
						)}
						{appendedEnvData && appendedEnvData?.length > 0 && !openLoader && (
							<Box sx={{ width: '100%', height: '48vh' }}>
								<VirtuosoGrid
									style={{ height: '96%', margin: '8px' }}
									totalCount={appendedEnvData.length}
									endReached={LoadNextPage}
									// components={gridComponents}
									components={{
										...gridComponents,
										Footer: appendedEnvData && appendedEnvData?.length > 0 && !openLoader && !isNoRecords && FooterComponent
									}}
									overscan={100}
									itemContent={(index) => CustomCovalentCard(appendedEnvData[index])}
								/>
							</Box>
						)}
						{/* {envData?.records &&
							!openLoader &&
							envData?.records?.map(env => {
								return (
									<CovalentCard key={env?.id}>
										<EnvCardOverviewLayout
											envData={env}
											onDelete={onDelete}
											onDefault={setDefault}
											setCName={setCName}
										/>{' '}
									</CovalentCard>
								);
							})} */}
						{appendedEnvData && appendedEnvData?.length < 1 && !openLoader && (
							<Grid item xs={12} xxl={12} sx={{ height: '47.5vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
								<Typography>No records found</Typography>
							</Grid>
						)}
						{/* {envData?.records && !envData?.records?.length < 1 && (
							<Grid container className="footer" data-testid="tableFooter">
								<Pagination
									sx={{
										'& .MuiPaginationItem-root': {
											'&:hover': {
												backgroundColor: theme => theme?.palette?.background?.blue03
											}
										}
									}}
									color="primary"
									shape="rounded"
									variant="outlined"
									count={
										totalRecords && totalRecords > recordsPerPage
											? Math.ceil(totalRecords / recordsPerPage)
											: 1
									}
									page={envPage}
									onChange={handlePageChanges}
									showFirstButton
									showLastButton
									siblingCount={2}
									boundaryCount={2}
									data-testid="paginationItem"
								/>
							</Grid>
						)} */}
					</Grid>
				)}
			</Grid>
		</>
	);
}

export default Environments;
