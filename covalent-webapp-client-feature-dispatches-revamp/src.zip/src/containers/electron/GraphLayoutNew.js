/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable no-unused-vars */
/* eslint-disable no-shadow */
/* eslint-disable camelcase */
/* eslint-disable array-callback-return */
/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
import React, { useEffect, useState, createRef, useMemo, useRef, useContext } from 'react';
import { useScreenshot, createFileName } from 'use-react-screenshot';
import ReactFlow, {
	MiniMap,
	getIncomers,
	getOutgoers,
	isEdge,
	useNodesState,
	useEdgesState
} from 'reactflow';
import 'reactflow/dist/style.css';
import Box from '@mui/material/Box';
import { useSelector } from 'react-redux';
import '../../App.css';
import './style.css';
import LayoutElk from './LayoutElk';
import ElectronNode from './ElectronNode';
import ParameterNode from './ParameterNode';
import DirectedEdge from './DirectedEdge';
import LatticeControls from './LatticeControls';
import Logo from '../../assets/logos/covalentLogo.svg';
import theme from './theme';
import { statusColor } from './misc';
import { GraphContext } from '../graph/contexts/GraphContext';
import GraphBreadcrumb from '../graph/layout/graphBreadcrumb';
import useUpdateEffect from '../../utils/useUpdateEffect';

function GraphLayoutNew(props) {
	// Live refresh
	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);
	const socketData = useSelector(({ socket }) => socket.socketData);
	const { GraphPreview, dispatchID, showPostProcess, setPostProcess } = props;
	const NODE_TEXT_COLOR = 'rgba(250, 250, 250, 0.6)';
	const [preview] = useState(false);
	const [hasSelectedNode] = useState(false);
	const nodeTypes = useMemo(() => ({ electron: ElectronNode, parameter: ParameterNode }), []);
	const edgeTypes = useMemo(() => ({ directed: DirectedEdge }), []);
	const [direction, setDirection] = useState('DOWN');
	const [showMinimap, setShowMinimap] = useState(false);
	const [showParams, setShowParams] = useState(false);

	const [algorithm, setAlgorithm] = useState('layered');
	const [highlighted, setHighlighted] = useState(false);
	const [hideLabels, setHideLabels] = useState(false);
	const [elements, setElements] = useState([]);
	const [nodesDraggable, setNodesDraggable] = useState(false);
	const [nodes, setNodes, onNodesChange] = useNodesState([]);
	const [edges, setEdges, onEdgesChange] = useEdgesState([]);
	const [zoomPercentage, setZoomPercentage] = useState(0);
	const [screen, setScreen] = useState(false);
	const [currentId, setCurrentId] = useState();
	const [prettify, setPrettify] = useState(true);
	const [triggerFitView, setTriggerFitView] = useState(false);
	const {
		getElectronDetailsFromNodeid,
		setSelectedNodeId,
		getGraphDetailsApi,
		setNodeClickFrom,
		setSublatticeId,
		sublatticeId,
		getLatticeAPI,
		setBreadcrumb,
		breadcrumb,
		nodeResult,
		setNodeData,
		nodeDetailClose,
		zoomClick
	} = useContext(GraphContext);

	// menu for layout
	const [anchorEl, setAnchorEl] = useState(null);
	const open = Boolean(anchorEl);
	const handleClick = event => {
		setAnchorEl(event.currentTarget);
	};
	const handleClose = () => {
		setAnchorEl(null);
	};

	const handleChangeAlgorithm = event => {
		setAnchorEl(null);
		setAlgorithm(event);
	};

	const handleHideLabels = () => {
		const value = !hideLabels;
		setHideLabels(value);
	};

	const getAllIncomers = (node, prevIncomers = []) => {
		const incomers = getIncomers(node, nodes, edges);
		return incomers.reduce((memo, incomer) => {
			memo.push(incomer);

			if (prevIncomers.findIndex(n => n.id === incomer.id) === -1) {
				prevIncomers.push(incomer);

				getAllIncomers(incomer, prevIncomers).forEach(foundNode => {
					memo.push(foundNode);
					if (prevIncomers.findIndex(n => n.id === foundNode.id) === -1) {
						prevIncomers.push(incomer);
					}
				});
			}
			return memo;
		}, []);
	};

	const getAllOutgoers = (node, prevOutgoers = []) => {
		const outgoers = getOutgoers(node, nodes, edges);
		return outgoers.reduce((memo, outgoer) => {
			memo.push(outgoer);

			if (prevOutgoers.findIndex(n => n.id === outgoer.id) === -1) {
				prevOutgoers.push(outgoer);

				getAllOutgoers(outgoer, prevOutgoers).forEach(foundNode => {
					memo.push(foundNode);

					if (prevOutgoers.findIndex(n => n.id === foundNode.id) === -1) {
						prevOutgoers.push(foundNode);
					}
				});
			}
			return memo;
		}, []);
	};

	const highlightNodesAndEdges = (node, prevElements, allIncomers, allOutgoers, selection) => {
		return prevElements?.map(elem => {
			const incomerIds = allIncomers.map(i => i.id);
			const outgoerIds = allOutgoers.map(o => o.id);
			const animated =
				(outgoerIds.includes(elem.target) &&
					(outgoerIds.includes(elem.source) || node.id === elem.source)) ||
				(incomerIds.includes(elem.source) &&
					(incomerIds.includes(elem.target) || node.id === elem.target));
			const strokeColor = animated ? '#6473FF' : '#303067';
			if (isEdge(elem) || selection) {
				elem.style = {
					...elem.style,
					stroke: strokeColor
				};
				elem.labelStyle = { fill: strokeColor };
			}
			return elem;
		});
	};

	const highlightPath = (node, selection) => {
		if (node && elements) {
			const allIncomers = getAllIncomers(node, nodes);
			const allOutgoers = getAllOutgoers(node, nodes);
			setHighlighted(true);
			setNodes(prevElements =>
				highlightNodesAndEdges(node, prevElements, allIncomers, allOutgoers, selection)
			);
			setEdges(prevElements =>
				highlightNodesAndEdges(node, prevElements, allIncomers, allOutgoers, selection)
			);
		}
	};

	useEffect(() => {
		if (socketData.dispatch_id === sublatticeId) {
			if (currentId && currentId?.id) {
				nodeResult(sublatticeId, currentId?.id, 'output', 'string');
				nodeResult(sublatticeId, currentId?.id, 'output', 'object');
				getElectronDetailsFromNodeid(sublatticeId, currentId?.id);
			}
		}
	}, [liveRefresh]);

	const onNodeClick = (_e, node) => {
		if (
			currentId?.id !== node.id ||
			(currentId?.id === node.id && sublatticeId !== node?.dispatchID)
		) {
			setNodeClickFrom('graph');
			if (node?.data?.nodeType === 'sublattice') {
				if (node?.data?.sublattices_id) {
					const breadcrumbdata = { name: node?.data?.fullName, id: node?.data?.sublattices_id };
					setBreadcrumb(e => [...e, breadcrumbdata]);
					getElectronDetailsFromNodeid(sublatticeId, node?.id);
					setSublatticeId(node?.data?.sublattices_id);
					getLatticeAPI(node?.data?.sublattices_id, 'sublattice');
					getGraphDetailsApi(node?.data?.sublattices_id);
					setSelectedNodeId('');
					setCurrentId(node);
				}
			} else if (node?.data?.nodeType !== 'parameter') {
				setSelectedNodeId(parseInt(node?.id, 10));
				nodeResult(sublatticeId, node?.id, 'output', 'string');
				nodeResult(sublatticeId, node?.id, 'output', 'object');
				getElectronDetailsFromNodeid(sublatticeId, node?.id);
				highlightPath(node, true);
				setCurrentId(node);
			}
		}
	};

	const resetNodeStyles = () => {
		setEdges(prevElements => {
			return prevElements?.map(elem => {
				if (isEdge(elem)) {
					elem.animated = false;
					elem.labelStyle = { fill: NODE_TEXT_COLOR };
					elem.style = {
						...elem.style,
						stroke: '#303067'
					};
				}
				return elem;
			});
		});
		setNodes(prevElements => {
			return prevElements?.map(elem => {
				elem.selected = false;
				return elem;
			});
		});
	};

	const nodeDetailCloseFn = () => {
		if (breadcrumb.length > 1 && sublatticeId !== breadcrumb[breadcrumb.length - 1].id) {
			getGraphDetailsApi(breadcrumb[breadcrumb.length - 1].id);
			setSublatticeId(breadcrumb[breadcrumb.length - 1].id);
		} else if (breadcrumb.length <= 1 && sublatticeId !== dispatchID) {
			getGraphDetailsApi(dispatchID);
			setSublatticeId(dispatchID);
			const breadcrumbdata = [...breadcrumb];
			setBreadcrumb([breadcrumbdata[0]]);
		}
		setSelectedNodeId('');
		setNodeData({});
		resetNodeStyles();
		setCurrentId('');
	};

	useUpdateEffect(() => {
		nodeDetailCloseFn();
	}, [nodeDetailClose]);

	const onBreadcrumbClick = item => {
		const breadcrumbdata = [...breadcrumb];
		const index = breadcrumbdata.findIndex(e => e?.id === item?.id);
		if (index !== 0) setBreadcrumb(breadcrumbdata?.slice(0, index + 1));
		else if (index === 0) setBreadcrumb([breadcrumbdata[0]]);
		const nodeIndexId = breadcrumbdata[index]?.id;
		if (nodeIndexId !== sublatticeId) {
			getGraphDetailsApi(nodeIndexId);
			setSelectedNodeId('');
			setSublatticeId(nodeIndexId);
			resetNodeStyles();
			setCurrentId('');
		}
	};
	const onMove = (_e, v) => {
		setZoomPercentage(Math.round(v.zoom * 50));
	};

	useEffect(() => {
		setHighlighted(false);
	}, [direction, showParams, algorithm, hideLabels, GraphPreview, highlighted]);

	const nodeEdgeSetFn = newElements => {
		const edgeSet = [];
		const nodeSet = [];
		newElements?.map(n => {
			const specialChars = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
			const idCheck = specialChars.test(n.id);
			if (idCheck) {
				edgeSet.push(n);
			} else {
				nodeSet.push(n);
			}
			setNodes(nodeSet);
			setEdges(edgeSet);
		});
		setElements(newElements);
		setTriggerFitView(prev => !prev);
	}; // eslint-disable-next-line camelcase
	const ref_chart = createRef(null);

	// eslint-disable-next-line no-unused-vars
	const screenShotObject = useScreenshot({
		type: 'image/jpeg',
		quality: 1.0
	});
	const takeScreenShot = screenShotObject[1];

	// eslint-disable-next-line no-shadow
	const download = (img, { name = dispatchID, extension = 'jpg' } = {}) => {
		const a = document.createElement('a');
		a.href = img;
		a.download = createFileName(extension, name);
		a.click();
	};

	useEffect(() => {
		if (screen) {
			const svgElements = ref_chart.current.querySelectorAll('svg');
			svgElements.forEach(item => {
				item.style.marginBottom = '14px';
			});
			takeScreenShot(ref_chart.current).then(download);
			svgElements.forEach(item => {
				item.style.marginBottom = '0px';
			});
			setScreen(false);
		}
	}, [screen]);

	// layouting
	useEffect(() => {
		LayoutElk(
			GraphPreview,
			direction,
			showParams,
			algorithm,
			hideLabels,
			preview,
			prettify,
			showPostProcess
		)
			.then(els => {
				nodeEdgeSetFn(els);
				setElements(els);
			})
			.catch(error => console.log(error));
	}, [GraphPreview, direction, showParams, algorithm, hideLabels, prettify, showPostProcess]);

	useEffect(() => {
		nodeEdgeSetFn(elements);
	}, [elements]);

	return (
		<>
			{breadcrumb?.length > 1 && <GraphBreadcrumb onBreadcrumbClick={onBreadcrumbClick} />}
			{breadcrumb?.length <= 1 && <Box width="100%" mt={2} ml={3} />}
			{elements?.length > 0 && nodes.length > 0 && (
				<ReactFlow
					ref={ref_chart}
					className="reactflowCtr"
					nodes={nodes}
					edges={edges}
					onNodesChange={onNodesChange}
					onEdgesChange={onEdgesChange}
					elements={elements}
					nodeTypes={nodeTypes}
					edgeTypes={edgeTypes}
					nodesDraggable={nodesDraggable}
					nodesConnectable={false}
					snapToGrid
					fitView
					minZoom={0}
					maxZoom={2}
					onMove={onMove}
					onNodeClick={(e, node) => onNodeClick(e, node)}
					selectNodesOnDrag={hasSelectedNode}
					preventScrolling={zoomClick}
					zoomOnPinch
				>
					{showMinimap && !screen && (
						<MiniMap
							style={{
								backgroundColor: theme.palette.background.default,
								position: 'absolute',
								bottom: 12,
								right: 50,
								zIndex: 5,
								height: 150,
								width: 300
							}}
							maskColor={theme.palette.background.paper}
							nodeColor={node => statusColor(node.data.status)}
						/>
					)}
					{screen && (
						<div>
							<img
								style={{
									position: 'absolute',
									zIndex: '2',
									paddingLeft: '25px',
									bottom: '25px'
								}}
								src={Logo}
								alt="covalentLogo"
							/>
						</div>
					)}
					{!screen && (
						<LatticeControls
							showParams={showParams}
							toggleParams={() => {
								setShowParams(!showParams);
							}}
							showPostProcess={showPostProcess}
							togglePostProcess={() => {
								setPostProcess(!showPostProcess);
							}}
							showMinimap={showMinimap}
							toggleMinimap={() => {
								setShowMinimap(!showMinimap);
							}}
							toggleScreenShot={() => {
								setScreen(true);
							}}
							open={open}
							anchorEl={anchorEl}
							handleClick={handleClick}
							handleClose={handleClose}
							direction={direction}
							setDirection={setDirection}
							algorithm={algorithm}
							handleChangeAlgorithm={handleChangeAlgorithm}
							handleHideLabels={handleHideLabels}
							hideLabels={hideLabels}
							nodesDraggable={nodesDraggable}
							toggleNodesDraggable={() => setNodesDraggable(!nodesDraggable)}
							zoomPercentage={zoomPercentage}
							togglePrettify={() => {
								setPrettify(!prettify);
							}}
							prettify={prettify}
							triggerFitView={triggerFitView}
						/>
					)}
				</ReactFlow>
			)}
		</>
	);
}

export default GraphLayoutNew;
