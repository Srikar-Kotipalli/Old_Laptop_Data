/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
/* eslint-disable react/jsx-props-no-spreading */
/* eslint-disable import/no-unused-modules */

import React, { useContext } from 'react';
import { Grid, Paper, Tooltip, tooltipClasses, Typography } from '@mui/material';
import { styled } from '@mui/material/styles';
import { Handle } from 'reactflow';
import { truncateMiddle, nodeLabelIcon, statusIcon, statusColor } from './misc';
import { GraphContext } from '../graph/contexts/GraphContext';

export const NODE_TEXT_COLOR = 'rgba(250, 250, 250, 0.6)';

const ElectronTooltip = styled(({ className, ...props }) => (
	<Tooltip {...props} classes={{ popper: className }} />
))(() => ({
	[`& .${tooltipClasses.tooltip}`]: {
		// customize tooltip
		maxWidth: 500
	}
}));

function ElectronNode({ data, selected, sourcePosition, targetPosition, isConnectable }) {
	const { selectedNodeId, sublatticeId } = useContext(GraphContext);

	return (
		<Grid
			sx={{
				display: 'flex',
				flexDirection: 'column',
				alignItems: 'center',
				justifyContent: 'center'
			}}
		>
			{' '}
			{data.executor ? (
				<ElectronTooltip title={data.executor} arrow placement="bottom-end">
					<Paper
						sx={{
							display: 'flex',
							alignItems: 'center',
							justifyContent: 'center',
							borderRadius: '5px 5px 0px 0px',
							minWidth: '30%',
							overflow: 'hidden',
							bgcolor: '#1C1C46',
							color: theme =>
								selected || (data?.node_id === selectedNodeId && data?.dispatchID === sublatticeId)
									? theme.palette.text.secondary
									: theme.palette.text.tertiary,
							'&:hover': {
								color: theme => theme.palette.text.secondary
							}
						}}
					>
						<Handle type="target" position={targetPosition} isConnectable={isConnectable} />
						<Typography sx={{ fontSize: '0.625rem' }}>
							{truncateMiddle(data.executor, 6, 0)}
						</Typography>
						<Handle type="source" position={sourcePosition} isConnectable={isConnectable} />
					</Paper>
				</ElectronTooltip>
			) : null}
			<ElectronTooltip
				title={
					data.hideLabels ? (
						<>
							<Typography sx={{ fontSize: '0.75rem' }} color="inherit">
								name : {data.fullName}
							</Typography>
							<Typography sx={{ fontSize: '0.75rem' }} color="inherit">
								executor : {data.executor}
							</Typography>
							<Typography sx={{ fontSize: '0.75rem' }} color="inherit">
								node_id : {data.node_id}
							</Typography>
						</>
					) : (
						data.fullName
					)
				}
				arrow
				placement="bottom-end"
			>
				<Paper
					className="nodeCtr"
					elevation={
						selected || (data?.node_id === selectedNodeId && data?.dispatchID === sublatticeId)
							? 5
							: 1
					}
					sx={{
						height: '34px',
						display: 'flex',
						alignItems: 'center',
						px: 1,
						py: 0.5,
						borderRadius: data?.nodeType === 'sublattice' ? '8px' : '100px',
						bgcolor:
							selected || (data?.node_id === selectedNodeId && data?.dispatchID === sublatticeId)
								? theme => theme.palette.background.covalentPurple
								: theme => theme.palette.background.paper,
						color:
							selected || (data?.node_id === selectedNodeId && data?.dispatchID === sublatticeId)
								? '#FAFAFA'
								: NODE_TEXT_COLOR,
						borderColor: statusColor(data.status),
						borderStyle: 'solid',
						borderWidth: 1,
						'&:hover': {
							bgcolor: theme => theme.palette.background.covalentPurple,
							color: theme => theme.palette.text.secondary
						}
					}}
				>
					<Handle
						type="target"
						position={targetPosition}
						isConnectable={isConnectable}
						data-testid="handleelectronNode"
					/>
					<Grid pt={0.3}>{nodeLabelIcon(data.nodeType)}</Grid>
					{data?.contains_qelectron && <Grid>{nodeLabelIcon('qelectron')}</Grid>}
					<Grid pt={0.5}>{statusIcon(data.status)}</Grid>
					<Typography sx={{ fontSize: 14, mb: 0.3, mt: 0.3 }}>{data.label}</Typography>
					<Handle
						data-testid="sourcehandleelectronNode"
						type="source"
						position={sourcePosition}
						isConnectable={isConnectable}
					/>
				</Paper>
			</ElectronTooltip>
			{!data.hideLabels ? (
				<ElectronTooltip title={data.node_id} arrow placement="bottom-end">
					<Paper
						sx={{
							position: 'absolute',
							top: data.executor ? 42 : 30,
							display: 'flex',
							alignItems: 'center',
							justifyContent: 'center',
							borderRadius: '16px',
							minWidth: '20%',
							bgcolor: '#1C1C46',
							color: theme => theme.palette.text.primary,

							'&:hover': {
								color: theme => theme.palette.text.secondary
							}
						}}
					>
						<Handle type="target" position={targetPosition} isConnectable={isConnectable} />
						<Typography sx={{ fontSize: '0.625rem' }}>{data.node_id}</Typography>
						<Handle type="source" position={sourcePosition} isConnectable={isConnectable} />
					</Paper>
				</ElectronTooltip>
			) : null}
		</Grid>
	);
}

export default ElectronNode;
