/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
/* eslint-disable no-else-return */
/* eslint-disable prefer-template */
/* eslint-disable import/no-unused-modules */
import React from 'react';
import theme from './theme';
import ActivitySvg from '../../assets/icons/status/pending.svg';
import CheckSvg from '../../assets/icons/status/checkmark.svg';
import ErrorSvg from '../../assets/icons/status/error.svg';
import CancelSvg from '../../assets/icons/status/stop.svg';
import FunctionSvg from '../../assets/icons/nodeType/fuction.svg';
import ParameterSvg from '../../assets/icons/nodeType/parameter.svg';
import SubLatticeSvg from '../../assets/icons/nodeType/sublattice.svg';
import ArgSvg from '../../assets/icons/nodeType/arg.svg';
import AttributeSvg from '../../assets/icons/nodeType/attribute.svg';
import ElectronDictSvg from '../../assets/icons/nodeType/electron-dict.svg';
import ElectronListSvg from '../../assets/icons/nodeType/electron-list.svg';
import GeneratedSvg from '../../assets/icons/nodeType/generated.svg';
import ConnectionLostSvg from '../../assets/icons/status/connectionLost.svg';
import TimeoutSvg from '../../assets/icons/status/timeout.svg';
import QueuedSvg from '../../assets/icons/status/queued.svg';
import DispatchNew from '../../assets/dispatch/dispatchNew.svg';
import CompletingSvg from '../../assets/icons/status/completing.svg';
import runningIcon from '../../assets/runningIcon.svg';
import QelectronSvg from '../../assets/icons/nodeType/qelectron.svg';
import Icon from '../../components/icon';

export const statusIcon = status => {
	switch (status) {
		case 'RUNNING':
		case 'STARTING':
		case 'DISPATCHING':
			return (
				<Icon src={runningIcon} alt={runningIcon} status="circleRunningStatus" type="pointer" />
			);
		case 'NEW_OBJECT':
			return <Icon src={DispatchNew} alt={DispatchNew} type="pointer" />;
		case 'PENDING':
		case 'REGISTERING':
		case 'PENDING_BACKEND':
			return <Icon src={ActivitySvg} alt={ActivitySvg} type="pointer" />;
		case 'QUEUED':
		case 'PROVISIONING':
		case 'DEPROVISIONING':
			return <Icon src={QueuedSvg} alt={QueuedSvg} type="pointer" />;
		case 'COMPLETING':
			return <Icon src={CompletingSvg} alt={CompletingSvg} type="pointer" />;
		case 'COMPLETED':
		case 'POSTPROCESSING':
		case 'PENDING_POSTPROCESSING':
		case 'POSTPROCESSING_FAILED':
			return <Icon src={CheckSvg} alt={CheckSvg} type="pointer" />;
		case 'FAILED':
		case 'REG_FAILED':
		case 'BOOT_FAILED':
		case 'PROVISION_FAILED':
		case 'DEPROVISION_FAILED':
			return <Icon src={ErrorSvg} alt={ErrorSvg} type="pointer" />;
		case 'CONNECTION_LOST':
			return <Icon src={ConnectionLostSvg} alt={ConnectionLostSvg} type="pointer" />;
		case 'TIMEOUT':
			return <Icon src={TimeoutSvg} alt={TimeoutSvg} type="pointer" />;
		case 'CANCELLED':
			return <Icon src={CancelSvg} alt={CancelSvg} type="pointer" />;
		default:
			return null;
	}
};

export const nodeLabelIcon = type => {
	switch (type) {
		case 'qelectron':
			return (
				<Icon src={QelectronSvg} alt={QelectronSvg} type="pointer" style={{ paddingTop: '5px' }} />
			);
		case 'function':
			return (
				<Icon src={FunctionSvg} alt={FunctionSvg} type="pointer" style={{ paddingTop: '5px' }} />
			);
		case 'electron_list':
			return (
				<Icon
					src={ElectronListSvg}
					alt={ElectronListSvg}
					type="pointer"
					style={{ paddingTop: '5px' }}
				/>
			);
		case 'parameter':
			return (
				<Icon src={ParameterSvg} alt={ParameterSvg} type="pointer" style={{ paddingTop: '5px' }} />
			);
		case 'sublattice':
			return (
				<Icon
					src={SubLatticeSvg}
					alt={SubLatticeSvg}
					type="pointer"
					style={{ paddingTop: '5px' }}
				/>
			);
		case 'electron_dict':
			return (
				<Icon
					src={ElectronDictSvg}
					alt={ElectronDictSvg}
					type="pointer"
					style={{ paddingTop: '5px' }}
				/>
			);
		case 'attribute':
			return (
				<Icon src={AttributeSvg} alt={AttributeSvg} type="pointer" style={{ paddingTop: '5px' }} />
			);
		case 'generated':
			return (
				<Icon src={GeneratedSvg} alt={GeneratedSvg} type="pointer" style={{ paddingTop: '5px' }} />
			);
		case 'subscripted':
			return (
				<Icon src={SubLattice} alt={SubLattice} type="pointer" style={{ paddingTop: '5px' }} />
			);
		case 'arg':
			return <Icon src={ArgSvg} alt={ArgSvg} type="pointer" style={{ paddingTop: '5px' }} />;
		default:
			return null;
	}
};

export const truncateMiddle = (s, start, end, omission = '…') => {
	if (!s) {
		return '';
	}
	const len = s.length;
	if ((start === 0 && end === 0) || start + end >= len) {
		return s;
	}
	if (!end) {
		return s.slice(0, start) + omission;
	}
	return s.slice(0, start) + omission + s.slice(-end);
};

export const truncate = (str, length) => {
	if (str.length > length) {
		return str.slice(0, length) + '...';
	} else return str;
};

export const statusColor = status => {
	return {
		RUNNING: theme.palette.running.main,
		DISPATCHING: theme.palette.running.main,
		STARTING: theme.palette.running.main,
		NEW_OBJECT: theme.palette.text.secondary,
		COMPLETED: theme.palette.success.main,
		FAILED: theme.palette.error.main,
		CANCELLED: theme.palette.error.main,
		POSTPROCESSING: theme.palette.success.main,
		PENDING_POSTPROCESSING: theme.palette.success.main,
		POSTPROCESSING_FAILED: theme.palette.success.main,
		REGISTERING: theme.palette.queued.main,
		PENDING: theme.palette.queued.main,
		PENDING_BACKEND: theme.palette.queued.main,
		QUEUED: theme.palette.queued.main,
		PROVISIONING: theme.palette.queued.main,
		DEPROVISIONING: theme.palette.queued.main,
		COMPLETING: theme.palette.success.main,
		REG_FAILED: theme.palette.error.main,
		BOOT_FAILED: theme.palette.error.main,
		PROVISION_FAILED: theme.palette.error.main,
		DEPROVISION_FAILED: theme.palette.error.main,
		CONNECTION_LOST: theme.palette.error.main,
		TIMEOUT: theme.palette.error.main,
		WARNING: theme.palette.warning.main,
		INFO: theme.palette.info.main,
		DEBUG: theme.palette.info.main,
		WARN: theme.palette.warning.main,
		ERROR: theme.palette.error.main,
		CRITICAL: theme.palette.error.main
	}[status];
};

export const isParameter = node => node?.name.startsWith(':parameter:');

export const isPostProcess = node => node?.name.startsWith(':postprocess:');
