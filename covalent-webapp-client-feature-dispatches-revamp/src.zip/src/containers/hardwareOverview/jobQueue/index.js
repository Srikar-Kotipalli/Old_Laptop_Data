import React, { useEffect, useState } from 'react';
import { Box, Table, TableRow, Typography } from '@mui/material';
import JobQueueTableHeader from './jobQueueTableHeader';
import JobQueueRow from './jobQueueRow';

function JobQueueComponent({ searchValue, toFilter }) {
	const [selected, setSelected] = useState('job_id');
	const [toSort, setToSort] = useState('asc');

	const jobQueueData = [
		{
			id: 1,
			job_id: 'acab026b-e839-48c4-b0b5-4a5b091ee003',
			status: 'FAILED',
			user: 'Santosh Radha',
			organization: 'Agnostiq',
			hardware: 'IntelCloud_XeonGold',
			started: '03 Feb, 12:05:38',
			completed: '04 Feb, 11:05:38',
			pricing: 400
		},
		{
			id: 2,
			job_id: '3415415125',
			status: 'RUNNING',
			user: 'Santosh Radha-1',
			organization: 'Agnostiq',
			hardware: 'NVDIA_GTX2070',
			started: '03 Feb, 12:05:38',
			completed: '06 Feb, 01:05:38',
			pricing: 500
		},
		{
			id: 3,
			job_id: 'acab026b-e839-48c4-b0b5-4a5b091ee003',
			status: 'COMPLETED',
			user: 'Santosh Radha-2',
			organization: 'Agnostiq',
			hardware: 'IBMQ_Manila',
			started: '03 Feb, 12:05:38',
			completed: '05 Feb, 08:05:38',
			pricing: 1234
		},
		{
			id: 4,
			job_id: 'acab026b-e839-48c4-b0b5-4a5b091ee003',
			status: 'FAILED',
			user: 'Santosh Radha-3',
			organization: 'Agnostiq',
			hardware: 'IntelCloud_XeonGold',
			started: '03 Feb, 12:05:38',
			completed: '12 Feb, 03:05:38',
			pricing: 1234
		},
		{
			id: 5,
			job_id: '3415415125',
			status: 'RUNNING',
			user: 'Santosh Radha-4',
			organization: 'Agnostiq',
			hardware: 'IonZ_Vancouver',
			started: '11 Feb, 02:05:38',
			completed: '03 Feb, 12:07:38',
			pricing: 1234
		},
		{
			id: 6,
			job_id: 'acab026b-e839-48c4-b0b5-4a5b091ee003',
			status: 'COMPLETED',
			user: 'Santosh Radha-5',
			organization: 'Agnostiq',
			hardware: 'IntelCloud_XeonGold',
			started: '21 Feb, 12:05:38',
			completed: '26 Feb, 09:05:38',
			pricing: 1234
		},
		{
			id: 7,
			job_id: 'acab026b-e839-48c4-b0b5-4a5b091ee003',
			status: 'FAILED',
			user: 'Santosh Radha-6',
			organization: 'Agnostiq',
			hardware: 'Azure_Quantum5',
			started: '03 Feb, 12:05:38',
			completed: '17 Feb, 12:05:38',
			pricing: 1234
		},
		{
			id: 8,
			job_id: '3415415125',
			status: 'RUNNING',
			user: 'Santosh Radha-7',
			organization: 'Agnostiq',
			hardware: 'AMD_Radeon6900XT',
			started: '03 Feb, 12:05:38',
			completed: '26 Feb, 12:05:38',
			pricing: 1234
		},
		{
			id: 9,
			job_id: 'acab026b-e839-48c4-b0b5-4a5b091ee003',
			status: 'COMPLETED',
			user: 'Santosh Radha-8',
			organization: 'Agnostiq',
			hardware: 'IonZ_Vancouver',
			started: '03 Feb, 12:05:38',
			completed: '05 Feb, 12:05:38',
			pricing: 1234
		}
	];

	const [datas, setDatas] = useState([]);
	const [selectAll, setSelectAll] = useState(false);
	const [selectedItems, setSelectedItems] = React.useState([]);

	const sortByField = (data, selectedColumn, sortDirection) => {
		return data.slice().sort((a, b) => {
			if (selectedColumn === 'started' || selectedColumn === 'completed') {
				const dateA = new Date(a[selectedColumn]);
				const dateB = new Date(b[selectedColumn]);
				if (sortDirection === 'asc') {
					return dateA - dateB;
				}
				return dateB - dateA;
			}
			if (selectedColumn === 'status') {
				const order = { RUNNING: 1, COMPLETED: 2, FAILED: 3 };
				const statusA = order[a[selectedColumn]] || 4;
				const statusB = order[b[selectedColumn]] || 4;

				if (sortDirection === 'asc') {
					return statusA - statusB;
				}
				return statusB - statusA;
			}

			if (selectedColumn === 'pricing') {
				const dateA = a.pricing;
				const dateB = b.pricing;
				if (sortDirection === 'asc') {
					return dateB - dateA;
				}
				return dateA - dateB;
			}
			const fieldA = a[selectedColumn]?.toLowerCase();
			const fieldB = b[selectedColumn]?.toLowerCase();

			if (sortDirection === 'asc') {
				return fieldA?.localeCompare(fieldB);
			}
			return fieldB?.localeCompare(fieldA);
		});
	};

	useEffect(() => {
		let sortedData = [...jobQueueData];
		if (searchValue) {
			const filteredData = sortedData.filter(
				item =>
					item.job_id.toLowerCase().includes(searchValue.toLowerCase()) ||
					item.user.toLowerCase().includes(searchValue.toLowerCase()) ||
					item.hardware.toLowerCase().includes(searchValue.toLowerCase())
			);
			sortedData = filteredData;
		}

		if (toFilter === 'last_updated') {
			sortedData.sort((a, b) => {
				const dateA = new Date(a.completed);
				const dateB = new Date(b.completed);
				return dateB - dateA;
			});
			setDatas(sortedData);
		}

		if (toFilter === 'popular') {
			sortedData.sort((a, b) => {
				const dateA = a.pricing;
				const dateB = b.pricing;
				return dateA - dateB;
			});
			setDatas(sortedData);
		}

		sortedData = sortByField(sortedData, selected, toSort);
		setDatas(sortedData);
	}, [selected, toSort, searchValue, toFilter]);

	const checkAllHandler = () => {
		if (!selectAll) {
			const postIds = datas.map(item => {
				return item.id;
			});
			setSelectedItems(postIds);
		} else {
			setSelectedItems([]);
		}
		setSelectAll(prev => !prev);
	};

	const checkboxHandler = e => {
		const isSelected = e.target.checked;
		const value = parseInt(e.target.value, 10);
		if (isSelected) {
			setSelectedItems([...selectedItems, value]);
		} else {
			setSelectAll(false);
			setSelectedItems(prevData => {
				return prevData.filter(id => {
					return id !== value;
				});
			});
		}
	};

	return (
		<Box>
			<Box
				sx={{
					height: 'calc(60vh - 115px)',
					overflow: 'auto'
				}}
			>
				<Table width="100%" stickyHeader className="tabComponentTable">
					<JobQueueTableHeader
						checkAllHandler={checkAllHandler}
						selectAll={selectAll}
						setSelected={setSelected}
						setToSort={setToSort}
						selected={selected}
						toSort={toSort}
					/>
					<tbody>
						{datas &&
							datas.map((dispatch, index) => (
								<TableRow key={dispatch.id} data-testid="dispatchListView">
									<JobQueueRow
										dispatch={dispatch}
										index={index}
										hierarchyType="dispatch"
										onCheckboxChecked={checkboxHandler}
										selectedItems={selectedItems}
									/>
								</TableRow>
							))}
					</tbody>
				</Table>
				{datas.length === 0 && (
					<Typography className="listHeading" color="textPrimary" variant="subtitle2">
						No records found
					</Typography>
				)}
			</Box>
		</Box>
	);
}

export default JobQueueComponent;
