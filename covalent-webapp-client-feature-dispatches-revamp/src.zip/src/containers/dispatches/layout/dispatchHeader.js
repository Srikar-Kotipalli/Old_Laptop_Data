/* eslint-disable no-unused-vars */
/* eslint-disable react/jsx-no-useless-fragment */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import { TableHead } from '@mui/material';
import { makeStyles } from '@mui/styles';
import TableSortLabel from '@mui/material/TableSortLabel';
import Box from '@mui/material/Box';
// import './style.css';
import { DISPATCH_HEADER_V2 } from '../../../constants/tableHeaderConstants';

const useStyles = makeStyles({
	table: {
		minWidth: 650
	},
	sticky: {
		position: 'sticky',
		left: 0
	}
});

export default function DispatchHeader({ sortOrder, sortColumn, onSort }) {
	const header = DISPATCH_HEADER_V2;
	const classes = useStyles();
	return (
		<>
			{!!header.length && (
				// <TableHead sx={{
				//     '& th': {
				//         border: 0, backgroundColor: '#1C1C46',
				//     },
				//     '& th:first-child': {
				//         borderRadius: '8px 0 0 8px'
				//     },
				//     '& th:last-child': {
				//         borderRadius: '0 8px 8px 0'
				//     }
				// }}>
				//     <TableRow sx={{
				//         '& td': { border: 0 }
				//     }}>
				<>
					{header.map(h => (
						<TableCell
							style={{ position: h?.id === 'id' ? 'sticky' : '' }}
							width={`${h.width} !important`}
							key={h.id}
							colSpan={h.colSpan || 1}
							align={h.align || 'center'}
							data-testid="tableHeader"
						>
							<TableSortLabel
								active={sortColumn === h.id}
								direction={sortColumn === h.id ? sortOrder : 'asc'}
								onClick={() => onSort(h.id)}
								disabled={!(h.id === 'name' || h.id === 'started_at' || h.id === 'updated_at')}
								data-testid="tableSort"
								// style={{ flexDirection: 'row-reverse' }}
							>
								{h.label}
							</TableSortLabel>
						</TableCell>
					))}
				</>
				//     </TableRow>
				// </TableHead >
			)}
		</>
	);
}
