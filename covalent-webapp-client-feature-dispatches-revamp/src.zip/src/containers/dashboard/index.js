/* eslint-disable max-len */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable jsx-a11y/anchor-is-valid */

import React, { useState, useEffect } from 'react';
import { Grid, Typography } from '@mui/material';
// import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import Icon from '../../components/icon';
import ViewAll from '../../assets/arrows/caretRight.svg';
import ActivityList from '../../components/sidebar/projects/activityList';
// import GithubIcon from '../../assets/github.svg';
// import Banner from '../../assets/banner/Banner.png';
import SupportList from '../../components/supportList';
// import Carousel from '../../components/carousel';
import Overview from '../../components/dashboard/overview';
import Recent from '../../components/dashboard/recent';
import Shared from '../../components/dashboard/shared';
import TokenComponent from '../../components/form/settings/tokenComponent';
import copyIcon from '../../assets/actions/copy.svg';
import tickIcon from '../../assets/checkmarks/checkmark.svg';
import slackIcon from '../../assets/logos/slack.svg';
import { getActivityList } from '../../api/activity/activityApi';
import useDidMountEffect from '../../utils/useDidMountEffect';
// import Warning from '../../assets/environments/warning.svg';
// import routes from '../../constants/routes.json';
// import { getPaymentMethods } from '../../api/billing/billingApi';

const help = [
	{
		title: 'Getting started',
		link: 'https://docs.covalent.xyz/docs/cloud/cloud_quickstart'
	},
	{
		title: 'Tutorials',
		link: 'https://docs.covalent.xyz/docs/cloud/tutorials-cloud/tutorials'
	},
	// eslint-disable-next-line quotes
	// Temporalily commenting this how-to
	// {
	// 	title: 'How-to\'s',
	// 	link: 'https://docs.covalent.xyz/docs/user-documentation/how-to/how-to-guide'
	// },
	{ title: 'Covalent blog', link: 'https://www.covalent.xyz/blog/' },
	{
		title: 'API Reference',
		link: 'https://docs.covalent.xyz/docs/cloud/cloud_api'
	},
	{
		title: 'Documentation',
		link: 'https://docs.covalent.xyz/'
	}
];

// const bannerData = {
// 	image: `${Banner}`,
// 	header: 'Introduction',
// 	paragraph:
// eslint-disable-next-line max-len
// 		'Covalent is a Pythonic workflow tool for computational scientists, AI/ML software engineers, and anyone who needs to run experiments on limited or expensive computing resources including quantum computers, HPC clusters, GPU arrays, and cloud services.',
// 	buttonGetStarted: 'Get started',
// 	buttonWalkthrough: 'Start app walkthrough'
// };

function Dashboard() {
	const [activityList, setActivityList] = useState([]);
	const [openActivityLoader, setOpenActivityLoader] = useState(false);
	// Live refresh
	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);
	// commented the card alert states for the time being
	// const navigate = useNavigate();
	// const [paymentMethodExists, setPaymentMethodExists] = useState(true);
	// const redirectToSettings = () => {
	// 	navigate(routes?.BILLING);
	// };

	useEffect(() => {
		setOpenActivityLoader(true);
		getActivityList(20)
			.then(payload => {
				const activityListPayload = payload?.items?.map(e => {
					return { ...e, sub_category: e.sub_category || 'Blank' };
				});
				setOpenActivityLoader(false);
				setActivityList(activityListPayload);
			})
			.catch(error => {
				setOpenActivityLoader(false);
				console.log(error);
			});
		// commented the card alert logic for the time being
		// getPaymentMethods()
		// 	.then(paymentMeth => {
		// 		if (paymentMeth?.length === 0) {
		// 			setPaymentMethodExists(false);
		// 		}
		// 	})
		// 	.catch(error => {
		// 		console.log("error", error);
		// 	});
	}, []);

	useDidMountEffect(() => {
		getActivityList(20)
			.then(payload => {
				const activityListPayload = payload?.items?.map(e => {
					return { ...e, sub_category: e.sub_category || 'Blank' };
				});
				setActivityList(activityListPayload);
			})
			.catch(error => {
				console.log(error);
			});
	}, [liveRefresh]);

	return (
		<Grid sx={{ mb: 4 }}>
			<Grid container spacing={{ xs: 3.5, xl: 4, xxl: 5 }}>
				<Grid item className="left-side" xs={8.75} xl={9}>
					{/* Commented the below marketing banner for the time being */}
					{/* <Carousel bannerData={bannerData} /> */}
					{/* <Grid
						xs={12}
						sx={{
							width: '100%',
							height: '40vh',
							backgroundImage: `url(${Banner})`,
							backgroundPosition: 'center',
							backgroundSize: 'cover',
							backgroundRepeat: 'no-repeat',
							zindex: 10
						}}
					>
					</Grid> */}
					{/* commented the card alert for the time being */}
					{/* {!paymentMethodExists && (
						<Grid
							mt="30px"
							item
							display="flex"
							justifyContent="flex-start"
							sx={{
								background: theme => theme?.palette?.background?.paper,
								borderRadius: '8px',
								border: '1px solid',
								padding: '10px 18px 10px 15px',
								borderColor: theme => theme?.palette?.background?.blue03
							}}
						>
							<Typography fontSize={14}>
								<Icon type="default" src={Warning} display="contents" />
								Looks like you haven&apos;t added a credit card yet. To dispatch new workflows,
								please update your payment details in&nbsp;
								<Link
									onClick={redirectToSettings}
									underline="always"
									sx={{
										fontSize: '14px',
										fontWeight: '400',
										color: theme => theme.palette.background.blue05,
										textDecorationColor: theme => theme.palette.background.blue05,
										cursor: 'pointer'
									}}
								>
									settings
								</Link>
								&nbsp;to continue.
							</Typography>
						</Grid>
					)} */}
					<Overview />
					<Recent />
					<Shared />
					<Grid pt={3}>
						<Grid item id="SupportLinks">
							<Typography variant="header20" sx={{ color: theme => theme.palette.text.secondary }}>
								Knowledgebase & support
							</Typography>
							<Grid container item xs={12} pt={2} direction="row" columnGap={3} rowGap={2}>
								<Grid
									item
									container
									xs={9}
									rowGap={2}
									sx={{
										borderRight: '1px solid',
										borderColor: theme => theme.palette.background.covalentPurple
									}}
								>
									<SupportList list={help} />
									<Grid item sx={{ display: 'flex' }}>
										{/* <Typography
										variant="h2"
										pb={0.5}
										sx={{
											color: 'rgba(174, 182, 255, 1)',
											cursor: 'pointer',
											'&:hover': {
												textDecoration: 'underline',
												color: theme => theme.palette.text.secondary
											}
										}}
									>
										View all
									</Typography>
									<Icon src={ViewAll} /> */}
									</Grid>
								</Grid>
								<Grid>
									<Grid container direction="row" alignItems="center">
										<Icon src={slackIcon} type="static" />
										<Typography
											variant="h2"
											pl={1}

											// sx={{
											// 	cursor: 'pointer',
											// 	'&:hover': {
											// 		textDecoration: 'underline',
											// 		color: theme => theme.palette.text.secondary
											// 	}
											// }}
										>
											Submit an issue
										</Typography>
									</Grid>
									<Grid
										item
										pt={2}
										sx={{ display: 'flex', alignItems: 'center' }}
										onClick={() =>
											window.open(
												'https://covalentworkflows.slack.com/join/shared_invite/zt-1ew7f2rfk-dKSXVQmRniu5mQW4Z_eQuw#/shared-invite/email',
												'_blank'
											)
										}
									>
										<Typography
											variant="h2"
											pl={0.5}
											sx={{
												color: theme => theme.palette.text.link,
												cursor: 'pointer',

												'&:hover': {
													textDecoration: 'underline',
													color: theme => theme.palette.text.secondary
												}
											}}
										>
											Visit slack
										</Typography>
										<Icon src={ViewAll} />
									</Grid>
								</Grid>
							</Grid>
						</Grid>
					</Grid>
				</Grid>
				<Grid item className="right-side" xs={3.25} xl={3} mt={3}>
					<Typography
						pt={0}
						mt={0}
						variant="header20"
						sx={{ color: theme => theme.palette.text.secondary }}
						id="apiKey"
					>
						API Key
					</Typography>
					<Grid mt={2}>
						<TokenComponent
							width="75%"
							fontSize="12px"
							copyIcon={copyIcon}
							copiedIcon={tickIcon}
							isDisabled
							from="settings"
							copyEnable
						/>
					</Grid>

					<Grid mt={3} id="act" pr={0} mr={0}>
						<Typography
							pb={2}
							variant="header20"
							sx={{ color: theme => theme.palette.text.secondary }}
						>
							Activity List
						</Typography>
						<ActivityList
							openActivityLoader={openActivityLoader}
							items={activityList}
							count={activityList?.length}
							noLabel
							height="34rem"
						/>
					</Grid>
				</Grid>
			</Grid>
		</Grid>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default Dashboard;
