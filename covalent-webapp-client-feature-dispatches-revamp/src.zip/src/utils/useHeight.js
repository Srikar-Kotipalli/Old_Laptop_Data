import { useState, useEffect } from 'react';

const heightBreakpoints = {
	xs: 0,
	sm: 600,
	md: 900,
	lg: 1200,
	xl: 1440
};
const useHeight = ({ xs, sm, md, lg, xl }) => {
	const [height, setHeight] = useState();
	const [windowHeight, setWindowHeight] = useState(window.innerHeight);
	useEffect(() => {
		const handleResize = () => {
			setWindowHeight(window.innerHeight);
		};
		if (windowHeight < heightBreakpoints.sm) {
			setHeight(xs);
		} else if (windowHeight < heightBreakpoints.md) {
			setHeight(sm);
		} else if (windowHeight < heightBreakpoints.lg) {
			setHeight(md);
		} else if (windowHeight < heightBreakpoints.xl) {
			setHeight(lg);
		} else {
			setHeight(xl);
		}
		window.addEventListener('resize', handleResize);
		return () => {
			window.removeEventListener('resize', handleResize);
		};
	}, [windowHeight]);
	return height;
};

export default useHeight;
