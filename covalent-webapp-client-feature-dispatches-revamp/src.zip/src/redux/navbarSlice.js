/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
	isOpen: true // Initially navbar is closed
};

export const navbarSlice = createSlice({
	name: 'navbar',
	initialState,
	reducers: {
		openNavbar: state => {
			state.isOpen = true;
		},
		closeNavbar: state => {
			state.isOpen = false;
		},
		toggleNavbar: state => {
			state.isOpen = !state.isOpen;
		}
	}
});

export const { openNavbar, closeNavbar, toggleNavbar } = navbarSlice.actions;

export const selectNavbarState = state => state.navbar.isOpen;

export default navbarSlice.reducer;
