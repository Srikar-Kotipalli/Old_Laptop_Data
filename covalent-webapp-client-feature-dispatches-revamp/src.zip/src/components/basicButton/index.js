import React from 'react';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

function BasicButton({ title, width, onClick, id }) {
	return (
		<Button
			sx={{
				'&:hover': { backgroundColor: theme => theme.palette.background.covalentPurple },
				display: 'flex',
				width,
				justifyContent: 'center',
				alignItems: 'center',
				borderRadius: '25px',
				border: '1px solid',
				borderColor: theme => theme.palette.background.blue05,
				backgroundColor: theme => theme.palette.background.paper
			}}
			variant=""
			onClick={onClick}
			data-testid="actionButton"
			id={id || ''}
		>
			<Typography sx={{ color: theme => theme.palette.text.secondary }} variant="subtitle2" pr={1}>
				{title}
			</Typography>
		</Button>
	);
}

export default BasicButton;
