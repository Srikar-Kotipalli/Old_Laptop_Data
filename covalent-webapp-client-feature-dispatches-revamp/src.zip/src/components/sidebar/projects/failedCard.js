import React from 'react';
import { Link } from 'react-router-dom';
import { Typography, Grid } from '@mui/material';
import OverlappingIcons from '../../icon/overlappingIcons';
import ViewAll from '../../../assets/arrows/caretRight.svg';
import Icon from '../../icon';
import { getTimeDifference } from '../../../utils/utils';
import EllipsisTooltip from '../../tooltip/ellipsisTooltip';

function FailedCard({ items, setValue, setSortOrder, count }) {
	return (
		<Grid
			sx={{
				width: '100%',
				overflow: 'hidden',
				border: '1px solid red',
				borderRadius: '16px',
				background: theme => theme.palette.background.paper
			}}
			mt={2}
		>
			{' '}
			<Grid sx={{ overflow: 'hidden' }}>
				{items.map(item => {
					return (
						<Grid
							container
							item
							xs={12}
							direction="row"
							alignItems="center"
							sx={{
								borderBottom: '2px solid',
								borderColor: theme => theme.palette.background.covalentPurple,
								height: '50px'
							}}
							key={item.id}
						>
							<Grid
								mx={0.5}
								item
								xs={12}
								alignItems="center"
								justifyContent="space-between"
								sx={{
									display: 'flex',
									height: '40px',
									borderRadius: '10px',
									'&:hover': {
										backgroundColor: theme => theme.palette.background.covalentPurple
									}
								}}
							>
								<Grid pl={1} sx={{ display: 'flex', alignItems: 'center' }}>
									<OverlappingIcons type="DISPATCH" status="FAILED" />
									<Typography variant="h2" pl={1} s={1} sx={{ display: 'flex' }}>
										<Link
											style={{ color: '#CBCBD7', textDecoration: 'none' }}
											to={`/graph/${item?.id}`}
										>
											<EllipsisTooltip
												value={item.title}
												variant="subtitle2"
												type="dispatch"
												attribute="electron"
												width="150px"
												paddingRight="0px"
											/>
										</Link>
									</Typography>
									<Typography variant="h2" pl={0.3} sx={{ display: 'flex', alignItems: 'center' }}>
										has
									</Typography>
									<Typography variant="h2" ml={1} sx={{ color: '#FF6464' }}>
										failed
									</Typography>
								</Grid>

								<Grid item xs={3} sx={{ display: 'flex', alignItems: 'center' }}>
									<Typography fontSize="40px" pl={2}>
										{' \u00b7 '}
									</Typography>
									<Typography variant="h2" pr={2} pl={1}>
										{getTimeDifference(item?.endTime)}
									</Typography>
								</Grid>
							</Grid>
						</Grid>
					);
				})}
			</Grid>
			{count > 2 ? (
				<Grid item xs={12} py={1} container direction="row" justifyContent="center">
					<Grid
						sx={{ display: 'flex', alignItems: 'center' }}
						onClick={() => {
							setValue('dispatches');
							setSortOrder('asc');
						}}
					>
						<Typography
							sx={{
								fontSize: theme => theme.typography.sidebar,
								color: theme => theme.palette.text.primary,
								cursor: 'pointer'
							}}
						>
							{count - 2} more failed dispatches
						</Typography>
						<Icon src={ViewAll} padding="2px 0px 0px 0px" />
					</Grid>
				</Grid>
			) : null}
		</Grid>
	);
}

export default FailedCard;
