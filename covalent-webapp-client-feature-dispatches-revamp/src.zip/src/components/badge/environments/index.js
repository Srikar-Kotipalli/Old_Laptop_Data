import React from 'react';
import Box from '@mui/material/Box';
import Badge from '@mui/material/Badge';
import Icon from '../../icon';

function DefaultBadge({ isDefault, value, icon, onClick }) {
	return (
		<Box sx={{ paddingLeft: '5px' }}>
			{isDefault ? (
				<Badge
					color="primary"
					sx={{
						border: '1px solid #1C1C46',
						borderRadius: '8px',
						backgroundColor: '#303067',
						padding: '3px 3px 2px 5px',
						color: '#CBCBD7',
						fontSize: '12px',
						cursor: 'default'
					}}
				>
					{value}
					{icon &&
						(value ? (
							<Box mt={0.2}>
								<Icon src={icon} alt="icon" clickHandler={onClick} title="Close" />
							</Box>
						) : (
							'  '
						))}
				</Badge>
			) : (
				// <Box> </Box>
				<> </>
			)}
		</Box>
	);
}

export default DefaultBadge;
