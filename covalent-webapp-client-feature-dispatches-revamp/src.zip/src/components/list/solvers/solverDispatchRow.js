/* eslint-disable import/no-unused-modules */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import { Grid, Box, Tooltip, Avatar } from '@mui/material';
import { Link } from 'react-router-dom';
import Checkbox from '@mui/material/Checkbox';
import ContextMenu from '../../menu/projects/contextMenu';
import Icon from '../../icon';
import checkbox from '../../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../../assets/checkboxes/checkboxChecked.svg';
import checkboxDisabled from '../../../assets/checkboxes/checkboxdisabled.svg';
import dispatchIcon from '../../../assets/dispatch/dispatchIcon.svg';
import '../projects/style.css';
import { ProjectContext } from '../../../containers/projects/projectContext';
import { dateFormatter } from '../../../utils/utils';
import { statusIcon } from '../../../utils/statusIcons';
import RuntimeTooltip from '../../tooltip/runTimeTooltip';
import EllipsisDefaultTooltip from '../../tooltip/ellipsisTooltip';
import CustomInputBase from '../../inputBase/projects';
import ListTags from '../../tags/projects/listTags';
import Runtime from '../../../utils/Runtime';
import CopyButton from '../../copyButton';

export default function DispatchRow(props) {
	const { dispatch, hierarchyType, indentType, cellheight, onCheckboxChecked } = props;
	const projectContext = React.useContext(ProjectContext);
	const { showArchived } = projectContext;

	// eslint-disable-next-line consistent-return
	const getAlignmentFromHierarchy = () => {
		if (indentType === 'singleHierarchy') {
			return '1.9rem';
		} else if (indentType === 'doubleHierarchy') {
			return '3.8rem';
		}
	};

	return (
		<>
			<TableCell
				sx={{
					width: '7%',
					height: cellheight
				}}
				align="left"
				data-testid="dispatchRow"
			>
				<Box paddingLeft={getAlignmentFromHierarchy()}>
					<Checkbox
						data-testid="dispatchCheckbox"
						size="small"
						value={dispatch.id}
						checked={dispatch.isChecked}
						disabled={showArchived || !!(dispatch?.shared && dispatch?.shared[0]?.sharedByName)}
						onChange={e => onCheckboxChecked(e, dispatch)}
						icon={
							<Icon
								src={
									!(dispatch?.shared && dispatch?.shared[0]?.sharedByName) && !showArchived
										? checkbox
										: checkboxDisabled
								}
								alt="checkbox"
								type="pointer"
							/>
						}
						checkedIcon={<Icon src={checkboxChecked} alt="checkboxChecked" type="pointer" />}
					/>
				</Box>
			</TableCell>
			<TableCell width="20%" align="left">
				<Box display="flex" flexDirection="row">
					<Box paddingTop="1px">
						<Icon src={dispatchIcon} alt="dispatchIcon" type="static" padding="0px 3px 3.5px 0px" />
					</Box>
					<Box marginLeft={1}>
						{dispatch.isAdd ? (
							<CustomInputBase type="dispatch" listItem={dispatch} />
						) : (
							<Link
								style={{ color: '#CBCBD7', textDecoration: 'none' }}
								to={`/graph/${dispatch.id}`}
								state={{}}
							>
								<EllipsisDefaultTooltip
									variant="subtitle2"
									value={dispatch.title}
									type="dispatch"
								/>
							</Link>
						)}
					</Box>
				</Box>
			</TableCell>
			<TableCell align="left" width="8%">
				<Box display="flex" flexDirection="row" justifyContent="space-between">
					{statusIcon(dispatch.status, '0px 3px 3.5px 0px', 'dashboard')}
					<EllipsisDefaultTooltip
						variant="subtitle2"
						value={`${dispatch.completedElectrons}/${dispatch.totalElectrons}`}
						type="dispatch"
						width="80px"
						attribute="electron"
						paddingLeft="3px"
						paddingBottom="2px"
					/>
				</Box>
			</TableCell>
			<TableCell align="left" width="28%">
				<ListTags items={dispatch} type={hierarchyType} owner={dispatch?.shared} />
			</TableCell>
			<TableCell align="left" width="9%">
				{dispatch.status === 'RUNNING' && dispatch?.startTime && dispatch?.runTime ? (
					<Runtime startTime={dispatch.startTime} runTime={dispatch.runTime} />
				) : (
					<RuntimeTooltip value={dispatch?.runTime} placement="top" />
				)}
			</TableCell>
			<TableCell align="left" width="12%">
				{dispatch.startTime ? dateFormatter(`${dispatch.startTime}Z`) : ''}
			</TableCell>
			<TableCell align="left" width="12%">
				${dispatch?.cost}
			</TableCell>
			<TableCell align="left" width="2.35%">
				<Tooltip title="Ravi">
					<Avatar
						sx={{
							width: 24,
							height: 24,
							fontSize: 12,
							bgcolor: '#8B31FF',
							color: 'white'
						}}
					>
						R
					</Avatar>
				</Tooltip>
			</TableCell>
			<TableCell align="left" width="2%">
				<Grid>
					<CopyButton content={dispatch.title} />
				</Grid>
			</TableCell>

			<TableCell align="left" width="2%">
				<ContextMenu
					dispatch={dispatch}
					hierarchyType={hierarchyType}
					type="dispatch"
					rowType="experimentRow"
					margin={1}
					disabled
				/>
			</TableCell>
		</>
	);
}
