/* eslint-disable react/jsx-no-constructed-context-values */
/* eslint-disable testing-library/no-node-access */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
import AllListView from '../allListView';
import { ProjectContext } from '../../../../containers/projects/projectContext';

const header = [
	{ label: 'Title', align: 'left', width: '28%', id: 'title' },
	{ label: 'Status', align: 'left', width: '10%', id: 'status' },
	{ label: 'Tags', align: 'left', width: '20%', id: 'tags' },
	{ label: 'Runtime', align: 'left', width: '5%', id: 'runTime' },
	{ label: 'Start time', align: 'left', width: '10%', id: 'startTime' },
	{ label: 'Last updated', align: 'left', width: '10%', id: 'lastUpdated' }
];
const allItems = [
	{
		id: '626a4713c265a015b9ae9447',
		title: 'Steel Pelican Hooper',
		count: 4,
		lastUpdated: '2022-04-28T13:19:39.382000',
		type: 'Project',
		isOpen: true
	},
	{
		id: '626a4713c265a015b9ae9447',
		title: 'Steel Pelicandd Hooper',
		count: 4,
		lastUpdated: '2022-04-28T13:19:39.382000',
		type: 'Project',
		isOpen: false
	},
	{
		id: '626a4707c265a015b9ae943f',
		title: 'Yellow Lead Great Dane',
		totalElectrons: 5,
		completedElectrons: 2,
		status: 'FAILED',
		startTime: '2022-01-12T21:46:00',
		lastUpdated: '2022-01-13T13:58:00',
		parentId: 'None',
		type: 'Dispatch',
		isPinned: false,
		tags: ['react', 'rust', 'node', 'js'],
		runTime: 543500
	},
	{
		id: '626a470dc265a015b9ae9444',
		title: 'Yellow Viper Starlite',
		totalElectrons: 41,
		count: 4,
		completedElectrons: 29,
		status: 'FAILED',
		startTime: '2022-01-12T00:04:00',
		lastUpdated: '2022-01-13T07:22:00',
		parentId: 'None',
		type: 'Experiment',
		tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
		runTime: 1590600,
		isOpen: false
	},
	{
		id: '62905d30e93e4df1ac40807a',
		title: 'Red Viper Ryan',
		totalElectrons: 41,
		count: 4,
		completedElectrons: 29,
		status: 'FAILED',
		startTime: '2022-01-12T00:04:00',
		lastUpdated: '2022-01-13T07:22:00',
		parentId: 'None',
		type: 'Experiment',
		tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
		runTime: 1590600,
		isOpen: true
	}
];

const hierarchyItems = [
	{
		id: '626a471s3c265a015b9ae9447',
		title: 'Steel White Hooper',
		count: 4,
		lastUpdated: '2022-04-28T13:19:39.382000',
		type: 'Project',
		isOpen: true,
		isLoader: false,
		hierarchyListItems: [
			{
				id: '626a470dc265a015b9ae9444',
				title: 'Yellow Viper Experiment',
				totalElectrons: 41,
				count: 4,
				completedElectrons: 29,
				status: 'FAILED',
				startTime: '2022-01-12T00:04:00',
				lastUpdated: '2022-01-13T07:22:00',
				parentId: 'None',
				type: 'Experiment',
				tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
				runTime: 1590600,
				isOpen: true,
				isLoader: false,
				dispatches: [
					{
						id: '626a470dc265a015b9sae9444',
						title: 'Green Viper Dispatch',
						totalElectrons: 41,
						count: 4,
						completedElectrons: 29,
						status: 'FAILED',
						startTime: '2022-01-12T00:04:00',
						lastUpdated: '2022-01-13T07:22:00',
						parentId: 'None',
						type: 'Dispatch',
						tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
						runTime: 1590600,
						isOpen: false
					}
				]
			},
			{
				id: '626a470dc265a01s5b9ae9444',
				title: 'Pink Viper Experiment',
				totalElectrons: 41,
				count: 4,
				completedElectrons: 29,
				status: 'FAILED',
				startTime: '2022-01-12T00:04:00',
				lastUpdated: '2022-01-13T07:22:00',
				parentId: 'None',
				type: 'Experiment',
				tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
				runTime: 1590600,
				isOpen: false,
				isLoader: false
			}
		]
	},
	{
		id: '626a470dc265a015b9sae9444',
		title: 'Yellow Viper Dispatch',
		totalElectrons: 41,
		count: 4,
		completedElectrons: 29,
		status: 'FAILED',
		startTime: '2022-01-12T00:04:00',
		lastUpdated: '2022-01-13T07:22:00',
		parentId: 'None',
		type: 'Dispatch',
		tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
		runTime: 1590600,
		isOpen: false
	},
	{
		id: '62905d30e93e4df1ac40807a',
		title: 'Red Viper Ryan',
		totalElectrons: 41,
		count: 4,
		completedElectrons: 29,
		status: 'FAILED',
		startTime: '2022-01-12T00:04:00',
		lastUpdated: '2022-01-13T07:22:00',
		parentId: 'None',
		type: 'Experiment',
		tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
		runTime: 1590600,
		isOpen: true,
		hierarchyListItems: [
			{
				id: '626a470dc265a015b9sae9444',
				title: 'White Viper Dispatch',
				totalElectrons: 41,
				count: 4,
				completedElectrons: 29,
				status: 'FAILED',
				startTime: '2022-01-12T00:04:00',
				lastUpdated: '2022-01-13T07:22:00',
				parentId: 'None',
				type: 'Dispatch',
				tags: ['react', 'python', 'rust', 'Machine-Learning', 'Jupyter'],
				runTime: 1590600,
				isOpen: false
			}
		]
	}
];

const timeFormatter = jest.fn();
const dateFormatter = jest.fn();
const handleClick = jest.fn();
describe('All list view', () => {
	test('renders All list view', () => {
		render(
			<ProjectContext.Provider value={{ allItems }}>
				<AllListView header={header} timeFormatter={timeFormatter} dateFormatter={dateFormatter} />
			</ProjectContext.Provider>
		);
		const element = screen.getByTestId('allListView');
		expect(element).toBeInTheDocument();
	});
	test('on click opens the dispatches and experiments in all view', () => {
		render(
			<ProjectContext.Provider value={{ allItems }}>
				<AllListView
					header={header}
					timeFormatter={timeFormatter}
					dateFormatter={dateFormatter}
					handleOpenAllExperiments={handleClick}
					handleOpenAllProjects={handleClick}
				/>
			</ProjectContext.Provider>
		);
		const caretRight = screen.getAllByAltText('caretRight');
		expect(caretRight).toHaveLength(2);
		caretRight.forEach(x => fireEvent.click(x));
		expect(handleClick).toBeCalledTimes(2);
		const dispatchRow = screen.getAllByTestId('dispatchRow');
		expect(dispatchRow).toHaveLength(1);
		const experimentRow = screen.getAllByTestId('experimentRow');
		expect(experimentRow).toHaveLength(2);
	});

	test('close project hierarchy', () => {
		render(
			<ProjectContext.Provider value={{ allItems }}>
				<AllListView
					header={header}
					timeFormatter={timeFormatter}
					dateFormatter={dateFormatter}
					handleOpenAllProjects={handleClick}
					handleOpenAllExperiments={handleClick}
				/>
			</ProjectContext.Provider>
		);
		const caretDown = screen.getAllByAltText('caretDown');
		expect(caretDown).toHaveLength(2);
		caretDown.forEach(x => fireEvent.click(x));
		expect(handleClick).toBeCalledTimes(4);
	});

	test('no records found', () => {
		render(
			<ProjectContext.Provider value={{ allItems: [] }}>
				<AllListView
					header={header}
					timeFormatter={timeFormatter}
					dateFormatter={dateFormatter}
					handleOpenAllProjects={handleClick}
					handleOpenAllExperiments={handleClick}
				/>
			</ProjectContext.Provider>
		);
		const noRecordsFound = screen.getByText('No records found');
		expect(noRecordsFound).toBeInTheDocument();
	});

	test('calls onCheckbox function on clicking checkbox', () => {
		render(
			<ProjectContext.Provider value={{ allItems, onCheckboxChecked: handleClick }}>
				<AllListView header={header} timeFormatter={timeFormatter} dateFormatter={dateFormatter} />
			</ProjectContext.Provider>
		);
		const element = screen.getByTestId('dispatchCheckbox').querySelector('input[type="checkbox"]');
		const allExperimentCheckbox = screen
			.getByTestId('allExperimentCheckbox')
			.querySelector('input[type="checkbox"]');
		fireEvent.click(element);
		fireEvent.click(allExperimentCheckbox);
		expect(handleClick).toBeCalledTimes(6);
	});
	test('render hierarchy items inside project', () => {
		render(
			<ProjectContext.Provider value={{ allItems: hierarchyItems, onCheckboxChecked: handleClick }}>
				<AllListView header={header} timeFormatter={timeFormatter} dateFormatter={dateFormatter} />
			</ProjectContext.Provider>
		);
		const projectExperiment = screen.getAllByTestId('projectExperiment');
		expect(projectExperiment).toHaveLength(2);
		const projectExperimentDispatch = screen.getByTestId('projectExperimentDispatch');
		expect(projectExperimentDispatch).toBeInTheDocument();
		const projectExperimentCheckbox = screen
			.getByTestId('projectExperimentCheckbox')
			.querySelector('input[type="checkbox"]');
		fireEvent.click(projectExperimentCheckbox);
		expect(handleClick).toBeCalled();
	});
	test('render open and close icons of experiment inside project', () => {
		render(
			<ProjectContext.Provider
				value={{ allItems: hierarchyItems, handleOpenAllProjects: handleClick }}
			>
				<AllListView header={header} timeFormatter={timeFormatter} dateFormatter={dateFormatter} />
			</ProjectContext.Provider>
		);
		const closeHierarchyInsideProject = screen.getByTestId('closeHierarchyInsideProject');
		expect(closeHierarchyInsideProject).toBeInTheDocument();
		const openHierarchyInsideProject = screen.getByTestId('openHierarchyInsideProject');
		expect(openHierarchyInsideProject).toBeInTheDocument();
	});
	test('render onclick function while clicking open and close icons', () => {
		render(
			<ProjectContext.Provider value={{ allItems: hierarchyItems }}>
				<AllListView
					header={header}
					handleOpenAllProjects={handleClick}
					timeFormatter={timeFormatter}
					dateFormatter={dateFormatter}
				/>
			</ProjectContext.Provider>
		);
		const closeHierarchyInsideProject = screen.getByTestId('closeHierarchyInsideProject');
		fireEvent.click(closeHierarchyInsideProject);
		const openHierarchyInsideProject = screen.getByTestId('openHierarchyInsideProject');
		fireEvent.click(openHierarchyInsideProject);
		expect(handleClick).toBeCalled();
	});
});
