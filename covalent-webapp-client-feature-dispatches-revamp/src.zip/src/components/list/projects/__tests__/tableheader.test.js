/* eslint-disable react/jsx-no-constructed-context-values */
/* eslint-disable testing-library/no-node-access */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
import TableHeader from '../tableheader';
import { ProjectContext } from '../../../../containers/projects/projectContext';

const header = [{ label: 'Title', align: 'left', width: '20%', id: 'title' }];

describe('table header view', () => {
	test('renders table header', () => {
		render(<TableHeader header={header} />);
		const element = screen.getByTestId('tableHeader');
		expect(element).toBeInTheDocument();
	});
	test('calls sort onlclick function', () => {
		const handleClick = jest.fn();
		render(
			<ProjectContext.Provider value={{ onSort: handleClick }}>
				<TableHeader header={header} />
			</ProjectContext.Provider>
		);
		const element = screen.getByTestId('tableSort');
		expect(element).toBeInTheDocument();
		fireEvent.click(element);
		expect(handleClick).toBeCalledTimes(1);
	});
	test('calls onCheckbox function on clicking checkbox', () => {
		const handleClick = jest.fn();
		render(
			<ProjectContext.Provider value={{ onAllSelected: handleClick }}>
				<TableHeader header={header} />
			</ProjectContext.Provider>
		);
		const element = screen.getByTestId('headerCheckbox').querySelector('input[type="checkbox"]');
		expect(element).toBeInTheDocument();
		fireEvent.click(element);
		expect(handleClick).toBeCalledTimes(1);
	});
});
