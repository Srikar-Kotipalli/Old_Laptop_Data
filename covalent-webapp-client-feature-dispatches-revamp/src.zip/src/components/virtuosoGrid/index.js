import React, { forwardRef } from 'react';
import { Box, Grid, Typography } from '@mui/material';
import { VirtuosoGrid } from 'react-virtuoso';


// To control how the List and how each Item within the List are rendered and this object is needed.
const gridComponents = {
    List: forwardRef(({ style, children }, ref) => (  // List is the container.
        <Grid container
            ref={ref}
            style={{
                display: 'flex',
                flexWrap: 'wrap',
                ...style
            }}
        >
            {children}
        </Grid>
    )),
    Item: ({ children }) => (  		// Each individual item
        <Grid item xs={12} sm={6} md={4} lg={4} xl={4}
            style={{
                padding: '0.5rem'
            }}
        >
            {children}
        </Grid>
    )
};

// Layout for all the items in the grid
const ItemWrapper = ({ children }) => (
    <Box
        style={{
            display: 'flex',
            width: '100%'
        }}
    >
        {children}
    </Box>
);

const CustomHardwareCard = (index,user) => (
    <ItemWrapper width='200px'>
        <Typography key={user?.id} user >hello</Typography>
    </ItemWrapper>
);

const CustomVirtuosoGrid = ({data,height,width}) => {
    return (
        <VirtuosoGrid
        style={{ height: {height}, width: {width}, marginTop: '20px' }}
				totalCount={data.length}
				components={gridComponents}
				overscan={100}
				itemContent={index => CustomHardwareCard(data[index])}
        />
    );
};

export default CustomVirtuosoGrid;