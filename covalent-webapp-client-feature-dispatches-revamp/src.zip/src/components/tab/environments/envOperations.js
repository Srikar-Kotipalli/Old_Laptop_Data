// /* eslint-disable import/no-unused-modules */
// /*
//  * Copyright 2022 Agnostiq Inc.
//  * Note: This file is subject to a proprietary license agreement entered into between
//  * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
//  * access and use this file is subject to the terms and conditions of such agreement.
//  * Please ensure you carefully review such agreements and, if you have any questions
//  * please reach out to Agnostiq at: [support@agnostiq.com].
//  */
import * as React from 'react';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import Divider from '@mui/material/Divider';

function StyledDivider() {
	return (
		<Divider sx={{ borderColor: '#303067' }} orientation="vertical" variant="middle" flexItem />
	);
}
function EnvironmnetTab(props) {
	const { value, onChange, isdisabled } = props;
	return (
		<TabContext value={value}>
			<TabList
				onChange={onChange}
				TabIndicatorProps={{
					style: {
						display: 'none'
					}
				}}
				sx={{
					'& .MuiTab-root.Mui-selected': {
						color: value === 'Error' && '#FF6464'
					},

					'& .MuiTab-root:hover': {
						color: '#AEB6FF'
					}
				}}
			>
				<Tab label="Overview" sx={{ minWidth: 0 }} value="overview" />
				<StyledDivider />
				{!isdisabled && (
					<Tab label="Edit" value="edit" disabled={isdisabled} sx={{ minWidth: 0 }} />
				)}
				{!isdisabled && <StyledDivider />}
				{/* <StyledDivider />
				<Tab label="Projects" value="projects" /> */}
				<Tab label="Logs" sx={{ minWidth: 0 }} value="logs" />
			</TabList>
		</TabContext>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default EnvironmnetTab;
