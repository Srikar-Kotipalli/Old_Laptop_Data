import React from 'react';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import Divider from '@mui/material/Divider';
import { Grid } from '@mui/material';

function StyledDivider() {
	return <Divider orientation="vertical" variant="middle" flexItem />;
}
function ExperimentCustomTab({ value, setValue, type }) {
	const handleTabChange = (_event, newValue) => {
		setValue(newValue);
	};

	return (
		<Grid item xs={12}>
			<TabContext value={value}>
				<TabList
					onChange={handleTabChange}
					sx={{
						background: 'transparent',
						'& .MuiTabs-indicator': {
							background: 'transparent'
						}
					}}
				>
					<Tab
						label="Overview"
						value="overview"
						sx={{
							'&.Mui-selected': {
								color: 'white'
							},
							fontSize: theme => theme.typography.sidebar,
							color: theme => theme.typography.sidebarTitle.color,
							minWidth: type !== 'Dispatch' ? '33%' : '25%',
							borderTopLeftRadius: value === 'overview' ? '8px' : '0px',
							borderTopRightRadius: value === 'overview' ? '8px' : '0px',
							borderColor: 'transparent',
							background:
								value === 'overview' ? theme => theme.palette.background.covalentPurple : null
						}}
					/>
					<StyledDivider />
					{type === 'Dispatch' ? (
						<Tab
							label="Output"
							value="output"
							sx={{
								'&.Mui-selected': {
									color: 'white'
								},
								fontSize: theme => theme.typography.sidebar,
								color: theme => theme.typography.sidebarTitle.color,
								minWidth: '25%',
								borderTopLeftRadius: value === 'output' ? '8px' : '0px',
								borderTopRightRadius: value === 'output' ? '8px' : '0px',
								borderColor: 'transparent',
								background:
									value === 'output' ? theme => theme.palette.background.covalentPurple : null
							}}
						/>
					) : null}
					<StyledDivider />
					<Tab
						label="Dispatches"
						value="dispatches"
						sx={{
							'&.Mui-selected': {
								color: 'white'
							},
							fontSize: theme => theme.typography.sidebar,
							color: theme => theme.typography.sidebarTitle.color,
							minWidth: type !== 'Dispatch' ? '33%' : '25%',
							borderTopLeftRadius: value === 'dispatches' ? '8px' : '0px',
							borderTopRightRadius: value === 'dispatches' ? '8px' : '0px',
							borderColor: 'transparent',
							background:
								value === 'dispatches' ? theme => theme.palette.background.covalentPurple : null
						}}
					/>
					<StyledDivider />
					<Tab
						label="Notes"
						value="notes"
						sx={{
							'&.Mui-selected': {
								color: 'white'
							},
							fontSize: theme => theme.typography.sidebar,
							color: theme => theme.typography.sidebarTitle.color,
							minWidth: type !== 'Dispatch' ? '33.333333333%' : '24%',
							borderTopLeftRadius: value === 'notes' ? '8px' : '0px',
							borderTopRightRadius: value === 'notes' ? '8px' : '0px',
							borderColor: 'transparent',
							background:
								value === 'notes' ? theme => theme.palette.background.covalentPurple : null
						}}
					/>
				</TabList>
			</TabContext>
		</Grid>
	);
}

export default ExperimentCustomTab;
