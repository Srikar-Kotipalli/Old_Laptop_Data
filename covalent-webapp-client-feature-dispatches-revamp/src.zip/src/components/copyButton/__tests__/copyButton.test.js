/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import '@testing-library/jest-dom';
import { render, screen, fireEvent } from '@testing-library/react';
import React from 'react';
import copy from 'copy-to-clipboard';
import CopyButton from '..';

describe('copy button', () => {
	test('copy button  rendered', () => {
		render(<CopyButton copied={false} />);
		const element = screen.getByAltText('copyIcon');
		expect(element).toBeInTheDocument();
	});
	test('call copy function', () => {
		render(<CopyButton copied={false} copy={copy} />);
		const element = screen.getByAltText('copyIcon');
		expect(element).toBeInTheDocument();
		fireEvent.click(element);
	});
});
