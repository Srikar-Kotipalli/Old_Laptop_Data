/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
import ShowItemsMenu from '../showItemsMenu';

describe('show items menu', () => {
	const mockAnchorEl = document.createElement('button');
	const open = Boolean(mockAnchorEl);
	const handleClick = jest.fn();

	test('renders show items menu button', () => {
		render(<ShowItemsMenu />);
		const element = screen.getByRole('button', { name: 'Show' });
		expect(element).toBeInTheDocument();
	});

	const showItemsMenuIcons = ['Archived'];
	test.each(showItemsMenuIcons)('the menu opens and we have  %p', args => {
		render(<ShowItemsMenu open={open} handleClick={handleClick} />);
		const button = screen.queryByText('Show');
		fireEvent.click(button);
		expect(button).toBeInTheDocument();
		const text = screen.queryByText(args);
		expect(text).toBeInTheDocument();
	});

	test('the checkboxes present', () => {
		render(<ShowItemsMenu open={open} handleClick={handleClick} />);
		const button = screen.queryByText('Show');
		fireEvent.click(button);
		expect(button).toBeInTheDocument();
		const project = screen.queryAllByTestId('checkbox');
		expect(project).toHaveLength(1);
	});

	test('disabled archive button', () => {
		render(<ShowItemsMenu open={open} handleClick={handleClick} />);
		const button = screen.queryByText('Show');
		fireEvent.click(button);
		expect(button).toBeInTheDocument();
		const element = screen.getByTestId('archivedAction');
		expect(element).toBeInTheDocument();
	});
});
