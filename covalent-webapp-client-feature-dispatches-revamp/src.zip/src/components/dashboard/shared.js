/* eslint-disable react/no-array-index-key */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useEffect, useState } from 'react';
import { Grid, Typography } from '@mui/material';
import SimpleDashboardCard from '../card/dashboard/simplecard';
import { allSharedItemsList } from '../../api/shared/sharedApi';
import Loader from '../loader';

function Shared() {
	const [sharedList, setSharedList] = useState([]);
	const [openLoader, setOpenLoader] = useState(false);

	const itemsListApi = () => {
		setOpenLoader(true);
		const bodyParameters = {
			count: 6,
			offset: 0
		};

		allSharedItemsList(bodyParameters)
			.then(response => setSharedList(response.items))
			.catch(error => {
				console.log(error);
			})
			.finally(() => {
				setOpenLoader(false);
			});
	};

	useEffect(() => {
		itemsListApi();
		return () => {
			setOpenLoader(false); // Cancel the loader if it is still open
		};
	}, []);

	return (
		<Grid pt={3}>
			<Typography variant="header20" sx={{ color: theme => theme.palette.text.secondary }}>
				Shared
			</Typography>
			<Grid container pt={2} direction="row" rowGap={2} columnGap={{ xs: 1, sm: 2, md: 3 }}>
				{openLoader && (
					<Loader isFetching={openLoader} position="relative" width="100%" height="7.9rem" />
				)}
				{sharedList &&
					sharedList?.map((data, index) => {
						return <SimpleDashboardCard data={data} key={index} />;
					})}
			</Grid>
			{(!sharedList || sharedList.length === 0) && !openLoader ? (
				<Grid
					container
					mt={2}
					direction="row"
					justifyContent="center"
					alignItems="center"
					sx={{ height: '7.3rem' }}
				>
					<Typography>No workflows shared</Typography>
				</Grid>
			) : null}
		</Grid>
	);
}

export default Shared;
