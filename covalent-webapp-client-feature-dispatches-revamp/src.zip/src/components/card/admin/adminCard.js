/* eslint-disable react/jsx-boolean-value */
import React from 'react';
import { Box } from '@mui/material';
import SolverAdminImage from '../../../assets/marketplace/solverAdminImage.svg';
import SolverContent from './solverContent';

function AdminCard({
	solverImage,
	downloads,
	name,
	apiCalls,
	revenue,
	chipData,
	handlePublishToMarketplace,
	solverId
}) {
	return (
		<Box>
			<Box>
				<img
					src={SolverAdminImage}
					alt="cardImage"
					style={{ width: '100%', height: '100%', marginBottom: '-5px' }}
				/>
			</Box>
			<SolverContent
				solverImage={solverImage}
				downloads={downloads}
				name={name}
				apiCalls={apiCalls}
				revenue={revenue}
				chipData={chipData}
				borderRadius={['0px', '0px', '8px', '8px']}
				width="100%"
				from="solverTab"
				handlePublishToMarketplace={handlePublishToMarketplace}
				solverId={solverId}
			/>
		</Box>
	);
}
export default AdminCard;
