/* eslint-disable no-unused-expressions */
/* eslint-disable react/jsx-boolean-value */
/* eslint-disable no-unsafe-optional-chaining */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useEffect } from 'react';
import { Box, Grid, Typography, Badge, Tooltip } from '@mui/material';
import './style.css';
import Chart from 'react-apexcharts';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../icon';
import VirtualImage from '../../../../assets/environments/virtualMachine.svg';
import Edit from '../../../../assets/actions/edit.svg';
import Delete from '../../../../assets/actions/delete.svg';
import Gear from '../../../../assets/helperMenu/gear.svg';
import CopyButton from '../../../copyButton';
import OverflowTooltip from '../../../tooltip/overflowTooltip';
import MarketplaceDialogBox from '../../../dialogBox/marketplace';
import DefaultBadge from '../../../badge/environments';
import { statusIcon } from '../../../../utils/statusIcons';
import useUpdateEffect from '../../../../utils/useUpdateEffect';

function PieCharts({ revenueChartData }) {
	const donutData = {
		series: revenueChartData.series,
		options: {
			dataLabels: {
				enabled: false
			},
			legend: {
				show: false
			},
			labels: revenueChartData.labels,
			colors: revenueChartData.colors,
			chart: {
				type: 'donut'
			},
			plotOptions: {
				pie: {
					customScale: 0.5,
					donut: {
						size: '75%'
					}
				}
			},
			// plotOptions: {
			//   pie: {
			//     expandOnClick: false
			//   }
			// },
			stroke: {
				colors: revenueChartData.colors
			}
			// responsive: [
			// 	{
			// 		breakpoint: 480,
			// 		options: {
			// 			chart: {
			// 				width: 200
			// 			},
			// 			dataLabels: {
			// 				enabled: false
			// 			},

			// 		}
			// 	}
			// ]
		}
	};
	return (
		<Chart options={donutData?.options} series={donutData?.series} height={100} type="donut" />
	);
}

function PackagesLabel({ title, color, value }) {
	return (
		<Grid sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
			<Badge
				variant="dot"
				sx={{
					'& .MuiBadge-badge': {
						color: theme => theme.palette.text.success,
						backgroundColor: color,
						marginRight: '0.25rem'
					}
				}}
			/>
			<Typography variant="h3" ml={1}>
				{title}:
			</Typography>
			<Typography variant="h3" ml={0.5}>
				{value}
			</Typography>
		</Grid>
	);
}

function EnvCardOverviewLayout(props) {
	const { envData, onDelete, onDefault, setCName } = props;
	const [dataReady, setDataReady] = useState(false);
	const [data, setData] = useState({});
	const [openDialogBox, setOpenDialogBox] = useState(false);
	const [isClicked, setIsClicked] = useState(true);
	const navigate = useNavigate();
	// const chipData = {
	// 	tags: ['python', 'react', 'quantum', 'ml', 'sass']
	// };

	// const hoverStyle = {
	// 	width: '25px',
	// 	height: '25px',
	// 	display: 'flex',
	// 	alignItems: 'center',
	// 	justifyContent: 'center',
	// 	borderRadius: '8px',
	// 	'&:hover': {
	// 		background: theme => theme.palette.background.blue14
	// 	}
	// };

	function findPipArrayLength(dep) {
		const pipArray = dep?.find(
			item => typeof item === 'object' && item !== null && 'pip' in item
		)?.pip;
		return pipArray?.length;
	}

	const navigateTo = (event, tabValue) => {
		// Pass the tabValue as a query parameter when navigating
		event.stopPropagation();
		navigate(`/environments/${envData?.id}`, { state: { tabValue } });
	};

	const setAsDefault = event => {
		event.stopPropagation();
		setCName(envData?.name) || setOpenDialogBox(true) || setIsClicked(true);
	};

	const deleteEnvironment = event => {
		event.stopPropagation();
		setCName(envData?.name) || setOpenDialogBox(true) || setIsClicked(false);
	};

	useEffect(() => {
		if (envData?.parsedData) {
			setData({
				series: [
					envData?.parsedData?.channels?.length || 0,
					envData?.parsedData?.dependencies?.length - 1 || 0,
					findPipArrayLength(envData?.parsedData?.dependencies) || 0
				],
				labels: ['channels', 'conda', 'pip'],
				colors: ['#DAC3FF', '#AD7BFF', '#6473FF']
			});
		}
	}, [envData]);

	useUpdateEffect(() => {
		setDataReady(true);
	}, [data]);

	const deleteEnv = event => {
		event.stopPropagation();
		onDelete(envData?.id);
		setOpenDialogBox(false);
	};

	const setDefaultEnv = event => {
		event.stopPropagation();
		onDefault(envData?.name);
		setOpenDialogBox(false);
	};

	return (
		<Box
			className="envCard"
			onClick={e => navigateTo(e, 'overview')}
			sx={{
				cursor: 'pointer',
				width:'100%',
				borderColor: theme => theme.palette.background.blue03,
				background: theme => theme.palette.background.blue12,
				transition: 'transform 0.2s ease',
				'&:hover': {
					background: theme => theme.palette.background.blue0380,
					transform: 'scale(1.02)',
					fontSmoothing: 'antialiased'
				},
				'&:active': {
					background: theme => theme.palette.background.covalentPurple,
					transform: 'translateY(2px)',
					fontSmoothing: 'antialiased'
				}
			}}
		>
			{/* <MarketplaceDialogBox
				setOpenDialogBox={setOpenDialogBox}
				openDialogBox={openDialogBox}
				handler={deleteEnv}
				confirmButtonTitle="Delete"
				title="Delete"
				message={`Are you sure about deleting ${capitalizeName(envData?.name)} ?`}
				srcIcon={Delete}
			/> */}
			<MarketplaceDialogBox
				setOpenDialogBox={setOpenDialogBox}
				openDialogBox={openDialogBox}
				handler={isClicked ? setDefaultEnv : deleteEnv}
				confirmButtonTitle={isClicked ? 'Set as Default' : 'Delete'}
				title={isClicked ? 'Set as Default' : 'Delete'}
				message={
					isClicked
						? `Are you sure to set this ${envData?.name} environment as default?`
						: `Are you sure about deleting ${envData?.name} ?`
				}
				// 	${
				// 		envData?.default ? 'default environment' : 'environment'
				//   }
				srcIcon={isClicked ? Gear : Delete}
			/>
			<Grid className="cardTitleContainer">
				<Box className="containerFlex">
					<Icon
						src={VirtualImage}
						width="16px"
						height="16px"
						padding="4px"
						type="cursor"
						title="Manage your compute environments"
					/>
					<Box ml={1}>
						<OverflowTooltip title={envData?.name} length={9} fontSize="16px" />
					</Box>
					<DefaultBadge isDefault={envData?.default} value="Default" />
					<Tooltip title={envData?.status} placement="bottom">
						<Box ml={0.7}>
							{envData?.status !== 'RUNNING' &&
								envData?.status !== 'CREATING' &&
								envData?.status !== 'IN_PROGRESS' &&
								statusIcon(envData?.status, '0px 0px 2px 0px', 'env')}
						</Box>
					</Tooltip>
					{/* Commented below code as it was previously used to view env details */}
					{/* <Tooltip title="View Details" placement="top">
						<Box>
							<Icon
								src={Arrow}
								padding="0 0 2px 0"
								type="pointer"
								style={{ marginLeft: '6px' }}
								clickHandler={() => navigateTo('overview')}
							/>
						</Box>
					</Tooltip> */}
				</Box>
				<Box sx={{ display: 'flex' }}>
					{envData?.status === 'READY' ? (
						<Icon
							padding="4px"
							bgColor="#08081a"
							src={Edit}
							title="Edit"
							margin="1.6px 0px 0px 16px"
							// padding="2px 0 0 3px"
							type="cursor"
							clickHandler={e => navigateTo(e, 'edit')}
						/>
					) : null}
					{['IN_PROGRESS', 'CREATING'].includes(envData?.status) ? (
						<Tooltip title="Saving Changes, Please Wait" placement="top">
							<Box ml={0.7} pt={0.1}>
								{envData?.status && statusIcon(envData?.status, '0px', 'env')}
							</Box>
						</Tooltip>
					) : null}
					<Box ml={1} mt={0.2}>
						<CopyButton
							content={envData?.name}
							placement="bottom"
							padding="4px"
							bgColor="#08081a"
						/>
					</Box>
					{/* <Icon src={Copy} padding="3px 0 0 0" type="static" style={{ marginLeft: '20px' }} /> */}
					{envData?.status === 'READY' && !envData?.default ? (
						<Icon
							margin="1.6px 0px 0px 8px"
							bgColor="#08081a"
							padding="4px"
							src={Delete}
							type="pointer"
							// style={{ marginLeft: '20px' }}
							clickHandler={deleteEnvironment}
							disabled={envData?.status !== 'READY'}
							title="Delete"
						/>
					) : null}
					{!envData?.default ? (
						envData?.status === 'READY' && (
							<Icon
								margin="1.6px 0px 0px 8px"
								src={Gear}
								bgColor="#08081a"
								padding="4px"
								type="pointer"
								title="Set as default"
								clickHandler={setAsDefault}
							/>
						)
					) : (
						<> </>
					)}
				</Box>
			</Grid>
			{/* // Commenting this as this is dummy data and can be uncomment to check this placeholder data. */}
			{/* <Grid container direction="row" justifyContent="space-between" alignItems="center">
				{chipData?.tags?.length > 0 ? (
					<Chips items={chipData?.tags} isExpandable={false} />
				) : (
					<Box sx={{ height: '44px' }} />
				)}
				<Typography variant="h3" mr="0.5rem">
					5/10/2023
				</Typography>
			</Grid>
			<Grid container direction="row" justifyContent="space-between" alignItems="center">
				<Typography variant="h2" mt={2}>
					Velit suscipit laboriosam rem quibusdam. Nostrum
				</Typography>
			</Grid> */}
			<Grid
				container
				direction="row"
				alignItems="center"
				mt={1}
				pl={1.87}
				sx={{ borderTop: theme => `1px solid ${theme.palette.background.blue03}` }}
			>
				{envData?.parsedData?.channels?.length === 0 &&
				envData?.parsedData?.dependencies?.length - 1 === 0 &&
				!findPipArrayLength(envData?.parsedData?.dependencies) ? (
					<Grid
						item
						xs={6}
						pt={1}
						sx={{
							display: 'flex',
							alignItems: 'center',
							height: '40px',
							justifyContent: 'flex-start'
						}}
					>
						<Typography variant="h2" mr="0.5rem">
							No Data Found
						</Typography>
					</Grid>
				) : (
					<>
						<Grid
							item
							xs={9}
							mt={1}
							sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}
						>
							<PackagesLabel
								title="channels"
								color="#DAC3FF"
								value={envData?.parsedData?.channels?.length || 0}
							/>
							<PackagesLabel
								title="conda"
								color="#AD7BFF"
								value={envData?.parsedData?.dependencies?.length - 1 || 0}
							/>
							<PackagesLabel
								title="pip"
								color="#6473FF"
								value={findPipArrayLength(envData?.parsedData?.dependencies) || 0}
							/>
						</Grid>
						<Grid
							item
							xs={3}
							mt={-0.2}
							pl={3}
							sx={{
								display: 'flex',
								alignItems: 'center',
								height: '40px',
								justifyContent: 'flex-end'
							}}
						>
							{dataReady && <PieCharts revenueChartData={data} />}
						</Grid>
					</>
				)}
			</Grid>
		</Box>
	);
}

export default EnvCardOverviewLayout;
