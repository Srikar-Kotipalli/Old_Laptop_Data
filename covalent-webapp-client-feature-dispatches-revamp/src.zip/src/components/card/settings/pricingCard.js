/* eslint-disable react/self-closing-comp */
/* eslint-disable import/no-unused-modules */
/* eslint-disable react/jsx-curly-brace-presence */

import React, { memo } from 'react';
import { Elements } from '@stripe/react-stripe-js';
import { Box, Grid, Typography, Dialog } from '@mui/material';
import './style.css';
import BorderButton from '../../primaryButton/environments';
import Add from '../../../assets/actions/add.svg';
import EditIcon from '../../../assets/actions/edit.svg';
import Delete from '../../../assets/actions/delete.svg';
import CheckoutForm from '../../../containers/settings/billing/checkoutForm';
import { BillingContext } from '../../../containers/settings/billing/billingContext';
import { capitalizeName } from '../../../utils/utils';
import Loader from '../../loader';
import stripePromise from '../../../containers/settings/billing/stripe';
import MarketplaceDialogBox from '../../dialogBox/marketplace';

function PricingCard() {
	const billingContext = React.useContext(BillingContext);
	const {
		defaultPaymentMethod,
		paymentMethod,
		charges,
		isLoading,
		externalSetupIntent,
		isBillingAccountPresent,
		isChargesLoading,
		deletePaymentMethod,
		openDeletePopup,
		toggleDeleteModal,
		togglePaymentModal,
		open,
		setOpen
	} = billingContext;

	const handleClose = () => setOpen(false);

	const appearance = {
		variables: {
			colorPrimary: '#0570de',
			colorBackground: '#1C1C46',
			colorText: '#ffffff',
			colorDanger: '#df1b41',
			fontFamily: 'Ideal Sans, system-ui, sans-serif',
			spacingUnit: '5px',
			borderRadius: '4px'
		}
	};
	return (
		<Grid container spacing={2} sx={{ my: 2, ml: 0 }}>
			<Grid
				item
				xs={4}
				sx={{
					bgcolor: '#1C1C46',
					pb: '16px',
					borderRadius: '16px'
				}}
			>
				{isChargesLoading && (
					<Loader isFetching={isChargesLoading} position="relative" width="100%" height="100%" />
				)}
				<Grid container spacing={2}>
					<Grid item xs={6}>
						{!isChargesLoading && (
							<Grid
								container
								direction="column"
								justifyContent="space-between"
								alignItems="flex-start"
								height="100%"
							>
								<Grid item xs>
									<Typography variant="caption" display="block">
										Compute Charges
									</Typography>
								</Grid>
								<Grid
									item
									xs
									sx={{
										display: 'flex',
										alignItems: 'flex-end',
										mt: 1
									}}
								>
									<Typography
										sx={{
											color: theme => theme.palette.text.primary,
											fontSize: '32px'
										}}
									>
										{charges?.display_price || '$0.00'}
									</Typography>
								</Grid>
							</Grid>
						)}
					</Grid>
				</Grid>
			</Grid>
			<Grid item xs={4} className="billingCardRight">
				<Box sx={{ border: '1px solid #303067', height: '100%', borderRadius: '8px', p: '16px' }}>
					{isLoading && (
						<Loader isFetching={isLoading} position="relative" width="100%" height="106px" />
					)}
					{!isLoading && (
						<Grid
							container
							direction="row"
							justifyContent="space-between"
							alignItems="flex-start"
							height="106px"
						>
							<Grid item xs={12}>
								<Typography variant="subtitle1" gutterBottom>
									Billing and Payment
								</Typography>
								<Typography variant="caption" display="block" gutterBottom>
									{isBillingAccountPresent
										? 'Change how you pay your plan'
										: 'No billing account found. Please contact the administrator.'}
								</Typography>
							</Grid>
							<Grid
								item
								xs={12}
								sx={{
									display: 'flex',
									alignItems: 'flex-end',
									mt: 2
								}}
							>
								{defaultPaymentMethod ? (
									<Grid container style={{ justifyContent: 'space-between' }}>
										<Grid item xs={6}>
											<Typography variant="caption" display="block" gutterBottom>
												{capitalizeName(paymentMethod?.card_brand)} ending ****
												{paymentMethod?.card_last4}
											</Typography>
										</Grid>
										<Grid item xs={3}>
											<BorderButton
												title="Edit"
												img={EditIcon}
												// padding={0.3}
												paddingLeft={1}
												handler={() => togglePaymentModal(true)}
											/>
										</Grid>
										<Grid item xs={3}>
											<BorderButton
												title="Delete"
												img={Delete}
												// padding={0.3}
												paddingLeft={1}
												handler={() => toggleDeleteModal(true)}
											/>
										</Grid>
									</Grid>
								) : (
									isBillingAccountPresent && (
										<BorderButton
											title="Add a payment method"
											img={Add}
											// padding={0.3}
											paddingLeft={1}
											handler={() => togglePaymentModal(true)}
										/>
									)
								)}
							</Grid>
						</Grid>
					)}
				</Box>
			</Grid>
			<Dialog open={open} onClose={handleClose} maxWidth={'sm'} fullWidth>
				{externalSetupIntent && (
					<Elements
						stripe={stripePromise()}
						options={{
							clientSecret: externalSetupIntent,
							appearance
						}}
					>
						<CheckoutForm togglePaymentModal={togglePaymentModal} />
					</Elements>
				)}
			</Dialog>
			<MarketplaceDialogBox
				openDialogBox={openDeletePopup}
				setOpenDialogBox={toggleDeleteModal}
				handler={deletePaymentMethod}
				confirmButtonTitle="Delete"
				title="Delete"
				message={'Are you sure about removing the existing credit card?'}
				srcIcon={Delete}
			/>
		</Grid>
	);
}

export default memo(PricingCard);
