import * as React from 'react';
import { styled } from '@mui/material/styles';
import Chip from '@mui/material/Chip';
import Box from '@mui/material/Box';

const ListItem = styled('li')(({ theme }) => ({
	margin: theme.spacing(0.5)
}));

export default function Chips({ chipdata, start, margin = '0px' }) {
	return (
		<Box
			sx={{
				display: 'flex',
				justifyContent: !start && 'center',
				listStyle: 'none',
				background: 'none',
				margin: { margin }
			}}
			component="ul"
		>
			{chipdata?.map(data => {
				return (
					<ListItem key={data.key}>
						<Chip label={data.label} size="small" />
					</ListItem>
				);
			})}
		</Box>
	);
}
