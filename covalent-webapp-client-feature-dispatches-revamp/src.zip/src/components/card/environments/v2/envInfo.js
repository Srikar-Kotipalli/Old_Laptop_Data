/* eslint-disable import/no-unused-modules */
import React from 'react';
import { Grid, Box, Typography } from '@mui/material';
import OverflowTooltip from '../../../tooltip/overflowTooltip';

function EnvInfo({ data }) {
	if (data.length === 0) {
		return <Typography>No Records Found</Typography>;
	}

	return (
		<Grid container spacing={2} sx={{ maxHeight: '120px', overflowY: 'auto' }}>
			{data.map((packageInfo, index) => (
				// eslint-disable-next-line react/no-array-index-key
				<Grid item xs={3} key={index}>
					{/* Each item takes up 4 columns in a 12-column grid */}
					<Box
						sx={{
							display: 'flex',
							alignItems: 'center',
							background: 'rgba(48, 48, 103, 0.20)',
							border: '1px solid #1C1C46',
							borderRadius: '7px',
							justifyContent: 'center',
							height: '26px'
						}}
					>
						<OverflowTooltip title={packageInfo} length={11} />
					</Box>
				</Grid>
			))}
		</Grid>
	);
}

export default EnvInfo;
