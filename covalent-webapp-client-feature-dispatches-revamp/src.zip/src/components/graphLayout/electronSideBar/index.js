/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
/* eslint-disable import/no-unused-modules */
/* eslint-disable react/jsx-props-no-spreading */

import React, { useEffect, useState } from 'react';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Slide from '@mui/material/Slide';
import Icon from '../../icon/index';
import { statusColor, formatDate } from '../../icon/misc';
import { statusIcon } from '../../../utils/statusIcons';
import GraphLayoutTab from '../../tabs/graphLayout/index';
import ResultSection from '../Result';
import ElectronIcon from '../../icon/electronIcon';
import functionIcon from '../../../assets/function-math.svg';
import closeIcon from '../../../assets/actions/close.svg';
import spcCpuIcon from '../../../assets/specifications/spc-cpu.svg';
import spcMemoryIcon from '../../../assets/specifications/spc-memory.svg';
import spcTimerIcon from '../../../assets/specifications/spc-timer.svg';
import spcGatewayIcon from '../../../assets/specifications/spec-gateway-api.svg';
import spcGpuIcon from '../../../assets/specifications/spec-gpu.svg';
import './style.css';
import { getExecutorByExecutorID, getBatchElectronsById } from '../../../api/graph/graphLayoutApi';
import { Capitalize, Prettify } from '../../../utils/utils';
import Loader from '../../loader';
import GraphRuntime from '../../../utils/GraphRuntime';
import OverflowTooltip from '../../tooltip/overflowTooltip';

function ElectronSideBar(props) {
	const containerRef = React.useRef(null);
	const {
		nodeDetailClose,
		nodeDetailEnable,
		electronDetails,
		nodeData,
		code,
		result,
		openLoader,
		count,
		setCount,
		resultObject,
		codeObject,
		input,
		inputObject,
		nodeError,
		nodeErrorObject,
		prettify
	} = props;
	const [value, setValue] = useState('overview');
	const [executorDetails, setExecutorDetails] = useState([]);
	// this state is for storing the electrons of sublattice
	const [nodeElectronDetails, setNodeElectronDetails] = useState([]);
	const [moveLoader, setMoveLoader] = useState(false);
	const [totalCount, setTotalCount] = useState(0);

	const handleChange = (_e, newValue) => {
		setValue(newValue);
		setCount(10);
	};

	const getExecutorDetailsApi = () => {
		if (electronDetails?.executor_id) {
			getExecutorByExecutorID(electronDetails?.executor_id)
				.then(response => {
					setExecutorDetails(response);
				})
				.catch(error => {
					console.log(error);
				});
		}
	};

	const getElectronsDetailsApi = () => {
		setMoveLoader(true);
		getBatchElectronsById(electronDetails?.sublattice_dispatch_id, count, 0)
			.then(response => {
				setNodeElectronDetails(response.records);
				setTotalCount(response.metadata.total_count);
			})
			.catch(error => {
				console.log(error);
			})
			.finally(() => setMoveLoader(false));
	};

	const showMore = () => {
		setCount(prev => prev + 5);
	};

	useEffect(() => {
		if (electronDetails?.type === 'sublattice') getElectronsDetailsApi();
	}, [count, electronDetails]);

	useEffect(() => {
		getExecutorDetailsApi();
	}, [electronDetails]);

	useEffect(() => {
		setValue('overview');
	}, [electronDetails]);

	const nodeLabel = (type, name) => {
		switch (type) {
			case 'parameter':
				return name?.replace(':parameter:', '');
			case 'electron_list':
				return name?.replace(':electron_list:', 'electron list');
			case 'sublattice':
				return name?.replace(':sublattice:', 'Sublattice:');
			default:
				return name;
		}
	};

	const nodeTitleFn = () => {
		if (prettify) {
			return Prettify(electronDetails?.name, electronDetails?.type || '');
		}
		return nodeLabel(electronDetails?.type, electronDetails?.name);
	};

	return (
		<Slide direction="left" in={nodeDetailEnable} mountOnEnter unmountOnExit timeout={400}>
			<Box
				open={nodeDetailEnable}
				onClose={nodeDetailClose}
				scroll="paper"
				className="electronSidebarCtr"
				sx={{
					width: { sm: '26.5vw', md: '26.5vw', lg: '26.5vw', xl: '21vw' },
					// width: { sm: '28%', md: '24rem', lg: '25rem' },
					position: 'absolute',
					top: '9.5%',
					right: { xs: '1.1rem' },
					background: 'rgba(28, 28, 70, 0.6)',
					borderRadius: '8px'
				}}
				ref={containerRef}
			>
				<Grid id="scroll-dialog-title" sx={{ padding: '10px 0px 0px 0px' }}>
					<Grid container alignItems="end" sx={{ mb: 2 }}>
						<Grid container item xs={9} alignItems="center" direction="row">
							<Grid item xs={12} sx={{ ml: 1, overflowWrap: 'anywhere', display: 'flex' }}>
								<Grid item sx={{ ml: 1, mt: 0.6 }}>
									<Icon src={functionIcon} data-testid="contextButton" alt="moreVerticalIcon" />
								</Grid>
								<Grid pl={1} pt={0.2} sx={{ width: '100%' }}>
									<OverflowTooltip
										title={nodeTitleFn()}
										width="100%"
										length={25}
										fontSize="20px"
										color={theme => theme.palette.text.secondary}
									/>
								</Grid>
							</Grid>
						</Grid>
						<Grid container item xs={3} direction="row" alignItems="center" justifyContent="end">
							<Grid sx={{ mr: 1 }}>
								<Icon src={closeIcon} alt="closeIcon" clickHandler={nodeDetailClose} />
							</Grid>
						</Grid>
					</Grid>
					<Box className="electron-tab">
						<GraphLayoutTab
							value={value}
							onChange={handleChange}
							nodeDataType={nodeData?.nodeType}
							result={result}
							subIsPresent={electronDetails?.sublattice_dispatch_id}
						/>
					</Box>
				</Grid>
				<Grid
					sx={{
						p: 0,
						bgcolor: 'rgba(28, 28, 70, 0.8)',
						borderBottomLeftRadius: '8px',
						borderBottomRightRadius: '8px'
					}}
				>
					<Grid
						className="electronSideInner"
						sx={{
							position: 'relative',
							overflow: 'auto',
							height: { sm: '70vh', lg: '74.2vh', xl: '76vh' }
						}}
					>
						{openLoader && (
							<Grid container sx={{ position: 'absolute' }}>
								<Loader isFetching={openLoader} width="100%" height="15rem" />
							</Grid>
						)}
						{value === 'overview' && !openLoader && (
							<Box className="tabBody">
								<Grid container spacing={1}>
									<Grid item>{statusIcon(electronDetails?.status)}</Grid>
									<Grid item>
										<Typography sx={{ color: statusColor(electronDetails?.status) }}>
											{electronDetails?.status === 'NEW_OBJECT'
												? 'New object'
												: Capitalize(electronDetails?.status)}
										</Typography>
									</Grid>
								</Grid>
								{electronDetails?.started_at && electronDetails?.completed_at && (
									<Box sx={{ mt: 2 }}>
										<Typography className="innertypohead">Started - Ended</Typography>
										<Typography className="innertyposubhead">
											{formatDate(electronDetails?.started_at)} -{' '}
											{formatDate(electronDetails?.completed_at)}
										</Typography>
									</Box>
								)}
								{electronDetails?.started_at && (
									<Box sx={{ mt: 2 }}>
										<Typography className="innertypohead">Runtime</Typography>
										<GraphRuntime
											startTime={electronDetails?.started_at}
											endTime={electronDetails?.completed_at}
											className="innertyposubhead"
										/>
									</Box>
								)}
								{input && (
									<Box sx={{ mt: 2 }}>
										<ResultSection
											label="Input"
											value={input}
											name="code"
											objectValue={inputObject}
										/>
									</Box>
								)}
								{nodeError && (
									<Box sx={{ mt: 2 }}>
										<ResultSection
											label="Error"
											value={nodeError}
											name="code"
											objectValue={nodeErrorObject}
										/>
									</Box>
								)}
								{result && (
									<Box sx={{ mt: 2 }}>
										<ResultSection
											label="Result"
											value={result}
											name="code"
											objectValue={resultObject}
										/>
									</Box>
								)}
								{code && (
									<Box sx={{ mt: 2 }}>
										<ResultSection label="Code" value={code} name="code" objectValue={codeObject} />
									</Box>
								)}
								{executorDetails && (
									<Box sx={{ mt: 2 }}>
										<Typography className="innertypohead">Specifications</Typography>
										<Grid
											container
											direction="row"
											spacing={1}
											alignItems="center"
											sx={{ mb: 0.5 }}
										>
											<Grid item>
												<Icon src={spcCpuIcon} alt="spcCpuIcon" />
											</Grid>
											<Grid item sx={{ fontSize: '12px', color: '#CBCBD7' }}>
												CPU Shares: {executorDetails?.cpu_shares}
											</Grid>
										</Grid>
										<Grid
											container
											direction="row"
											spacing={1}
											alignItems="center"
											sx={{ mb: 0.5 }}
										>
											<Grid item>
												<Icon src={spcMemoryIcon} alt="spcCpuIcon" />
											</Grid>
											<Grid item sx={{ fontSize: '12px', color: '#CBCBD7' }}>
												Memory: {executorDetails?.memory}
											</Grid>
										</Grid>
										<Grid
											container
											direction="row"
											spacing={1}
											alignItems="center"
											sx={{ mb: 0.5 }}
										>
											<Grid item>
												<Icon src={spcGpuIcon} alt="spcCpuIcon" />
											</Grid>
											<Grid item sx={{ fontSize: '12px', color: '#CBCBD7' }}>
												GPUs: {executorDetails?.num_gpus}
											</Grid>
										</Grid>

										<Grid
											container
											direction="row"
											spacing={1}
											alignItems="center"
											sx={{ mb: 0.5 }}
										>
											<Grid item>
												<Icon src={spcGatewayIcon} alt="spcCpuIcon" />
											</Grid>
											<Grid item sx={{ fontSize: '12px', color: '#CBCBD7' }}>
												GPU type: {executorDetails?.gpu_type}
											</Grid>
										</Grid>

										<Grid
											container
											direction="row"
											spacing={1}
											alignItems="center"
											sx={{ mb: 0.5 }}
										>
											<Grid item>
												<Icon src={spcTimerIcon} alt="spcCpuIcon" />
											</Grid>
											<Grid item sx={{ fontSize: '12px', color: '#CBCBD7' }}>
												Time limit: {executorDetails?.time_limit}
											</Grid>
										</Grid>
									</Box>
								)}
							</Box>
						)}

						{nodeData?.nodeType === 'sublattice' && value === 'electrons' && (
							<Box className="tabBody">
								<ElectronIcon
									data={nodeElectronDetails}
									moveLoader={moveLoader}
									showMore={showMore}
									totalCount={totalCount}
								/>
							</Box>
						)}
						{value === 'console' && result && (
							<Box className="tabBody">
								<ResultSection value={result} name="code" hideCopy objectValue={resultObject} />
							</Box>
						)}
					</Grid>
				</Grid>
			</Box>
		</Slide>
	);
}

export default ElectronSideBar;
