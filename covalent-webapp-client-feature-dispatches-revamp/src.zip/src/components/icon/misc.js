/* eslint-disable import/no-unused-modules */
/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */

import React from 'react';
import { isValid, format, parseISO } from 'date-fns';
import cancelIcon from '../../assets/cancelIcon.svg';
import runningIcon from '../../assets/runningIcon.svg';
import errorIcon from '../../assets/icons/status/error.svg';
import completeIcon from '../../assets/icons/status/completing.svg';
import Icon from './index';

export const formatDate = date => {
	if (date) {
		date = parseISO(date);
	}
	return isValid(date) ? format(date, 'MMM dd, HH:mm:ss') : '-';
};

export const statusColor = status => {
	return {
		RUNNING: '#DAC3FF',
		Cancelled: '#FF6464',
		COMPLETED: '#55D899',
		FAILED: '#FF6464'
	}[status];
};

export const statusIcon = status => {
	switch (status) {
		case 'RUNNING':
			return <Icon src={runningIcon} status="circleRunningStatus" alt="runningIcon" />;
		case 'COMPLETED':
			return <Icon src={completeIcon} alt="completeIcon" />;
		case 'CANCELLED':
			return <Icon src={cancelIcon} alt="cancelIcon" />;
		case 'FAILED':
			return <Icon src={errorIcon} alt="errorIcon" />;
		default:
			return null;
	}
};
