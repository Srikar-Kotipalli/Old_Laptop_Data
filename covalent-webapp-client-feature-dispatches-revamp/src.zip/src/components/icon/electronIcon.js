/* eslint-disable react/jsx-no-useless-fragment */
/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
/* eslint-disable react/no-array-index-key */

import React from 'react';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Divider from '@mui/material/Divider';
import { Typography, ListItemButton, Tooltip } from '@mui/material';
import OverlappingIcons from './overlappingIcons';
import MiniMoreLoader from '../../assets/loaders/loader.svg';
import caretDownIcon from '../../assets/arrows/caretDown.svg';
import Icon from './index';
import { stringReducer } from '../../utils/utils';

function ElectronIcon(props) {
	const { data, moveLoader, showMore, totalCount } = props;

	return (
		<>
			{data.length > 0 ? (
				data.map((item, key) => (
					<React.Fragment key={key}>
						<Grid container direction="row" spacing={2} alignItems="center">
							<Grid item>
								<Box>
									<OverlappingIcons
										type={item.type.toUpperCase()}
										status={item.status.toUpperCase()}
									/>
								</Box>
							</Grid>
							<Tooltip title={item.name}>
								<Typography pt={2} pl={1} variant="h2">
									{stringReducer(item.name, 30)}
								</Typography>
							</Tooltip>
						</Grid>
						<Divider sx={{ borderColor: '#303067', my: 2 }} />
					</React.Fragment>
				))
			) : (
				<Grid container direction="row" justifyContent="center">
					<Typography variant="h2">No Records Found</Typography>
				</Grid>
			)}
			{data.length !== 0 && data.length < totalCount && (
				<ListItemButton
					component="div"
					onClick={showMore}
					sx={{
						padding: '0rem',
						background: 'transparent',
						'&:hover': {
							background: 'transparent'
						}
					}}
				>
					{moveLoader ? (
						<Icon src={MiniMoreLoader} type="static" alt="moveLoader" />
					) : (
						<Icon src={caretDownIcon} type="pointer" alt="caretDown" padding="0px 3px 2px 0px" />
					)}
					<Typography variant="subtitle2" color="textPrimary">
						Show more
					</Typography>
				</ListItemButton>
			)}
		</>
	);
}

export default ElectronIcon;
