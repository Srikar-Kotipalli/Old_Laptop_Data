/* eslint-disable import/no-unused-modules */
/* eslint-disable import/prefer-default-export */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import sampleDispatch from '../sampleDispatchAxios';

// API to get all the Sample Dispatch details
export const getTutorial = apiKey => {
	// add a header to the exisitng header in CUSTOMAXIOS
	sampleDispatch.defaults.headers['x-api-key'] = apiKey;
	return sampleDispatch
		.get(`${process.env.REACT_APP_ENDPOINT_URL_AQ_BACKEND_ROOT}/tutorials`)
		.then(payload => {
			return payload;
		});
};

// API to get the Dispatch code in the Sample dispatch
export const getDispatchCode = (path, apiKey) => {
	sampleDispatch.defaults.headers['x-api-key'] = apiKey;
	return sampleDispatch
		.get(`${process.env.REACT_APP_ENDPOINT_URL_AQ_BACKEND_ROOT}${path}`)
		.then(payload => {
			return payload;
		});
};

// API to create a Sample dispatch

// eslint-disable-next-line import/no-unused-modules
export const createDispatch = (bodyParameters, path, apiKey) => {
	sampleDispatch.defaults.headers['x-api-key'] = apiKey;
	return sampleDispatch
		.post(`${process.env.REACT_APP_ENDPOINT_URL_AQ_BACKEND_ROOT}${path}`, bodyParameters)
		.then(payload => {
			return payload;
		});
};
