/* eslint-disable import/no-unused-modules */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import api from '../functionAxios';

export const getBatchFunctions = bodyParameters => {
	const { count, status, direction, sort, page, search } = bodyParameters;
	return api
		.get(`${process.env.REACT_APP_ENDPOINT_URL_AQ_FUNCTION_SERVE_BACKEND}/v0/functions`, {
			params: {
				count,
				search,
				sort,
				page,
				direction,
				...(bodyParameters?.status && {
					status
				})
			}
		})
		.then(payload => {
			return payload;
		});
};

export const getFunctionDetails = (functionId, apiKey) => {
	api.defaults.headers['x-api-key'] = apiKey;
	return api
		.get(
			`${process.env.REACT_APP_ENDPOINT_URL_AQ_FUNCTION_SERVE_BACKEND}/v0/functions/${functionId}`
		)
		.then(payload => {
			return payload;
		});
};

export const teardownFunction = (functionId, apiKey) => {
	api.defaults.headers['x-api-key'] = apiKey;
	return api
		.put(
			`${process.env.REACT_APP_ENDPOINT_URL_AQ_FUNCTION_SERVE_BACKEND}/v0/functions/${functionId}/teardown`
		)
		.then(payload => {
			return payload;
		});
};

export const testEndpointFunction = (url, apiKey) => {
	api.defaults.headers['x-api-key'] = apiKey;
	return api.post(url).then(payload => {
		return payload;
	});
};
export const getInferenceKeys = functionId => {
	return api
		.get(
			`${process.env.REACT_APP_ENDPOINT_URL_AQ_FUNCTION_SERVE_BACKEND}/v0/functions/${functionId}/inference-keys`
		)
		.then(payload => {
			return payload;
		});
};

export const addNewInferenceKey = functionId => {
	return api
		.post(
			`${process.env.REACT_APP_ENDPOINT_URL_AQ_FUNCTION_SERVE_BACKEND}/v0/functions/${functionId}/inference-keys`
		)
		.then(payload => {
			return payload;
		});
};

export const deleteInferenceKey = (functionId, keyId) => {
	return api
		.delete(
			`${process.env.REACT_APP_ENDPOINT_URL_AQ_FUNCTION_SERVE_BACKEND}/v0/functions/${functionId}/inference-keys/${keyId}`
		)
		.then(payload => {
			return payload;
		});
};
