import * as React from 'react';
import { useTheme, useMediaQuery } from '@mui/material';

const useTagParams = () => {
	const [numberOfItems, setNumberOfItems] = React.useState(3);
	const [maxWidth, setMaxWidth] = React.useState('90px');
	const theme = useTheme();
	const onlyExtraSmall = useMediaQuery(theme.breakpoints.only('xs')); // 0px - 1000px
	const onlySmallScreen = useMediaQuery(theme.breakpoints.only('sm')); // 1000px-1420px
	const onlyMediumScreen = useMediaQuery(theme.breakpoints.only('md')); // 1420- 1500px
	const onlyLargeScreen = useMediaQuery(theme.breakpoints.only('lg')); // 1500px- 1800px
	React.useLayoutEffect(() => {
		if (onlySmallScreen || onlyExtraSmall) {
			setNumberOfItems(1);
			setMaxWidth('50px');
		} else if (onlyMediumScreen || onlyLargeScreen) {
			setNumberOfItems(2);
			setMaxWidth('70px');
		} else {
			setNumberOfItems(3);
			setMaxWidth('90px');
		}
	});
	return { numberOfItems, maxWidth };
};

export default useTagParams;
