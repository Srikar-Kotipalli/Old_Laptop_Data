/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable import/prefer-default-export */

import React from 'react';
import { Typography, Box } from '@mui/material';
import dispatchSuccess from '../assets/dispatch/dispatchSuccess.svg';
import dispatchRunning from '../assets/dispatch/dispatchRunning.svg';
import dispatchCancelled from '../assets/dispatch/dispatchCancelled.svg';
import dispatchQued from '../assets/dispatch/dispatchQued.svg';
import dispatchNew from '../assets/dispatch/dispatchNew.svg';
import dispatchRunningDashboard from '../assets/dispatch/dispatchRunningDashboard.svg';
import dispatchError from '../assets/dispatch/dispatchError.svg';
import DispatchIcon from '../assets/dispatches/dispatch.svg';
import HardwareIcon from '../assets/hardware/hardware.svg';
import OnlineIcon from '../assets/hardware/online.svg';
import OfflineIcon from '../assets/hardware/offline.svg';
import experiments from '../assets/dashboard/experiments.svg';
import cost from '../assets/dashboard/cost.svg';
import dispatches from '../assets/dashboard/dispatches.svg';
import running from '../assets/dashboard/running.svg';
import ClassicalOn from '../assets/classicalOn.svg';
import ClassicalOff from '../assets/classicalOff.svg';
import QuantumOn from '../assets/quantumOn.svg';
import QuantumOff from '../assets/quantumOff.svg';
import QuantumBlank from '../assets/quantumBlank.svg';
import ClassicalBlank from '../assets/classicalBlank.svg';
import Icon from '../components/icon';
import PythonIcon from '../assets/icons/python.svg';
import FunctionIcon from '../assets/icons/function.svg';
import BashIcon from '../assets/icons/bash.svg';
import ParameterSvg from '../assets/icons/nodeType/parameter.svg';
import ElectronListSvg from '../assets/icons/nodeType/electron-list.svg';
import GeneratedSvg from '../assets/icons/nodeType/generated.svg';
import SubLatticeSvg from '../assets/icons/nodeType/sublattice.svg';
import ElectronDictSvg from '../assets/icons/nodeType/electron-dict.svg';
import ArgSvg from '../assets/icons/nodeType/arg.svg';
import AttributeSvg from '../assets/icons/nodeType/attribute.svg';
import EnvOnline from '../assets/environments/online.svg';
import pending from '../assets/dispatch/pending.svg';
import runningTimeline from '../assets/dispatch/running.svg';
import dispatching from '../assets/graph/dispatching.svg';
import ActiveIcon from '../assets/icons/status/active.svg';
import CreatingIcon from '../assets/icons/status/creating.svg';
import InactiveIcon from '../assets/icons/status/inactive.svg';

export const statusIcon = (status, padding, type = 'sidebar') => {
	switch (status) {
		case 'RUNNING':
		case 'CREATING':
		case 'IN_PROGRESS':
			if (type === 'dashboard' || type === 'env') {
				return (
					<Icon
						status="circleRunningStatus"
						src={dispatchRunningDashboard}
						type="static"
						alt="runningIcon"
						padding={padding}
					/>
				);
			} else if (type === 'sharemeScreen') {
				return <Icon src={dispatchRunning} type="static" alt="runningIcon" />;
			}
			return (
				<Icon
					status="circleRunningStatus"
					src={dispatchRunning}
					type="static"
					alt="runningIcon"
					padding={padding}
				/>
			);
		case 'COMPLETED':
		case 'READY':
			if (type === 'env') {
				return <Icon src={EnvOnline} type="static" alt="successIcon" padding={padding} />;
			}
			return <Icon src={dispatchSuccess} type="static" alt="successIcon" padding={padding} />;
		case 'FAILED':
			return <Icon src={dispatchError} type="static" alt="errorIcon" padding={padding} />;
		case 'DISPATCHING':
			return <Icon src={dispatching} type="static" alt="dispatchingIcon" padding={padding} />;
		case 'NEW':
			return <Icon src={dispatchNew} type="static" alt="newIcon" padding={padding} />;
		case 'NEW_OBJECT':
		case '':
			return <Icon src={dispatchNew} type="static" alt="newIcon" padding={padding} />;
		default:
			return null;
	}
};

export const functionServeStatus = title => {
	switch (title) {
		case 'ACTIVE':
			return (
				<>
					<Icon margin="0px 3px" src={ActiveIcon} alt="activeIcon" />
					<Typography sx={{ color: theme => theme.palette.text.success, fontSize: '12px' }}>
						Active
					</Typography>
				</>
			);
		case 'INACTIVE':
			return (
				<>
					<Icon margin="0px 3px" src={InactiveIcon} alt="inactiveIcon" />
					<Typography sx={{ color: theme => theme.palette.text.gray03, fontSize: '12px' }}>
						Inactive
					</Typography>
				</>
			);
		case 'CREATING':
			return (
				<>
					<Icon margin="0px 3px" src={CreatingIcon} alt="creatingIcon" />
					<Typography sx={{ color: theme => theme.palette.text.creating, fontSize: '12px' }}>
						Creating
					</Typography>
				</>
			);
		default:
			return null;
	}
};

export const statusTitle = (status, title, pl = '', ml = '', variant = 'h2') => {
	switch (status) {
		case 'OFFLINE':
		case 'FAILED':
			return (
				<Typography
					pl={pl}
					ml={ml}
					variant={variant}
					sx={{ color: theme => theme.palette.text.failed }}
				>
					{title}
				</Typography>
			);
		case 'ONLINE':
		case 'COMPLETED':
			return (
				<Typography
					pl={pl}
					ml={ml}
					variant={variant}
					sx={{ color: theme => theme.palette.text.success }}
				>
					{title}
				</Typography>
			);
		case 'RUNNING':
		case 'running':
			return (
				<Typography
					pl={pl}
					ml={ml}
					variant={variant}
					sx={{ color: theme => theme.palette.text.running }}
				>
					{title}
				</Typography>
			);
		case 'Blank':
			return (
				<Typography pl={pl} ml={ml} variant={variant}>
					created
				</Typography>
			);
		case 'NEW_OBJECT':
			return (
				<Typography pl={pl} ml={ml} variant={variant}>
					been initialised
				</Typography>
			);
		default:
			return null;
	}
};

export const dpexpStatusIcons = (status, animated = false) => {
	switch (status) {
		case 'RUNNING':
			if (animated) {
				return (
					<Icon
						status="circleRunningStatus"
						src={dispatchRunningDashboard}
						type="static"
						alt="runningIcon"
						width="10px"
						height="10px"
					/>
				);
			}
			return <img src={dispatchRunning} alt="runningIcon" width="10px" />;
		case 'CANCELLED':
			return <img src={dispatchCancelled} alt="runningIcon" width="10px" />;
		case 'QUED':
			return <img src={dispatchQued} alt="runningIcon" width="12px" />;
		case 'COMPLETED':
			return <img src={dispatchSuccess} alt="successIcon" width="10px" />;
		case 'FAILED':
			return <img src={dispatchError} alt="errorIcon" width="10px" />;
		case 'ONLINE':
			return <img src={OnlineIcon} alt="errorIcon" />;
		case 'OFFLINE':
			return <img src={OfflineIcon} alt="errorIcon" />;
		case 'NEW_OBJECT':
			return <img src={dispatchNew} alt="newIcon" width="10px" />;
		default:
			return null;
	}
};

export const dpexpMainIcons = type => {
	switch (type) {
		case 'DISPATCH':
			return <img src={DispatchIcon} alt="dispatchIcon" />;
		case 'SUBLATTICE':
			return <img src={SubLatticeSvg} alt="sublatticeIcon" />;
		case 'HARDWARE':
			return <img src={HardwareIcon} alt="hardwareIcon" />;
		case 'PYTHON':
			return <img src={PythonIcon} alt="hardwareIcon" />;
		case 'BASH':
			return <img src={BashIcon} alt="hardwareIcon" />;
		case 'FUNCTION':
			return (
				<img src={FunctionIcon} alt="hardwareIcon" style={{ padding: '0px 0px 0.5rem 0px' }} />
			);
		case 'PARAMETER':
			return (
				<img
					src={ParameterSvg}
					alt="parameterIcon"
					style={{ padding: '0.2rem 0px 0.5rem 0.1rem' }}
				/>
			);
		case 'ELECTRON_LIST':
			return (
				<img
					src={ElectronListSvg}
					alt="electron_list"
					style={{ padding: '0rem 0px 0.5rem 0.1rem' }}
				/>
			);
		case 'ELECTRON_DICT':
			return (
				<img
					src={ElectronDictSvg}
					alt={ElectronDictSvg}
					type="pointer"
					style={{ padding: '0rem 0px 0.5rem 0.1rem' }}
				/>
			);
		case 'ATTRIBUTE':
			return (
				<img
					src={AttributeSvg}
					alt={AttributeSvg}
					type="pointer"
					style={{ padding: '0rem 0px 0.5rem 0.1rem' }}
				/>
			);
		case 'GENERATED':
			return (
				<img
					src={GeneratedSvg}
					alt={GeneratedSvg}
					type="pointer"
					style={{ padding: '0rem 0px 0.5rem 0.1rem' }}
				/>
			);
		case 'SUBSCRIPTED':
			return (
				<img
					src={SubLatticeSvg}
					alt={SubLatticeSvg}
					type="pointer"
					style={{ padding: '0rem 0px 0.5rem 0.1rem' }}
				/>
			);
		case 'ARG':
			return (
				<img
					src={ArgSvg}
					alt={ArgSvg}
					type="pointer"
					style={{ padding: '0rem 0px 0.5rem 0.1rem' }}
				/>
			);
		default:
			return null;
	}
};

export const dbOverviewStatusIcon = title => {
	switch (title) {
		case 'Experiments':
			return <Icon src={experiments} type="static" alt="runningIcon" />;
		case 'Dispatches':
			return <Icon src={dispatches} type="static" alt="successIcon" />;
		case 'Running':
			return <Icon src={running} type="static" alt="errorIcon" />;
		case 'Cost':
			return <Icon src={cost} type="static" alt="costIcon" />;

		default:
			return null;
	}
};

// eslint-disable-next-line consistent-return
export const getHardwareSourceIcon = (type, status) => {
	if (type === 'Classical') {
		if (status === 'online') {
			return ClassicalOn;
		} else if (status === 'offline') {
			return ClassicalOff;
		}

		return ClassicalBlank;
	} else if (type === 'Quantum') {
		if (status === 'online') {
			return QuantumOn;
		} else if (status === 'offline') {
			return QuantumOff;
		}
		return QuantumBlank;
	}
};

// eslint-disable-next-line import/no-unused-modules
export const envStatusIcons = (status, padding) => {
	switch (status) {
		case 'IN_PROGRESS':
			return (
				<Icon
					status="circleRunningStatus"
					src={dispatchRunningDashboard}
					type="static"
					alt="runningIcon"
					padding={padding}
				/>
			);
		case 'READY':
			return <img src={dispatchSuccess} alt="successIcon" width="17px" />;
		case 'ERROR':
			return <img src={dispatchError} alt="errorIcon" width="17px" />;
		case 'CREATING':
			return <img src={dispatchNew} alt="newIcon" width="17px" />;
		default:
			return null;
	}
};

// eslint-disable-next-line import/no-unused-modules
export function getTimeLineIcon(status) {
	if (status === 'Pending') {
		return (
			<Box
				sx={{
					height: '26px',
					width: '26px',
					borderRadius: '4px',
					border: '1px solid rgba(48, 48, 103, 0.20)',
					display: 'grid',
					placeItems: 'center',
					background: 'rgba(28, 28, 70, 0.30)'
				}}
			>
				<img src={pending} alt="img" />
			</Box>
		);
	} else if (status === 'Failed') {
		return (
			<Box
				sx={{
					height: '26px',
					width: '26px',
					borderRadius: '4px',
					border: '1px solid rgba(48, 48, 103, 0.20)',
					display: 'grid',
					placeItems: 'center',
					background: 'rgba(28, 28, 70, 0.30)'
				}}
			>
				<img src={dispatchError} alt="img" />
			</Box>
		);
		// eslint-disable-next-line no-else-return
	} else if (status === 'Running') {
		return (
			<Box
				sx={{
					height: '26px',
					width: '26px',
					borderRadius: '4px',
					border: '1px solid rgba(48, 48, 103, 0.20)',
					display: 'grid',
					placeItems: 'center',
					background: 'rgba(28, 28, 70, 0.30)'
				}}
			>
				<img src={runningTimeline} alt="img" />
			</Box>
		);
		// eslint-disable-next-line no-else-return
	} else if (status === 'Dispatching') {
		return (
			<Box
				sx={{
					height: '26px',
					width: '26px',
					borderRadius: '4px',
					border: '1px solid rgba(48, 48, 103, 0.20)',
					display: 'grid',
					placeItems: 'center',
					background: 'rgba(28, 28, 70, 0.30)'
				}}
			>
				<img src={dispatching} alt="img" />
			</Box>
		);
		// eslint-disable-next-line no-else-return
	} else {
		return (
			<Box
				sx={{
					height: '26px',
					width: '26px',
					borderRadius: '4px',
					border: '1px solid rgba(48, 48, 103, 0.20)',
					display: 'grid',
					placeItems: 'center',
					background: 'rgba(28, 28, 70, 0.30)'
				}}
			>
				<img src={dispatchSuccess} alt="img" />
			</Box>
		);
	}
}
