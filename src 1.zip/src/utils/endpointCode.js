/* eslint-disable import/prefer-default-export */
/* eslint-disable import/no-unused-modules */
/* eslint-disable default-case */
/* eslint-disable no-duplicate-case */

const endpointCode = ({ caseNumber, method, route, invokeUrl }) => {
	const result = { curl: '', request: '' };
	switch (caseNumber) {
		case 1:
			result['curl'] = `
    curl -s -X ${method}\\
        "${invokeUrl}${route}"\\
        -d '{param1: "value1", param2: "value2"}'
        `;

			result['request'] = `
    import requests

    url = "${invokeUrl}${route}"

    data = {"param1": "value1", "param2": "value2"}
    response = requests.request(${method}, url, json=data)

    print(response.text)
            `;
			break;
		case 2:
			result['curl'] = `
    curl -s -X ${method}\\
        "${invokeUrl}${route}"
        `;

			result['request'] = `
    import requests

    url = "${invokeUrl}${route}"
    response = requests.request(${method}, url)
            
    print(response.text)
    `;
			break;

		case 3:
			result['curl'] = `
    curl -sN -X ${method}\\
        "${invokeUrl}${route}"\\
        -d '{param1: "value1", param2: "value2"}'
        `;

			result['request'] = `
    import requests

    url = "${invokeUrl}${route}"
            
    data = {"param1": "value1", "param2": "value2"}
    response = requests.request(${method}, url, stream=True, json=data)
            
    for chunk in response.iter_content(chunk_size=None):
    print(chunk)
    `;
			break;
		case 4:
			result['curl'] = `
    curl -sN -X ${method}\\
        "${invokeUrl}${route}"
        `;

			result['request'] = `
    import requests

    url = "${invokeUrl}${route}"
    response = requests.request(${method}, url, stream=True)
            
    for chunk in response.iter_content(chunk_size=None):
    print(chunk)
    `;
			break;

		case 5:
			result['curl'] = `
    token="<token>"
    curl -s -X ${method}\\
        "${invokeUrl}${route}"\\
        -H "x-api-token: $token"\\
        -d '{param1: "value1", param2: "value2"}'
        `;

			result['request'] = `
    import requests

    token = "<token>"
    url = "${invokeUrl}${route}"
            
    headers = {"x-api-key": token}
    data = {"param1": "value1", "param2": "value2"}
    response = requests.request(${method}, url, headers=headers, json=data)
            
    print(response.text)
    `;
			break;

		case 6:
			result['curl'] = `
    token="<token>"
    curl -s -X ${method}\\
        "${invokeUrl}${route}"\\
        -H "x-api-token: $token"
        `;

			result['request'] = `
    import requests

    token = "<token>"
    url = "${invokeUrl}${route}"
            
    headers = {"x-api-key": token}
    response = requests.request(${method}, url, headers=headers)
            
    print(response.text)
    `;
			break;

		case 7:
			result['curl'] = `
    token="<token>"
    curl -sN -X ${method}\\
        "${invokeUrl}${route}"\\
        -H "x-api-token: $token"\\
        -d '{param1: "value1", param2: "value2"}' 
        `;

			result['request'] = `
    import requests

    token = "<token>"
    url = "${invokeUrl}${route}"
            
    headers = {"x-api-key": token}
    data = {"param1": "value1", "param2": "value2"}
    response = requests.request(${method}, url, stream=True, headers=headers, json=data)
            
    for chunk in response.iter_content(chunk_size=None):
    print(chunk)
        `;
			break;

		case 8:
			result['curl'] = `
    token="<token>"
    curl -sN -X ${method} \\
        "${invokeUrl}${route}" \\
        -H "x-api-token: $token"   
        `;

			result['request'] = `
    import requests

    token = "<token>"
    url = "${invokeUrl}${route}"
            
    headers = {"x-api-key": token}
    response = requests.request(${method}, url, stream=True, headers=headers)
            
    for chunk in response.iter_content(chunk_size=None):
    print(chunk)
    `;
			break;
		default:
			result['curl'] = `
    curl -s -X ${method}\\
        "${invokeUrl}${route}"
        `;

			result['request'] = `
    import requests
    
    url = "${invokeUrl}${route}"
    response = requests.request(${method}, url)
                
    print(response.text)
    `;
			break;
	}
	return result;
};

export default endpointCode;
