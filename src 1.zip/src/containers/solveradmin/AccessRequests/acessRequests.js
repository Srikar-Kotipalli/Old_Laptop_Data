/* eslint-disable react/no-array-index-key */
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import {
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableRow,
	Typography,
	TableHead,
	Checkbox,
	Button,
	Chip,
	TableSortLabel
} from '@mui/material';

import Icon from '../../../components/icon';
import checkbox from '../../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../../assets/checkboxes/checkboxChecked.svg';
import { addNewSolver } from '../../../redux/solverSlice';
import { addNewHardware } from '../../../redux/hardwareSlice';
import { markDeniedSolverRequest, markGrantedSolverRequest } from '../../../redux/solverAdminSlice';
import {
	markDeniedHardwareRequest,
	markGrantedHardwareRequest
} from '../../../redux/hardwareAdminSlice';
import { dateFormatter } from '../../../utils/utils';
import MarketplaceDialogBox from '../../../components/dialogBox/marketplace/index';
import CustomisedSnackbar from '../../../components/snackbar/projects/index';

function DataTable(props) {
	const { searchValue, accessRequests, type, toFilter } = props;

	const [selectedItems, setSelectedItems] = useState([]);
	const [openDialogBox, setOpenDialogBox] = React.useState(false);
	const [clickMode, setClickMode] = React.useState('');
	const [currentData, setCurrentData] = React.useState({});
	const [selectAll, setSelectAll] = React.useState(false);
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState(false);
	const [datas, setDatas] = React.useState(accessRequests);
	const [selected, setSelected] = useState('requestedBy');
	const [toSort, setToSort] = useState('asc');
	const dispatch = useDispatch();

	const sortByField = (data, selectedColumn, sortDirection) => {
		return data.slice().sort((a, b) => {
			if (selectedColumn === 'requestDate') {
				const dateA = new Date(a.requestDate);
				const dateB = new Date(b.requestDate);
				if (toSort === 'asc') {
					return dateA - dateB;
				}
				return dateB - dateA;
			}
			const fieldA = a[selectedColumn]?.toLowerCase();
			const fieldB = b[selectedColumn]?.toLowerCase();

			if (sortDirection === 'asc') {
				return fieldA?.localeCompare(fieldB);
			}
			return fieldB?.localeCompare(fieldA);
		});
	};

	React.useEffect(() => {
		let sortedData = [...accessRequests];
		if (searchValue) {
			const filteredData = sortedData.filter(
				item =>
					item?.name.toLowerCase().includes(searchValue.toLowerCase()) ||
					item.requestedBy.toLowerCase().includes(searchValue.toLowerCase())
			);
			sortedData = filteredData;
		}

		if (toFilter === 'last_updated') {
			sortedData.sort((a, b) => {
				const dateA = new Date(a.requestDate);
				const dateB = new Date(b.requestDate);
				return dateA - dateB;
			});
			setDatas(sortedData);
		}

		if (toFilter === 'popular') {
			sortedData.sort((a, b) => {
				const dateA = a.downloads;
				const dateB = b.downloads;

				return dateB - dateA;
			});
			setDatas(sortedData);
		}

		sortedData = sortByField(sortedData, selected, toSort);
		setDatas(sortedData);
	}, [selected, toSort, searchValue, accessRequests, toFilter]);

	const checkAllHandler = () => {
		if (!selectAll) {
			const postIds = datas.map(item => {
				return type === 'solver' ? item?.solverId : item?.hardwareId;
			});
			setSelectedItems(postIds);
		} else {
			setSelectedItems([]);
		}
		setSelectAll(prev => !prev);
	};

	const handleRowSelect = (event, id) => {
		if (event.target.checked) {
			setSelectedItems(prevSelectedRows => [...prevSelectedRows, id]);
		} else {
			setSelectedItems(prevSelectedRows => prevSelectedRows.filter(rowId => rowId !== id));
			setSelectAll(false);
		}
	};

	const handleGrant = data => {
		if (type === 'solver') {
			dispatch(addNewSolver({ solver: { ...data, isGranted: true } }));
			dispatch(markGrantedSolverRequest({ request: data }));
		} else {
			dispatch(
				addNewHardware({
					hardware: { ...data, isGranted: true, type: 'Classical', status: 'online', key: 'abcd' }
				})
			);
			dispatch(markGrantedHardwareRequest({ request: data }));
		}
		setOpenDialogBox(false);
		setOpenSnackbar(true);
		setSnackbarMessage('Access Granted Successfully!');
	};

	const handleDeny = data => {
		if (type === 'solver') dispatch(markDeniedSolverRequest({ request: data }));
		else dispatch(markDeniedHardwareRequest({ request: data }));
		setOpenDialogBox(false);
	};

	const callbackHandler = () => {
		if (clickMode === 'grant') handleGrant(currentData);
		else if (clickMode === 'deny') handleDeny(currentData);
	};

	return (
		<>
			<MarketplaceDialogBox
				openDialogBox={openDialogBox}
				setOpenDialogBox={setOpenDialogBox}
				title={clickMode === 'grant' ? 'Grant Access Confirmation' : 'Deny Access Confirmation'}
				message={`Are you sure you want to ${clickMode} access?`}
				confirmButtonTitle={clickMode === 'grant' ? 'Grant Access' : 'Deny Access'}
				handler={() => callbackHandler()}
			/>
			<CustomisedSnackbar
				testId="solversSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>

			<TableContainer sx={{ width: '90%' }}>
				<Table className="tabComponentTable">
					<TableHead>
						<TableRow
							sx={{
								color: '#CBCBD7',
								'&:hover': { backgroundColor: 'transparent' }
							}}
						>
							<TableCell sx={{ borderBottom: 'none' }}>
								<Checkbox
									data-testid="headerCheckbox"
									size="small"
									sx={{ padding: '2px 0px 0px 5px' }}
									checked={selectAll}
									onChange={checkAllHandler}
									icon={
										<Icon src={checkbox} alt="checkbox" type="pointer" width="12px" height="12px" />
									}
									checkedIcon={
										<Icon
											src={checkboxChecked}
											alt="checkboxChecked"
											type="pointer"
											width="12px"
											height="12px"
										/>
									}
									// disabled={ || addMode}
								/>
							</TableCell>

							<TableCell sx={{ fontWeight: 'bold', borderBottom: 'none' }}>
								<TableSortLabel
									active={selected === 'requestedBy'}
									direction={toSort === 'asc' ? 'asc' : 'desc'}
									onClick={() => {
										setSelected('requestedBy');
										if (toSort === 'desc') {
											setToSort('asc');
										} else setToSort('desc');
									}}
								>
									Organization{' '}
								</TableSortLabel>
							</TableCell>
							<TableCell sx={{ fontWeight: 'bold', borderBottom: 'none' }}>
								<TableSortLabel
									active={selected === 'name'}
									direction={toSort === 'asc' ? 'asc' : 'desc'}
									onClick={() => {
										setSelected('name');
										if (toSort === 'desc') {
											setToSort('asc');
										} else setToSort('desc');
									}}
								>
									{type === 'solver' ? 'Solver' : 'Hardware'}
								</TableSortLabel>
							</TableCell>
							<TableCell sx={{ fontWeight: 'bold', borderBottom: 'none' }}>
								<TableSortLabel
									active={selected === 'requestDate'}
									direction={toSort === 'asc' ? 'asc' : 'desc'}
									onClick={() => {
										setSelected('requestDate');
										if (toSort === 'desc') {
											setToSort('asc');
										} else setToSort('desc');
									}}
								>
									Request Date
								</TableSortLabel>
							</TableCell>
							<TableCell sx={{ borderBottom: 'none' }}> </TableCell>
							<TableCell sx={{ borderBottom: 'none' }}> </TableCell>
						</TableRow>
					</TableHead>

					<TableBody>
						{datas?.map((row, id) => (
							// eslint-disable-next-line react/no-array-index-key
							<TableRow key={id}>
								<TableCell width="59">
									<Checkbox
										// data-testid="headerCheckbox"
										size="small"
										sx={{ padding: '2px 0px 0px 5px' }}
										value={type === 'solver' ? row?.solverId : row?.hardwareId}
										checked={
											type === 'solver'
												? selectedItems.includes(row?.solverId)
												: selectedItems.includes(row?.hardwareId)
										}
										onChange={event =>
											handleRowSelect(event, type === 'solver' ? row?.solverId : row?.hardwareId)
										}
										icon={
											<Icon
												src={checkbox}
												alt="checkbox"
												type="pointer"
												width="12px"
												height="12px"
											/>
										}
										checkedIcon={
											<Icon
												src={checkboxChecked}
												alt="checkboxChecked"
												type="pointer"
												width="12px"
												height="12px"
											/>
										}
										// disabled={ || addMode}
										// disabled={ || addMode}
									/>
								</TableCell>
								{/* <TableCell>{row.id}</TableCell> */}
								<TableCell width="360">{row?.requestedBy}</TableCell>
								<TableCell width="360">{row?.name}</TableCell>
								<TableCell width="360">{dateFormatter(row?.requestDate)}</TableCell>
								<TableCell width="90">
									{!row?.isGranted && !row?.isDenied ? (
										<Button
											variant="contained"
											sx={{
												backgroundColor: '#5552FF',
												color: '#ffffff',
												width: '69px',
												height: '22px',
												borderRadius: '70px'
											}}
											onClick={() => {
												setClickMode('grant');
												setCurrentData(row);
												setOpenDialogBox(true);
											}}
										>
											Grant
										</Button>
									) : (
										<Chip
											label={row?.isGranted ? 'Approved' : 'Denied'}
											size="small"
											sx={{
												backgroundColor: row?.isGranted ? '#55D89910' : '#FF64641A',
												color: row?.isGranted ? '#55D899' : '#FF6464',
												border: ''
											}}
										/>
									)}
								</TableCell>
								<TableCell sx={{ paddingRight: '0.5rem' }}>
									{!row?.isGranted && !row?.isDenied && (
										<Button
											variant="outlined"
											sx={{ color: '#ffffff', width: '69px', height: '22px', borderRadius: '70px' }}
											onClick={() => {
												setClickMode('deny');
												setCurrentData(row);
												setOpenDialogBox(true);
											}}
										>
											Deny
										</Button>
									)}
								</TableCell>
							</TableRow>
						))}

						{datas?.length < 1 && (
							<TableRow sx={{ '&:hover': { backgroundColor: 'transparent' } }}>
								<TableCell width="59" />
								<TableCell width="360px">
									<Typography variant="h2">No records found</Typography>
								</TableCell>
								<TableCell width="360px" />
								<TableCell width="360px" />
							</TableRow>
						)}
					</TableBody>
				</Table>
			</TableContainer>
		</>
	);
}

export default DataTable;
