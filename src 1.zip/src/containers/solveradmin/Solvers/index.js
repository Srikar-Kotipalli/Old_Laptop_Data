import React, { useState } from 'react';
import { Grid, Typography } from '@mui/material';
import { useDispatch } from 'react-redux';
import AdminCard from '../../../components/card/admin/adminCard';
import { addSolverCard } from '../../../redux/marketplaceSlice';
import MarketplaceDialogBox from '../../../components/dialogBox/marketplace/index';
import CustomisedSnackbar from '../../../components/snackbar/projects/index';

function AdminSolvers({ adminSolversData, sort, searchValue, toFilter }) {
	const [data, setData] = useState([]);
	const dispatch = useDispatch();
	const [openDialogBox, setOpenDialogBox] = useState(false);
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage] = useState(false);
	const [currentSolver, setCurrentSolver] = useState({});

	const handlePublishToMarketplace = () => {
		dispatch(addSolverCard({ solver: currentSolver }));
		setOpenDialogBox(false);
	};

	React.useEffect(() => {
		let sortedData = [...adminSolversData];
		if (searchValue) {
			const filteredData = sortedData.filter(item =>
				item?.name.toLowerCase().includes(searchValue.toLowerCase())
			);
			sortedData = filteredData;
		}
		if (toFilter === 'last_updated') {
			sortedData.sort((a, b) => {
				if (sort === 'asc') {
					return a.revenue - b.revenue;
				}
				return b.revenue - a.revenue;
			});
			setData(sortedData);
		}

		if (toFilter === 'popular') {
			sortedData.sort((a, b) => {
				if (sort === 'asc') {
					return a.downloads - b.downloads;
				}
				return b.downloads - a.downloads;
			});
			setData(sortedData);
		}
	}, [toFilter, sort, searchValue]);

	return (
		<Grid
			mt={5}
			container
			columnSpacing={1}
			ml={0.2}
			sx={{
				border: theme => `1px solid ${theme.palette.background.blue03}`,
				borderRadius: '8px',
				padding: '10px',
				width: { xs: '94%', sm: '98%', lg: '99.5%', xl: '100%' }
			}}
		>
			<MarketplaceDialogBox
				openDialogBox={openDialogBox}
				setOpenDialogBox={setOpenDialogBox}
				title="Publish solver"
				message="Are you sure you want to publish solver?"
				confirmButtonTitle="Publish"
				handler={() => handlePublishToMarketplace()}
			/>
			<CustomisedSnackbar
				testId="solversSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			{data.length !== 0 ? (
				data.map(solver => (
					<Grid
						key={solver?.solverId}
						item
						xs={6}
						sm={4}
						md={4}
						lg={4}
						xl={4}
						xxl={3}
						sx={{ padding: '10px' }}
					>
						<AdminCard
							solverImage={solver?.solverImage}
							downloads={solver?.downloads}
							name={solver?.name}
							apiCalls={solver?.apiCalls}
							revenue={solver?.revenue}
							chipData={solver?.chipdata}
							handlePublishToMarketplace={() => {
								setCurrentSolver(solver);
								setOpenDialogBox(true);
							}}
							solverId={solver?.solverId}
						/>
					</Grid>
				))
			) : (
				<Typography fontFamily="DM Sans" color="#CBCBD7" fontWeight="500" fontSize="14px">
					No Records Found
				</Typography>
			)}
		</Grid>
	);
}
export default AdminSolvers;
