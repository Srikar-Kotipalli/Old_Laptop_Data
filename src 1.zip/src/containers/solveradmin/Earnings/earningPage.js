import React, { useState } from 'react';
import { Box, Stack, Typography, Grid } from '@mui/material';
import Icon from '../../../components/icon';
import modelBuilderIcon from '../../../assets/modelBuilderIcon.svg';
import downloadIcon from '../../../assets/downloadIcon.svg';
import infoCircleIcon from '../../../assets/infoCircleIcon.svg';
import pinColorIcon from '../../../assets/pinColorIcon.svg';
import unpinIcon from '../../../assets/actions/pin.svg';
import moreVerticalIcon from '../../../assets/menus/menuVerticalIcon.svg';
import Chips from '../../../components/card/marketplace/chips';
import './style.css';
import PieChart from '../../../components/chart/pieChart';

function SolversAdminEarningsPage({ data }) {
	const revenueChartData = {
		series: [23, 11, 54, 72],
		labels: ['Downloads', 'Api call', 'Earnings', 'Other'],
		colors: ['#8B31FF', '#41418D', '#AD7BFF', '#6D7CFF']
	};

	const [isPinned, setIsPinned] = useState(false);
	return (
		<Box className="solverstabAdminCtr" width="60%">
			<Grid container>
				<Grid
					item
					xs={7}
					sx={{
						borderRight: theme => `1px solid ${theme.palette.background.blue03}`,
						pr: '8px'
					}}
				>
					<Grid container spacing={2}>
						<Grid item xs={8}>
							<Stack direction="row" spacing={1.5} alignItems="center">
								<Icon type="static" src={modelBuilderIcon} width="24px" height="24px" />
								<Typography>{data.name}</Typography>
								<Box
									sx={{
										width: '7px',
										height: '7px',
										background: theme => theme.palette.text.success,
										borderRadius: '50%'
									}}
								/>
							</Stack>
						</Grid>
						<Grid item xs={4}>
							<Stack direction="row" spacing={2} alignItems="center" justifyContent="start">
								<Box className="arrowRight" onClick={() => setIsPinned(!isPinned)}>
									{isPinned ? <Icon src={pinColorIcon} /> : <Icon src={unpinIcon} />}
								</Box>
								<Box
									sx={{
										pt: 0.5,
										borderRadius: 1,
										border: '0.5px solid transparent',
										'&:hover': { borderColor: theme => theme.palette.background.blue04 }
									}}
								>
									<Icon src={moreVerticalIcon} />
								</Box>
							</Stack>
						</Grid>
					</Grid>
					<Chips chipdata={data.chipsData} start />
					<Grid container spacing={2} sx={{ mt: 0 }}>
						<Grid item xs={4}>
							<Typography className="solvTabHead2" sx={{ mb: 1 }}>
								Total API Calls
							</Typography>
							<Stack direction="row" spacing={0.5} alignItems="center">
								<Typography variant="downloadsSolvers">${data.total_api_calls}</Typography>
								<Box sx={{ position: 'relative', top: '1px' }}>
									<Icon src={infoCircleIcon} />
								</Box>
							</Stack>
						</Grid>
						<Grid item xs={4}>
							<Typography className="solvTabHead2" sx={{ mb: 1 }}>
								Downloads
							</Typography>
							<Stack direction="row" spacing={0.5} alignItems="center">
								<Box>
									<Icon src={downloadIcon} />
								</Box>
								<Typography
									className="copyTextResolveText"
									sx={{
										color: theme => theme.palette.text.secondary
									}}
								>
									{data.download}
								</Typography>
							</Stack>
						</Grid>
						<Grid item xs={4}>
							<Typography className="solvTabHead2" sx={{ mb: 1 }}>
								Total Earnings
							</Typography>
							<Stack direction="row" spacing={0.5} alignItems="center">
								<Typography className="copyTextResolveText">${data.total_earnins}</Typography>
								<Box sx={{ position: 'relative', top: '1px' }}>
									<Icon src={infoCircleIcon} />
								</Box>
							</Stack>
						</Grid>
					</Grid>
				</Grid>
				<Grid item xs={5} sx={{ px: 1 }}>
					<PieChart revenueChartData={revenueChartData} height={120} />
				</Grid>
			</Grid>
		</Box>
	);
}

export default SolversAdminEarningsPage;
