/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable react/jsx-no-useless-fragment */
import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { Box, Grid } from '@mui/material';
import Breadcrumb from '../../components/breadcrumb';
import { headDataSolverAdmin } from '../marketplace/marketplaceConstants';
import SolverAdminTab from '../../components/tab/solveradmin';
import SubHeaderControls from '../../components/marketplace/subHeaderControls';
import AdminOverview from './Overview';
import AdminSolvers from './Solvers';
import SolversAdminEarnings from './Earnings';
import Billing from '../solverscontainer/billing';
import DataTable from './AccessRequests/acessRequests';
import OverviewHeader from '../hardwareOverview/header';

function SolverAdmin() {
	const [value, setValue] = useState('Overview');
	const [selected, setSelected] = useState('last_updated');
	const [sort, setSort] = useState('asc');
	const [searchValue, setSearchValue] = React.useState('');
	const { allSolvers } = useSelector(state => state.solverAdmin);
	const { accessRequests } = useSelector(state => state.solverAdmin);
	const [overviewData] = useState(allSolvers?.slice(-4));
	const [toFilter, setToFilter] = useState('last_updated');

	// handle tab changes
	const handleTabChange = (_event, newValue) => {
		setSearchValue('');
		setValue(newValue);
	};

	const solversEarningData = [
		{
			id: 0,
			name: 'ibm_solver-1',
			total_api_calls: '300K',
			download: '1032',
			total_earnins: '20',
			chipsData: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			]
		},
		{
			id: 1,
			name: 'ibm_solver-2',
			total_api_calls: '200K',
			download: '200',
			total_earnins: '25',
			chipsData: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'rust' },
				{ key: 2, label: 'react' },
				{ key: 3, label: '+2' }
			]
		},
		{
			id: 2,
			name: 'ibm_solver-1',
			total_api_calls: '300K',
			download: '1032',
			total_earnins: '20',
			chipsData: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			]
		},
		{
			id: 3,
			name: 'ibm_solver-2',
			total_api_calls: '200K',
			download: '200',
			total_earnins: '25',
			chipsData: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'rust' },
				{ key: 2, label: 'react' },
				{ key: 3, label: '+2' }
			]
		}
	];

	return (
		<Box sx={{ mb: 4 }}>
			<Breadcrumb secondary="Solvers" name={value} to="/solveradmin" />
			<Box>
				<OverviewHeader data={headDataSolverAdmin} placement="solverAdmin" />
			</Box>
			<Box mt={3} sx={{ marginLeft: '-10px' }}>
				<SolverAdminTab value={value} onChange={handleTabChange} />
			</Box>
			<Box sx={{ width: { lg: '102%', xl: '102%', xxl: '102%' } }}>
				{value !== 'Overview' ? (
					<SubHeaderControls
						width="100%"
						selected={selected}
						setSelected={setSelected}
						sort={sort}
						setSort={setSort}
						searchValue={searchValue}
						setSearchValue={setSearchValue}
						toFilter={toFilter}
						setToFilter={setToFilter}
						value={value}
					/>
				) : (
					<></>
				)}
			</Box>
			<Box>
				{value === 'Overview' && <AdminOverview overviewData={overviewData} />}

				{value === 'Solvers' && (
					<AdminSolvers
						adminSolversData={allSolvers}
						searchValue={searchValue}
						selected={selected}
						sort={sort}
						toFilter={toFilter}
					/>
				)}

				{value === 'Earnings' && (
					<Box mt={5}>
						<SolversAdminEarnings
							searchValue={searchValue}
							setSearchValue={setSearchValue}
							earningsData={solversEarningData}
							toFilter={toFilter}
							sort={sort}
						/>
					</Box>
				)}
				{value === 'Access Requests' && (
					<Grid mt={3}>
						<DataTable
							accessRequests={accessRequests}
							searchValue={searchValue}
							setSearchValue={setSearchValue}
							selected={selected}
							sort={sort}
							type="solver"
							toFilter={toFilter}
							setToFilter={setToFilter}
						/>
					</Grid>
				)}
				{value === 'Billing' && (
					<Grid sx={{ width: '102%' }}>
						{' '}
						<Billing
							searchValue={searchValue}
							setSearchValue={setSearchValue}
							toFilter={toFilter}
						/>
					</Grid>
				)}
			</Box>
		</Box>
	);
}

export default SolverAdmin;
