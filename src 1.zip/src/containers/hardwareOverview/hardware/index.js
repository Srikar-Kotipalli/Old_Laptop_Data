import React, { useState, useEffect } from 'react';
import { Box, Grid, Typography } from '@mui/material';
import SolverContent from '../../../components/card/admin/solverContent';

function HardwareComponent({ overviewData, searchValue, sort, toFilter }) {
	const [datas, setDatas] = useState([]);

	useEffect(() => {
		let sortedData = [...overviewData];
		if (searchValue) {
			const filteredData = sortedData.filter(item =>
				item?.name.toLowerCase().includes(searchValue.toLowerCase())
			);
			sortedData = filteredData;
		}

		if (toFilter === 'last_updated') {
			sortedData.sort((a, b) => {
				const dateA = new Date(a.purchaseDate);
				const dateB = new Date(b.purchaseDate);
				if (sort === 'asc') {
					return dateA - dateB;
				}
				return dateB - dateA;
			});
			setDatas(sortedData);
		}

		if (toFilter === 'popular') {
			sortedData.sort((a, b) => {
				const dateA = a.downloads;
				const dateB = b.downloads;
				if (sort === 'asc') {
					return dateB - dateA;
				}
				return dateA - dateB;
			});
			setDatas(sortedData);
		}
	}, [toFilter, sort, searchValue]);

	return (
		<Box mt={0} pt={0}>
			<Box sx={{ mt: 0 }}>
				<Grid
					container
					spacing={3}
					sx={{
						m: 0,
						paddingBottom: '24px',
						paddingRight: '24px',
						border: '1px solid #303067',
						borderRadius: '8px'
					}}
				>
					{datas.map(hardware => (
						<Grid
							key={hardware.id}
							item
							xs={6}
							sm={4}
							md={3}
							lg={3}
							xl={3}
							xxl={3}
							sx={{ display: 'grid', placeItems: 'center' }}
						>
							<SolverContent
								from="hardware"
								solverImage={hardware.solverImage}
								downloads={hardware.downloads}
								name={hardware?.name}
								apiCalls={hardware.apiCalls}
								revenue={hardware.revenue}
								chipData={hardware.chipData}
								borderRadius={['8px', '8px', '8px', '8px']}
								width="100%"
							/>
						</Grid>
					))}
					{datas.length < 1 && (
						<Typography mt={3} ml={1} variant="h2">
							No records found
						</Typography>
					)}{' '}
				</Grid>
			</Box>
		</Box>
	);
}

export default HardwareComponent;
