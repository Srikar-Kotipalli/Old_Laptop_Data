/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Auth, Hub } from 'aws-amplify';
import CustomisedSnackbar from '../../components/snackbar/projects';
import Loader from '../../components/loader';

function ProtectedRoute({ children }) {
	const navigate = useNavigate();
	const [refreshToken, setRefreshToken] = useState(false);
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState('');
	const [loaded, setLoaded] = useState(false);

	useEffect(() => {
		setInterval(() => {
			setRefreshToken(prevState => !prevState);
		}, 10000);
	}, []);

	useEffect(() => {
		Auth.currentSession()
			.then(res => {
				const accessToken = res.getAccessToken();
				const jwtAccess = accessToken.getJwtToken();
				const idToken = res.getIdToken();
				const jwtId = idToken.getJwtToken();
				localStorage.setItem('AUTH_ACCESS_TOKEN', jwtAccess);
				localStorage.setItem('AUTH_ID_TOKEN', jwtId);
				setLoaded(true);
			})
			.catch(() => {
				setSnackbarMessage('Session expired,please login to continue');
				setOpenSnackbar(true);
				localStorage.setItem('AUTH_ACCESS_TOKEN', null);
				localStorage.setItem('AUTH_ID_TOKEN', null);
				navigate('/login');
			});
	}, [refreshToken]);

	useEffect(() => {
		const unsubscribe = Hub.listen('auth', ({ payload: { event, data } }) => {
			// eslint-disable-next-line default-case
			switch (event) {
				case 'signIn_failure':
				case 'cognitoHostedUI_failure':
				case 'customState_failure':
					window.localStorage.setItem('isFederatedError', 'true');
					if (data?.message === 'User+is+not+enabled') {
						window.localStorage.setItem(
							'federatedError',
							'You are yet to be activated. Please contact the administrator.'
						);
					} else if (data?.message === 'User+is+disabled.+') {
						window.localStorage.setItem(
							'federatedError',
							'Sign up successful.You are yet to be activated. Please contact the administrator.'
						);
					} else if (
						data?.message ===
						'PreSignUp+failed+with+error+Sorry%2C+User+already+exist+with+same+email.+'
					) {
						window.localStorage.setItem('federatedError', 'User already exist with same email.');
					} else {
						window.localStorage.setItem('federatedError', data?.message);
					}
					break;
			}
		});

		Auth.currentAuthenticatedUser().catch(() => {
			navigate('/login');
		});
		return unsubscribe;
	}, []);

	if (!loaded) return <Loader isFetching={!loaded} width="100%" height="100vh" />;
	if (loaded)
		return (
			<>
				<CustomisedSnackbar
					open={openSnackbar}
					message={snackbarMessage}
					clickHandler={() => setOpenSnackbar(false)}
					onClose={() => setOpenSnackbar(false)}
				/>
				{children}
			</>
		);
}
export default ProtectedRoute;
