/* eslint-disable import/prefer-default-export */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';

// eslint-disable-next-line import/no-unused-modules
export const LoginContext = React.createContext({
	setMode: () => {
		// THis is setMode
	},
	setRegisterMode: () => {
		// This is for register subpages
	},
	setSnackbarMessage: () => {
		// THis is setSnackbarMessage
	},
	setOpenSnackbar: () => {
		// THis is setOpenSnackbar
	},
	setOpenLoader: () => {
		// THis is setOpenLoader
	},
	setCognitoUser: () => {
		// THis is setCognitoUser
	},
	setEmail: () => {
		// THis is setEmail
	},
	email: '',
	username: '',
	setUsername: () => {
		// THis is setUsername
	},
	password: '',
	setPassword: () => {
		// This is used for register user page
	},
	rePassword: '',
	setRePassword: () => {
		// This is used for register user page
	},
	announcements: '',
	setAnnouncements: () => {
		// This is for register page product updates to email
	},
	cognitoUser: {},
	mode: '',
	registerMode: '',
	openSnackbar: false,
	snackbarMessage: '',
	openLoader: false
});
