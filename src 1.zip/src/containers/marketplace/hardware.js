/* eslint-disable no-unused-vars */
/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable eqeqeq */
/* eslint-disable no-var */
/* eslint-disable consistent-return */
import React, { lazy, useEffect, useState } from 'react';
import { Box, Grid, Typography, Button } from '@mui/material';
import { useSelector, useDispatch } from 'react-redux';
import { useParams, useNavigate } from 'react-router-dom';
import Breadcrumb from '../../components/breadcrumb';
import MarketplaceHeader from '../../components/marketplace/header';
import OrganizationHardwareChip from '../../components/marketplace/chip';
import UsageBlock from '../../components/marketplace/usageBlock';
import DescriptionBlock from '../../components/marketplace/descriptionBlock';
import OrganizationPriceTable from '../../components/marketplace/pricetable';
import './style.css';
import { headData, priceTableData, descriptionData } from './marketplaceConstants';
// eslint-disable-next-line import/no-named-as-default
// import data from '../../components/Card/marketplace/hardwareData';
import RequestAccessButton from '../../components/marketplace/requestAccessButton';
import { addAccessRequestHardware } from '../../redux/hardwareAdminSlice';
import MarketplaceDialogBox from '../../components/dialogBox/marketplace/index';
import CustomisedSnackbar from '../../components/snackbar/projects/index';
import Chips from '../../components/card/marketplace/chips';

const PageNotFoundScreen = lazy(() => import('../pagenotfound'));

function OrganizationHardware() {
	const { hardwareId } = useParams();
	const { data } = useSelector(state => state.marketplace);
	const { user } = useSelector(state => state.common);
	const { allMyHardwares } = useSelector(state => state.hardware);
	const isvalididInfo = useState(false);
	const setisValidid = isvalididInfo[1];
	const dispatch = useDispatch();
	const [openDialogBox, setOpenDialogBox] = useState(false);
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState(false);

	useEffect(() => {
		window.scrollTo({
			top: 0,
			behavior: 'smooth'
		});
		// eslint-disable-next-line radix
		const index = data?.details?.findIndex(e => e?.hardwareId === parseInt(hardwareId));
		if (index === -1) {
			setisValidid(false);
		} else {
			setisValidid(true);
		}
	}, []);

	const onRequestAccess = () => {
		let tempArray = {};
		const index = allMyHardwares?.findIndex(e => e?.hardwareId === parseInt(hardwareId, 10));
		if (index === -1) {
			const i = data?.details?.findIndex(e => e?.hardwareId === parseInt(hardwareId, 10));
			tempArray = { ...data?.details[i] };
			tempArray['requestDate'] = new Date().toISOString();
			if (user?.attributes) {
				if (user?.attributes['custom:isOrganisation'] === 'True')
					tempArray['requestedBy'] = user?.attributes['custom:organisationName'];
				else tempArray['requestedBy'] = user?.attributes?.given_name;
			}
			dispatch(addAccessRequestHardware({ hardware: tempArray }));
			setOpenDialogBox(false);
			setOpenSnackbar(true);
			setSnackbarMessage('Access Requested Successfully!');
		} else {
			setOpenDialogBox(false);
			setOpenSnackbar(true);
			setSnackbarMessage('Access granted already!');
		}
	};

	const fetchHeadData = () => {
		const index = data.details.findIndex(e => e.hardwareId == hardwareId);
		if (index !== -1) return data?.details[index].headData;
	};
	const toBreadcrumb = () => {
		const index = data.details.findIndex(e => e.hardwareId == hardwareId);
		if (index !== -1) return data?.details[index].headData.name;
	};

	const index = data.details.findIndex(e => e.hardwareId == hardwareId);

	return (
		<>
			{/* {!isvalidid ? (
				navigateFunc()
			) : (
				<> */}
			{data?.details[hardwareId]?.parameters ? (
				<Box>
					<MarketplaceDialogBox
						openDialogBox={openDialogBox}
						setOpenDialogBox={setOpenDialogBox}
						title="Confirm Request"
						message="Are you sure you want to request access?"
						confirmButtonTitle="Request Access"
						handler={onRequestAccess}
					/>
					<CustomisedSnackbar
						testId="solversSnackbar"
						open={openSnackbar}
						message={snackbarMessage}
						clickHandler={() => setOpenSnackbar(false)}
						onClose={() => setOpenSnackbar(false)}
					/>
					<Breadcrumb secondary="Marketplace" to="/marketplace" name={toBreadcrumb()} />
					<Box>
						<Box>
							<MarketplaceHeader data={fetchHeadData()} />
						</Box>
						<Box
							sx={{
								border: '1px solid #303067',
								borderRadius: '8px',
								mb: 3
							}}
							padding=" 20px 10px"
						>
							<Grid container spacing={4}>
								<Grid item xs={6}>
									<Box sx={{ mt: 0, ml: 3, mb: 5 }}>
										<Box>
											<Typography className="headtitleCtr" sx={{ color: '#AEB6FF' }}>
												{data?.hardwareDetails.tagsHeading}
											</Typography>
											<Chips chipdata={data?.details[index]?.chipdata} start="start" />
										</Box>
										<Box sx={{ my: 4, mr: '100px' }}>
											<Typography
												className="headtitleCtr"
												sx={{ color: '#AEB6FF', fontSize: '16px' }}
											>
												About {data?.details[index]?.technology}
											</Typography>
											<Box>
												<Typography sx={{ pb: 2 }} className="aboutContent">
													{data?.hardwareDetails?.aboutHardware.content}
												</Typography>
												{data?.hardwareDetails?.aboutHardware?.points.map(item => (
													<li key={item.id} className="aboutContent">
														{item.point}
													</li>
												))}
											</Box>
										</Box>
										<Box sx={{ mb: 3 }}>
											<Typography className="headtitleCtr" sx={{ color: '#AEB6FF' }}>
												Parameters
											</Typography>
											<Grid container spacing={2}>
												<Grid item xs={4}>
													<Typography className="parameterHead">num_cpus</Typography>
													<Typography className="parameterSubHead">
														{data?.details[hardwareId]?.parameters.cpus}
													</Typography>
												</Grid>
												<Grid item xs={8}>
													<Typography className="parameterHead">num_gpus</Typography>
													<Typography className="parameterSubHead">
														{data?.details[hardwareId]?.parameters.gpus}
													</Typography>
												</Grid>
												<Grid item xs={4}>
													<Typography className="parameterHead">num_qubits</Typography>
													<Typography className="parameterSubHead">
														{data?.details[hardwareId]?.parameters.num_qbits}
													</Typography>
												</Grid>
												<Grid item xs={8}>
													<Typography className="parameterHead">Dispatches</Typography>
													<Typography className="parameterSubHead">
														{data?.details[hardwareId]?.parameters.dispatches}
													</Typography>
												</Grid>
											</Grid>
										</Box>
										<Box sx={{ mb: 3 }}>
											<OrganizationPriceTable tableData={priceTableData} />
										</Box>
										<Box>
											{/* <Button endIcon={<Icon src={ArrowRightWhite} />} className="requestBtn">
											Request Access
										</Button> */}
											<RequestAccessButton
												hardwareId={hardwareId}
												handleClick={() => setOpenDialogBox(true)}
												type="hardware"
											/>
										</Box>
									</Box>
								</Grid>
								<Grid
									item
									container
									xs={6}
									justifyContent="flex-end"
									mt="0.5rem"
									sx={{ paddingRight: '1rem' }}
								>
									<UsageBlock
										code={data.hardwareDetails.usage}
										heading="Usage"
										margin="0px 0 40px 0px"
									/>
									<DescriptionBlock desc={data?.hardwareDetails.description} minHeight="650px" />
								</Grid>
							</Grid>
						</Box>
					</Box>
				</Box>
			) : (
				<Grid sx={{ position: 'absolute', top: 0, width: '100%', left: 0 }}>
					<PageNotFoundScreen />
				</Grid>
			)}
			{/* </>
			)} */}
		</>
	);
}

export default OrganizationHardware;
