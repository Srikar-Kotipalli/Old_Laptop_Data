/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable no-unused-vars */
/* eslint-disable import/no-unused-modules */
import React, { useState, useEffect } from 'react';
import Backdrop from '@mui/material/Backdrop';
import { useDebounce } from 'use-debounce';
import { Box, Typography, Grid, Tooltip } from '@mui/material';
import { useDispatch } from 'react-redux';
import DispatchCard from '../../components/card/projects/dispatchCard';
import ShowItemsMenu from '../../components/menu/projects/showItemsMenu';
import SearchInput from '../../components/inputBase/projects/searchInput';
import ShareWithMeScreenListView from '../../components/list/sharewithme/shareWithMeScreenListView';
import { DISPATCH_HEADER } from '../../constants/tableHeaderConstants';
import { allSharedItemsList } from '../../api/shared/sharedApi';
import covLoader from '../../assets/loaders/covLoader.svg';
import Icon from '../../components/icon';
import DeletableTags from '../../components/tags/projects/deletableTags';
import closeIcon from '../../assets/actions/close.svg';
import CustomisedSnackbar from '../../components/snackbar/projects';
import { enableShare, enableShareState } from '../../redux/navbarSlice';

function ShareWithMeScreen() {
	const dispatch = useDispatch();
	// state for shared table
	const [sharedList, setSharedList] = useState([]);

	// to handle search and sort
	const [searchKey, setSearchKey] = useState('');
	const [recordcount, setRecordCount] = useState(0);
	const [searchValue] = useDebounce(searchKey, 1000);
	const [sortColumn, setSortColumn] = useState('lastUpdated');
	const [sortOrder, setSortOrder] = useState('desc');
	// state for pagination
	const [page, setPage] = useState(1);
	const [offset, setOffset] = useState(0);
	// handle tags actions
	const [tagsToFilter, setTagsToFilter] = useState([]);
	// state for handling archived dispatches
	const [showArchived, setShowArchived] = useState(false);

	const [openLoader, setOpenLoader] = useState(false);
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState('');

	const handlePageChanges = (_event, pageValue) => {
		setPage(pageValue);
		const offsetValue = pageValue === 1 ? 0 : pageValue * 10 - 10;
		setOffset(offsetValue);
	};

	// useEffect(() => {
	// 	dispatch(enableShare(false));
	// }, []);

	const sharedListApi = () => {
		const bodyParameters = {
			count: 10,
			// filterBy: value,
			offset,
			direction: sortOrder,
			sort: sortColumn,
			search: searchKey,
			tags: tagsToFilter,
			showArchived
		};
		if (searchValue?.length === 0 || searchValue?.length >= 3) {
			setOpenLoader(true);
			allSharedItemsList(bodyParameters)
				.then(response => {
					setRecordCount(response.count);
					const list = response?.items;
					setSharedList(list);
				})
				.catch(error => {
					setOpenSnackbar(true);
					setSnackbarMessage('Something went wrong,please contact the administrator!');
				})
				.finally(() => setOpenLoader(false));
		}
	};

	useEffect(() => {
		sharedListApi();
	}, [sortColumn, sortOrder, showArchived, searchValue, tagsToFilter, page]);

	const onSort = column => {
		setPage(1);
		setOffset(0);
		const isAsc = sortColumn === column && sortOrder === 'asc';
		setSortOrder(isAsc ? 'desc' : 'asc');
		setSortColumn(column);
	};

	const filterTags = tags => {
		setPage(1);
		setOffset(0);
		const filteredTags = tagsToFilter;
		if (filteredTags.indexOf(tags) === -1) {
			filteredTags.push(tags);
			setTagsToFilter([...filteredTags]);
		}
	};

	const deleteTags = tags => {
		const filteredTags = tagsToFilter;
		const index = filteredTags.indexOf(tags);
		if (index !== -1) {
			filteredTags.splice(index, 1);
		}
		setTagsToFilter([...filteredTags]);
	};

	// search
	const onSearch = e => {
		setSearchKey(e.target.value);
	};

	// cancel search
	const cancelSearch = () => {
		setSearchKey('');
	};

	return (
		<Box>
			<CustomisedSnackbar
				testId="projectSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>

			{/* <Backdrop
				open={openLoader}
				sx={{ zIndex: theme => theme.zIndex.drawer + 1125, backgroundColor: 'rgba(0,0,0,0.85)' }}
			>
				<Icon type="pointer" src={covLoader} />
			</Backdrop> */}
			{/* <Typography variant='h1' sx={{ color: 'white' }}>Shared with me</Typography> */}
			{openLoader && (
				<Grid
					sx={{
						height: '70vh',
						width: '100%',
						display: 'flex',
						alignItems: 'center',
						justifyContent: 'center'
					}}
				>
					<Icon type="pointer" src={covLoader} />
				</Grid>
			)}
			{!openLoader && (
				<Box sx={{ mt: 5 }}>
					<Typography variant="h6" gutterBottom sx={{ color: 'white' }} id="recentShared">
						Recently shared
					</Typography>
					<Grid>
						<Grid container direction="row" className="containerSpacing" id="dispatchCard">
							<DispatchCard shareScreen="true" />
						</Grid>
					</Grid>
					<Box sx={{ mt: 5 }}>
						<Grid container>
							<Grid item xs={7} sx={{ color: '#AEB6FF', fontSize: '14px', fontWeight: 700 }}>
								Items ( {recordcount} )
								{tagsToFilter && (
									<Grid
										item
										xs={12}
										sx={{ display: 'flex', paddingTop: '5px', paddingLeft: '5px' }}
									>
										<DeletableTags tags={tagsToFilter} variant="shared" deleteTagss={deleteTags} />
										{tagsToFilter.length > 0 ? (
											<Tooltip title="Clear all filtered tags" placement="right">
												<Grid
													sx={{
														display: 'flex',
														backgroundColor: '#303067',
														marginLeft: '5px',
														borderRadius: '8px',
														pt: 0.3
													}}
												>
													<Icon src={closeIcon} clickHandler={() => setTagsToFilter([])} />
												</Grid>
											</Tooltip>
										) : (
											// eslint-disable-next-line react/jsx-no-useless-fragment
											<></>
										)}
									</Grid>
								)}
							</Grid>
							<Grid item xs={5} className="buttonGrid" sx={{ paddingRight: '0' }}>
								<Grid style={{ paddingRight: '10px' }}>
									<ShowItemsMenu setShowArchived={setShowArchived} showArchived={showArchived} />
								</Grid>
								<Grid item xs={7} className="searchGrid">
									<SearchInput
										sx={{
											border: '1px solid #303067',
											borderRadius: '20px',
											height: '32.69px',
											'&.Mui-focused ': {
												border: '1px solid #6473ff'
											}
										}}
										value={searchKey || ''}
										onChange={e => onSearch(e)}
										cancelSearch={cancelSearch}
									/>
								</Grid>
							</Grid>
						</Grid>
						<Box sx={{ mt: 2 }}>
							<ShareWithMeScreenListView
								header={DISPATCH_HEADER}
								orderBy={sortColumn}
								order={sortOrder}
								shareWithTableData={sharedList}
								onSort={onSort}
								handlePageChanges={handlePageChanges}
								page={page}
								totalRecords={recordcount}
								showArchived={showArchived}
								filterTags={filterTags}
							/>
						</Box>
					</Box>
				</Box>
			)}
		</Box>
	);
}

export default ShareWithMeScreen;
