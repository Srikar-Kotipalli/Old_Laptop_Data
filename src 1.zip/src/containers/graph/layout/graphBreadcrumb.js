import React, { useContext } from 'react';
import { Breadcrumbs, Box, Typography } from '@mui/material';
import { GraphContext } from '../contexts/GraphContext';

function GraphBreadcrumb({ onBreadcrumbClick }) {
	const { breadcrumb } = useContext(GraphContext);
	return (
		<Box
			width="fit-content"
			mt={2}
			ml={3}
			p={1}
			sx={{
				backgroundColor: 'rgba(28, 28, 70, 0.40)',
				border: '1px solid rgba(48, 48, 103, 1)',
				borderRadius: '8px'
			}}
		>
			<Breadcrumbs aria-label="breadcrumb" sx={{ fontSize: '12px' }}>
				{breadcrumb?.map((item, index) => {
					return (
						<Typography
							// eslint-disable-next-line react/no-array-index-key
							key={index}
							fontSize="12px"
							color={breadcrumb?.length && index === breadcrumb.length - 1 ? '#AEB6FF' : '#CBCBD7'}
							onClick={() => onBreadcrumbClick(item)}
							sx={{
								cursor:
									breadcrumb?.length && index !== breadcrumb.length - 1 ? 'pointer' : 'default',
								'&:hover': {
									color: breadcrumb?.length && index !== breadcrumb.length - 1 ? '#AEB6FF' : '',
									textDecoration:
										breadcrumb?.length && index !== breadcrumb.length - 1 ? 'underline #AEB6FF' : ''
								}
							}}
						>
							{item?.name}
						</Typography>
					);
				})}
			</Breadcrumbs>
		</Box>
	);
}

export default GraphBreadcrumb;
