/* eslint-disable camelcase */
/* eslint-disable no-unused-vars */
/* eslint-disable react/jsx-no-useless-fragment */
import React, { useState, useContext } from 'react';
import { Box } from '@mui/material';
import { useParams } from 'react-router-dom';
import { dpexpStatusIcons } from '../../../utils/statusIcons';
import OverflowTooltip from '../../../components/tooltip/overflowTooltip';
import Qelectron from '../../../assets/graph/QelectronImage.svg';
import GraphRuntime from '../../../utils/GraphRuntime';
import { GraphContext } from '../contexts/GraphContext';
import { Prettify } from '../../../utils/utils';
import ArrowRight from '../../../assets/arrows/arrowRight.svg';
import Icon from '../../../components/icon';

// eslint-disable-next-line no-unused-vars
function FunctionChip({ functionInfo, from }) {
	const {
		setSelectedNodeId,
		setTabValue,
		selectedNodeId,
		setNodeClickFrom,
		sublatticeId,
		setSublatticeId,
		setBreadcrumb,
		showPostProcess,
		setPostProcess
	} = useContext(GraphContext);
	const [isSelected, setIsSelected] = useState(false);

	const { dispatchID } = useParams();
	const populateBreadcrumbs = () => {
		const breadcrumbdata = [];
		let data = functionInfo?.parentInfo;
		while (data) {
			breadcrumbdata.push({
				name: Prettify(data?.name, data?.type),
				id: data?.sublattice_dispatch_id
			});
			data = data.parentInfo;
		}
		breadcrumbdata.push({ name: 'Main Graph', id: dispatchID });
		breadcrumbdata.reverse();
		setBreadcrumb([...breadcrumbdata]);
	};

	const selectNode = e => {
		e.stopPropagation();
		if (from !== 'funcChip') populateBreadcrumbs();
		setIsSelected(!isSelected);
		setSelectedNodeId(functionInfo?.transport_graph_node_id);
		setSublatticeId(functionInfo?.dispatchID);
		setNodeClickFrom(from);
		if (functionInfo?.name.includes('postprocess')) setPostProcess(true);
	};

	return (
		<>
			<Box
				onClick={e => {
					// e => {
					// e.stopPropagation();
					// if (from !== 'funcChip') populateBreadcrumbs();
					// setIsSelected(!isSelected);
					// setSelectedNodeId(functionInfo?.transport_graph_node_id);
					// setSublatticeId(functionInfo?.dispatchID);
					// // setTabValue('Detail View');
					// setNodeClickFrom(from);
					selectNode(e);
				}}
				sx={{
					boxShadow: '0px 4px 8px 0px rgba(0, 0, 0, 0.35)',
					height: '38px',
					borderRadius: '8px',
					background:
						selectedNodeId &&
						(selectedNodeId === functionInfo?.transport_graph_node_id ||
							(selectedNodeId === '' && functionInfo?.transport_graph_node_id === 0)) &&
						sublatticeId === functionInfo?.dispatchID
							? '#303067'
							: // : 'linear-gradient(91deg, rgba(28, 28, 70, 0.40) 0.19%, rgba(28, 28, 70, 0.00) 99.81%)',
							  'rgba(28, 28, 70, 0.4)',
					padding: '10px',
					display: 'flex',
					justifyContent: 'space-between',
					border: '1px solid #08081A',
					'&:hover': {
						background: '#1C1C46'
					},
					alignItems: 'center',
					cursor: 'pointer'
				}}
			>
				<Box sx={{ display: 'flex' }}>
					<OverflowTooltip title={Prettify(functionInfo?.name)} length={16} />
					<Box sx={{ display: 'grid', placeItems: 'center', marginLeft: '8px' }}>
						{dpexpStatusIcons(functionInfo?.status, true)}
					</Box>
					<Box sx={{ display: 'grid', placeItems: 'center', marginLeft: '8px' }}>
						{functionInfo?.contains_qelectrons ? <img src={Qelectron} alt="isQelectron" /> : null}
					</Box>
				</Box>
				<Box
					sx={{
						display: 'flex',
						justifyContent: 'space-between',
						placeItems: 'center',
						gap: '20px'
					}}
				>
					{functionInfo?.started_at && functionInfo?.completed_at ? (
						<GraphRuntime
							startTime={functionInfo?.started_at}
							endTime={functionInfo?.completed_at}
							className="overviewsubhead"
							sx={{ fontSize: '14px' }}
						/>
					) : null}
					{/* <Box sx={{border:"1px solid yellow",placeItems:"center"}}> */}
					<Icon
						src={ArrowRight}
						alt="Next"
						clickHandler={e => {
							selectNode(e);
							setTabValue('Detail View');
						}}
						title="View Detail"
					/>
					{/* <img src={ArrowRight} alt="arrowimg" /> */}
					{/* </Box> */}
				</Box>
			</Box>
		</>
	);
}

export default FunctionChip;
