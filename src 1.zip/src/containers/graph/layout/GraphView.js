/* eslint-disable react/jsx-boolean-value */
import React, { useContext, useEffect } from 'react';
import { Grid } from '@mui/material';
import { useParams } from 'react-router-dom';
// import NodeDrawer from './NodeDrawer';
import GraphLayoutNew from '../../electron/GraphLayoutNew';
import { GraphContext } from '../contexts/GraphContext';
import Loader from '../../../components/loader';
// import ElectronsList from './ElectronsList';

function GraphView() {
	const { GraphPreview, isFetchingGraph, setZoomClick, showPostProcess, setPostProcess } =
		useContext(GraphContext);
	// const [showPostProcess, setPostProcess] = useState(false);
	const nodeMap = new Map((GraphPreview?.nodes ?? []).map(node => [node?.name, node]));
	const { dispatchID } = useParams();
	const searchName = ':postprocess:';
	const searchStatus = 'FAILED';
	const desiredNode = nodeMap?.get(searchName);
	useEffect(() => {
		if (desiredNode && desiredNode?.status === searchStatus) {
			setPostProcess(true);
		}
	}, [GraphPreview]);

	return (
		<>
			{/* <Grid item container direction="row" mt={2} justifyContent="space-between">
				<Grid
					item
					xs={3}
					sx={{
						border: '1px solid rgba(48, 48, 103, 1)',
						borderRadius: '8px',
						height: 'fit-content',
					}}
				> */}
			{/* <NodeDrawer
					isSublattice={
						((selectedNodeId || selectedNodeId === 0) && nodeData?.type === 'sublattice') ||
						(selectedNodeId === '' &&
							breadcrumb?.length > 1 &&
							breadcrumb[breadcrumb.length - 1]?.id === sublatticeId)
					}
					nodeData={nodeData}
					isSelected={!!(selectedNodeId || selectedNodeId === 0) && nodeData?.type !== 'sublattice'}
				/> */}
			{/* <Grid>
						<ElectronsList />
					</Grid>
				</Grid> */}
			<Grid
				// item
				// xs={8.6}
				sx={{
					border: '1px solid rgba(48, 48, 103, 1)',
					borderRadius: '8px',
					height: '105vh'
				}}
				onClick={() => setZoomClick(true)}
				onMouseLeave={() => setZoomClick(false)}
			>
				{isFetchingGraph && (
					<Loader isFetching={isFetchingGraph} width="100%" position="relative" height="70vh" />
				)}
				{!isFetchingGraph && (
					<GraphLayoutNew
						id="graphTour"
						showPostProcess={showPostProcess}
						setPostProcess={setPostProcess}
						GraphPreview={GraphPreview}
						dispatchID={dispatchID}
					/>
				)}
				{/* </Grid> */}
			</Grid>
		</>
	);
}

export default GraphView;
