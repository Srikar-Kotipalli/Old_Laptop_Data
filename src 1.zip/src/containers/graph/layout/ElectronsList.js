/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable no-unused-vars */
/* eslint-disable react/jsx-no-bind */
import React, { useEffect, useState, useContext } from 'react';
import { Box, Tooltip, Typography, Chip, Grid, Skeleton } from '@mui/material';
import { useParams } from 'react-router-dom';
import { AutoSizer, List } from 'react-virtualized';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import { styled } from '@mui/material/styles';
import Filter from '../../../assets/graph/filter.svg';
import Filtered from '../../../assets/graph/filter_filled.svg';
import closeIcon from '../../../assets/actions/close.svg';
import FunctionChip from './FunctionChip';
import ErrorFunction from '../../../assets/graph/ErrorFunction.svg';
import SublatticeFunctionChip from './SublatticeFunctionChip';
import { GraphContext } from '../contexts/GraphContext';
import { getAllElectrons, getGraphDetails } from '../../../api/graph/graphLayoutApi';
import { Capitalize } from '../../../utils/utils';
import Icon from '../../../components/icon';

function ElectronsList({ Refresh }) {
	const [isHovered, setIsHovered] = useState(false);
	const { entireGraph, latticeDetails } = useContext(GraphContext);
	const [open, setOpen] = useState(false);
	const [chipdata, setChipData] = useState([]);
	const [anchorEl, setAnchorEl] = React.useState(null);
	const [isFetching, setIsFetching] = useState(true);
	const [failedFunction, setFailedFunction] = useState();
	// entireGraph?.nodes?.filter(e => e?.status === 'FAILED' && e?.type !== 'parameter')
	const [functions, setFunctions] = useState();
	// entireGraph?.nodes?.filter(e => e?.status !== 'FAILED' && e?.type !== 'parameter')

	useEffect(() => {
		setIsFetching(true);
		setFailedFunction(
			entireGraph?.nodes?.filter(e => e?.status === 'FAILED' && e?.type !== 'parameter')
		);
		setFunctions(
			entireGraph?.nodes?.filter(e => e?.status !== 'FAILED' && e?.type !== 'parameter')
		);
		setIsFetching(false);
	}, [entireGraph, Refresh]);

	const ListItem = styled('li')(({ theme }) => ({
		margin: theme.spacing(0.5)
	}));

	useEffect(() => {
		if (chipdata?.length > 0) {
			const chipDataCopy = [...chipdata];
			if (latticeDetails?.status === 'FAILED') {
				const startIndex = chipDataCopy?.findIndex(i => i === 'NEW_OBJECT');
				if (startIndex !== -1) chipDataCopy?.splice(startIndex, 1);
				const newIndex = chipDataCopy?.findIndex(i => i === 'CANCELED');
				if (newIndex !== -1) chipDataCopy[newIndex] = 'NEW_OBJECT';
			}
			setFunctions(
				entireGraph?.nodes?.filter(
					e => e?.type !== 'parameter' && chipDataCopy?.findIndex(i => i === e?.status) !== -1
				)
			);
		} else setFunctions(entireGraph?.nodes?.filter(e => e?.type !== 'parameter'));
	}, [entireGraph, chipdata]);

	const handleClose = () => setOpen(false);

	const handleOpen = info => {
		if (!info?.expanded) {
			const nodes12 = [];
			getGraphDetails(info?.sublattice_dispatch_id)
				.then(response => {
					response?.nodes?.map(node => {
						return nodes12.push({
							name: node?.name,
							type: node?.type,
							function_id: node?.function_id,
							value_id: node?.value_id,
							deps_id: node?.deps_id,
							call_before_id: node?.call_before_id,
							call_after_id: node?.call_after_id,
							executor_id: node?.executor_id,
							results_id: node?.results_id,
							stdout_id: node?.stdout_id,
							stderr_id: node?.stderr_id,
							error_id: node?.error_id,
							created_at: node?.created_at,
							started_at: node?.started_at,
							completed_at: node?.completed_at,
							status: node?.status,
							python_version: node?.python_version,
							runtime: node?.runtime,
							parent_lattice_id: node?.parent_lattice_id,
							transport_graph_node_id: node?.transport_graph_node_id,
							id: node?.transport_graph_node_id,
							node_id: node?.transport_graph_node_id,
							executor_label: node?.executor?.environment_name,
							sublattice_dispatch_id: node?.sublattice_dispatch_id, // child sublattice's id
							dispatchID: info?.sublattice_dispatch_id, // corres dispatch id of the node
							masterDispatchID: info?.masterDispatchID, // master sublattice's dispatch id
							masterNodeID: info?.masterNodeID, // master sublattice's node id
							indent: info?.indent ? info.indent + 1 : 1,
							parentInfo: info
						});
					});
					const data = {
						nodes: nodes12?.filter(e => e?.type !== 'parameter')
					};
					if (info?.indent > 1) {
						const splitIndex = functions?.findIndex(
							e => e?.sublattice_dispatch_id === info?.dispatchID
						);
						const masterIndex = functions?.findIndex(
							e =>
								e?.transport_graph_node_id === info?.masterNodeID &&
								e?.dispatchID === info?.masterDispatchID
						);
						if (splitIndex !== -1) {
							const prevArr = functions?.slice(0, splitIndex + 1);
							const postArr = functions?.slice(splitIndex + functions[splitIndex].length + 1);
							prevArr[splitIndex] = {
								...info,
								expanded: true,
								length: data.nodes.length,
								indent: 1,
								back: true,
								nodes: data?.nodes,
								parentInfo: prevArr[splitIndex]
							};
							const framedArray = [...prevArr, ...data.nodes, ...postArr];
							if (masterIndex !== -1 && masterIndex !== splitIndex) {
								framedArray[masterIndex] = {
									...framedArray[masterIndex],
									length:
										framedArray[masterIndex].length -
										functions[splitIndex].length +
										data.nodes.length
								};
							}
							setFunctions(framedArray);
						}
					} else if (info?.indent === 1) {
						const splitIndex = functions?.findIndex(
							e =>
								e?.transport_graph_node_id === info?.transport_graph_node_id &&
								e?.dispatchID === info?.dispatchID
						);
						const masterIndex = functions?.findIndex(
							e =>
								e?.transport_graph_node_id === info?.masterNodeID &&
								e?.dispatchID === info?.masterDispatchID
						);
						if (splitIndex !== -1) {
							const prevArr = functions?.slice(0, splitIndex + 1);
							const postArr = functions?.slice(splitIndex + 1);
							prevArr[splitIndex] = {
								...prevArr[splitIndex],
								expanded: true,
								length: data.nodes.length,
								nodes: data.nodes
							};
							const framedArray = [...prevArr, ...data.nodes, ...postArr];
							if (masterIndex !== -1 && masterIndex !== splitIndex) {
								framedArray[masterIndex] = {
									...framedArray[masterIndex],
									length: framedArray[masterIndex].length + data.nodes.length
								};
							}
							setFunctions(framedArray);
						}
					} else {
						const splitIndex = functions?.findIndex(
							e =>
								e?.transport_graph_node_id === info?.masterNodeID &&
								e?.dispatchID === info?.masterDispatchID
						);
						if (splitIndex !== -1) {
							const prevArr = functions?.slice(0, splitIndex + 1);
							const postArr = functions?.slice(splitIndex + 1);
							prevArr[splitIndex] = {
								...prevArr[splitIndex],
								expanded: true,
								length: data?.nodes?.length
							};
							const framedArray = [...prevArr, ...data.nodes, ...postArr];
							setFunctions(framedArray);
						}
					}
				})
				.catch(_error => {
					setFunctions(e => [...e]);
				});
		} else {
			let splitIndex = -1;
			let masterIndex = -1;
			if (info?.indent === 1) {
				splitIndex = functions?.findIndex(
					e =>
						e?.transport_graph_node_id === info?.transport_graph_node_id &&
						e?.dispatchID === info?.dispatchID
				);
				masterIndex = functions?.findIndex(
					e =>
						e?.transport_graph_node_id === info?.masterNodeID &&
						e?.dispatchID === info?.masterDispatchID
				);
			} else {
				splitIndex = functions?.findIndex(
					e =>
						e?.transport_graph_node_id === info?.masterNodeID &&
						e?.dispatchID === info?.masterDispatchID
				);
			}
			if (splitIndex !== -1) {
				const prevArr = functions?.slice(0, splitIndex + 1);
				const postArr = functions?.slice(splitIndex + info.length + 1);
				prevArr[splitIndex] = { ...prevArr[splitIndex], expanded: false };
				const framedArray = [...prevArr, ...postArr];
				if (masterIndex !== -1 && masterIndex !== splitIndex && info?.indent === 1) {
					framedArray[masterIndex] = {
						...framedArray[masterIndex],
						length: framedArray[masterIndex].length - info.length
					};
				}
				setFunctions(framedArray);
			}
		}
	};

	// to be implemented
	const handleHierarchyBack = info => {
		const splitIndex = functions?.findIndex(
			e =>
				e?.transport_graph_node_id === info?.transport_graph_node_id &&
				e?.dispatchID === info?.dispatchID
		);
		const masterIndex = functions?.findIndex(
			e =>
				e?.transport_graph_node_id === info?.masterNodeID &&
				e?.dispatchID === info?.masterDispatchID
		);
		if (splitIndex !== -1) {
			const prevArr = functions?.slice(0, splitIndex + 1);
			let postArr = [];
			if (info?.expanded) {
				postArr = functions?.slice(splitIndex + functions[splitIndex].length + 1);
			} else {
				postArr = functions?.slice(splitIndex + 1);
			}
			prevArr[splitIndex] = info?.parentInfo;
			const framedArray = [...prevArr, ...info.parentInfo.nodes, ...postArr];
			if (masterIndex !== -1 && masterIndex !== splitIndex) {
				if (info?.expanded) {
					framedArray[masterIndex] = {
						...framedArray[masterIndex],
						length:
							framedArray[masterIndex].length -
							functions[splitIndex].length +
							info.parentInfo.length
					};
				} else {
					framedArray[masterIndex] = {
						...framedArray[masterIndex],
						length: framedArray[masterIndex].length + info.parentInfo.length
					};
				}
			}
			setFunctions(framedArray);
		}
	};

	const rowRenderer = ({ index, key, style }) => {
		return (
			<div key={key} style={style}>
				<Box sx={{ padding: '5px 5px 5px 0px' }}>
					{functions[index]?.type === 'sublattice' ? (
						<Box
							sx={{
								borderLeft: functions[index]?.indent ? '1px solid #303067' : '',
								ml: functions[index]?.indent > 1 ? '1rem' : '0rem'
							}}
						>
							<Box
								sx={{
									ml: functions[index]?.indent
										? functions[index]?.indent === 1
											? '1rem'
											: '2rem'
										: '0rem'
								}}
							>
								<SublatticeFunctionChip
									functionInfo={functions[index]}
									handleOpen={handleOpen}
									handleHierarchyBack={handleHierarchyBack}
								/>
							</Box>
						</Box>
					) : (
						<Box
							sx={{
								borderLeft: functions[index]?.indent ? '1px solid #303067' : '',
								ml: functions[index]?.indent > 1 ? '1rem' : '0rem'
							}}
						>
							<Box
								sx={{
									ml: functions[index]?.indent
										? functions[index]?.indent === 1
											? '1rem'
											: '2rem'
										: '0rem'
								}}
							>
								<FunctionChip functionInfo={functions[index]} />
							</Box>
						</Box>
					)}
				</Box>
			</div>
		);
	};

	const failedRowRenderer = ({ index, key, style }) => {
		return (
			<div key={key} style={style}>
				<Box sx={{ padding: '5px 5px 5px 0px' }}>
					{failedFunction[index]?.type === 'sublattice' ? (
						<Box
							sx={{
								borderLeft: functions[index]?.indent ? '1px solid #303067' : '',
								ml: functions[index]?.indent > 1 ? '1rem' : '0rem'
							}}
						>
							<Box
								sx={{
									ml: functions[index]?.indent
										? functions[index]?.indent === 1
											? '1rem'
											: '2rem'
										: '0rem'
								}}
							>
								<SublatticeFunctionChip
									functionInfo={failedFunction[index]}
									handleOpen={handleOpen}
									handleHierarchyBack={handleHierarchyBack}
								/>
							</Box>
						</Box>
					) : (
						<Box
							sx={{
								borderLeft: functions[index]?.indent ? '1px solid #303067' : '',
								ml: functions[index]?.indent > 1 ? '1rem' : '0rem'
							}}
						>
							<Box
								sx={{
									ml: functions[index]?.indent
										? functions[index]?.indent === 1
											? '1rem'
											: '2rem'
										: '0rem'
								}}
							>
								<FunctionChip functionInfo={failedFunction[index]} />
							</Box>
						</Box>
					)}
				</Box>
			</div>
		);
	};

	const handleDelete = tag => {
		// handle delete
		const chips = [...chipdata];
		const index = chips.indexOf(tag);
		if (index !== -1) {
			chips.splice(index, 1);
		}
		setChipData([...chips]);
	};

	return (
		<Box
			sx={{
				overflowY: 'scroll',
				width: '100%',
				height: '600px',
				overflowX: 'hidden',
				padding: '0px 0px 0px 5px'
			}}
		>
			<Box>
				{failedFunction && failedFunction?.length > 0 && (
					<Box sx={{ width: '100%' }}>
						<Box sx={{ display: 'flex', gap: '5px', pt: '10px', pb: '10px' }}>
							<img src={ErrorFunction} alt="errorstatus" />
							<Typography
								sx={{
									fontSize: '14px',
									color: 'rgba(255, 100, 100, 1)',
									// display: 'grid',
									// border: '1px solid yellow',
									pt: '4px'
									// placeItems: 'center'
								}}
							>
								Functions with Errors
							</Typography>
						</Box>
						{!isFetching ? (
							<>
								{failedFunction?.length > 0 && (
									<AutoSizer>
										{({ width }) => (
											<List
												// ref={registerChild}
												height={failedFunction ? failedFunction.length * 50 : 0}
												// onRowsRendered={onRowsRendered}
												rowCount={failedFunction?.length}
												rowHeight={47}
												rowRenderer={failedRowRenderer}
												width={width}
											/>
										)}
									</AutoSizer>
								)}
							</>
						) : (
							<Skeleton variant="text" width={100} />
						)}
						{/* {failedFunction?.length === 0 && (
						<Typography
							sx={{
								mt: '10px',
								fontSize: '14px',
								color: '#CBCBD7',
								fontWeight: '400',
								marginBottom: '10px',
								ml: 1
							}}
						>
							No records Found
						</Typography>
					)} */}
					</Box>
				)}
			</Box>
			{/* <Box> */}
			<Menu
				variant="menu"
				anchorEl={anchorEl}
				open={open}
				onClose={handleClose}
				keepMounted={false}
			>
				{['NEW_OBJECT', 'RUNNING', 'COMPLETED', 'FAILED', 'CANCELED']?.map(info => (
					<MenuItem
						key={info}
						onClick={() => {
							const chips = [...chipdata];
							chips?.push(info);
							setChipData([...chips]);
							handleClose();
						}}
						disabled={chipdata?.findIndex(e => e === info) !== -1}
						data-testid="filter"
					>
						<Typography variant="subtitle2">
							{info === 'NEW_OBJECT' ? 'Starting' : Capitalize(info)}
						</Typography>
					</MenuItem>
				))}
			</Menu>

			<Box
				sx={{
					display: 'flex',
					justifyContent: 'space-between',
					// marginBottom: '10px',
					padding: '10px 5px 10px 5px',
					mt: failedFunction ? failedFunction.length * 6 : 0
				}}
			>
				<Typography
					sx={{
						fontSize: '14px',
						color: '#AEB6FF',
						fontWeight: '700',
						// marginBottom: '10px',
						// border:"1px solid red",
						display: 'grid',
						placeItems: 'center',
						cursor: 'default'
					}}
				>
					All Functions
				</Typography>
				<Tooltip title="Filter" placement="top">
					<span>
						<Box onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
							<Icon
								src={isHovered ? Filtered : Filter}
								alt="filter"
								clickHandler={event => {
									setAnchorEl(event?.currentTarget);
									setOpen(prevState => !prevState);
								}}
								bgColor="#2a2a5c"
								padding="4px"
							/>
						</Box>
					</span>
				</Tooltip>
			</Box>
			<Box
				sx={{
					display: 'flex',
					listStyle: 'none',
					background: 'none',
					flexWrap: 'wrap',
					overflowY: 'auto',
					maxHeight: '5rem'
				}}
				component="ul"
			>
				{chipdata?.map((data, index) => {
					return (
						// eslint-disable-next-line react/no-array-index-key
						<ListItem key={index}>
							<Chip
								label={data === 'NEW_OBJECT' ? 'Starting' : Capitalize(data)}
								size="small"
								onDelete={() => handleDelete(data)}
							/>
						</ListItem>
					);
				})}
				{chipdata?.length > 0 ? (
					<Tooltip title="Clear all filters" placement="right">
						<Grid
							sx={{
								display: 'flex',
								backgroundColor: '#303067',
								marginLeft: '5px',
								borderRadius: '8px',
								pt: 0.1,
								pl: 0.4,
								width: '24px',
								height: '24px',
								marginTop: '5px'
							}}
						>
							<Icon
								src={closeIcon}
								clickHandler={() => setChipData([])}
								width="12px"
								height="12px"
							/>
						</Grid>
					</Tooltip>
				) : (
					<></>
				)}
			</Box>
			<Box sx={{ width: '100%' }}>
				{!isFetching ? (
					<>
						{functions?.length > 0 && (
							<AutoSizer>
								{({ width }) => (
									<List
										// ref={registerChild}
										height={functions ? functions.length * 48 : 0}
										// onRowsRendered={onRowsRendered}
										rowCount={functions?.length}
										rowHeight={47}
										rowRenderer={rowRenderer}
										width={width}
									/>
								)}
							</AutoSizer>
						)}
					</>
				) : (
					<Skeleton variant="text" width={100} />
				)}
			</Box>
			{functions?.length === 0 && (
				<Typography
					sx={{
						fontSize: '14px',
						color: '#CBCBD7',
						fontWeight: '400',
						marginBottom: '50px',
						ml: 1,
						mt: '7px'
					}}
				>
					No records Found
				</Typography>
			)}
			{/* </Box> */}
		</Box>
	);
}

export default ElectronsList;
