import React from 'react';
import { Typography, Box } from '@mui/material';

function Metrics({ heading, duration, imgSrc }) {
	return (
		<Box
			sx={{
				borderRadius: '8px',
				border: '1px solid #303067',
				background: 'rgba(28, 28, 70, 0.40)',
				padding: '6px 15px 6px 15px',
				display: 'flex',
				justifyContent: 'space-between'
			}}
		>
			<Box sx={{ display: 'flex' }}>
				<Box
					sx={{
						width: '14px',
						height: '14px',
						display: 'grid',
						placeItems: 'center',
						marginRight: '11px'
					}}
				>
					<img src={imgSrc} alt="metricImage" />
				</Box>
				<Typography
					sx={{ fontSize: '14px', color: '#CBCBD7', fontWeight: '400', paddingLeft: '11px' }}
				>
					{heading}
				</Typography>
			</Box>
			<Typography sx={{ fontSize: '14px', color: '#CBCBD7', fontWeight: '700' }}>
				{duration}
			</Typography>
		</Box>
	);
}

export default Metrics;
