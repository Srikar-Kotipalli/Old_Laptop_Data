/* eslint-disable react/jsx-no-constructed-context-values */
/* eslint-disable react/function-component-definition */
/* eslint-disable no-unused-vars */
import React, { createContext, useEffect, useState } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import { useEdges } from 'reactflow';
import {
	getGraphDetails,
	getLatticeByDispatchID,
	getDispatchByInput,
	getCodeByLattice,
	getAllElectrons,
	getElectronByNode,
	getNodeAssetsById,
	getQElectronNodeJobs,
	getQelectronAssetsUrl,
	getAssetFromUrl,
	getJobExecutors,
	getQelectronJobOverview,
	getAllStatusBasedElectrons,
	getLatticeCost,
	getNodeCost
} from '../../../api/graph/graphLayoutApi';

import { getElectronInput } from '../../../api/experiments/dispatchApi';

export const GraphContext = createContext();

const GraphProvider = ({ children }) => {
	const [GraphPreview, setGraphPreviewData] = useState({});
	const [entireGraph, setEntireGraph] = useState({});
	const [latticeDetails, setLatticeDetails] = useState({});
	const [sublatticeDetails, setSubLatticeDetails] = useState({});
	const [openLoader, setOpenLoader] = useState(false);
	const [notFound, setNotFound] = useState(false);
	const [dispatchResult, setDispatchResult] = useState('');
	const [dispatchResultcopy, setDispatchResultcopy] = useState('');
	const [input, setInput] = useState('');
	const [code, setCode] = useState({});
	const [dispatchCodeCopy, setDispatchCodeCopy] = useState('');
	const [error, setError] = useState('');
	const [functionsList, setFunctionList] = useState([]);
	const [allElectrons, setAllElectrons] = useState([]);
	const [errorFunctions, setErrorFunctions] = useState([]);
	const [description, setDescription] = useState('');
	const [nodeData, setNodeData] = useState({});
	const [timeline, setTimeline] = useState([]);
	const [latticeTimeline, setLatticeTimeline] = useState([]);
	const [selectedNodeResult, setSelectedNodeResult] = useState('');
	const [selectedNodeResultCopy, setSelectedNodeResultCopy] = useState('');
	const [selectedNodeInput, setSelectedNodeInput] = useState('');
	const [selectedNodeInputCopy, setSelectedNodeInputCopy] = useState('');
	const [selectedNodeCode, setSelectedNodeCode] = useState('');
	const [selectedNodeCodeCopy, setSelectedNodeCodeCopy] = useState('');
	const [selectedNodeConsole, setSelectedNodeConsole] = useState('');
	const [nodeJobs, setNodeJobs] = useState({});
	const [selectedJob, setSelectedJob] = useState('');
	const [selectedJobDetails, setSelectedJobDetails] = useState({});
	const [qelectronCircuit, setQElectronCircuit] = useState('');
	const [qelectronResult, setQelectronResult] = useState('');
	const [result, setResult] = useState('');
	const [selectedJobExecutors, setSelectedJobExecutors] = useState({});
	const [allowedExecutor, setAllowedExecutor] = useState('');
	const [selectedNodeId, setSelectedNodeId] = useState('');
	const [nodeClickFrom, setNodeClickFrom] = useState('funcChip');
	const [sublatticeId, setSublatticeId] = useState('');
	const [tabValue, setTabValue] = useState('Graph View');
	const [electronsLoading, setElectronsLoading] = useState(false);
	const [isFetchingLatticeDetails, setIsfetchingLatticeDetails] = useState(false);
	const [isFetchingLatticeInput, setIsFetchingLatticeInput] = useState(false);
	const [isFetchingLatticeResult, setIsFetchingLatticeResult] = useState(false);
	const [isFetchingLatticeError, setIsFetchingLatticeError] = useState(false);
	const [isFetchingLatticeErrorFunctions, setIsFetchingLatticeErrorFunctions] = useState(false);
	const [isFetchingNodeData, setIsFetchingNodedata] = useState(false);
	const [isFetchingSelectedJobDetails, setIsFetchingSelectedJobDetails] = useState(false);
	const [isFetchingGraph, setIsFetchingGraph] = useState(false);
	const [breadcrumb, setBreadcrumb] = useState([]);
	const [nodeError, setNodeError] = useState('');
	const [nodeDetailClose, setNodeDetailClose] = useState(false);
	const [zoomClick, setZoomClick] = useState(false);
	const [latticeCost, setLatticeCost] = useState('$0.00');
	const [nodeCost, setNodeCost] = useState('$0.00');
	const [isFetchingLatticeCost, setIsFetchingLatticeCost] = useState(false);
	const [isFetchingNodeCost, setIsFetchingNodeCost] = useState(false);
	const [isFetchingNodeResult, setIsFetchingNodeResult] = useState(false);
	const [isFetchingNodeCode, setIsFetchingNodeCode] = useState(false);
	const [isFetchingNodeInput, setIsFetchingNodeInput] = useState(false);
	const [isFetchingNodeError, setIsFetchingNodeError] = useState(false);
	const [isFetchingNodeConsole, setIsFetchingNodeConsole] = useState(false);
	const [isFetchingLatticeCode, setIsFetchingLatticeCode] = useState(false);

	const [showPostProcess, setPostProcess] = useState(false);
	const [enableShareOption, setEnableShareOption] = useState(false);
	const [foundObject, setFoundObject] = useState('');
	const [popupNode, setPopupNode] = useState('');
	const [subLatticeElectron, setSublatticeElectron] = useState(null);
	const [subLatticeRuntime, setSublatticeRuntime] = useState(null);
	const [isFetchingHover, setIsFetchingHover] = useState(false);
	const [isNodeBoxVisible, setNodeBoxVisible] = useState(false);
	const [sublatticeStatus, setSublatticeStatus] = useState('');

	useEffect(() => {
		if (tabValue === 'Graph View') {
			setNodeBoxVisible(false);
		}
	}, [tabValue]);

	// nodes edges
	const getGraphDetailsApi = (dispatchID, intialLoad = false, noLoader = false) => {
		if (!noLoader) setIsFetchingGraph(true);
		const nodesArr = [];
		const edgesArr = [];
		getGraphDetails(dispatchID)
			.then(response => {
				response?.nodes?.map(node => {
					return nodesArr.push({
						name: node?.name,
						type: node?.type,
						function_id: node?.function_id,
						value_id: node?.value_id,
						deps_id: node?.deps_id,
						call_before_id: node?.call_before_id,
						call_after_id: node?.call_after_id,
						executor_id: node?.executor_id,
						results_id: node?.results_id,
						stdout_id: node?.stdout_id,
						stderr_id: node?.stderr_id,
						error_id: node?.error_id,
						created_at: node?.created_at,
						started_at: node?.started_at,
						completed_at: node?.completed_at,
						status: node?.status,
						python_version: node?.python_version,
						runtime: node?.runtime,
						parent_lattice_id: node?.parent_lattice_id,
						transport_graph_node_id: node?.transport_graph_node_id,
						id: node?.transport_graph_node_id,
						node_id: node?.transport_graph_node_id,
						executor_label: node?.executor?.environment_name,
						sublattice_dispatch_id: node?.sublattice_dispatch_id,
						contains_qelectrons: node?.contains_qelectrons,
						masterDispatchID: dispatchID,
						masterNodeID: node?.transport_graph_node_id,
						dispatchID
					});
				});
				response?.edges?.map(edge => {
					return edgesArr.push({
						edge_name: edge?.edge_name,
						parameter_type: edge?.parameter_type,
						arg_index: edge?.arg_index,
						source: edge?.from_node_id,
						target: edge?.to_node_id
					});
				});
				const data = {
					nodes: nodesArr,
					links: edgesArr
				};
				setGraphPreviewData(data);
				if (intialLoad) {
					setEntireGraph(data);
				}
			})
			.catch(_error => {
				setGraphPreviewData({});
				if (intialLoad) setEntireGraph({});
			})
			.finally(() => {
				setIsFetchingGraph(false);
			});
	};

	// dispatch details
	const getLatticeAPI = (dispatchID, type, noLoader = false) => {
		if (type !== 'sublattice' && !noLoader) {
			setIsfetchingLatticeDetails(true);
			setOpenLoader(true);
		}
		getLatticeByDispatchID(dispatchID)
			.then(response => {
				if (type === 'sublattice') setSubLatticeDetails(response);
				else {
					setLatticeDetails(response);
					setIsfetchingLatticeDetails(false);
					if (!response?.started_at) {
						setLatticeTimeline([
							{
								status: response?.created_at ? 'Pending' : null,
								time: response?.created_at ? response?.created_at : null,
								color: '#86869A',
								icon: 'Pending'
							}
						]);
					} else if (response?.status === 'RUNNING') {
						setLatticeTimeline([
							{
								status: response?.created_at ? 'Pending' : null,
								time: response?.created_at ? response?.created_at : null,
								color: '#86869A',
								icon: 'Pending'
							},
							{
								status: response?.started_at ? 'Running' : null,
								time: response?.started_at ? response?.started_at : null,
								color: '#86869A',
								icon: 'Running'
							}
						]);
					} else {
						setLatticeTimeline([
							{
								status: response?.created_at ? 'Pending' : null,
								time: response?.created_at ? response?.created_at : null,
								color: '#86869A',
								icon: 'Pending'
							},
							{
								status: response?.started_at ? 'Running' : null,
								time: response?.started_at ? response?.started_at : null,
								color: '#86869A',
								icon: 'Running'
							},
							{
								status: response?.completed_at
									? response.status === 'COMPLETED'
										? 'Completed'
										: 'Failed'
									: null,
								time: response?.completed_at ? response?.completed_at : null,
								color: response.status === 'COMPLETED' ? '#55D899' : '#FF6464',
								icon: response.status === 'COMPLETED' ? 'Completed' : 'Failed'
							}
						]);
					}
				}
			})
			.catch(_error => {
				if (type === 'sublattice') setSubLatticeDetails({});
				else {
					setLatticeDetails({});
					setLatticeTimeline([]);
					setNotFound(true);
				}
				setIsfetchingLatticeDetails(false);
			});
	};

	const getDispatchResult = dispatchID => {
		setIsFetchingLatticeResult(true);
		getDispatchByInput(dispatchID, 'result', 'string')
			.then(response => {
				if (response?.urls && response?.urls?.length > 0 && response?.urls[0]?.url) {
					getAssetFromUrl(response?.urls[0]?.url)
						.then(res => {
							setDispatchResult(res?.data);
							setIsFetchingLatticeResult(false);
						})
						.catch(err => {
							setDispatchResult('None');
							setIsFetchingLatticeResult(false);
						});
				} else {
					setDispatchResult('None');
					setIsFetchingLatticeResult(false);
				}
			})
			.catch(e => {
				setDispatchResult('None');
				setIsFetchingLatticeResult(false);
			});
	};

	const getDispatchResultCopy = dispatchID => {
		getDispatchByInput(dispatchID, 'result', 'object')
			.then(response => {
				if (response?.urls && response?.urls?.length > 0 && response?.urls[0]?.url) {
					getAssetFromUrl(response?.urls[0]?.url)
						.then(res => {
							setDispatchResultcopy(`
				import pickle
				import base64		
				string_object = "${res?.data}"		
				decoded_object = base64.b64decode(string_object)		
				deserialized_object = pickle.loads(decoded_object)		
				print(deserialized_object)`);
						})
						.catch(err => {
							setDispatchResultcopy('');
						});
				} else {
					setDispatchResultcopy('');
				}
			})
			.catch(e => {
				setDispatchResultcopy('');
			});
	};

	const getInput = dispatchID => {
		setIsFetchingLatticeInput(true);
		getDispatchByInput(dispatchID, 'inputs', 'string')
			.then(response => {
				if (response?.urls && response?.urls?.length > 0 && response?.urls[0]?.url) {
					getAssetFromUrl(response?.urls[0]?.url)
						.then(res => {
							setInput(res?.data?.toString());
							setIsFetchingLatticeInput(false);
						})
						.catch(err => {
							setInput('None');
							setIsFetchingLatticeInput(false);
						});
				} else {
					setInput('None');
					setIsFetchingLatticeInput(false);
				}
			})
			.catch(e => {
				setInput('None');
				setIsFetchingLatticeInput(false);
			});
	};

	const getCode = dispatchID => {
		setIsFetchingLatticeCode(true);
		getCodeByLattice(dispatchID, 'workflow_function_string')
			.then(response => {
				if (response?.urls && response?.urls?.length > 0 && response?.urls[0]?.url) {
					getAssetFromUrl(response?.urls[0]?.url)
						.then(res => {
							setCode(res?.data?.toString());
							setIsFetchingLatticeCode(false);
						})
						.catch(err => {
							setCode('None');
							setIsFetchingLatticeCode(false);
						});
				} else {
					setCode('None');
					setIsFetchingLatticeCode(false);
				}
			})
			.catch(e => {
				setCode('None');
				setIsFetchingLatticeCode(false);
			});
		getCodeByLattice(dispatchID, '__doc__')
			.then(response => {
				if (response?.urls && response?.urls?.length > 0 && response?.urls[0]?.url) {
					getAssetFromUrl(response?.urls[0]?.url)
						.then(res => {
							setDescription(res?.data?.toString());
						})
						.catch(err => {
							setDescription('');
						});
				} else {
					setDescription('');
				}
			})
			.catch(e => {
				setDescription('');
			});
	};

	const getDispatchCodeCopy = dispatchID => {
		getCodeByLattice(dispatchID, 'workflow_function', 'object')
			.then(response => {
				if (response?.urls && response?.urls?.length > 0 && response?.urls[0]?.url) {
					getAssetFromUrl(response?.urls[0]?.url)
						.then(res => {
							setDispatchCodeCopy(res?.data?.toString());
						})
						.catch(err => {
							setDispatchCodeCopy('');
						});
				} else {
					setDispatchCodeCopy('');
				}
			})
			.catch(e => {
				setDispatchCodeCopy('');
			});
	};

	const getError = dispatchID => {
		setIsFetchingLatticeError(true);
		getDispatchByInput(dispatchID, 'error')
			.then(response => {
				setError(response);
				setIsFetchingLatticeError(false);
			})
			.catch(e => {
				setError('');
				setIsFetchingLatticeError(false);
			});
	};

	const getElectrons = (dispatchID, count) => {
		setElectronsLoading(true);
		getAllElectrons(dispatchID, count)
			.then(response => {
				setAllElectrons(response);
				setElectronsLoading(false);
			})
			.catch(e => {
				setAllElectrons([]);
				setElectronsLoading(false);
			});
	};

	const getErrorFunctions = () => {
		// commenting this until we solve the api call on scroll issue
		// setIsFetchingLatticeErrorFunctions(true);
		// getAllStatusBasedElectrons(dispatchID, status)
		// 	.then(response => {
		// 		setErrorFunctions(response);
		// 		setIsFetchingLatticeErrorFunctions(false);
		// 	})
		// 	.catch(e => {
		// 		setErrorFunctions([]);
		// 		setIsFetchingLatticeErrorFunctions(false);
		// 	});
		setErrorFunctions(
			entireGraph?.nodes?.filter(e => e?.type !== 'parameter' && e?.status === 'FAILED')
		);
	};

	const getFunctionsofaType = (dispatchID, type, status) => {
		getElectronsByBatch(dispatchID, type, status)
			.then(response => {
				setFunctionList(response);
			})
			.catch(e => {});
	};

	const getElectronDetailsFromNodeid = (dispatchID, nodeID, noLoader = false) => {
		if (!noLoader) setIsFetchingNodedata(true);
		setIsFetchingNodeCost(true);
		getElectronByNode(dispatchID, nodeID)
			.then(response => {
				setNodeData(response);
				if (!response?.started_at) {
					if (response?.completed_at) {
						setTimeline([
							{
								status: response?.created_at ? 'Pending' : null,
								time: response?.created_at ? response?.created_at : null,
								color: '#86869A',
								icon: 'Pending',
								index: 0
							},
							{
								status: response?.completed_at
									? response.status === 'COMPLETED'
										? 'Completed'
										: 'Failed'
									: null,
								time: response?.completed_at ? response?.completed_at : null,
								color: response.status === 'COMPLETED' ? '#55D899' : '#FF6464',
								icon: response.status === 'COMPLETED' ? 'Completed' : 'Failed',
								index: 1
							}
						]);
					} else {
						setTimeline([
							{
								status: response?.created_at ? 'Pending' : null,
								time: response?.created_at ? response?.created_at : null,
								color: '#86869A',
								icon: 'Pending',
								index: 0
							},
							{ status: 'placeholder', index: 1 },
							{ status: 'placeholder', index: 2 }
						]);
					}
				} else if (response?.status === 'RUNNING') {
					setTimeline([
						{
							status: response?.created_at ? 'Pending' : null,
							time: response?.created_at ? response?.created_at : null,
							color: '#86869A',
							icon: 'Pending',
							index: 0
						},
						{
							status: response?.started_at ? 'Running' : null,
							time: response?.started_at ? response?.started_at : null,
							color: '#86869A',
							icon: 'Running',
							index: 1
						},
						{ status: 'placeholder', index: 2 }
					]);
				} else if (response?.status === 'DISPATCHING') {
					setTimeline([
						{
							status: response?.created_at ? 'Pending' : null,
							time: response?.created_at ? response?.created_at : null,
							color: '#86869A',
							icon: 'Pending',
							width: '110px',
							index: 0
						},
						{
							status: response?.started_at ? 'Running' : null,
							time: response?.started_at ? response?.started_at : null,
							color: '#86869A',
							icon: 'Running',
							width: '110px',
							index: 1
						},
						{
							status: response?.completed_at ? 'Dispatching' : null,
							time: response?.completed_at ? response?.completed_at : null,
							color: '#86869A',
							icon: 'Dispatching',
							width: '110px',
							index: 2
						},
						{ status: 'placeholder', index: 3, width: '110px' }
					]);
				} else {
					setTimeline([
						{
							status: response?.created_at ? 'Pending' : null,
							time: response?.created_at ? response?.created_at : null,
							color: '#86869A',
							icon: 'Pending',
							index: 0
						},
						{
							status: response?.started_at ? 'Running' : null,
							time: response?.started_at ? response?.started_at : null,
							color: '#86869A',
							icon: 'Running',
							index: 1
						},
						{
							status: response?.completed_at
								? response.status === 'COMPLETED'
									? 'Completed'
									: 'Failed'
								: null,
							time: response?.completed_at ? response?.completed_at : null,
							color: response.status === 'COMPLETED' ? '#55D899' : '#FF6464',
							icon: response.status === 'COMPLETED' ? 'Completed' : 'Failed',
							index: 2
						}
					]);
				}
				setIsFetchingNodedata(false);
			})
			.catch(e => {
				setNodeData({});
				setTimeline([]);
				setIsFetchingNodedata(false);
				setIsFetchingNodeCost(false);
			});
	};

	const nodeResult = (dispatchID, nodeID, key, representation) => {
		setIsFetchingNodeResult(true);
		getNodeAssetsById(dispatchID, nodeID, key, representation)
			.then(response => {
				setIsFetchingNodeResult(false);
				if (response?.urls && response?.urls?.length > 0 && response?.urls[0]?.url) {
					getAssetFromUrl(response?.urls[0]?.url)
						.then(res => {
							if (representation === 'string') setSelectedNodeResult(res?.data);
							else setSelectedNodeResultCopy(res?.data);
						})
						.catch(err => {
							if (representation === 'string') setSelectedNodeResult('None');
							else setSelectedNodeResultCopy('');
						});
				} else {
					if (representation === 'string') setSelectedNodeResult('None');
					else setSelectedNodeResultCopy('');
				}
			})
			.catch(e => {
				if (representation === 'string') setSelectedNodeResult('None');
				else setSelectedNodeResultCopy('');
				setIsFetchingNodeResult(false);
			});
	};

	const nodeErrorFn = (dispatchID, nodeID, key, representation) => {
		setIsFetchingNodeError(true);
		getNodeAssetsById(dispatchID, nodeID, key, representation)
			.then(response => {
				if (response?.urls && response?.urls?.length > 0 && response?.urls[0]?.url) {
					getAssetFromUrl(response?.urls[0]?.url)
						.then(res => {
							setNodeError(res?.data);
						})
						.catch(err => {
							setNodeError('None');
						});
				} else {
					setNodeError('None');
				}
				setIsFetchingNodeError(false);
			})
			.catch(e => {
				setNodeError(
					`This task has failed with unknown error, please contact the covalent team with the\n dispatch and task id - (${dispatchID} , ${nodeID} )`
				);
				setIsFetchingNodeError(false);
			});
	};

	const nodeInput = (dispatchID, nodeID, representation) => {
		setIsFetchingNodeInput(true);
		getElectronInput(dispatchID, nodeID, representation)
			.then(response => {
				// setProp(isObject ? copyObject(response.toString()) : JSON.stringify(response));
				setSelectedNodeInput(JSON.stringify(response));
				setIsFetchingNodeInput(false);
			})
			.catch(e => {
				setSelectedNodeInput('None');
				setIsFetchingNodeInput(false);
			});
	};

	const nodeInputCopy = (dispatchID, nodeID, representation) => {
		getElectronInput(dispatchID, nodeID, representation)
			.then(response => {
				setSelectedNodeInputCopy(response?.toString());
			})
			.catch(e => {
				setSelectedNodeInputCopy('');
			});
	};

	const nodeConsole = (dispatchID, nodeID, key, representation) => {
		setIsFetchingNodeConsole(true);
		getNodeAssetsById(dispatchID, nodeID, key, representation)
			.then(response => {
				if (response?.urls && response?.urls?.length > 0 && response?.urls[0]?.url) {
					getAssetFromUrl(response?.urls[0]?.url)
						.then(res => {
							setSelectedNodeConsole(res?.data);
							setIsFetchingNodeConsole(false);
						})
						.catch(err => {
							setSelectedNodeConsole('None');
							setIsFetchingNodeConsole(false);
						});
				} else {
					setSelectedNodeConsole('None');
					setIsFetchingNodeConsole(false);
				}
			})
			.catch(e => {
				setSelectedNodeConsole('None');
				setIsFetchingNodeConsole(false);
			});
	};

	const getLatticeCostValue = dispatchID => {
		setIsFetchingLatticeCost(true);
		getLatticeCost(dispatchID)
			.then(response => {
				setIsFetchingLatticeCost(false);
				setLatticeCost(response?.display_price);
			})
			.catch(e => {
				setLatticeCost('$0.00');
				setIsFetchingLatticeCost(false);
			});
	};

	const getNodeCostValue = jobID => {
		setIsFetchingNodeCost(true);
		getNodeCost(jobID)
			.then(response => {
				setIsFetchingNodeCost(false);
				setNodeCost(response?.display_price);
			})
			.catch(e => {
				setIsFetchingNodeCost(false);
				setNodeCost('$0.00');
			});
	};

	const getNodeCode = (dispatchID, nodeID, key) => {
		setIsFetchingNodeCode(true);
		getNodeAssetsById(dispatchID, nodeID, key)
			.then(response => {
				if (response?.urls && response?.urls?.length > 0 && response?.urls[0]?.url) {
					getAssetFromUrl(response?.urls[0]?.url)
						.then(res => {
							setSelectedNodeCode(res?.data);
							setIsFetchingNodeCode(false);
						})
						.catch(err => {
							setSelectedNodeCode('None');
							setIsFetchingNodeCode(false);
						});
				} else {
					setSelectedNodeCode('None');
					setIsFetchingNodeCode(false);
				}
			})
			.catch(e => {
				setSelectedNodeCode('None');
				setIsFetchingNodeCode(false);
			});
	};

	const getNodeCodeCopy = (dispatchID, nodeID, key) => {
		getNodeAssetsById(dispatchID, nodeID, key, 'object')
			.then(response => {
				if (response?.urls && response?.urls?.length > 0 && response?.urls[0]?.url) {
					getAssetFromUrl(response?.urls[0]?.url)
						.then(res => {
							setSelectedNodeCodeCopy(res?.data);
						})
						.catch(err => {
							setSelectedNodeCodeCopy('');
						});
				} else {
					setSelectedNodeCodeCopy('');
				}
			})
			.catch(e => {
				setSelectedNodeCodeCopy('');
			});
	};

	const getJobsOfQElectronNode = (dispatchID, nodeID) => {
		setIsFetchingSelectedJobDetails(true);
		getQElectronNodeJobs(dispatchID, nodeID)
			.then(response => {
				setNodeJobs(response);
				if (response?.length > 0 && response[0] && response[0]?.circuit_id) {
					setSelectedJob(response[0]?.circuit_id);
					getQelectronJobOverview(response[0]?.circuit_id)
						.then(res => {
							setSelectedJobDetails(res);
							setIsFetchingSelectedJobDetails(false);
						})
						.catch(err => {
							setSelectedJobDetails({});
							setIsFetchingSelectedJobDetails(false);
						});
				} else {
					setNodeJobs([]);
					setSelectedJobDetails({});
					setIsFetchingSelectedJobDetails(false);
				}
			})
			.catch(e => {
				setNodeJobs([]);
				setSelectedJobDetails({});
				setIsFetchingSelectedJobDetails(false);
			});
	};

	const getQelectronAssets = (circuitId, key) => {
		getQelectronAssetsUrl(circuitId, key)
			.then(response => {
				getAssetFromUrl(response?.url)
					.then(assets => {
						if (key === 'circuit_string') setQElectronCircuit(assets?.data);
						else setQelectronResult(assets?.data);
					})
					.catch(err => {
						if (key === 'circuit_string') setQElectronCircuit('None');
						else setQelectronResult('None');
					});
			})
			.catch(e => {
				if (key === 'circuit_string') setQElectronCircuit('None');
				else setQelectronResult('None');
			});
	};

	return (
		<GraphContext.Provider
			value={{
				getGraphDetailsApi,
				getLatticeAPI,
				getDispatchResult,
				dispatchResult,
				dispatchResultcopy,
				getDispatchCodeCopy,
				dispatchCodeCopy,
				getDispatchResultCopy,
				nodeResult,
				selectedNodeResult,
				selectedNodeResultCopy,
				setSelectedNodeResultCopy,
				getInput,
				getCode,
				getError,
				error,
				input,
				code,
				latticeDetails,
				getFunctionsofaType,
				functionsList,
				getElectrons,
				allElectrons,
				getErrorFunctions,
				errorFunctions,
				description,
				getElectronDetailsFromNodeid,
				nodeData,
				nodeInput,
				selectedNodeInput,
				nodeInputCopy,
				selectedNodeInputCopy,
				getNodeCode,
				selectedNodeCode,
				getNodeCodeCopy,
				selectedNodeCodeCopy,
				getJobsOfQElectronNode,
				nodeJobs,
				getQelectronAssets,
				result,
				setResult,
				selectedJobExecutors,
				allowedExecutor,
				GraphPreview,
				setNodeData,
				timeline,
				selectedNodeId,
				setSelectedNodeId,
				tabValue,
				setTabValue,
				setSelectedJob,
				selectedJob,
				qelectronCircuit,
				setQElectronCircuit,
				qelectronResult,
				setQelectronResult,
				selectedJobDetails,
				setSelectedJobDetails,
				setIsFetchingNodedata,
				isFetchingLatticeDetails,
				isFetchingLatticeInput,
				isFetchingLatticeResult,
				isFetchingLatticeError,
				isFetchingLatticeErrorFunctions,
				isFetchingNodeData,
				isFetchingSelectedJobDetails,
				sublatticeDetails,
				setNodeClickFrom,
				nodeClickFrom,
				setSublatticeId,
				sublatticeId,
				setBreadcrumb,
				breadcrumb,
				isFetchingGraph,
				setIsFetchingGraph,
				entireGraph,
				setIsFetchingSelectedJobDetails,
				notFound,
				nodeError,
				nodeErrorFn,
				setNodeDetailClose,
				nodeDetailClose,
				latticeTimeline,
				setZoomClick,
				zoomClick,
				latticeCost,
				nodeCost,
				getLatticeCostValue,
				getNodeCostValue,
				isFetchingLatticeCost,
				isFetchingNodeCost,
				setIsFetchingNodeCost,
				setIsFetchingLatticeCost,
				selectedNodeConsole,
				setSelectedNodeConsole,
				nodeConsole,
				isFetchingNodeCode,
				isFetchingNodeError,
				isFetchingNodeConsole,
				isFetchingNodeInput,
				isFetchingNodeResult,
				isFetchingLatticeCode,
				showPostProcess,
				setPostProcess,
				enableShareOption,
				setEnableShareOption,
				foundObject,
				setFoundObject,
				popupNode,
				setPopupNode,
				subLatticeElectron,
				setSublatticeElectron,
				subLatticeRuntime,
				setSublatticeRuntime,
				isFetchingHover,
				setIsFetchingHover,
				isNodeBoxVisible,
				setNodeBoxVisible,
				sublatticeStatus,
				setSublatticeStatus
			}}
		>
			{children}
		</GraphContext.Provider>
	);
};

export default GraphProvider;
