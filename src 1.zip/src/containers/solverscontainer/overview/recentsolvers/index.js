import { Box, Stack, Typography, Grid } from '@mui/material';
import React from 'react';
import './style.css';
import { useSelector } from 'react-redux';
import Icon from '../../../../components/icon';
import utilizationIcon from '../../../../assets/utilizationIcon.svg';
import RecentSolversList from '../../../../components/solvers/overview/recentSolvers';

function RecentSolvers({ solversCardClick }) {
	const { allMySolvers } = useSelector(state => state.solver);
	const recentSolverData = allMySolvers?.slice(-4);

	return (
		<Box className="recentSolversCtr">
			<Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1 }}>
				<Box className="utilizationHeaderIcon">
					<Icon type="static" src={utilizationIcon} />
				</Box>
				<Box>
					<Typography className="utilzationLabel" sx={{ color: '#FFF' }}>
						Recent Solvers
					</Typography>
				</Box>
			</Stack>
			<Grid container spacing={2} sx={{ mt: 1 }}>
				{recentSolverData?.map(solverInfo => (
					<Grid item xs={4} key={solverInfo.token}>
						<RecentSolversList solverInfo={solverInfo} solversCardClick={solversCardClick} />
					</Grid>
				))}
				{recentSolverData?.length === 0 && (
					<Typography color="textPrimary" mt={3} ml={2} variant="subtitle2">
						No records found
					</Typography>
				)}
				{/* <Grid item xs={4}>
          <RecentSolversList />
        </Grid>
        <Grid item xs={4}>
          <RecentSolversList />
        </Grid>
        <Grid item xs={4}>
          <RecentSolversList />
        </Grid> */}
			</Grid>
		</Box>
	);
}

export default RecentSolvers;
