/* eslint-disable no-unused-vars */
import React, { useState } from 'react';
import { Box, Grid, SvgIcon, Select, MenuItem, Chip } from '@mui/material';
import SearchInput from '../../../components/inputBase/projects/searchInput';
import '../solvers/style.css';
import SolversListView from '../../../components/list/solvers/solverListView';

function CustomIcon(props) {
	return (
		// eslint-disable-next-line react/jsx-props-no-spreading
		<SvgIcon {...props} style={{ transform: 'translateY(20%)' }}>
			<svg
				width="16"
				height="16"
				viewBox="0 0 16 22"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					d="M8 10.9998L3 5.9998L3.7 5.2998L8 9.59981L12.3 5.2998L13 5.9998L8 10.9998Z"
					fill="#CBCBD7"
				/>
			</svg>
		</SvgIcon>
	);
}

function CustomArrow(props) {
	return (
		// eslint-disable-next-line react/jsx-props-no-spreading
		<SvgIcon {...props} style={{ transform: 'translateY(20%)' }}>
			<svg
				width="16"
				height="16"
				viewBox="0 0 16 16"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					d="M8 5.9998L3 10.9998L3.7 11.6998L8 7.39981L12.3 11.6998L13 10.9998L8 5.9998Z"
					fill="#CBCBD7"
				/>
			</svg>
		</SvgIcon>
	);
}

function RunsComponent({ name, dispatchesList, allDispatches }) {
	const [searchKey, setSearchKey] = useState('');
	const [selected, setSelected] = useState('last_updated');
	const [sortColumn, setSortColumn] = useState('startTime');
	const [sortOrder, setSortOrder] = useState('desc');
	// state for pagination
	const [page, setPage] = useState(1);
	const [selectedSolver, setSelectedSolver] = useState(name);
	const [dispatches, setDispatches] = useState(dispatchesList);
	const [dataShown, setDataShown] = useState(dispatchesList);

	const onSort = column => {
		setPage(1);
		const isAsc = sortColumn === column && sortOrder === 'asc';
		setSortOrder(isAsc ? 'desc' : 'asc');
		setSortColumn(column);
	};

	// cancel search
	const cancelSearch = () => {
		setSearchKey('');
	};

	const selectionChangeHandler = event => {
		if (event.target.value === 'last_updated') {
			setSortOrder('desc');
		}
		setSelected(event.target.value);
	};

	React.useEffect(() => {
		let sortedData = [...dataShown];

		if (searchKey) {
			const filteredData = sortedData.filter(item =>
				item?.title.toLowerCase().includes(searchKey.toLowerCase())
			);
			sortedData = filteredData;
		} else {
			sortedData = [...dataShown];
		}

		if (selected === 'last_updated') {
			sortedData.sort((a, b) => {
				const dateA = new Date(a.startTime);
				const dateB = new Date(b.startTime);
				if (sortOrder === 'asc') {
					return dateA - dateB;
				}
				return dateB - dateA;
			});
		}

		if (selected === 'popular') {
			sortedData.sort((a, b) => {
				if (sortOrder === 'asc') {
					return a.cost - b.cost;
				}
				return b.cost - a.cost;
			});
		}

		setDispatches(sortedData);
	}, [selected, sortColumn, sortOrder, searchKey]);

	return (
		<>
			<Box>
				<Grid
					container
					direction="row"
					justifyContent="space-between"
					alignItems="center"
					pt={4}
					pb={4}
					width="100%"
				>
					<SearchInput
						sx={{
							border: '1px solid #303067',
							borderRadius: '20px',
							width: '260px',
							height: '32.69px',
							'&.Mui-focused ': {
								border: '1px solid #6473ff'
							}
							// mt:'10rem'
						}}
						value={searchKey || ''}
						onChange={e => setSearchKey(e.target.value)}
						cancelSearch={cancelSearch}
					/>
					<Box sx={{ display: 'flex' }}>
						<Box sx={{ paddingRight: '0px' }} display="flex" direction="row" spacing={3}>
							<Select
								IconComponent={CustomIcon}
								value={selected}
								onChange={selectionChangeHandler}
								sx={{
									fontSize: '14px',
									background: '#08081A',
									borderRadius: '200px',
									padding: '0rem 1rem',
									width: selected.length > 8 ? '9.5rem' : selected.length < 6 ? '6rem' : '8rem',
									height: '32px',
									color: '#BEBEBE',
									'.MuiOutlinedInput-notchedOutline': {
										borderColor: '#6473FF'
									},
									'&.Mui-focused .MuiOutlinedInput-notchedOutline': {
										borderColor: '#6473FF'
									},
									'&:hover .MuiOutlinedInput-notchedOutline': {
										borderColor: '#6473FF'
									},
									'.MuiSvgIcon-root ': {
										fill: 'transparent !important'
									}
								}}
							>
								<MenuItem sx={{ fontSize: '14px' }} value="last_updated">
									Last Updated{' '}
								</MenuItem>
								<MenuItem sx={{ fontSize: '14px' }} value="popular">
									Popular{' '}
								</MenuItem>
							</Select>
						</Box>
					</Box>
				</Grid>
			</Box>
			{selectedSolver && (
				<Grid item xs={12} sx={{ display: 'flex', paddingTop: '5px', paddingLeft: '5px' }}>
					<Chip
						variant="filled"
						size="small"
						label={selectedSolver}
						key={selectedSolver}
						onDelete={() => {
							setSelectedSolver('');
							setDispatches([...allDispatches]);
							setDataShown([...allDispatches]);
						}}
					/>
				</Grid>
			)}
			<Box>
				<SolversListView
					dispatchesList={dispatches}
					orderBy={sortColumn}
					order={sortOrder}
					onSort={onSort}
					page={page}
				/>
			</Box>
		</>
	);
}

export default RunsComponent;
