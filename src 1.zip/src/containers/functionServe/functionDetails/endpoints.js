/* eslint-disable quotes */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useEffect, useState } from 'react';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import { useMediaQuery } from '@mui/material';
import Box from '@mui/material/Box';
import { useSelector } from 'react-redux';
import AddressCard from '../../../components/card/functionServe/addressCard';
import EndpointCard from '../../../components/card/functionServe/endpointCard';
import SyntaxHighlight from '../../../components/syntaxHiglighter/layouts/withCopy';
import EndpointIcon from '../../../assets/functions/endpoints.svg';
import Icon from '../../../components/icon';
import Loader from '../../../components/loader';
import endpointCode from '../../../utils/endpointCode';

function FunctionEndpoint({
	data,
	selectedEndpointValue,
	apiKey,
	setOpenSnackbar,
	setSnackbarMessage
}) {
	const [isLoading, setIsLoading] = useState(true);
	const [isCodeLoading, setIsCodeLoading] = useState(true);
	const [selectedEndpoint, setSelectedEndpoint] = useState(selectedEndpointValue);
	const [curlCode, setCurlCode] = useState('');
	const [code, setCode] = useState('');
	const { disableInteractions } = useSelector(state => state.functionServe);

	useEffect(() => {
		setTimeout(() => {
			setIsLoading(false);
			setIsCodeLoading(false);
		}, 1000);
	}, []);

	const isWideScreen = useMediaQuery('(min-height: 1000px)');
	const isMediumScreen = useMediaQuery('(min-height: 900px)');
	const isMediumScreen2 = useMediaQuery('(min-height: 850px)');

	const getHeightByScreenHeight = () => {
		if (isWideScreen) {
			return '64vh';
		} else if (isMediumScreen) {
			return '59.5vh';
		} else if (isMediumScreen2) {
			return '56vh';
		}
		return '50vh';
	};

	// Options to select an endpoint and deselect it upon clicking again
	const selectEndPoint = endpoint => {
		if (endpoint?.endpoint_fn === selectedEndpoint?.endpoint_fn) {
			setSelectedEndpoint('');
		} else {
			setSelectedEndpoint(endpoint);
			setIsCodeLoading(true);
			setTimeout(() => {
				setIsCodeLoading(false);
			}, 1000);
		}
	};

	const getCodes = (auth, streaming, enableEndoint) => {
		if (!auth && !streaming && !enableEndoint) return 1;
		else if (!auth && !streaming && enableEndoint) return 2;
		else if (!auth && streaming && !enableEndoint) return 3;
		else if (!auth && streaming && enableEndoint) return 4;
		else if (auth && !streaming && !enableEndoint) return 5;
		else if (auth && !streaming && enableEndoint) return 6;
		else if (auth && streaming && !enableEndoint) return 7;
		else if (auth && streaming && enableEndoint) return 8;
		return 9;
	};

	useEffect(() => {
		// default case will be 2 when there is no selected endpoint->health check
		const codeValues = endpointCode({
			caseNumber:
				selectedEndpoint === ''
					? 2
					: getCodes(
							data?.auth,
							selectedEndpoint?.streaming,
							selectedEndpoint?.test_endpoint_enabled
					  ),
			method: selectedEndpoint?.method || '{endpoint-method}',
			route: selectedEndpoint?.route || '{endpoint-route}',
			invokeUrl: data?.invoke_url || '{invoke_url}'
		});
		setCurlCode(codeValues['curl']);
		setCode(codeValues['request']);
	}, [selectedEndpoint]);

	return (
		<Grid container justifyContent="space-between">
			<Grid item xs={5}>
				<AddressCard
					isLoading={isLoading}
					address={data?.invoke_url !== null ? data?.invoke_url : 'Address Not Found !'}
				/>
				<Typography sx={{ color: theme => theme.palette.text.secondary, marginTop: '29px' }}>
					List of Endpoints
				</Typography>
				{isLoading ? (
					<Box
						sx={{
							height: '382px',
							border: '1px solid',
							marginTop: '10px',
							borderRadius: '8px',
							borderColor: theme => theme.palette.background.blue03
						}}
					>
						<Loader isFetching={isLoading} width="100%" position="relative" height="100%" />
					</Box>
				) : (
					<Box
						sx={{
							height: getHeightByScreenHeight(),
							overflow: 'auto',
							scrollbarColor: '#5552FF #08081a'
						}}
					>
						{data?.endpoints?.length > 0 &&
							data?.endpoints?.map(item => (
								<Box key={item?.route}>
									<EndpointCard
										endpoint={item}
										invokeUrl={data?.invoke_url}
										functionId={data?.id}
										message="Please include default values for custom function arguments to enable one-click testing"
										selectedEndpoint={selectedEndpoint}
										selectEndPoint={selectEndPoint}
										apiKey={apiKey}
										setOpenSnackbar={setOpenSnackbar}
										setSnackbarMessage={setSnackbarMessage}
										disableInteractions={disableInteractions}
									/>
								</Box>
							))}
						{data?.endpoints?.length === 0 && (
							<Box
								sx={{
									width: '100%',
									height: '160px',
									mt: 1,
									borderRadius: '8px',
									display: 'flex',
									justifyContent: 'center',
									alignItems: 'center',
									flexDirection: 'column',
									border: theme => `1px solid ${theme?.palette?.background?.blue03}`
								}}
							>
								<Icon
									src={EndpointIcon}
									type="static"
									alt="noSecretsIcon"
									width="30px"
									height="25px"
								/>
								<Typography variant="h2" mt="22px">
									No Endpoints found
								</Typography>
							</Box>
						)}
					</Box>
				)}
			</Grid>
			<Grid item xs={6}>
				<Typography sx={{ color: theme => theme.palette.text.secondary }}>
					Request Templates
				</Typography>
				{isCodeLoading ? (
					<Loader isFetching={isCodeLoading} width="100%" position="relative" height="80%" />
				) : (
					<>
						{curlCode && <SyntaxHighlight src={curlCode} />}
						{code && (
							<Box sx={{ margintop: '18px' }}>
								<SyntaxHighlight src={code} />
							</Box>
						)}
					</>
				)}
			</Grid>
		</Grid>
	);
}

export default FunctionEndpoint;
