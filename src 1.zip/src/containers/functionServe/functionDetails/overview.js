/* eslint-disable react/jsx-props-no-spreading */
/* eslint-disable no-unused-vars */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable react/no-array-index-key */

import React, { useEffect, useState } from 'react';
import { useMediaQuery, useTheme } from '@mui/material';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import Tooltip, { tooltipClasses } from '@mui/material/Tooltip';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import Skeleton from '@mui/material/Skeleton';
import { useNavigate, useParams } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { makeStyles } from '@mui/styles';
import { styled } from '@mui/material/styles';
import {
	FunctionOverviewCard,
	FunctionEnvironmentCard,
	FunctionHardwareCard
} from '../../../components/card/functionServe/functionOverview';
import MarketplaceDialogBox from '../../../components/dialogBox/marketplace';
import CustomButton from '../../../components/primaryButton/functionServe';
import FunctionIcon from '../../../assets/functions/function.svg';
import EndpointIcon from '../../../assets/functions/endpoints.svg';
import ArrowRight from '../../../assets/arrows/arrowRight.svg';
import CopyButton from '../../../components/copyButton';
import Icon from '../../../components/icon';
import routes from '../../../constants/routes.json';
import Delete from '../../../assets/actions/delete.svg';
import Loader from '../../../components/loader';
import { deleteInferenceKey } from '../../../api/functionServe/functionServeApi';
import NoSecretsFoundIcon from '../../../assets/secretsArchieveIcon.svg';
import { getGbfromMb } from '../../../utils/utils';
import useLength from '../../../utils/useLength';
import OverflowTooltip from '../../../components/tooltip/overflowTooltip';

const useStyles = makeStyles({
	chipRoot: {
		height: '24px',
		marginRight: '5px',
		'& .MuiChip-label': {
			padding: '0px 4px 0px 4px'
		},
		'& .MuiChip-icon': {
			order: 1,
			marginRight: '4px',
			cursor: 'pointer'
		},
		'& .MuiChip-deleteIcon': {
			order: 2,
			color: '#9999b2'
		}
	}
});
const BootstrapTooltip = styled(({ className, ...props }) => (
	<Tooltip {...props} arrow classes={{ popper: className }} />
))(({ theme }) => ({
	[`& .${tooltipClasses.arrow}`]: {
		color: 'rgba(28, 28, 70, 1)'
	},
	[`& .${tooltipClasses.tooltip}`]: {
		backgroundColor: 'rgba(28, 28, 70, 1)'
	}
}));

function DetailedDescription({ title, value, isLoading }) {
	return (
		<Box mt="20px" padding="30px 40px 30px 30px">
			<Typography
				fontWeight="700"
				mb="10px"
				fontSize="16px"
				sx={{ color: theme => theme.palette.text.secondary }}
			>
				{title}
			</Typography>
			<Typography sx={{ color: theme => theme.palette.text.gray03, fontSize: '14px' }}>
				{isLoading ? (
					<>
						<Skeleton variant="rounded" width="70%" height={14} sx={{ margin: '0px' }} />
						<Skeleton variant="rounded" width="50%" height={14} sx={{ marginTop: '10px' }} />
						<Skeleton variant="rounded" width="30%" height={14} sx={{ marginTop: '10px' }} />
					</>
				) : (
					value
				)}
			</Typography>
		</Box>
	);
}

function AuthManagement({
	data,
	setOpenDialogBox,
	isLoading,
	setDeleteKey,
	handleAddToken,
	disableInteractions
}) {
	const handleDeleteIcon = e => {
		setOpenDialogBox(true);
		setDeleteKey(e?.id);
	};

	const onClickAddToken = () => {
		if (!disableInteractions) handleAddToken();
	};

	const onClickDeleteToken = e => {
		if (!disableInteractions) handleDeleteIcon(e);
	};
	const authWidth = useLength({ xs: '90%', s: '80%', m: '70%', l: '50%', xl: '50%' });
	return (
		<Box mt="20px" padding="12px 15px">
			<>
				<Box height="32px" mb="15px" display="flex" justifyContent="space-between">
					<Typography fontWeight="700" mb="10px" fontSize="16px">
						Auth Management
					</Typography>
					<Button
						variant="outlined"
						sx={{
							width: '100px',
							border: '1px solid',
							'&:hover': {
								backgroundColor: theme => theme.palette.background.covalentPurple,
								color: theme => theme?.palette?.text?.secondary,
								borderRadius: '25px',
								borderColor: theme => theme?.palette?.background?.blue05
							},
							borderColor: theme => theme?.palette?.background?.blue05,
							backgroundColor: theme => theme.palette.background.covalentPurple,
							display: 'flex',
							justifyContent: 'center',
							borderRadius: '25px',
							height: '32px',
							marginLeft: '0.2rem',
							'&:disabled': {
								backgroundColor: theme => theme.palette.background.paper,
								color: theme => theme.palette.text.gray03,
								borderRadius: '25px',
								borderColor: theme => theme.palette.text.gray03
							}
						}}
						onClick={onClickAddToken}
						disabled={isLoading || disableInteractions}
					>
						<Typography
							pt={0}
							variant="popUpDispatch"
							sx={{
								color: theme => theme?.palette?.background?.blue09,
								display: 'flex'
							}}
						>
							Add Token
						</Typography>
					</Button>
				</Box>
				{isLoading ? (
					<Loader isFetching={isLoading} width={authWidth} position="relative" height="180px" />
				) : (
					<Box
						maxHeight="180px"
						overflow="auto"
						sx={{
							paddingRight: '10px',
							position: 'relative',
							width: authWidth,
							minWidth: '330px',
							scrollbarColor: '#5552FF #08081a'
						}}
					>
						{Array.isArray(data) && data.length > 0 ? (
							data.map((e, i) => (
								<Box width="100%" key={`${e?.id}-${i}`} display="flex" marginTop="10px">
									<Typography fontSize="14px" marginRight="20px" minWidth="200px">
										{e?.id &&
											`**********************${e.id.substring(e.id.length - 5, e.id.length)}`}
									</Typography>
									<CopyButton content={e?.id} margin="0px 10px 0px 7px" placement="bottom" />
									<Tooltip title="Delete" placement="right">
										<Box>
											<Icon
												display="flex"
												padding="4px 0px 4px 4px "
												src={Delete}
												clickHandler={() => onClickDeleteToken(e)}
												alt="delete"
												disabled={disableInteractions}
											/>
										</Box>
									</Tooltip>
								</Box>
							))
						) : (
							<Box
								sx={{
									width: '100%',
									height: '160px',
									borderRadius: '8px',
									display: 'flex',
									justifyContent: 'center',
									alignItems: 'center',
									flexDirection: 'column',
									border: theme => `1px solid ${theme?.palette?.background?.blue03}`
								}}
							>
								<Icon src={NoSecretsFoundIcon} type="static" alt="noSecretsIcon" />
								<Typography variant="h2" mt="22px">
									No Tokens found
								</Typography>
							</Box>
						)}
					</Box>
				)}
			</>
		</Box>
	);
}

function InitFunctionInputs({ title, data }) {
	return (
		<Box mt="20px" padding="0px">
			<Typography
				sx={{
					fontSize: '14px',
					color: theme => theme.palette.text.gray03,
					fontWeight: 700,
					marginBottom: '7px'
				}}
			>
				{title}
			</Typography>
			<Box
				sx={{
					width: '100%',
					// minWidth: '592px',
					height: '158px',
					padding: '8px 24px 0px 24px',
					border: '1px solid',
					borderRadius: '8px',
					borderColor: theme => theme.palette.background.blue03
				}}
			>
				<Box display="flex" width="60%" mb="10px" color={theme => theme.palette.text.gray03}>
					<Typography width="50%" align="center" fontSize="10px">
						Key
					</Typography>
					<Typography width="50%" align="center" fontSize="10px">
						Value
					</Typography>
				</Box>
				<Box
					maxHeight="110px"
					width="60%"
					overflow="auto"
					sx={{ position: 'relative', scrollbarColor: '#5552FF #08081a' }}
					padding={0}
					margin={0}
				>
					{Array.isArray(data) &&
						data?.map((e, i) => (
							<Box key={`${e?.key}-${i}`} display="flex">
								<Typography width="50%" align="center" fontSize="14px">
									{e?.key}
								</Typography>
								<Typography width="50%" align="center" fontSize="14px">
									{e?.value}
								</Typography>
							</Box>
						))}
				</Box>
			</Box>
		</Box>
	);
}

function FunctionOverview(props) {
	const {
		setTabValue,
		setSelectedEndpoint,
		overViewData,
		authLoader,
		authTokens,
		setAuthLoader,
		getBatchAuthTokens,
		setOpenSnackbar,
		setSnackbarMessage,
		handleAddToken,
		envDetails,
		loader,
		onTearDown
	} = props;

	const classes = useStyles(); // Instantiate the useStyles hook to get the classes object

	const { disableInteractions } = useSelector(state => state.functionServe);
	const [openDialogBox, setOpenDialogBox] = useState(false);
	const [deleteKey, setDeleteKey] = useState();
	const [numberOfItems, setNumberOfItems] = React.useState(3);
	const theme = useTheme();
	const onlyExtraSmall = useMediaQuery(theme.breakpoints.only('xs')); // 0px - 1000px
	const onlySmallScreen = useMediaQuery(theme.breakpoints.only('sm')); // 1000px-1420px
	const onlyMediumScreen = useMediaQuery(theme.breakpoints.only('md')); // 1420- 1500px
	const onlyLargeScreen = useMediaQuery(theme.breakpoints.only('lg')); // 1500px- 1800px

	// Dummy data for init function inputs
	const inputData = [
		{ key: 'abcd', value: '12' },
		{ key: 'bcde', value: '34' },
		{ key: 'cdef', value: '56' },
		{ key: 'defg', value: '78' },
		{ key: 'abcd', value: '12' },
		{ key: 'bcde', value: '34' },
		{ key: 'cdef', value: '56' },
		{ key: 'defg', value: '78' }
	];

	const [functionData, setFunctionData] = useState(overViewData);
	const [hardwareData, setHardwareData] = useState({
		title: '',
		status: 'online',
		cost: '$15/hr',
		parameters: {
			CPU: 0,
			GPU: '',
			Mem: ''
		},
		tags: ['covalent', 'nvidia', 'GPU'],
		created_date: '22-03-2024'
	});
	const environmentDetails = {
		envId: envDetails?.id,
		envName: functionData && functionData?.executor?.env,
		status: envDetails?.status
	};
	const { functionId } = useParams();
	const navigate = useNavigate();
	const onInitFunctionSelect = () => {
		navigate(`${routes.FUNCTION_SERVE}/${functionId}/Endpoints`);
	};

	const onEndpointSelect = value => {
		setSelectedEndpoint(value);
		navigate(`${routes.FUNCTION_SERVE}/${functionId}/Endpoints`);
	};

	const deleteToken = () => {
		setAuthLoader(true);
		if (deleteKey) {
			deleteInferenceKey(overViewData?.id, deleteKey)
				.then(() => {
					setSnackbarMessage('Token deleted successfully');
					setOpenSnackbar(true);
				})
				.catch(err => {
					isLoading = false;
					setSnackbarMessage(err);
					setOpenSnackbar(true);
				})
				.finally(() => {
					getBatchAuthTokens(overViewData?.id);
				});
		}
		setOpenDialogBox(false);
	};

	useEffect(() => {
		setFunctionData(overViewData);
		setHardwareData({
			title: overViewData?.executor?.gpu_type || '-',
			status: 'online',
			cost: '$15/hr',
			parameters: {
				CPU: overViewData?.executor?.num_cpus,
				GPU: overViewData?.executor?.num_gpus,
				Mem: getGbfromMb(overViewData?.executor?.memory)
			},
			tags: ['covalent', 'nvidia', 'GPU'],
			created_date: '22-03-2024'
		});
	}, [overViewData]);

	React.useEffect(() => {
		if (onlyExtraSmall) {
			setNumberOfItems(1);
		} else if (onlySmallScreen) {
			setNumberOfItems(2);
		} else if (onlyMediumScreen) {
			setNumberOfItems(2);
		} else if (onlyLargeScreen) {
			setNumberOfItems(3);
		} else {
			setNumberOfItems(3);
		}
	});

	const onClickInitFunction = () => {
		if (!disableInteractions) onInitFunctionSelect();
	};

	const onClickEndpoints = e => {
		if (!disableInteractions) onEndpointSelect(e);
	};
	return (
		<Grid container display="flex" justifyContent="space-between">
			<MarketplaceDialogBox
				openDialogBox={openDialogBox}
				setOpenDialogBox={setOpenDialogBox}
				handler={deleteToken}
				confirmButtonTitle="Delete"
				title="Delete"
				message="Are you sure about deleting the token ?"
				srcIcon={Delete}
			/>
			<Grid item xs={6} sm={6} padding="0px 20px 0px 0px">
				<FunctionOverviewCard
					data={functionData}
					updateFunctionData={setFunctionData}
					isLoading={loader}
					onTearDown={onTearDown}
				/>
				<FunctionEnvironmentCard environmentDetails={environmentDetails} isLoading={loader} />
				<FunctionHardwareCard data={hardwareData} isLoading={loader} />
				<DetailedDescription
					title="Detailed Description"
					value={(functionData && functionData?.description) || ''}
					isLoading={loader}
				/>
			</Grid>
			<Grid item xs={4} sm={5} md={6} padding="0px 0px 0px 20px">
				<Box
					sx={{
						width: '100%',
						// minWidth: '592px',
						height: '360px',
						padding: '12px 24px',
						border: '1px solid',
						borderRadius: '8px',
						borderColor: theme.palette.background.blue03
					}}
				>
					<Typography sx={{ fontSize: '16px', fontWeight: 700, marginBottom: '22px' }}>
						Service Overview
					</Typography>
					<Grid container>
						<Grid
							item
							xs={6}
							flexDirection="column"
							display="flex"
							width="100%"
							padding="0px 10px 0px 0px"
						>
							{loader && !functionData?.tags && (
								<Grid mb={3} sx={{ display: 'flex' }}>
									<Skeleton
										variant="rounded"
										width={60}
										height={24}
										sx={{ margin: '0px 3px 0px 0px' }}
									/>
									<Skeleton
										variant="rounded"
										width={60}
										height={24}
										sx={{ margin: '0px 3px 0px 0px' }}
									/>
									<Skeleton variant="rounded" width={60} height={24} />
								</Grid>
							)}
							{functionData?.tags && functionData?.tags.length > 0 && (
								<Grid mb={2}>
									<Stack
										padding="0px 10px 10px 0px"
										direction="row"
										spacing={1}
										sx={{ width: '100%' }}
									>
										{functionData?.tags?.length > 0 &&
											functionData?.tags.slice(0, numberOfItems).map(tags => (
												<Chip
													classes={{
														root: classes.chipRoot
													}}
													variant="filled"
													size="small"
													label={
														<Grid
															sx={{
																cursor: 'default',
																whiteSpace: 'nowrap',
																textOverflow: 'ellipsis',
																overflow: 'hidden'
															}}
														>
															<OverflowTooltip title={tags} length={12} />
															{/* {tags} */}
														</Grid>
													}
													key={tags}
												/>
											))}
										{functionData?.tags.slice(numberOfItems, functionData?.tags.length).length >
											0 && (
											<BootstrapTooltip
												title={functionData?.tags
													.slice(numberOfItems, functionData?.tags.length)
													.map(tags => (
														<Chip
															variant="filled"
															size="small"
															label={
																<Grid sx={{ cursor: 'default' }}>
																	<OverflowTooltip title={tags} length={12} />
																</Grid>
															}
															key={tags}
														/>
													))}
												key={`+${
													functionData?.tags.slice(numberOfItems, functionData?.tags.length).length
												}`}
												placement="top"
											>
												<Chip
													className="chipContainer"
													sx={{ cursor: 'default' }}
													variant="filled"
													color="secondary"
													size="small"
													label={`+${
														functionData?.tags.slice(numberOfItems, functionData?.tags.length)
															.length
													}`}
												/>
											</BootstrapTooltip>
										)}
										{/* {tags.map((tag, index) => {
										return <Chip label={tag} />;
									})} */}
									</Stack>
								</Grid>
							)}

							<CustomButton
								fontSize="14px"
								title="Init Function"
								disabled={disableInteractions}
								cursor={disableInteractions && 'static'}
								maxWidth="100%"
								width="100%"
								startIcon={FunctionIcon}
								endIcon={ArrowRight}
								onClick={onClickInitFunction}
								borderColor={theme.palette.background.blue03}
							/>
							<InitFunctionInputs title="Init Function Inputs" data={inputData} />
						</Grid>
						<Grid item xs={6} display="flex" width="100%">
							<Divider
								sx={{
									width: '1px',
									height: '221px',
									margin: '0px 30px 0px 30px',
									backgroundColor: theme.palette.background.blue03
								}}
							/>
							<Box width="100%">
								<Typography
									sx={{
										fontSize: '14px',
										color: theme.palette.text.gray03,
										fontWeight: 700,
										marginBottom: '11px'
									}}
								>
									Endpoints
								</Typography>
								<Box maxHeight="205px" overflow="auto" sx={{ scrollbarColor: '#5552FF #08081a' }}>
									{loader ? (
										<>
											<Skeleton variant="rounded" width="70%" height={30} sx={{ margin: '0px' }} />
											<Skeleton
												variant="rounded"
												width="70%"
												height={30}
												sx={{ marginTop: '10px' }}
											/>
											<Skeleton
												variant="rounded"
												width="70%"
												height={30}
												sx={{ marginTop: '10px' }}
											/>
										</>
									) : functionData && functionData?.endpoints?.length > 0 ? (
										functionData?.endpoints?.map((e, i) => (
											<div key={`${e?.route}-${i}`}>
												<CustomButton
													fontSize="14px"
													margin="0px 0px 12px 0px"
													title={e?.route}
													cursor={disableInteractions && 'static'}
													disabled={disableInteractions}
													width="96%"
													startIcon={EndpointIcon}
													endIcon={ArrowRight}
													onClick={() => onClickEndpoints(e)}
													borderColor={theme.palette.background.blue03}
												/>
											</div>
										))
									) : (
										<Box
											sx={{
												width: '96%',
												height: '205px',
												borderRadius: '8px',
												display: 'flex',
												justifyContent: 'center',
												alignItems: 'center',
												flexDirection: 'column',
												border: `1px solid ${theme?.palette?.background?.blue03}`
											}}
										>
											<Icon
												src={EndpointIcon}
												type="static"
												alt="noSecretsIcon"
												width="25px"
												height="20px"
											/>
											<Typography variant="h2" mt="22px">
												No Endpoints found
											</Typography>
										</Box>
									)}
								</Box>
							</Box>
						</Grid>
					</Grid>
				</Box>
				<AuthManagement
					data={authTokens}
					setOpenDialogBox={setOpenDialogBox}
					isLoading={authLoader}
					setDeleteKey={setDeleteKey}
					handleAddToken={handleAddToken}
					disableInteractions={disableInteractions}
				/>
			</Grid>
		</Grid>
	);
}

export default FunctionOverview;
