/* eslint-disable no-unused-vars */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import Tooltip from '@mui/material/Tooltip';
// import { useSelector } from 'react-redux';
import { Auth } from 'aws-amplify';
import { useDispatch, useSelector } from 'react-redux';
import { Skeleton } from '@mui/material';
import CommonTab from '../../../components/tab/graph';
import Overview from './overview';
import Endpoints from './endpoints';
import Icon from '../../../components/icon';
import HomeIconInactive from '../../../assets/navbar/home.svg';
import HintIcon from '../../../assets/actions/hint.svg';
// import { selectNavbarState } from '../../../redux/navbarSlice';
import routes from '../../../constants/routes.json';
import { getUserAPIKey } from '../../../api/users/apiKey';
import {
	getFunctionDetails,
	getInferenceKeys,
	addNewInferenceKey,
	teardownFunction
} from '../../../api/functionServe/functionServeApi';
import { getBatchEnvironments } from '../../../api/environments/environmentsApi';
import useUpdateEffect from '../../../utils/useUpdateEffect';
import { setDisableInteractions } from '../../../redux/functionServeSlice';
import CustomisedSnackbar from '../../../components/snackbar/projects';
import Breadcrumb from '../../../components/breadcrumb';
import { capitalizeName } from '../../../utils/utils';

function FunctionServe(props) {
	const { tab } = props;
	const { functionId } = useParams();
	const [tabValue, setTabValue] = useState(tab);
	const navigate = useNavigate();
	const location = useLocation();
	// const { functionVal } = location.state || {};
	const [selectedEndpoint, setSelectedEndpoint] = useState('');
	const [functionData, setFunctionData] = useState({});
	const [token, setToken] = useState('');
	const functionServeAction = useDispatch();
	const { disableInteractions } = useSelector(state => state.functionServe);
	const [authLoader, setAuthLoader] = useState(true);
	const [authTokens, setAuthTokens] = useState([]);
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState('');
	const [envDetails, setEnvDetails] = useState([]);
	const [loader, setLoader] = useState(true);
	const [functionDataLoader, setFunctionDataLoader] = useState(true);

	// state variable to trigger call function details api upon teardown
	const [functionTeardown, setFunctionTeardown] = useState(false);

	const onTabChange = (e, val) => {
		setTabValue(val);
		if (tab === 'Overview') {
			setSelectedEndpoint('');
		}
		navigate(`${routes?.FUNCTION_SERVE}/${functionId}/${val}`);
	};

	useEffect(() => {
		if (location?.pathname?.split('/')[3]) {
			setTabValue(location?.pathname?.split('/')[3]);
		}
	}, [location?.pathname]);

	useEffect(() => {
		Auth.currentAuthenticatedUser()
			.then(user => {
				const res = user?.attributes;
				getUserAPIKey(res && res['custom:userID'])
					.then(payload => {
						if (payload) {
							setToken(payload[payload.length - 1]?.api_key);
						} else setToken('');
					})
					.catch(() => {
						setToken('');
					});
			})
			.catch(() => {
				setToken('');
			});
	}, []);

	const getBatchAuthTokens = functionDetailID => {
		getInferenceKeys(functionDetailID)
			.then(res => {
				if (res) {
					setAuthTokens(res);
				}
			})
			.catch(err => {
				setOpenSnackbar(true);
				setSnackbarMessage(err);
			})
			.finally(() => {
				setAuthLoader(false);
			});
	};

	const handleAddToken = () => {
		setAuthLoader(true);
		addNewInferenceKey(functionId)
			.then(response => {
				if (response) {
					setSnackbarMessage('Token added successfully');
					setOpenSnackbar(true);
				}
			})
			.catch(err => {
				console.log('Error in adding token: ', err);
			})
			.finally(() => {
				getBatchAuthTokens(functionId);
			});
	};

	const getEnvironmentDetails = envName => {
		// Calling environment batch api to find the id,status of the environment with the name
		setLoader(true);
		getBatchEnvironments(1, 0, envName, 'build_completed_at', 'desc')
			.then(response => {
				if (response) {
					setEnvDetails(response?.records[0]);
				}
			})
			.catch(error => {
				console.log('Error in fetching environment:', error);
			})
			.finally(() => {
				setLoader(false);
			});
	};

	useUpdateEffect(() => {
		if (token !== '') {
			setFunctionDataLoader(true);
			getFunctionDetails(functionId, token)
				.then(response => {
					if (response) {
						getBatchAuthTokens(response?.id);
						setFunctionData(response);
						getEnvironmentDetails(response?.executor?.env);
					}
					if (response?.status === 'ACTIVE') {
						functionServeAction(setDisableInteractions({ disableInteractions: false }));
					} else {
						functionServeAction(setDisableInteractions({ disableInteractions: true }));
					}
				})
				.catch(err => {
					console.log('Error: ', err);
					setFunctionData({});
				})
				.finally(() => {
					setFunctionDataLoader(false);
				});
		}
	}, [token, functionTeardown]);

	const onTearDown = () => {
		if (functionId && token) {
			teardownFunction(functionId, token)
				.then(res => {
					setFunctionTeardown(prevState => !prevState);
					functionServeAction(setDisableInteractions({ disableInteractions: true }));
					if (res) {
						setSnackbarMessage('Teardown successful');
						setOpenSnackbar(true);
					}
				})
				.catch(err => {
					setSnackbarMessage('Function teardown failed, please try again after some time');
					// setSnackbarMessage(err?.detail);
					setOpenSnackbar(true);
				});
		}
	};

	return (
		<Grid>
			<CustomisedSnackbar
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			<Breadcrumb
				home={<Icon padding={0} src={HomeIconInactive} />}
				secondary="Functions"
				name={capitalizeName(tab)}
				to={routes?.FUNCTION_SERVE}
			/>
			<Box sx={{ display: 'flex', alignItems: 'center', marginTop: '30px' }}>
				{!functionDataLoader && (
					<>
						<Typography
							sx={{
								fontSize: '32px',
								height: 'auto',
								width: 'fit-content',
								transition: 'padding-left 0.3s ease-in-out'
							}}
							id="appWalkthrough"
						// temporarily commenting out until neu machina render is fixed
						// pl={isOpen ? 10 : 0}
						// variant="h1"
						// mr={1}
						// sx={{ fontFamily: 'Machina, sans-serif', color: '#FFFFFF !important'
						// }}
						>
							{functionData?.title || 'Function Details'}
						</Typography>
						<Tooltip
							placement="right"
							title={
								tab === 'Overview'
									? 'See below for information about this service deployment. Inspect the service status, monitor costs, manage authorization tokens, or  click “Teardown” to stop this service.'
									: 'The endpoints available on this service are listed here, along with the service URL. Select any endpoint to view boilerplate code for interacting with it. Use the “Test Endpoint” button, if available, to submit a default request.'
							}
						>
							<span>
								<Icon padding={0} margin="0px 0px 0px 8px" src={HintIcon} />
							</span>
						</Tooltip>
					</>
				)}
				{functionDataLoader && <Skeleton variant="text" width={230} height={48} />}
			</Box>
			<Box mt={1}>
				<CommonTab
					firstValue="Overview"
					secondValue="Endpoints"
					value={tabValue}
					onChange={onTabChange}
				/>
			</Box>
			<Grid mt={2}>
				{tabValue === 'Overview' && (
					<Overview
						overViewData={functionData}
						setTabValue={setTabValue}
						setSelectedEndpoint={setSelectedEndpoint}
						authLoader={authLoader}
						authTokens={authTokens}
						setAuthLoader={setAuthLoader}
						setAuthTokens={setAuthTokens}
						getBatchAuthTokens={getBatchAuthTokens}
						setOpenSnackbar={setOpenSnackbar}
						setSnackbarMessage={setSnackbarMessage}
						handleAddToken={handleAddToken}
						envDetails={envDetails}
						loader={loader}
						onTearDown={onTearDown}
					/>
				)}
				{tabValue === 'Endpoints' && (
					<Endpoints
						data={functionData}
						selectedEndpointValue={selectedEndpoint}
						apiKey={token}
						setOpenSnackbar={setOpenSnackbar}
						setSnackbarMessage={setSnackbarMessage}
					/>
				)}
			</Grid>
		</Grid>
	);
}

function FunctionLayoutValidate() {

};

export default FunctionLayoutValidate;
