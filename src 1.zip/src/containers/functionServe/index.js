/* eslint-disable no-unused-vars */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useEffect } from 'react';
import { useDebounce } from 'use-debounce';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import { Virtuoso } from 'react-virtuoso';
import { useDispatch } from 'react-redux';
import SubHeaderControls from '../../components/subHeaderControls/v2';
import FunctionServeCard from '../../components/card/functionServe/functionServeCard';
import MarketplaceDialogBox from '../../components/dialogBox/marketplace';
import CustomisedSnackbar from '../../components/snackbar/projects';
import NotFound from '../../components/notFound';
import Loader from '../../components/loader';
import { setDisableInteractions } from '../../redux/functionServeSlice';
import { getBatchFunctions } from '../../api/functionServe/functionServeApi';

function FunctionServe() {
	const [sortOrder, setSortOrder] = useState('DESC');
	const [filterStatus, setFilterStatus] = useState('ALL');
	const [searchKey, setSearchKey] = useState('');
	const [searchValue] = useDebounce(searchKey, 2000);
	const [page, setPage] = useState(0);
	const functionServeAction = useDispatch();
	// States for snackbar and dialog box
	const [openDialogBox, setOpenDialogBox] = useState(false);
	const [snackbarOpen, setSnackbarOpen] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState('');

	const [functionData, setFunctionData] = useState([]);

	// State to get selected item to show on delete dialog box and snackbar message
	const [selected, setSelected] = useState('');

	const [loading, setLoading] = useState(true);

	const functionsListApi = () => {
		const statusBody = filterStatus === 'ALL' ? '' : filterStatus;
		const bodyParameters = {
			count: 0,
			page,
			search: searchValue,
			sort: 'created_at',
			direction: sortOrder,
			status: statusBody
		};
		getBatchFunctions(bodyParameters)
			.then(res => {
				if (res) {
					setFunctionData(res?.records);
				}
			})
			.catch(err => console.log(err))
			.finally(() => {
				setLoading(false);
			});
	};

	useEffect(() => {
		setLoading(true);
		functionsListApi();
		functionServeAction(setDisableInteractions({ disableInteractions: true }));
	}, [filterStatus, sortOrder, page, searchValue]);

	const snackbarClose = () => {
		setSnackbarOpen(false);
	};

	const onDelete = title => {
		setOpenDialogBox(true);
		setSelected(title);
	};

	const deleteHandler = () => {
		setOpenDialogBox(false);
		setSnackbarOpen(true);
		setSnackbarMessage(`${selected} deleted successfully`);
	};

	const renderFunctionServeCard = (index, user) => (
		<FunctionServeCard key={user.id} data={user} onDelete={onDelete} />
	);

	return (
		<Grid>
			<CustomisedSnackbar
				message={snackbarMessage}
				open={snackbarOpen}
				onClose={snackbarClose}
				clickHandler={snackbarClose}
			/>
			<MarketplaceDialogBox
				openDialogBox={openDialogBox}
				setOpenDialogBox={setOpenDialogBox}
				handler={deleteHandler}
				// disableSaveButton={disableSaveButton}
				title="Delete function serve"
				message={
					<>
						<Typography sx={{ display: 'flex' }}>Are you sure about deleting </Typography>
						<Typography px={0.5} sx={{ display: 'flex', fontWeight: 'bold' }}>
							{selected}
						</Typography>
						?
					</>
				}
				confirmButtonTitle="Delete"
			/>
			<Grid container>
				<Grid item xs={7} sx={{ position: 'relative' }}>
					<SubHeaderControls
						filterComponent
						displaySearchFirst
						sortComponent
						sortTitle="Created Date"
						filterTitles={['ALL', 'ACTIVE', 'INACTIVE', 'CREATING']}
						sort={sortOrder}
						setSortBy={setSortOrder}
						filterBy={filterStatus}
						setFilterBy={setFilterStatus}
						searchKey={searchKey}
						setSearchKey={setSearchKey}
					/>
					{loading && <Loader position="relative" isFetching width="100%" height="66vh" />}
					{!loading && functionData?.length > 0 && (
						<Virtuoso
							style={{
								height: '68.5vh',
								width: '100%',
								paddingRight: '10px',
								marginTop: 24,
								scrollbarWidth: 'thin ',
								scrollbarColor: '#5552FF #08081a'
							}}
							data={functionData}
							itemContent={renderFunctionServeCard}
						/>
					)}
					{!loading && functionData?.length === 0 && (
						<NotFound height="20vh" message="No functions found" />
					)}
				</Grid>

				{/* {dummyData.map(item => (
					<FunctionServeCard key={item.id} data={item} onDelete={onDelete} />
				))} */}
			</Grid>
		</Grid>
	);
}

export default FunctionServe;
