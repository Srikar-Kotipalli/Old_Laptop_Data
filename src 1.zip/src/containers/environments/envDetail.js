/* eslint-disable react/no-array-index-key */
/* eslint-disable no-unused-vars */
/* eslint-disable no-await-in-loop*/
/* eslint-disable no-unsafe-optional-chaining*/
import React, { lazy, useEffect, useState } from 'react';
import { Box, Grid, Stack, InputBase, Tooltip } from '@mui/material';
import jsYaml from 'js-yaml';
import YAML from 'yaml';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import Backdrop from '@mui/material/Backdrop';
import { useSelector } from 'react-redux';
import moment from 'moment';
import Breadcrumb from '../../components/breadcrumb';
import covLoader from '../../assets/loaders/covLoader.svg';
import Icon from '../../components/icon';
import EnvironmentImage from '../../assets/environments/overviewIcon.svg';
import SearchIcon from '../../assets/actions/search.svg';
import CopyButton from '../../components/copyButton';
import Edit from '../../assets/actions/edit.svg';
import Delete from '../../assets/actions/delete.svg';
import InfoCard from '../../components/card/environments/v2/envInfo';
import PipInfoCard from '../../components/card/environments/v2/pipInfoCard';
import EnvironmentTab from '../../components/tab/environments/envOperations';
import { capitalizeName } from '../../utils/utils';
import useLength from '../../utils/useLength';
import {
	getYamlFile,
	getEnvironment,
	getDefaultEnvironment,
	deleteEnivronment,
	enivronmentLogs
} from '../../api/environments/environmentsApi';
// import covLoader from '../../assets/loaders/covLoader.svg';
import EnvOverviewHeader from '../../components/overviewHeader/Environments';
import MarketplaceDialogBox from '../../components/dialogBox/marketplace';
import EnvAccordion from '../../components/accordion/environments';
import Loader from '../../components/loader';
import AddNewEnvironment from './addEnvironment';
import EnvLogs from './envLogs';
import CustomisedSnackbar from '../../components/snackbar/projects';
import routes from '../../constants/routes.json';
import useUpdateEffect from '../../utils/useUpdateEffect';

const PageNotFoundScreen = lazy(() => import('../pagenotfound'));

function EnvDetails() {
	const [expanded, setExpanded] = useState(true);
	const [isDefault, setIsDefault] = useState(false);
	const [openLoader, setOpenLoader] = useState(true);
	const [yamlContent, setYamlContent] = useState('');
	const [openSnackbar, setOpenSnackbar] = React.useState(false);
	const [snackbarMessage, setSnackbarMessage] = React.useState('');
	const [channels, setChannels] = React.useState([]);
	const [pip, setPip] = React.useState([]);
	const [conda, setConda] = React.useState([]);
	// const [variables, setVariables] = React.useState([]);
	const [envname, setEnvName] = React.useState('');
	const [searchQuery, setSearchQuery] = useState('');
	const [openDialogBox, setOpenDialogBox] = useState(false);
	// the below variable is used to disable/enable the edit tab upon the environment creation and edit
	const [disabled, setDisabled] = useState(false);
	const [logsRefreshDisabled, setLogsRefreshDisabled] = useState(false);
	const [status, setStatus] = useState();
	const { id } = useParams();
	let envId = id;
	const navigate = useNavigate();
	const location = useLocation();
	const { tabValue } = location.state || { tabValue: 'overview' };
	const [value, setValue] = useState(tabValue);
	const [fetch, setFetch] = useState(false);
	const [logsMessage, setLogsMessage] = useState('');
	const [triggerLogs, setTriggerLogs] = useState(false);
	const [isLogsLoading, setIsLogsLoading] = useState(false);
	const [logError, setLogError] = useState(false);
	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);
	const [envDateTime, setEnvDateTime] = useState({
		createdDate: '',
		lastBuildDate: ''
	});
	const socketData = useSelector(({ socket }) => socket.socketData);
	const logsLength = useLength({ xs: 100, s: 100, m: 140, l: 160, xl: 180 });

	function splitLongStrings(messageData) {
		// filter out the log messages which has an empty line
		const filteredMessageData = messageData?.filter(message => message !== '\n');

		// split the lengthy messages after every 200 characters
		const updatedMessageData = filteredMessageData
			?.map(message => {
				if (message?.length > logsLength) {
					const splitMessages = [];
					let startIndex = 0;
					let endIndex = logsLength;
					while (startIndex < message?.length) {
						if (endIndex >= message?.length) {
							endIndex = message?.length;
						}
						splitMessages?.push(message?.slice(startIndex, endIndex));
						startIndex = endIndex;
						endIndex += logsLength;
					}
					return splitMessages;
				}
				return [message];
			})
			.flat();
		return updatedMessageData;
	}

	const fetchLogs = async () => {
		let prevToken = '';
		let nextForwardToken = '';
		let exitCondition;
		// counter used to check empty events and terminate after three consecutive empty response
		let count = 0;
		let logsMessageValue = '';
		// used to check if the logs fetch API failed
		let didLogRefreshFail = false;
		// to display a loader only on the first load and not upon refreshing the screen
		let didLogUpdate = false;
		if (!isLogsLoading && !logsRefreshDisabled) {
			setIsLogsLoading(true);
		}
		do {
			try {
				const _res = await enivronmentLogs(id, nextForwardToken);
				// commenting the condition where we check the message for successful build completion inorder to terminate the loop
				// message length is checked for events.length > 3 because we are accessing the second last element in the array for the SUCCEEDED message
				const responseMessage = _res?.events?.map(item => item?.message);
				const messageData = splitLongStrings(responseMessage);
				// check if one of the log event has the phrase POST_BUILD State: SUCCEEDED if so then the stream has reached the end of logs (Currently using the default exit condition)
				// const logSucceeded =
				// 	Array.isArray(messageData) && messageData.length > 1
				// 		? messageData.some(message => message.includes('POST_BUILD State: SUCCEEDED'))
				// 		: false;
				exitCondition = nextForwardToken === _res?.nextForwardToken;
				// if (status === 'READY') {
				// 	exitCondition = logSucceeded;
				// 	// exitCondition = _res.events?.length === 0;
				// } else {
				// 	exitCondition = nextForwardToken !== _res?.nextForwardToken;
				// }
				if (_res?.events?.length !== 0) {
					logsMessageValue += messageData?.join('\n');
					// setLogsMessage(prevLogs => prevLogs + messageData?.join('\n'));
					setLogsMessage(logsMessageValue);
					didLogUpdate = true;
				} else {
					// increase the counter every time event is returned as empty
					count += 1;
				}
				prevToken = nextForwardToken;
				nextForwardToken = _res?.nextForwardToken;
				if (_res?.events && _res?.events?.length !== 0) {
					setIsLogsLoading(false);
				}
			} catch (error) {
				console.log(error);
				didLogRefreshFail = true;
				if (error?.detail === 'expected string or bytes-like object' || error?.status === 500) {
					setOpenSnackbar(true);
					setLogError(true);
					setSnackbarMessage(
						'Unable to fetch logs for this environment, please rebuild the environment to fetch latest logs'
					);
					setLogsRefreshDisabled(false);
					return;
				}
				setLogsRefreshDisabled(false);
				setIsLogsLoading(false);
				setSnackbarMessage(
					error?.detail ? error.detail : 'Something went wrong, contact administrator'
				);
				setOpenSnackbar(true);
				break;
			}
			// terminate the loop when the exitCondition is met or envId becomes empty
			// or when the counter becomes 3
		} while (!exitCondition && envId !== '' && count < 3);
		if (
			logsRefreshDisabled &&
			!didLogRefreshFail &&
			count < 3 &&
			!didLogUpdate &&
			status !== 'READY'
		) {
			setSnackbarMessage('Please wait as latest logs are being generated...');
			setOpenSnackbar(true);
		} else if (logsRefreshDisabled && !didLogRefreshFail) {
			setSnackbarMessage('Logs refreshed successfully');
			setOpenSnackbar(true);
		}
		setLogsRefreshDisabled(false);
	};

	useUpdateEffect(() => {
		return () => {
			envId = '';
		};
	}, []);

	useUpdateEffect(() => {
		fetchLogs();
	}, [triggerLogs]);

	const handleTabClick = (_e, val) => {
		setValue(val);
		setSearchQuery('');
	};

	const onclick = () => {
		getDefaultEnvironment()
			.then(resDefault => {
				if (id === resDefault?.environment_id) {
					setIsDefault(true);
				}
			})
			.catch(() => {
				setIsDefault(false);
			});
		getEnvironment(id)
			.then(result => {
				setStatus(result?.status);
				setTriggerLogs(prevState => !prevState);
				if (result?.status !== 'READY') {
					setDisabled(true);
				}
				// Compute the last build and created date
				const buildCompletedTime = result?.build_completed_at
					? moment(new Date(result?.build_completed_at)).format('MM-DD-YYYY')
					: '-';
				const createdDateTime = result?.created_at
					? moment(new Date(result?.created_at)).format('MM-DD-YYYY')
					: '-';
				setEnvDateTime({
					buildCompletedTime,
					createdDate: createdDateTime
				});
				if (result?.definition) {
					const name = result?.name;
					setEnvName(name);
					getYamlFile(result?.definition)
						.then(res => {
							// Need to check if this parse and dump is really necessary as it cancels each other out
							const parsedData = YAML.parse(res?.data);
							const YamlOutput = jsYaml.dump(parsedData, {
								lineWidth: -1
							});
							setYamlContent(YamlOutput);
							// eslint-disable-next-line no-unsafe-optional-chaining
							setChannels([...parsedData?.channels]);
							setPip(() => {
								const tempArr = [];
								parsedData?.dependencies?.forEach(element => {
									if (typeof element === 'object' && element?.pip) tempArr.push(...element['pip']);
								});
								return tempArr;
							});

							setConda(() => {
								const tempArr = [];
								parsedData?.dependencies?.forEach(element => {
									if (typeof element !== 'object') tempArr.push(element);
								});
								return tempArr;
							});

							// setVariables([]);
							setOpenLoader(false);
						})
						.catch(_error => {
							setChannels([]);
							setPip([]);
							setConda([]);
							setVariables([]);
							setOpenLoader(false);
						});
				} else {
					setEnvData({});
				}
			})
			.catch(err => {
				setOpenLoader(false);
				console.log('Error:', err);
			});
	};

	const setDeleteEnvironment = () => {
		deleteEnivronment(id)
			.then(_res => {
				setSnackbarMessage(`Environment ${envname} has been deleted successfully`);
				setOpenSnackbar(true);
				setOpenLoader(true);
				setTimeout(() => navigate('/environments'), 500);
			})
			.catch(err => {
				setSnackbarMessage(
					err?.detail ? err.detail : 'Something went wrong, contact administrator'
				);
				setOpenSnackbar(true);
			});
	};

	const deleteEnv = () => {
		setDeleteEnvironment();
		setOpenDialogBox(false);
	};

	const handleChange = () => {
		setExpanded(!expanded);
	};

	const filteredData = pip?.filter(item =>
		item?.toLowerCase()?.includes(searchQuery?.toLowerCase())
	);

	useUpdateEffect(() => {
		if (socketData?.message === 'environment' && id === socketData?.env_id) {
			const statusVal = socketData?.status;
			onclick();
			if (statusVal === 'READY') {
				setDisabled(false);
			} else {
				setDisabled(true);
			}
		}
	}, [liveRefresh]);

	useEffect(() => {
		onclick();
		setOpenLoader(true);
		const searchParams = new URLSearchParams(location.search);
		const tabFromQuery = searchParams.get('tab');
		if (tabFromQuery) {
			setValue(tabFromQuery);
		}
	}, [id, location?.search, fetch]);

	return (
		<>
			<MarketplaceDialogBox
				openDialogBox={openDialogBox}
				setOpenDialogBox={setOpenDialogBox}
				handler={deleteEnv}
				confirmButtonTitle="Delete"
				title="Delete"
				message={`Are you sure about deleting ${envname} ?`}
				srcIcon={Delete}
			/>
			<CustomisedSnackbar
				testId="envSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			<Loader isFetching={openLoader} width="100vw" height="100vh" />
			{!openLoader &&
				(envname ? (
					<>
						<Breadcrumb secondary="Environments" name={capitalizeName(value)} to="/environments" />
						<EnvOverviewHeader
							envName={envname}
							image={EnvironmentImage}
							defaultEnv={isDefault}
							status={status}
						/>
						<Grid container sx={{ justifyContent: 'space-between' }}>
							<Grid item xs={6} sm={6} md={6} lg={7} xl={7.5} p="15px 0 15px 0">
								<EnvironmentTab value={value} onChange={handleTabClick} isdisabled={disabled} />
							</Grid>
							<Grid
								item
								xs={6}
								sm={6}
								md={5.5}
								lg={4.8}
								xl={4.1}
								pl={{ xs: 0, sm: 0, lg: 0, xl: 0 }}
							>
								<Grid container sx={{ justifyContent: 'space-around' }}>
									{/* while uncommenting the below data remove justify content and width styles */}

									<Box sx={{ float: 'right', mt: 2 }} width="100%">
										<Grid container justifyContent="start">
											<Grid sx={{ mr: '58px', display: 'flex' }}>
												<Stack direction="row" spacing={2} alignItems="center">
													<Box className="createdlabel">Created Date</Box>
													<Box className="createdlabelsub" sx={{ fontSize: '14px' }}>
														{envDateTime?.createdDate}
													</Box>
												</Stack>
											</Grid>
											<Grid sx={{ mr: '58px', display: 'flex' }}>
												<Stack direction="row" spacing={2} alignItems="center">
													<Box className="createdlabel">Last Build</Box>
													<Box className="createdlabelsub" sx={{ fontSize: '14px' }}>
														{envDateTime?.buildCompletedTime}
													</Box>
												</Stack>
											</Grid>
											<Grid>
												<Stack direction="row" spacing={1} alignItems="center">
													<CopyButton
														content={envname}
														placement="bottom"
														padding="5px"
														bgColor="#2a2a5c"
													/>
													{!isDefault && status === 'READY' && (
														<Tooltip title="Delete">
															<div>
																<Icon
																	bgColor="#2a2a5c"
																	padding="4px"
																	src={Delete}
																	clickHandler={() => setOpenDialogBox(true)}
																	alt="delete"
																/>
															</div>
														</Tooltip>
													)}
												</Stack>
											</Grid>
										</Grid>
									</Box>
								</Grid>
							</Grid>
						</Grid>
						{value === 'overview' && (
							<Grid container columnSpacing={2} sx={{ marginLeft: 0, width: '100%' }}>
								<Grid item xs={7} p="15px 0 15px 0">
									<Box
										sx={{
											border: '1px solid rgba(48, 48, 103, 1)',
											borderRadius: '8px',
											padding: '4%'
										}}
									>
										<Box sx={{ width: '70%' }}>
											<Box
												sx={{
													padding: '0 0 30px 0',
													color: 'white',
													fontSize: '16px',
													cursor: 'default'
												}}
											>
												Channels
											</Box>
											<Box pb="45px">
												<InfoCard data={channels} />
											</Box>
											<Box
												sx={{
													padding: '0 0 30px 0',
													color: 'white',
													fontSize: '16px',
													cursor: 'default'
												}}
											>
												Pip Packages Added
											</Box>
											<Stack spacing={2} width="50%">
												<InputBase
													placeholder="Search"
													value={searchQuery}
													onChange={e => setSearchQuery(e.target.value)}
													startAdornment={<Icon src={SearchIcon} alt="Search" />}
													sx={{
														color: 'rgba(203, 203, 215, 1)',
														border: '1px solid rgba(48, 48, 103, 1)',
														borderRadius: '60px',
														padding: '4px'
													}}
												/>
												<Box>
													<PipInfoCard data={filteredData} maxHeight="150px" />
												</Box>
											</Stack>
											<Box
												sx={{
													padding: '40px 0 30px 0',
													color: 'white',
													fontSize: '16px',
													cursor: 'default'
												}}
											>
												Conda
											</Box>
											<InfoCard data={conda} />
										</Box>
									</Box>
								</Grid>
								<Grid item xs={4.5} lg={4.8} xl={4.7} xxl={4.6}>
									<EnvAccordion
										expanded={expanded}
										handleChange={handleChange}
										yamlContent={yamlContent}
										width="32vw"
									/>
								</Grid>
							</Grid>
						)}
						{value === 'edit' && (
							<AddNewEnvironment
								setOpenLoader={setOpenLoader}
								fetch={fetch}
								setFetch={setFetch}
								editName={envname}
								editConda={conda}
								editPip={filteredData}
								editChannels={channels}
								editid={id}
								setTabValue={setValue}
							/>
						)}
						{value === 'logs' && (
							<EnvLogs
								envId={id}
								envname={envname}
								logsMessage={logsMessage}
								logError={logError}
								setLogError={setLogError}
								isDataLoading={isLogsLoading}
								setIsLogsLoading={setIsLogsLoading}
								setLogsMessage={setLogsMessage}
								rebuildDisabled={disabled}
								fetchEnvDetails={onclick}
								setRebuildDisabed={setDisabled}
								refreshDisabled={logsRefreshDisabled}
								setRefreshDisabled={setLogsRefreshDisabled}
							/>
						)}
					</>
				) : (
					<Grid sx={{ position: 'absolute', top: 0, width: '100%', left: 0 }}>
						<PageNotFoundScreen
							buttonText="Back to Environments"
							returnURL={routes?.ENVIRONMENTS}
						/>
					</Grid>
				))}
		</>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default EnvDetails;
