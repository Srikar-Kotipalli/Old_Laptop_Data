/* eslint-disable import/prefer-default-export */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';

export const ProjectContext = React.createContext({
	allItems: [],
	multipleSelectedItems: [],
	value: 'all',
	page: '1',
	totalRecords: 0,
	isAction: false,
	isMoved: false,
	handlePageChanges: () => {
		// This is handlePageChanges
	},
	onPin: () => {
		// This is onPin
	},
	onCheckboxChecked: () => {
		// This is onCheckboxChecked
	},
	onSort: () => {
		// This is onSort
	},
	addListItem: () => {
		// This is addListItem
	},
	editListItem: () => {
		// This is editListItem
	},
	sortColumn: 'lastUpdated',
	sortOrder: 'desc',
	projectAdded: false,
	isEdit: false,
	itemsToMove: () => {
		// This is itemsToMove
	},
	onAllSelected: () => {
		// This is onAllSelected
	},
	allSelected: false,
	sidebarHandler: () => {
		// This is sidebarHandler
	},
	closeSidebar: () => {
		// This is closeSidebar
	},
	filterTags: () => {
		// This is filterTags
	},
	deleteTags: () => {
		// This is deleteTags
	},
	addTags: () => {
		// This is addTags
	},
	saveTags: () => {
		// This is saveTags
	},
	postTagAddition: () => {
		// This is postTagAddition
	},
	setIsEdit: () => {
		// This is setIsEdit
	},
	onDeleteOrArchive: () => {
		// This is onDeleteOrArchive
	},
	setOpenProjectSnackbar: () => {
		// This is setOpenProjectSnackbar
	},
	setSnackbarMessage: () => {
		// This is setSnackbarMessage
	},
	postAddEditItem: () => {
		// This is postAddEditItem
	},
	sidebarActions: false,
	setSidebarActions: () => {
		// This is setSidebarActions
	},
	showArchived: false,
	sidebarId: '',
	openSidebar: false,
	openLoader: false,
	handleOpenExperiments: () => {
		// This is handleOpenExperiments
	},
	handleOpenAllProjects: () => {
		// This is handleOpenAllProjects
	},
	searchValue: '',
	tagsToFilter: [],
	setEditableText: () => {
		// This is setEditableText
	},
	addMode: false,
	editableText: '',
	deleteListTags: () => {
		// This is deleteListTags
	},
	setOpenLoader: () => {
		// This is setOpenLoader
	}
});
