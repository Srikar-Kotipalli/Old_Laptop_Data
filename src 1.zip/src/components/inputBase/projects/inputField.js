import * as React from 'react';
import { Box, Typography, Select, MenuItem, FormControl, FormHelperText } from '@mui/material';
import TextField from '@mui/material/TextField';
import { makeStyles } from '@mui/styles';
import visibilityOff from '../../../assets/hardware/visibilityOff.svg';
import visibilityOn from '../../../assets/hardware/visibilityOn.svg';
import Icon from '../../icon';

const useStyles = makeStyles({
	icon: { color: 'white' },
	root: { color: 'white' },
	notchedOutline: {
		borderWidth: '1px',
		borderColor: '#303067',
		borderRadius: '8px'
	}
});

function CustomInput(props) {
	const {
		placeholderTxt,
		value,
		handleChange,
		// handleEnter,
		typeInput,
		error,
		fieldName,
		name,
		width,
		height,
		endAdornment,
		fullWidth,
		errorTop,
		type,
		menuItems,
		readOnly,
		menuProps,
		defaultText = ''
	} = props;
	const [isVisible, setIsVisible] = React.useState(false);
	const [typing, setTyping] = React.useState(false);

	const classes = useStyles();

	React.useEffect(() => {
		if (value === '') setIsVisible(false);
	}, [value]);

	// to get the type for text field
	const getTypeForTextField = () => {
		if (typeInput === 'password' && value !== '') {
			if (isVisible) return 'text';
			return 'password';
		}
		return typeInput;
	};

	// to return the visibility images on toggle
	const toggleVisibility = () => {
		if (isVisible) return visibilityOn;
		return visibilityOff;
	};

	const handleFocus = () => {
		setTyping(true);
	};

	const handleBlur = () => {
		setTyping(false);
	};

	return (
		<Box display="flex" flexDirection="column">
			{fieldName && (
				<Typography
					variant="h1"
					sx={{
						fontSize: '14px',
						paddingLeft: '2px',
						color: '#CBCBD7'
					}}
				>
					{fieldName}
				</Typography>
			)}
			{type !== 'select' ? (
				<FormControl>
					<TextField
						id={`${placeholderTxt || name}-id`}
						label={placeholderTxt || ''}
						autoComplete="new-password"
						variant="outlined"
						onFocus={handleFocus}
						onBlur={handleBlur}
						sx={theme => ({
							px: 0.2,
							py: 2,
							pt: '5px',
							width: width || '100%',
							height: height || '32px',
							fontSize: '15px',
							// color: error ? 'error' : '#FFF',
							'& .MuiOutlinedInput-notchedOutline': {
								width: width || '100%',
								height: height || '40px'
							},
							'&:hover .MuiOutlinedInput-notchedOutline': {
								borderColor: `${theme.palette.background.blue05} !important`
							},
							'& .MuiInputBase-input .MuiOutlinedInput-input': {
								height: '3em'
							},
							'& input::placeholder': {
								fontSize: '14px'
							},
							'& .MuiFormHelperText-root': {
								marginTop: errorTop || '6px',
								marginLeft: '-1px'
							},
							'& .MuiOutlinedInput-root': {
								color: typing ? '#FFF' : '#86869A',
								padding: '13.695px 10px',
								fontSize: '14px'
							},
							'& .MuiInputLabel-root': {
								color: '#86869A',
								fontSize: '15px',
								marginTop: '6px'
								// marginTop: '-3px'
							},
							'& .MuiInputLabel-root.Mui-focused': {
								color: '#86869A',
								top: '2px'
							},
							'& .MuiInputLabel-shrink': {
								top: '2px'
							},
							'& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
								border: '1px solid #104794',
								boxShadow:
									'0px 1px 5px 0px rgba(16,71,148,255), 0px 0px 0.5px 3px rgba(21,49,108,255)'
							}
						})}
						// helperText={error}
						error={!!error}
						disabled={false}
						name={name}
						onChange={handleChange}
						value={value || ''}
						type={getTypeForTextField()}
						fullWidth={fullWidth}
						InputProps={{
							form: {
								autocomplete: 'off'
							},
							endAdornment:
								endAdornment && typeInput === 'password' && value !== '' ? (
									<Icon
										src={toggleVisibility()}
										alt="off/on"
										clickHandler={() => setIsVisible(prevState => !prevState)}
										type="pointer"
										padding="5px 0px 3.5px 6px"
									/>
								) : (
									endAdornment || null
								),
							classes: {
								notchedOutline: classes.notchedOutline
							},
							readOnly: readOnly || false
						}}
					/>
					{error && (
						<FormHelperText sx={{ marginLeft: 0 }} htmlFor={`${placeholderTxt || name}-id`} error>
							{error}
						</FormHelperText>
					)}
				</FormControl>
			) : (
				<FormControl>
					<Select
						labelId="demo-simple-select-label"
						id={`${placeholderTxt || name}-id`}
						displayEmpty
						// helperText={error}
						error={!!error}
						value={value}
						name={name}
						onFocus={handleFocus}
						onBlur={handleBlur}
						renderValue={option => (option?.length ? menuItems && menuItems[option] : defaultText)}
						onChange={handleChange}
						MenuProps={menuProps || ''}
						sx={{
							'& .MuiOutlinedInput-input': {
								borderRadius: '0px',
								height: '100% !important',
								alignItems: 'center',
								display: 'flex'
							},
							color: typing ? '#FFF' : '#86869A',
							fontSize: '14px',
							width: width || '300px',
							height: height || '32px',
							borderRadius: '8px',
							border: '1px solid #303067',
							px: 1.2,
							mt: 0.8
						}}
						inputProps={{
							classes: {
								icon: classes.icon
								// root: classes.icon
							}
						}}
						className="dropdownSelect"
					>
						{menuItems &&
							Object.keys(menuItems)?.map(item => (
								<MenuItem key={item} value={item} sx={{ fontSize: '14px' }}>
									{menuItems[item]}
								</MenuItem>
							))}
					</Select>
					{error && (
						<FormHelperText sx={{ marginLeft: 0 }} htmlFor={`${placeholderTxt || name}-id`} error>
							{error}
						</FormHelperText>
					)}
				</FormControl>
			)}
		</Box>
	);
}

export default CustomInput;
