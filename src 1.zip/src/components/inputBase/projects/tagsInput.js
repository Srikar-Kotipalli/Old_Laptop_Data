/* eslint-disable prefer-const */
/* eslint-disable react/jsx-no-duplicate-props */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';
import Tooltip from '@mui/material/Tooltip';
import TextField from '@mui/material/TextField';
import Icon from '../../icon';
import closeIcon from '../../../assets/checkmarks/closeError.svg';
import tickIcon from '../../../assets/checkmarks/checkmarkSuccess.svg';
import { ProjectContext } from '../../../containers/projects/projectContext';

export default function TagsInput(props) {
	const { type, listItem, saveSidebarTags, editableText } = props;
	const { saveTags } = React.useContext(ProjectContext);
	let crudAction = 'add';
	if (editableText) crudAction = 'edit';
	let saveFinalTags = saveTags;
	if (type === 'experimentSidebar') saveFinalTags = saveSidebarTags;
	const [text, setText] = React.useState('');
	let textInput = React.useRef(null);
	React.useEffect(() => {
		textInput.current.focus();
	}, []);
	React.useEffect(() => {
		if (editableText) setText(editableText);
	}, [editableText]);
	const onChange = e => {
		const newValue = e.target.value;
		setText(newValue);
	};
	const onFocus = event => {
		const target = event.target;
		setTimeout(() => target.select(), 0);
	};
	return (
		<TextField
			variant="standard"
			data-testid="inputBase"
			name="text"
			placeholder="Separate tags with commas"
			value={text}
			style={{ width: '80%' }}
			inputProps={{
				autoComplete: 'off',
				style: {
					fontSize: '12px',
					paddingBottom: '1px'
				}
			}}
			type="text"
			onChange={e => onChange(e)}
			onFocus={e => onFocus(e)}
			inputRef={textInput}
			onKeyDown={e =>
				e.key === 'Enter' && text !== '' && saveFinalTags(text, 'save', type, listItem, crudAction)
			}
			InputProps={{
				disableUnderline: true,
				endAdornment: (
					<>
						<Tooltip
							title={
								text === null || text === '' || text === undefined
									? 'Please enter a valid text to save'
									: 'Please click to save'
							}
							placement="top"
						>
							<span>
								<Icon
									disabled={text === null || text === '' || text === undefined}
									src={tickIcon}
									type="pointer"
									alt="tickIcon"
									clickHandler={() => saveFinalTags(text, 'save', type, listItem, crudAction)}
								/>
							</span>
						</Tooltip>
						<Tooltip title="Please click to cancel the crudAction" placement="top">
							<span>
								<Icon
									src={closeIcon}
									type="pointer"
									alt="closeIcon"
									clickHandler={() => saveFinalTags(text, 'close', type, listItem, crudAction)}
								/>
							</span>
						</Tooltip>
					</>
				)
			}}
		/>
	);
}
