/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState } from 'react';
import copy from 'copy-to-clipboard';
import Tooltip from '@mui/material/Tooltip';
import Icon from '../icon';
import copyIcon from '../../assets/actions/copy.svg';
import copyGrey from '../../assets/actions/copyGrey.svg';
import tickIcon from '../../assets/checkmarks/checkmark.svg';

function CopyButton({
	content,
	borderEnable,
	title = 'Copy',
	margin,
	padding,
	placement,
	bgColor,
	display,
	regular = true
}) {
	const [copied, setCopied] = useState(false);
	return (
		<Tooltip title={copied ? 'Copied!' : title} placement={placement || 'right'}>
			<span
				style={{
					border: borderEnable && '1px solid #303067',
					borderRadius: borderEnable && '8px',
					padding: borderEnable && '2px',
					margin: margin || 0
				}}
			>
				{copied ? (
					<Icon
						clickHandler={e => {
							e.stopPropagation();
						}}
						src={tickIcon}
						bgColor={bgColor}
						alt="tickIcon"
						display={display}
						type="static"
						width="14px"
						height="14px"
						padding={padding}
					/>
				) : (
					<Icon
						padding={padding}
						bgColor={bgColor}
						display={display}
						clickHandler={e => {
							e.stopPropagation();
							copy(content);
							setCopied(true);
							setTimeout(() => setCopied(false), 1200);
						}}
						alt="copyIcon"
						type="pointer"
						src={!regular ? copyGrey : copyIcon}
						testId="copyIcon"
						width="14px"
						height="14px"
					/>
				)}
			</span>
		</Tooltip>
	);
}

export default CopyButton;
