import React from 'react';
import Chart from 'react-apexcharts';

function ScatterChart({ solversSeriesData, height }) {
	const chartData = {
		series: solversSeriesData,
		options: {
			chart: {
				height: 350,
				type: 'scatter',
				toolbar: {
					show: false
				},
				zoom: {
					enabled: true,
					type: 'xy'
				},
				colors: ['#55D899', '#5552FF', '#FF6464', '#FFC164']
			},
			colors: ['#55D899', '#5552FF', '#FF6464', '#FFC164'],
			legend: {
				show: false
			},
			dataLabels: {
				enabled: false
			},
			markers: {
				size: 4,
				strokeColors: '#fff',
				strokeWidth: 0
			},
			xaxis: {
				title: {
					text: 'Time',
					style: {
						color: 'white'
					}
				},
				axisTicks: {
					show: false
				},
				crosshairs: {
					show: false
				},
				axisBorder: {
					show: false
				},
				labels: {
					show: false
				},
				tooltip: {
					enabled: false
				}
			},
			yaxis: {
				min: 0,
				max: 10,
				labels: {
					formatter: value => `${value} m`,
					style: {
						colors: ['white']
					}
				},
				// labels: {
				// 	style: {
				// 		colors: ['white']
				// 	}
				// },
				tickAmount: 5
			},
			grid: {
				borderColor: '#303067'
			},
			tooltip: {
				custom({ series, seriesIndex, dataPointIndex }) {
					return `${series[seriesIndex][dataPointIndex]}%`;
				}
			}
		}
	};
	return (
		<Chart
			options={chartData.options}
			series={chartData.series}
			type="scatter"
			height={height || 220}
		/>
	);
}

export default ScatterChart;
