/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Icon from '../icon';
import ArchiveIcon from '../../assets/billing/archive.svg';

function NotFound({ message, width = '100%', height = '167px' }) {
	return (
		<Box
			sx={{
				marginTop: '20px',
				marginBottom: '20px',
				width,
				height,
				border: '1px solid',
				borderRadius: '8px',
				borderColor: theme => theme.palette.background.blue03,
				display: 'flex',
				alignItems: 'center',
				justifyContent: 'center'
			}}
		>
			<Box
				sx={{
					display: 'flex',
					flexDirection: 'column',
					alignItems: 'center',
					justifyContent: 'center'
				}}
			>
				<Icon src={ArchiveIcon} />
				<Typography variant="h2" sx={{ marginTop: '22px' }}>
					{message}{' '}
				</Typography>
			</Box>
		</Box>
	);
}

export default NotFound;
