/* eslint-disable no-unused-vars */
/* eslint-disable react/jsx-props-no-spreading */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState } from 'react';
import { useMediaQuery, useTheme } from '@mui/material';
import Tooltip, { tooltipClasses } from '@mui/material/Tooltip';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import { makeStyles } from '@mui/styles';
import { styled } from '@mui/material/styles';

import { ProjectContext } from '../../containers/projects/projectContext';

const useStyles = makeStyles({
	chipRoot: {
		marginRight: '5px',
		'& .MuiChip-label': {
			padding: '0px 4px 0px 4px'
		},
		'& .MuiChip-icon': {
			order: 1,
			marginRight: '4px',
			cursor: 'pointer'
		},
		'& .MuiChip-deleteIcon': {
			order: 2,
			color: '#9999b2'
		}
	}
});

function Chips({ items, isExpandable, clickable }) {
	const [isInAdmin, setIsInAdmin] = useState(false);
	const [isInSolversData, setIsInSolverData] = useState(false);
	const projectContext = React.useContext(ProjectContext);
	const { filterTags } = projectContext;

	const classes = useStyles();
	const [numberOfItems, setNumberOfItems] = React.useState(3);
	const [maxWidth, setMaxWidth] = React.useState('90px');
	const theme = useTheme();
	const onlyExtraSmall = useMediaQuery(theme.breakpoints.only('xs')); // 0px - 1000px
	const onlySmallScreen = useMediaQuery(theme.breakpoints.only('sm')); // 1000px-1420px
	const onlyMediumScreen = useMediaQuery(theme.breakpoints.only('md')); // 1420- 1500px
	const onlyLargeScreen = useMediaQuery(theme.breakpoints.only('lg')); // 1500px- 1800px
	const [isInSolvers, setIsInSolvers] = useState(true);
	const [data, setData] = useState(items);
	const boxStyle = {
		width: isInAdmin ? null : '700px'
	};

	const BootstrapTooltip = styled(({ className, ...props }) => (
		<Tooltip {...props} arrow classes={{ popper: className }} />
	))(({ themes }) => ({
		[`& .${tooltipClasses.arrow}`]: {
			color: 'rgba(28, 28, 70, 1)'
		},
		[`& .${tooltipClasses.tooltip}`]: {
			backgroundColor: 'rgba(28, 28, 70, 1)'
		}
	}));
	React.useEffect(() => {
		const url = window.location.href;
		if (url.includes('solvers')) {
			setIsInSolvers(false);
			setData(items);
		}

		if (url.includes('solvers')) {
			setIsInSolverData(true);
		}

		if (onlyExtraSmall) {
			setNumberOfItems(1);
			setMaxWidth('50px');
		} else if (onlySmallScreen) {
			setNumberOfItems(2);
			setMaxWidth('50px');
		} else if (onlyMediumScreen) {
			setNumberOfItems(2);
			setMaxWidth('50px');
		} else if (onlyLargeScreen) {
			setNumberOfItems(3);
			setMaxWidth('50px');
		} else {
			setNumberOfItems(3);
			setMaxWidth('50px');
		}

		if (url.includes('solveradmin')) {
			setIsInAdmin(true);
		}
	});

	return (
		<div>
			<Stack padding="10px 10px 10px 0px" direction="row" spacing={1} sx={{ width: '100%' }}>
				{!isExpandable && items && items.length > numberOfItems ? (
					items.slice(0, numberOfItems).map(tags => (
						<Tooltip title={tags} key={tags}>
							<Chip
								classes={{
									root: classes.chipRoot
								}}
								variant="filled"
								size="small"
								label={
									<Grid
										sx={{
											maxWidth,
											cursor: clickable ? 'pointer' : 'default',
											whiteSpace: 'nowrap',
											textOverflow: 'ellipsis',
											overflow: 'hidden'
										}}
										onClick={() => filterTags(tags)}
									>
										{tags}
									</Grid>
								}
								key={tags}
							/>
						</Tooltip>
					))
				) : (
					<Box sx={boxStyle}>
						{items.map(tags => (
							<Tooltip title={tags} key={tags}>
								<Chip
									classes={{
										root: classes.chipRoot
									}}
									variant="filled"
									size="small"
									label={
										<Grid
											sx={{
												// maxWidth: isInAdmin? '10px':null,
												maxWidth: '50px',
												cursor: clickable ? 'pointer' : 'default',
												whiteSpace: 'nowrap',
												textOverflow: 'ellipsis',
												overflow: 'hidden'
											}}
											onClick={() => filterTags(tags)}
										>
											{tags}
										</Grid>
									}
									key={tags}
								/>
							</Tooltip>
						))}
					</Box>
				)}

				{!isExpandable && items && items.length > numberOfItems && (
					<BootstrapTooltip
						title={items.slice(numberOfItems, items.length).map(tags => (
							<Tooltip title={tags} key={tags}>
								<Chip
									classes={{
										root: classes.chipRoot
									}}
									variant="filled"
									size="small"
									label={
										<Grid
											sx={{
												cursor: clickable ? 'pointer' : 'default',
												maxWidth: '50px',
												whiteSpace: 'nowrap',
												textOverflow: 'ellipsis',
												overflow: 'hidden'
											}}
											onClick={() => filterTags(tags)}
										>
											{tags}
										</Grid>
									}
									key={tags}
								/>
							</Tooltip>
						))}
						key={`+${items.slice(numberOfItems, items.length).length}`}
						placement="top"
					>
						<Chip
							className="chipContainer"
							sx={{ cursor: clickable ? 'pointer' : 'default' }}
							variant="filled"
							color="secondary"
							size="small"
							label={`+${items.slice(numberOfItems, items.length).length}`}
						/>
					</BootstrapTooltip>
				)}
			</Stack>
		</div>
	);
}

export default Chips;
