import React, { useState, useEffect } from 'react';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import ArrowForwardIcon from '../../assets/arrows/caretRight.svg';
import Warning from '../../assets/environments/warning.svg';
import ArrowBackIcon from '../../assets/arrows/caretLeft.svg';
import Icon from '../icon';
import { BillingContext } from '../../containers/billing/billingContext';

const AlertCarousel = () => {
	const billingContext = React.useContext(BillingContext);

	const { paymentMethod, isLoading, toggleOpenDetails, isBillingAccountPresent } = billingContext;

	const [index, setIndex] = useState(0);

	const [isVisible, setIsVisible] = useState(true);

	const [alerts, setAlerts] = useState([]);

	useEffect(() => {
		const newAlerts = [];
		if (!isLoading) {
			if (!isBillingAccountPresent) {
				newAlerts.push('No billing account found');
			} else if (!paymentMethod) {
				newAlerts.push('Credit Card Details have not been added');
			}
			setAlerts(newAlerts);
		}
	}, [paymentMethod, isLoading]);

	const handleNext = () => {
		setIsVisible(false);
		setTimeout(() => {
			if (Array.isArray(alerts) && alerts?.length) {
				setIndex(prevIndex => (prevIndex + 1) % alerts.length);
				setIsVisible(true);
			}
		}, 300); // You can adjust the duration of the fade-in transition (in milliseconds)
	};

	const handlePrev = () => {
		setIsVisible(false);
		setTimeout(() => {
			if (Array.isArray(alerts) && alerts?.length) {
				setIndex(prevIndex => (prevIndex - 1 + alerts.length) % alerts.length);
				setIsVisible(true);
			}
		}, 300); // You can adjust the duration of the fade-in transition (in milliseconds)
	};

	return (
		alerts?.length > 0 && (
			<Paper
				sx={{
					position: 'relative',
					marginTop: '34px',
					height: '34px',
					padding: '10px 30px 10px 30px',
					display: 'flex',
					background: theme => theme.palette.background.covalentPurple,
					border: '1px solid',
					borderRadius: '8px',
					borderColor: theme => theme.palette.background.blue03,
					alignItems: 'center'
				}}
				elevation={3}
			>
				{alerts?.length > 1 && (
					<Box sx={{ display: 'flex', alignItems: 'center' }}>
						<Box
							mr={0.5}
							sx={{
								display: 'flex',
								alignItems: 'center',
								justifyContent: 'center',
								width: '16px',
								height: '16px',
								borderRadius: '4px',
								background: theme => theme.palette.background.blue03
							}}
						>
							<Icon clickHandler={handlePrev} src={ArrowBackIcon} padding="0 0 0 0" />
						</Box>
						<Typography
							variant="h2"
							textAlign="center"
							width="30px"
							// sx={{ opacity: isVisible ? 1 : 0, transition: 'opacity 0.3s ease-in-out' }}
						>
							{`${index + 1}/${alerts?.length}`}
						</Typography>
						<Box
							ml={0.5}
							mr={1}
							sx={{
								display: 'flex',
								alignItems: 'center',
								justifyContent: 'center',
								width: '16px',
								height: '16px',
								borderRadius: '4px',
								background: theme => theme.palette.background.blue03
							}}
						>
							<Icon clickHandler={handleNext} src={ArrowForwardIcon} />
						</Box>
					</Box>
				)}
				<Typography
					variant="h2"
					display="contents"
					sx={{ opacity: isVisible ? 1 : 0, transition: 'opacity 0.3s ease-in-out' }}
				>
					<Icon type="static" src={Warning} />
					{Array.isArray(alerts) && alerts?.length > 0 && index >= 0 && alerts[index]}
				</Typography>
				{Array.isArray(alerts) &&
					alerts?.length > 0 &&
					alerts[0] === 'Credit Card Details have not been added' && (
						<Box
							onClick={toggleOpenDetails}
							sx={{
								fontSize: '14px',
								color: theme => theme.palette.text.primary,
								position: 'absolute',
								right: 44,
								cursor: 'pointer',
								padding: '2px 8px',
								border: '1px solid transparent',
								'&:hover': {
									color: theme => theme.palette.text.secondary,
									border: '1px solid #6473FF',
									borderRadius: '70px'
								}
							}}
						>
							Add now
						</Box>
					)}
			</Paper>
		)
	);
};

export default AlertCarousel;
