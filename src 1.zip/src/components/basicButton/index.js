import React from 'react';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Tooltip from '@mui/material/Tooltip';

function BasicButton({ title, width, onClick, id, disabled = false, message }) {
	return (
		<Tooltip title={disabled ? message : ''} placement="top">
			<Button
				sx={{
					cursor: disabled ? 'default' : 'pointer',
					'&:hover': {
						backgroundColor: disabled
							? theme => theme.palette.background.paper
							: theme => theme.palette.background.covalentPurple
					},
					display: 'flex',
					width,
					justifyContent: 'center',
					alignItems: 'center',
					borderRadius: '25px',
					border: '1px solid',
					borderColor: disabled
						? theme => theme.palette.text.gray03
						: theme => theme.palette.background.blue05,
					backgroundColor: theme => theme.palette.background.paper
				}}
				variant=""
				onClick={onClick}
				data-testid="actionButton"
				id={id || ''}
			>
				<Typography
					pt={0.2}
					sx={{
						color: disabled
							? theme => theme.palette.text.gray03
							: theme => theme.palette.text.secondary
					}}
					variant="subtitle2"
					pr={0}
				>
					{title}
				</Typography>
			</Button>
		</Tooltip>
	);
}

export default BasicButton;
