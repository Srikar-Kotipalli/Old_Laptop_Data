/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
import Icon from '../index';

const imageUrl =
	'https://images.unsplash.com/photo-1531436107035-40b2e85b7a1b?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;w=1000&amp;q=80';

describe('icon', () => {
	test('renders icon', () => {
		render(<Icon alt="icon" />);
		const element = screen.getByAltText('icon');
		expect(element).toBeInTheDocument();
	});
	test('renders image in icon', () => {
		render(<Icon src={imageUrl} alt="icon" />);
		const element = screen.getByAltText('icon');
		expect(element).toHaveAttribute('src', imageUrl);
	});
	test('the click event is working on clicking icon', () => {
		const clickHandler = jest.fn();
		render(<Icon clickHandler={clickHandler} />);
		const button = screen.getByRole('button');
		fireEvent.click(button);
		expect(clickHandler).toBeCalledTimes(1);
	});
});
