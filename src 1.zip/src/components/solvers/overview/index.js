import React, { useEffect, useState } from 'react';
import { Box, Stack, Typography } from '@mui/material';
import { styled } from '@mui/material/styles';
import LinearProgress, { linearProgressClasses } from '@mui/material/LinearProgress';
import Icon from '../../icon';
import costDownIcon from '../../../assets/costDownIcon.svg';
import AreaChart from '../../chart/areaChart';
import PieChart from '../../chart/pieChart';

const UsageChartData = {
	data: [10, 2, 18, 15, 13, 38, 35, 75, 33, 45, 34, 96, 22],
	categories: [
		'2023-07-24T01:41:13Z',
		'2023-07-24T02:41:13Z',
		'2023-07-24T03:41:13Z',
		'2023-07-24T04:41:13Z',
		'2023-07-24T05:41:13Z',
		'2023-07-24T06:41:13Z',
		'2023-07-24T07:41:13Z',
		'2023-07-24T08:41:13Z',
		'2023-07-24T09:41:13Z',
		'2023-07-24T10:41:13Z',
		'2023-07-24T11:41:13Z',
		'2023-07-24T12:41:13Z'
	]
};

const revenueChartData = {
	series: [23, 11, 54, 72],
	labels: ['Request', 'Earning', 'Purchase', 'Other'],
	colors: ['#8B31FF', '#41418D', '#AD7BFF', '#6D7CFF']
};

const BorderLinearProgress = styled(LinearProgress)(() => ({
	height: '2px',
	borderRadius: '8px',
	[`&.${linearProgressClasses.colorPrimary}`]: {
		backgroundColor: '#303067'
	},
	[`& .${linearProgressClasses.bar}`]: {
		borderRadius: 5,
		backgroundColor: '#5552FF'
	}
}));

const BorderLinearProgress1 = styled(LinearProgress)(() => ({
	height: '5px',
	width: '90px',
	borderRadius: '30px',
	[`&.${linearProgressClasses.colorPrimary}`]: {
		backgroundColor: 'transparent'
	},
	[`& .${linearProgressClasses.bar}`]: {
		borderRadius: 5,
		backgroundColor: '#5552FF'
	}
}));

function OverviewTemplate({ heading = 'heading', headingIcon, type }) {
	const [isCost, setIsCost] = useState(false);
	useEffect(() => {
		if (type === 'cost') {
			setIsCost(true);
		}
	});
	return (
		<Box className="utilCtr" padding="26px">
			<Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1 }}>
				<Box className="utilizationHeaderIcon">
					<Icon type="static" src={headingIcon} />
				</Box>
				<Box>
					<Typography className="utilzationLabel" color="#ffffff">
						{heading}{' '}
					</Typography>
				</Box>
			</Stack>
			{isCost ? (
				<>
					<Box sx={{ my: 3 }}>
						<Stack direction="row" spacing={1}>
							<Box>
								<Typography className="costTitle-1">$55,785</Typography>
								<BorderLinearProgress variant="determinate" value={50} sx={{ mt: 2 }} />
							</Box>
							<Box>
								<Stack direction="row" spacing={1}>
									<Box>
										<Icon type="static" src={costDownIcon} />
									</Box>
									<Box>
										<Typography className="costTitle-2">-22%</Typography>
									</Box>
								</Stack>
							</Box>
						</Stack>
					</Box>
					<Box>
						<Typography sx={{ color: '#CBCBD7', fontSize: '12px', lineHeight: '16px', mb: 2 }}>
							Project
						</Typography>
						<Stack direction="row" spacing={2} alignItems="center">
							<Typography className="pbarHead" sx={{ width: '70px' }}>
								Budget
							</Typography>
							<Box>
								<BorderLinearProgress1 variant="determinate" value={80} />
							</Box>
							<Typography>$134,200</Typography>
						</Stack>
						<Stack direction="row" spacing={2} alignItems="center" sx={{ my: 2 }}>
							<Typography className="pbarHead" sx={{ width: '70px' }}>
								Cost
							</Typography>
							<Box>
								<BorderLinearProgress1 variant="determinate" value={40} />
							</Box>
							<Typography>$134,200</Typography>
						</Stack>
					</Box>
				</>
			) : (
				<Box>
					{type === 'utlization' ? (
						<AreaChart UsageChartData={UsageChartData} height={190} />
					) : (
						<PieChart revenueChartData={revenueChartData} height={190} />
					)}
				</Box>
			)}
		</Box>
	);
}

export default OverviewTemplate;
