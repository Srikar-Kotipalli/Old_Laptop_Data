/* eslint-disable no-unused-vars */
import { Box, Grid, Stack, Typography } from '@mui/material';
import React from 'react';
import IONQLOGO from '../../../../assets/IONQBIGLogo.svg';
import solverArrowRightIcon from '../../../../assets/solverArrowRightIcon.svg';
import modelBuilderIcon from '../../../../assets/modelBuilderIcon.svg';
import infoCircleIcon from '../../../../assets/infoCircleIcon.svg';
import Icon from '../../../icon';
import './style.css';
import SettingsCopyButton from '../../../copyButton/settings';
import copyIcon from '../../../../assets/copyIcon.svg';
import tickIcon from '../../../../assets/checkmarks/checkmark.svg';

function RecentSolversList({ solverInfo, solversCardClick }) {
	return (
		<Box className="resolveList">
			<Grid container spacing={2}>
				<Grid item xs={9}>
					<Icon type="static" src={IONQLOGO} />
				</Grid>
				<Grid item xs={3} sx={{ display: 'grid', placeItems: 'end', paddingRight: '10px' }}>
					<Box
						sx={{ height: '24px', width: '24px', borderRadius: '8px', backgroundColor: '#1C1C46' }}
					>
						<Icon
							src={solverArrowRightIcon}
							padding="6px"
							height="12px"
							width="12px"
							clickHandler={e => solversCardClick(solverInfo?.name, solverInfo?.solverId)}
						/>
					</Box>
				</Grid>
			</Grid>
			<Stack direction="row" spacing={1.5} alignItems="center" sx={{ my: 2 }}>
				<Icon type="static" src={modelBuilderIcon} />
				<Typography>{solverInfo?.name}</Typography>
				<Box
					sx={{
						width: '7px',
						height: '7px',
						background: '#55D899',
						borderRadius: '50%'
					}}
				/>
			</Stack>
			<Grid container spacing={2} alignItems="center">
				<Grid item xs={7}>
					<Stack direction="row" spacing={1}>
						<Typography className="copyTextResolve copyTextResolveText">
							{solverInfo?.token}
						</Typography>
						<Box className="copynewIcon">
							<SettingsCopyButton
								content="715515b0-d"
								copyIcon={copyIcon}
								copiedIcon={tickIcon}
								title="Copy"
							/>
						</Box>
					</Stack>
				</Grid>
				<Grid item xs={5}>
					<Box sx={{ display: 'grid', placeItems: 'end' }}>
						<Stack
							direction="row"
							spacing={1}
							alignItems="center"
							justifyContent="center"
							sx={{ paddingRight: '10px' }}
						>
							<Typography className="copyTextResolveText">{`$${solverInfo?.price} per ${solverInfo?.per}`}</Typography>
							<Box>
								<Icon src={infoCircleIcon} height="12px" width="12px" />
							</Box>
						</Stack>
					</Box>
				</Grid>
			</Grid>
		</Box>
	);
}

export default RecentSolversList;
