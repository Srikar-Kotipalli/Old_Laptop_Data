/* eslint-disable max-len */
import * as React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import { Grid } from '@mui/material';
import Icon from '../../icon';
import closeIcon from '../../../assets/actions/close.svg';

// eslint-disable-next-line import/no-unused-modules
export default function TCPopupMenu({ open, setOpen }) {
	const [openDialogBox, setOpenDialogBox] = React.useState(open);
	const handleClose = () => setOpen(false);

	React.useEffect(() => {
		setOpenDialogBox(open);
	}, [open]);

	return (
		<Modal
			open={openDialogBox}
			aria-labelledby="modal-modal-title"
			aria-describedby="modal-modal-description"
			data-testid="dialogBox"
			sx={{
				backdropFilter: 'blur(1px)'
				// other styles here
			}}
		>
			<div>
				<Box
					sx={{
						position: 'absolute',
						top: '48%',
						left: '50%',
						transform: 'translate(-50%, -50%)',
						minWidth: 850,
						minHeight: 630,
						'@media (max-width: 800px)': {
							minWidth: '90%',
							maxWidth: '90%',
							top: '50%',
							left: '50%',
							minHeight: '83vh',
							maxHeight: '83vh'
						},
						bgcolor: 'background.paper',
						border: '1px solid #6473FF',
						borderRadius: '24px',
						boxShadow: 24,
						p: 2
					}}
				>
					<Grid sx={{ display: 'flex', justifyContent: 'space-between' }}>
						<Grid sx={{ display: 'flex' }}>
							{/* <Icon src={icon} type="static" alt="arrowRightAltIcon" padding="0px 3px 6px 3.5px" /> */}
							<Typography
								sx={{
									paddingBottom: '5px',
									paddingLeft: '18rem',
									fontWeight: 'bold',
									'@media (max-width: 780px)': {
										paddingLeft: '0rem'
									}
								}}
								color="textPrimary"
								variant="subtitle2"
								data-testid="messageTitle"
							>
								COVALENT CLOUD TERMS OF SERVICE
							</Typography>
						</Grid>
						<Grid>
							<Icon
								src={closeIcon}
								type="pointer"
								alt="arrowRightAltIcon"
								clickHandler={handleClose}
							/>
						</Grid>
					</Grid>
					<Box
						sx={{
							mt: 3,
							height: 560,
							'@media (max-width: 800px)': {
								height: '70vh'
							},
							display: 'flex',
							flexDirection: 'column',
							overflow: 'auto'
							// overflowY: "scroll",
						}}
					>
						<Box sx={{ mr: '1rem', ml: '0.3rem' }}>
							<Typography
								sx={{
									paddingBottom: '5px',

									paddingTop: '3px'
								}}
								color="textPrimary"
								variant="subtitle2"
								data-testid="messageTitle"
							>
								Last updated: June 23, 2023
							</Typography>
							<Typography color="textPrimary" variant="subtitle2">
								This Covalent Cloud Terms of Service (“<b>Terms of Service</b>”) governs Customer’s
								access to and use of the Services, including the Covalent Cloud Services that are
								provided by Agnostiq. These Terms of Service together with any Addenda, Order Forms
								and other Documentation, guidelines, or policies Agnostiq may provide in writing
								(collectively the “<b>Agreement</b>”) form a binding legal agreement between
								Agnostiq Inc. (“<b>Agnostiq</b>”) and the Customer visiting, browsing, accessing,
								downloading, installing or otherwise using (the terms “<b>use</b>” and “<b>using</b>
								” will refer to any of the foregoing) the Services. The term “<b>Customer</b>”
								refers to the organization agreeing to this Agreement. This Agreement is entered
								into on the earlier of the date Customer first uses any part of the Services and the
								date Customer agrees to be bound by this Agreement (the “<b>Effective Date</b>”).
								Each of Agnostiq and Customer will individually be referred to as a “<b>Party</b>”
								and jointly as the “<b>Parties</b>”. For purposes of this Agreement, Customer
								Property as defined in Section 2(a) below includes any Customer IP; and Agnostiq
								Property as defined in Section 2(c), includes Covalent Materials.
							</Typography>
							<Typography
								color="textPrimary"
								sx={{ fontSize: '0.875rem', fontWeight: 'bold' }}
								mt={2}
							>
								BY USING THE SERVICES, CUSTOMER ACKNOWLEDGES THAT IT HAS READ, ACCEPTS AND AGREES TO
								BE BOUND BY AND COMPLY WITH THE TERMS AND CONDITIONS SET OUT IN THIS AGREEMENT, AS
								AMENDED FROM TIME TO TIME IN ACCORDANCE WITH SECTION 12(n). IF CUSTOMER DOES NOT
								ACCEPT AND AGREE TO BE BOUND BY THIS AGREEMENT, CUSTOMER WILL IMMEDIATELY CEASE ANY
								FURTHER USE OF THE SERVICES. BY USING THE SERVICES, CUSTOMER REPRESENTS AND WARRANTS
								TO AGNOSTIQ THAT CUSTOMER HAS THE CAPACITY TO ENTER INTO THIS LEGALLY BINDING
								AGREEMENT. IF CUSTOMER IS USING THE SERVICES ON BEHALF OF ANOTHER PERSON, CUSTOMER
								HEREBY REPRESENTS AND WARRANTS TO AGNOSTIQ THAT CUSTOMER HAS THE AUTHORITY TO BIND
								SUCH PERSON TO THIS AGREEMENT.
							</Typography>
							<Typography
								color="textPrimary"
								sx={{ fontSize: '0.875rem', fontWeight: 'bold' }}
								mt={2}
							>
								THE SERVICES MAY NOT BE ACCESSED FOR PURPOSES OF MONITORING THEIR AVAILABILITY,
								PERFORMANCE OR FUNCTIONALITY, OR FOR ANY OTHER BENCHMARKING OR COMPETITIVE PURPOSES.
							</Typography>
							<Typography
								color="textPrimary"
								sx={{ fontSize: '0.875rem', fontWeight: 'bold' }}
								mt={2}
							>
								AGNOSTIQ’S DIRECT COMPETITORS ARE PROHIBITED FROM ACCESSING ANY SERVICES, EXCEPT
								WITH AGNOSTIQ’S PRIOR WRITTEN CONSENT.
							</Typography>
							<ul style={{ marginTop: '4px' }}>
								<li id="list1">
									<b>1. Covalent Cloud Services</b>
									<ol id="list2" type="a">
										<li>
											<u>Provisioning of the Covalent Cloud Services.</u> Subject to any limitations
											set forth in this Agreement, Customer may permit its End Customers to access
											or use the: (A) web services described in the applicable Order Forms or
											applicable Addenda (collectively the “Covalent Cloud Services”); and (B)
											Covalent Materials (pursuant to the License in Section 2(e)), provided that in
											both instances such access and use is solely for the purpose of enabling such
											End Customers to use and modify a Customer Application. Agnostiq grants to
											Customer a limited, revocable, non-exclusive, non- sublicensable (except as
											permitted herein to Permitted Users), non-transferable right during the
											applicable Subscription Term to allow its Permitted Users to access and use
											the Covalent Cloud Services in accordance with the Documentation.
										</li>
										<li>
											<u>Use of the Covalent Cloud API.</u>
											<ol id="list2" type="i">
												<li>
													Agnostiq may make available to Customer the Covalent Cloud API in order to
													facilitate Customer’s access to and use of the Covalent Cloud Services. To
													use the Covalent Cloud API, Customer must first sign up with Agnostiq and
													receive an API key from Agnostiq (each, an “API Key”). Customer
													acknowledges that such API Keys are Agnostiq’s Confidential Information
													(as defined below) and will not share Customer’s API Keys with any third
													party without Agnostiq’s prior consent. In addition, Agnostiq may, in its
													sole discretion, change, cancel, or discontinue the API Key at any time,
													without Customer’s consent.
												</li>
												<li>
													Customer may incorporate the Covalent Cloud API into the Customer
													Application and otherwise use the Covalent Cloud API in connection with
													its internal business purposes, provided such incorporation and use is
													done in accordance and in compliance with this Agreement and the related
													Documentation.
												</li>
												<li>
													Unless otherwise set out in an Order Form, the number of calls Customer
													makes to the Covalent Cloud API during any given period may be limited, at
													Agnostiq’s sole discretion, based on various factors that include the
													manner in which Customer makes calls to the Covalent Cloud API and the
													anticipated volume of use associated with Customer.
												</li>
												<li>
													Agnostiq reserves the right to change the Covalent Cloud API and related
													Documentation at any time and without notice. Customer acknowledges and
													understands that these changes may require Customer to make changes to
													Customer Applications at Customer’s own cost and expense.
												</li>
												<li>
													Notwithstanding the foregoing, Agnostiq retains the right, at Agnostiq’s
													sole discretion, to suspend or revoke Customer’s access to the Covalent
													Cloud API, at any time and for any reason, including for: (A) violation of
													the terms of this Agreement, the responsible use guidelines or any other
													responsible use guidelines Agnostiq provides to Customer or are posted on
													the Website; (B) Customer’s use of the Covalent Cloud API contrary to the
													related Documentation; (C) for scheduled maintenance; or (D) to address
													any emergency security concerns.
												</li>
											</ol>
										</li>
										<li>
											<u>Monitoring Usage of Covalent Cloud API.</u>
											<ol id="list2" type="i">
												<li>
													Agnostiq may monitor Customer’s use of the Covalent Cloud API and that
													Customer will not block or otherwise interfere with Agnostiq’s monitoring.
												</li>
												<li>
													At Agnostiq’s request, Customer will provide Agnostiq access to, and use
													of, the Customer Application, at no cost to Agnostiq, for the purpose of
													monitoring or reviewing Customer Application for compliance with this
													Agreement.
												</li>
											</ol>
										</li>
										<li>
											<u>Restrictions on Use.</u> Customer will not, and will not permit any other
											person (including any Permitted Users) to, access or use the Services except
											as expressly permitted by this Agreement. Without limiting the generality of
											the foregoing, Customer will not itself, and will not permit others (including
											any Permitted Users) to:
											<ol id="list2" type="i">
												<li>
													sub-license (except as permitted herein to Permitted Users), sell, rent,
													lend, lease or distribute the Covalent Cloud Services, any other Agnostiq
													Property or any Intellectual Property Rights therein, or otherwise make
													the Covalent Cloud Services available to others;
												</li>
												<li>
													permit any third party direct access the Covalent Cloud Services, or
													otherwise use, copy, distribute, or make available the Covalent Cloud
													Services to permit timesharing, service bureau use or commercially exploit
													the Covalent Cloud Services;
												</li>
												<li>
													use or access the Covalent Cloud Services or any other Agnostiq Property:
													(A) in violation of any applicable law or Intellectual Property Right, (B)
													in a manner that threatens the security or functionality of the Covalent
													Cloud Services; (C) for any High Risk Activities; (D) for engaging in any
													regulated profession, trade or services including providing any legal
													advice, financial advice or medical advice; or (E) for any purpose or in
													any manner not expressly permitted in this Agreement;
												</li>
												<li>
													circumvent the intended features, functionality or limitations of the
													Covalent Cloud Services;
												</li>
												<li>
													use the Covalent Cloud Services or any other Agnostiq Property for
													personal, family or household purposes;
												</li>
												<li>buy, sell, or transfer API Keys without Agnostiq’s prior consent;</li>
												<li>
													use the Covalent Cloud Services in a manner which, in the opinion of
													Agnostiq bring Agnostiq (or its affiliates’, successors’ or assignees’)
													name, logo, brand or trademarks into public disrepute, contempt, scandal
													or ridicule, would adversely affect the reputation or goodwill of Agnostiq
													or any of its the trademarks, or adversely affect the relationship between
													Agnostiq and any of its licensors or other customers;
												</li>
												<li>
													use the Services to create, collect, transmit, store, use or Process any
													Customer Input:
													<ol id="list2" type="A">
														<li>
															that contains any computer viruses, worms, malicious code, or any
															software intended to damage or alter a computer system or data;
														</li>
														<li>
															that Customer does not have the lawful right to create, collect,
															transmit, store, use or Process;
														</li>
														<li>
															that violates any applicable laws, or infringes, violates or otherwise
															misappropriates the intellectual property or other rights of any third
															party (including any moral right, privacy right or right of
															publicity);
														</li>
													</ol>
												</li>
												<li>
													Modify, reverse engineer, de-compile, disassemble or otherwise attempt to
													discover the source code or underlying components of algorithms and
													systems of the Covalent Cloud Services (or any other Agnostiq Property)
													except to the extent such restrictions are contrary to applicable law);
												</li>
												<li>
													remove or obscure any proprietary notices or labels on the Covalent Cloud
													Services, or any other Agnostiq Property including brand, copyright,
													trademark and patent or patent pending notices;
												</li>
												<li>
													access or use the Covalent Cloud Services or any other Agnostiq Property
													that Customer receives through or from the Covalent Cloud Services for the
													purpose of building a similar or competitive product or service; or
												</li>
												<li>
													perform any vulnerability, penetration or similar testing of the Covalent
													Cloud Services without the prior written consent of Agnostiq.
												</li>
											</ol>
										</li>
										<li>
											<u>Suspension of Access; Scheduled Downtime; Modifications.</u> Agnostiq may
											from time to time and in its discretion, without limiting any of its other
											rights or remedies at law or in equity, under this Agreement:
											<ol id="list2" type="i">
												<li>
													suspend Customer’s access to or use of the Services:
													<ol id="list2" type="A">
														<li>for scheduled maintenance;</li>
														<li>due to a Force Majeure;</li>
														<li>
															if Customer is delinquent in its payment of Fees under Section 7;
														</li>
														<li>
															if Agnostiq believes in good faith that Customer or any Permitted User
															has violated any provision of this Agreement;
														</li>
														<li>to address any emergency security concerns; or</li>
														<li>
															if required to do so by a regulatory body or as a result of a change
															in applicable law; and
														</li>
													</ol>
												</li>
												<li>
													make any Modifications to the Services. Customer acknowledges and
													understands that these changes may require Customer to make changes to any
													Customer Applications, at Customer’s own cost and expense.
												</li>
											</ol>
										</li>
										<li>
											<u>Subcontracting.</u> Agnostiq may engage third parties, including cloud
											service providers and quantum hardware providers, to provide the Services
											without Customer’s consent and without prior notice to Customer.
										</li>
										<li>
											<u>Third Party Services.</u> The Services may contain or require the use of
											third party technology that is licensed under separate license terms, and not
											under this Agreement or other third party products that are owned by third
											parties (collectively “Third Party Services”). Customer is responsible for
											separately obtaining or licensing such technology. Customer will accept and
											comply with the license terms applicable to Third Party Services. If Customer
											does not agree to abide by the applicable license terms for any such Third
											Party Services, then Customer should not install, access, or use such Third
											Party Services. Any acquisition by Customer of such Third Party Services, and
											any exchange of data between Customer and any such provider of Third Party
											Services is solely between Customer and the applicable Third Party Services
											provider. Agnostiq does not warrant or support Third Party Services or other
											third party products, offerings or services, whether or not they are
											designated by Agnostiq as “certified” or otherwise. Agnostiq cannot guarantee
											the continued availability of such Third Party Services features and may cease
											providing them without entitling Customer to any refund, credit, or other
											compensation, if for example and without limitation, the provider of a Third
											Party Services ceases to make the Third Party Services available for
											interoperation or otherwise in connection with the corresponding service
											features in a manner acceptable to Agnostiq. Agnostiq is not responsible for
											any disclosure, Modification or deletion of Customer Data resulting from
											access by such Third Party Services or its provider.
										</li>
										<li>
											<u>Free Trials.</u> If Customer receives access to the Covalent Cloud Services
											on a free, beta or trial basis (“Free Trial”), its use of the Services in
											connection with the Free Trial, and Customer’s use of any Covalent Cloud
											Services including any content created in connection with such Free Trial, is
											permitted only for Customer’s internal evaluation during the period designated
											by Agnostiq. Customer will comply with all terms related to any Free Trial as
											posted on Agnostiq’s website, or otherwise made available to Customer.
											Agnostiq may add or modify terms, including lowering or raising any usage
											limits, related to access to or use of any Free Trial at any time. Support
											Services or service levels do not apply to Free Trial unless otherwise agreed
											to by Agnostiq in writing. Agnostiq may suspend or terminate Customer’s access
											to or use of any Free Trial at any time. Customer agrees that Agnostiq will
											not be liable to Customer or any third party for such termination.
											NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS AGREEMENT, AFTER SUSPENSION
											OR TERMINATION OF CUSTOMER’S ACCESS TO OR USE OF ANY FREE TRIAL FOR ANY
											REASON: (A) CUSTOMER WILL NOT HAVE ANY FURTHER RIGHT TO ACCESS OR USE THE
											APPLICABLE FREE TRIAL; AND (B) CUSTOMER INPUT USED IN THE APPLICABLE FREE
											TRAIL MAY BE DELETED OR INACCESSIBLE. NOTWITHSTANDING THE “WARRANTIES;
											DISCLAIMERS; INDEMNITY” SECTION AND “AGNOSTIQ INDEMNITIES” SECTION BELOW, THE
											FREE TRIAL IS PROVIDED “AS-IS” WITHOUT ANY WARRANTY AND AGNOSTIQ WILL HAVE NO
											INDEMNIFICATION OBLIGATIONS NOR LIABILITY OF ANY TYPE WITH RESPECT TO THE FREE
											TRIAL UNLESS SUCH EXCLUSION OF LIABILITY IS NOT ENFORCEABLE UNDER APPLICABLE
											LAW IN WHICH CASE AGNOSTIQ’S LIABILITY WITH RESPECT TO THE FREE TRIAL WILL NOT
											EXCEED $100.00. WITHOUT LIMITING THE FOREGOING, AGNOSTIQ AND ITS AFFILIATES
											AND ITS LICENSORS DO NOT REPRESENT OR WARRANT TO CUSTOMER THAT: (I) CUSTOMER’S
											USE OF THE FREE TRIAL WILL MEET CUSTOMER’S REQUIREMENTS; (II) CUSTOMER’S USE
											OF THE FREE TRIAL WILL BE UNINTERRUPTED, TIMELY, SECURE OR FREE FROM ERROR;
											AND (III) DATA OR ANY COVALENT MATERIALS PROVIDED THROUGH THE FREE TRIAL WILL
											BE ACCURATE. NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THE “LIMITATION OF
											LIABILITY” SECTION BELOW, CUSTOMER WILL BE FULLY LIABLE UNDER THIS AGREEMENT
											TO AGNOSTIQ AND ITS AFFILIATES FOR ANY DAMAGES ARISING OUT OF CUSTOMER’S USE
											OF THE FREE TRIAL, ANY BREACH BY CUSTOMER OF THIS AGREEMENT AND ANY OF
											CUSTOMER’S INDEMNIFICATION OBLIGATIONS HEREUNDER.
										</li>
										<li>
											<u>Professional Services.</u> Customer and Agnostiq may enter into Order Forms
											that describe the specific Professional Services to be performed by Agnostiq.
										</li>
									</ol>
								</li>
								<li id="list1">
									<b>2. Ownership; Reservation of Rights</b>
									<ol id="list2" type="a">
										<li>
											<u>Customer IP.</u> During the Term, Customer may provide its input to the
											Covalent Cloud Services such as Customer Data, source code, or other content
											(“<b>Customer Input</b>”) and receive output generated and returned by the
											Covalent Cloud Services which is a processed form of or derived from the
											Customer Input (“<b>Customer Output</b>”) (Customer Input and Customer Output
											are collectively “<b>Customer IP</b>”). As between the Parties and to the
											extent permitted by applicable law, Customer will own all Customer IP.
											Customer grants to Agnostiq: (i) a nonexclusive, worldwide, royalty-free,
											irrevocable, transferable sublicensable, and fully paid-up licence during the
											Term to access, collect, use, Process, store, disclose, transmit, transfer,
											copy, Modify and display Customer IP solely to provide the Services.
										</li>
										<li>
											<u>Customer Application.</u> Customer hereby grants Agnostiq a worldwide,
											limited, non-exclusive right to access, distribute, and use the Customer
											Application solely as necessary to certify compatibility of such Customer
											Application with the Covalent Cloud Services. Upon such certification,
											Agnostiq may permit Customer to make the Customer Application available to End
											Customers via Agnostiq’s marketplace in accordance with and subject to
											Angostiq’s applicable marketplace terms and conditions. Please get in touch
											with Agnostiq at contact@agnostiq.ai for a copy of these marketplace terms and
											conditions.
										</li>
										<li>
											<u>Agnostiq Property.</u> Agnostiq or its licensors retain all ownership and
											Intellectual Property Rights in and to: (i) the Services; (ii) Documentation;
											(iii) Covalent Materials; (iv) Covalent Metadata; and (v) anything developed
											or delivered by or on behalf of Agnostiq in accordance with the terms of this
											Agreement including Deliverables; and (v) any Modifications to the foregoing
											(collectively, the “<b>Agnostiq Property</b>”). All rights not expressly
											granted by Agnostiq to Customer under this Agreement are reserved.
										</li>
										<li>
											<u>Covalent Metadata.</u> Customer acknowledges and agrees that Agnostiq may
											develop or generate metadata that is based on a Customer’s use of the Services
											(“<b>Covalent Metadata</b>”). The Covalent Metadata will not include any
											Customer Input. Agnostiq may use, Process, store, disclose and transmit the
											Covalent Metadata for any purpose and without restriction or obligation to
											Customer of any kind.
										</li>
										<li>
											<u>License.</u> Subject to the terms of this License and this Agreement,
											Agnostiq grants Customer a limited, royalty-free, revocable, non-exclusive,
											non-sublicensable (except as permitted herein to Permitted Users),
											non-transferrable license to copy and use the Covalent Materials, and the
											Intellectual Property Rights therein, solely in connection with Customer’s
											permitted use of the Services during the Subscription Term and to permit End
											Customers to access or use the Covalent Materials solely for the purpose of
											enabling such End Customers to use and modify a Customer Application (“
											<b>License</b>”). Except as expressly provided in this Section 2(e), Customer
											obtains no other rights under this Agreement or this License from Agnostiq,
											its affiliates or suppliers to the Services and Covalent Materials, including
											any related Intellectual Property Rights. Some Covalent Materials may be
											provided to Customer under a separate license, such as the Apache License,
											Version 2.0. In the event of a conflict between the License and any separate
											license, the separate license will prevail with respect to that portion of the
											Covalent Materials that is the subject to such separate license.
										</li>
										<li>
											<u>Feedback.</u> Customer grants to Agnostiq and its affiliates a worldwide,
											perpetual, irrevocable, royalty-free license to use and incorporate into the
											Services, any suggestion, enhancement request, recommendation, correction or
											other feedback provided by Customer or Permitted Users relating to the
											operation of Services or any of Agnostiq’s affiliates’ services (“
											<b>Feedback</b>”). Nothing in this Agreement will restrict our right to use,
											profit from, disclose, publish or otherwise exploit any Feedback, without
											compensation to the Customer or Permitted Users and without any obligation to
											the Customer or any Permitted User. Agnostiq is not obligated to use any
											Feedback.
										</li>
									</ol>
								</li>
								<li id="list1">
									<b>3. Privacy</b>
									<ol id="list2" type="a">
										<li>
											<u>Agnostiq Privacy Policy.</u> Customer understands that Personal
											Information, including the Personal Information of Permitted Users, will be
											treated in accordance with Agnostiq’s privacy policy located at
											https://www.covalent.xyz/privacy-policy/ (the “<b>Privacy Policy</b>”).
											Agnostiq may, without Customer consent, revise its Privacy Policy from time to
											time, as is customary business practice in its field (e.g., to incorporate
											improvements in its solutions offerings or align its practices with changing
											regulatory requirements).
										</li>
										<li>
											<u>Compliance with Privacy Law.</u> Each Party will comply with the
											obligations imposed on it under all applicable Privacy Law applicable to a
											Party.
										</li>
										<li>
											<u>Customer Application.</u> If Customer wishes to use the Covalent Cloud
											Services for it or Agnostiq to Process Personal Information other than Account
											Information, Customer will obtain Agnostiq’s prior written consent and
											Customer will agree to such additional agreements or Documentation as may be
											required by Agnostiq, in its sole discretion, in respect of such Processing of
											Personal Information. Customer is solely responsible for access, collection or
											transmission of any Personal Information on or via the Customer Application.
											Customer will be responsible for obtaining Permitted Users’ consent for any
											other use, including for marketing purposes, of End Customer contact
											information or Permitted User’s Personal Information obtained from Agnostiq,
											and Agnostiq will not be responsible or liable for such other use.
										</li>
									</ol>
								</li>
								<li id="list1">
									<b>4. Communications Over the Internet and Public Networks</b>
									<p
										style={{
											marginLeft: '30px'
										}}
									>
										Given the inherent nature of the internet and public networks, and without
										limiting the Privacy Policy referenced herein, Agnostiq does not, and cannot,
										guarantee the security of data transmitted or the confidentiality of any
										communications made by Customer or any Permitted User over the Internet or
										public networks in connection with Customer’s use of the Covalent Cloud
										Services.
									</p>
								</li>
								<li id="list1">
									<b>5. User Accounts; Customer Responsibilities</b>
									<ol id="list2" type="a">
										<li>
											<u>User Accounts.</u> Upon Customer’s request, Agnostiq will issue one or more
											user accounts (each, a “<b>Customer User Account</b>”) for use by Customer and
											all Permitted Users of Customer that Customer wishes to have access to and use
											of the Covalent Cloud Services and Covalent Cloud API.
										</li>
										<li>
											<u>Customer Responsibilities.</u>
											<ol id="list2" type="i">
												<li>
													Customer will permit Agnostiq or its third-party evaluation agents to
													verify whether the Customer Application meets the security, privacy,
													compliance controls, and other requirements provided by Agnostiq
													(“Criteria”) based on the Supporting Evidence provided by Customer to
													Agnostiq. Agnostiq will make commercially reasonable efforts to complete
													the evaluation within a reasonable time.
												</li>
												<li>
													Customer will promptly notify Agnostiq of any actual or suspected
													unauthorized use of the Covalent Cloud Services. Agnostiq reserves the
													right to suspend, deactivate, or replace a Customer User Account if it
													determines that a Customer User Account may have been used for an
													unauthorized purpose;
												</li>
												<li>
													Customer will ensure that Permitted Users only use the Covalent Cloud
													Services through the Customer User Account. Customer will not allow any
													Permitted User to share the Customer User Account with any other person;
													and
												</li>
												<li>
													Customer will solely be responsible for:
													<ol id="list2" type="A">
														<li>
															the accuracy, quality and legality of Customer Input, the means by
															which Customer acquired Customer Input, Customer’s use of Customer
															Input with the Services, and the interoperation of any third party
															products or systems with which Customer uses Services;
														</li>
														<li>
															providing, at its own expense, all network access to the Services,
															including, without limitation, acquiring, installing and maintaining
															all telecommunications equipment, hardware, software and other
															equipment as may be necessary to connect to, access and use the
															Services;
														</li>
														<li>
															properly configuring and using the Services and taking its own steps
															to maintain appropriate security, protection and backup of its
															infrastructure (including without limitation any databases, servers,
															and any other protocol) which may include the use of encryption
															technology to protect such infrastructure from unauthorized access and
															routine archiving of such infrastructure;
														</li>
														<li>
															ensuring that the Customer Application, network, operating systems and
															the software of Customer’s servers, databases, and computer systems
															use reasonable security measures to protect Permitted User (including
															any End Customer) information and ensuring that the Customer
															Application does not jeopardize or compromise user security, the
															security of the Covalent Cloud Services, any related services or
															systems, or any Customer’s systems;
														</li>
														<li>
															ensuring that Customer does not install or launch executable code on
															the user’s environment beyond what is identified in or may reasonably
															be expected or approved by Agnostiq;
														</li>
														<li>
															using the Services in accordance with this Agreement and applicable
															laws;
														</li>
														<li>
															identifying and authenticating all Permitted Users and for ensuring
															only Permitted Users access and use Covalent Cloud Services;
														</li>
														<li>
															ensuring that all Permitted Users (including End Customers) of the
															Covalent Cloud Services are contractually bound to terms and
															conditions with Customer that are consistent with any obligations
															under this Agreement and that are no less restrictive or protective of
															Agnostiq’s rights than those set forth in this Agreement. Without
															limiting the foregoing, any contract terms are between Customer and
															End Customer will not create any obligations or responsibilities of
															any kind for Agnostiq. Customer acknowledges that Agnostiq grants no
															right or license to Customer Applications through the operation of the
															Covalent Cloud Services or any other Agnostiq Property; and
														</li>
														<li>
															ensuring that Permitted Users comply with this Agreement and that none
															of the Permitted Users bring or maintain any Claim against Agnostiq,
															its shareholders, employees, officers, directors, affiliates, agents,
															contractors, successors, and assigns in respect of any matter related
															to or in connection with the subject matter of this Agreement.
															Customer will be liable for any breach by a Permitted User of this
															Agreement.
														</li>
													</ol>
												</li>
											</ol>
										</li>
									</ol>
								</li>
								<li id="list1">
									<b>6. Support</b>
									<p
										style={{
											marginLeft: '30px'
										}}
									>
										Customer will generally have access to Agnostiq’s technical support services in
										relation to the Covalent Cloud Services (“<b>Support Services</b>”) via email at
										contact@agnostiq.ai from 9 a.m. to 5 p.m. (Eastern Time) each Monday to Friday,
										(excluding statutory and civic holidays observed in Toronto, Ontario). Subject
										to Customer’s payment of applicable Fees, Agnostiq may provide premium support
										as part of Support Services, if set forth in an applicable Order Form or
										otherwise agreed to in writing by Agnostiq. For clarity and avoidance of all
										doubt, Agnostiq is not responsible for providing support for Customer
										Applications.
									</p>
								</li>
								<li id="list1">
									<b>7. Fees and Payment</b>
									<ol id="list2" type="a">
										<li>
											<u>Fees.</u> Fees, compute costs associated with applicable Third Party
											Services, or amounts under this Agreement are as outlined in the pricing plan
											or Order Form provided to Customer. Customer will pay to Agnostiq the fees,
											costs for any applicable Third Party Services and other costs charged to
											Customer’s account: (i) according to the prices and terms as set forth on
											Agnostiq’s then-current applicable pricing page as may be amended from time to
											time in Agnostiq’s discretion or agreed to by Customer in any Order Form; or
											(ii) as otherwise disclosed to Customer including via any Third Party Service
											page (collectively the “<b>Fees</b>”). If Customer’s use of the Services
											exceeds the service capacity set forth on the Order Form, or otherwise
											requires the payment of additional fees (per the terms of this Agreement),
											Customer will be billed for such usage and Customer agrees to pay the
											additional fees in the manner provided herein. If Customer requests that
											Agnostiq provide it with services in addition to the Services, Customer will
											be billed for such additional services based on Agnostiq’s standard rates.
										</li>
										<li>
											<u>Payment</u> Customer will provide current, complete and accurate billing
											information including a valid and authorized payment method. Agnostiq may
											charge Customer’s payment method on an agreed-upon periodic basis but may
											reasonably change the date on which the charge is posted. Customer must
											promptly update all information to keep Customer’s billing account current,
											complete and accurate (such as a change in billing address, credit card
											number, or credit card expiration date), and Customer must promptly notify
											Agnostiq if Customer’s payment method is cancelled (e.g., for loss or theft).
											Customer authorizes Agnostiq and its affiliates, and Agnostiq’s third-party
											payment processor(s), to charge Customer’s payment method for the Fees. If
											Customer’s payment cannot be completed, Agnostiq will provide Customer written
											notice and may suspend access to the Services until payment is received.
											Unless otherwise agreed in writing by Agnostiq, Fees are payable in United
											States dollars and are due upon invoice issuance. Payments are non-refundable
											except as provided in this Agreement.
										</li>
										<li>
											<u>Changes to the Fees.</u> Agnostiq reserves the right to change the Fees or
											applicable charges and to institute new charges and Fees upon prior notice to
											Customer (which may be sent by email). If Agnostiq has increased the Fees
											payable by Customer, then Customer may terminate this Agreement in accordance
											with Section 11(b) and notwithstanding Section 11(b)(ii), Customer will not be
											required to pay any termination fee or any Fees that are outstanding in the
											Term
										</li>
										<li>
											<u>Disputed Charges.</u> If Customer believes Agnostiq has charged Customer
											incorrectly, Customer must contact Agnostiq no later than 45 days after having
											been charged by Agnostiq in order to request an adjustment or credit. In the
											event of a dispute, Customer will pay any undisputed amounts in accordance
											with the payment terms herein, and the Parties will discuss the disputed
											amounts in good faith in order to resolve the dispute.
										</li>
										<li>
											<u>Late Payment.</u> Customer may not withhold or setoff any amounts due under
											this Agreement. If Customer fails to make any payment when due, without
											limiting Agnostiq’s other rights and remedies, Agnostiq may: (i) suspend, in
											accordance with Section 1(e), Customer’s and all other Permitted Users’ access
											to any portion or all of the Services until such amounts are paid in full; or
											(ii) terminate this Agreement immediately on notice (which may be sent by
											electronic means to Customer), without incurring any obligation or liability
											to Customer or any other person by reason of such suspension or termination.
										</li>
										<li>
											<u>Taxes.</u> The Fees set out in this Agreement do not include applicable
											sales, use, gross receipts, value-added, GST or HST, personal property or
											other taxes. Customer will be responsible for and will pay all applicable
											taxes, duties, tariffs, assessments, export and import fees or similar charges
											(including interest and penalties imposed thereon) on the transactions
											contemplated in connection with this Agreement, other than taxes based on the
											net income or profits of Agnostiq.
										</li>
										<li>
											<u>Suspension.</u> Any suspension of the Services by Agnostiq pursuant to the
											terms of this Agreement, including suspension of the Services pursuant to
											Section 1(e) or 7(b), will not excuse Customer from its obligation to make
											payments under this Agreement.
										</li>
										<li>
											<u>Payment Processor.</u> Payment and collection of Fees is enabled through
											and executed by a third party payment processors. Transaction fees associated
											with the individual payment and collection of Fees or amounts under this
											Agreement are as outlined in the pricing plan provided to Customer. Customer
											may be required to agree to terms and conditions as required by such third
											party payment processor from time to time. Prior to using the Services and any
											components thereof, Customer must have all applicable such third party payment
											processor’s terms and conditions in effect. By using the Services or any
											component thereof, Customer acknowledges it must be in full compliance with
											the terms and conditions of such third party payment processor and be in good
											standing with such third party payment processor
										</li>
									</ol>
								</li>
								<li id="list1">
									<b>8. Confidential Information</b>
									<ol id="list2" type="a">
										<li>
											<u>Definitions.</u> For the purposes of this Agreement, a Party receiving
											Confidential Information (as defined below) will be the “<b>Recipient</b>”,
											the Party disclosing such information will be the “<b>Discloser</b>” and “
											<b>Confidential Information</b>” of Discloser means any and all information of
											Discloser or any of its licensors that has or will come into the possession or
											knowledge of the Recipient in connection with or as a result of entering into
											this Agreement. Where Discloser is Agnostiq, Confidential Information includes
											any information concerning the business, affairs, operations, properties,
											assets (including, without limitation, technology and intellectual property),
											employees, customers, suppliers contracts, prospects, liabilities, research,
											processes or methods of operation proposed by Agnostiq, its affiliates, and
											the investment that is made available to Customer, as well as any
											reproductions, summaries, analyses or extracts of such information. Where
											Discloser is Customer, Confidential Information includes Customer Property and
											where Discloser is Agnostiq includes all Agnostiq Property. Notwithstanding
											the foregoing, except with respect to Personal Information, Confidential
											Information does not include: (i) information already known to Recipient prior
											to the Effective Date or that subsequently becomes known to Recipient from a
											third party that has no obligation to the Discloser to keep such information
											confidential; (ii) information that is publicly available prior to the
											Effective Date, or that subsequently becomes publicly available through no
											breach of this Agreement or wrongful act of Recipient; (iii) information
											received by Recipient from a third party who was free to disclose it without
											confidentiality obligations; or (iv) information that Recipient can
											demonstrate (through written records) was independently developed by it by
											individuals employed or engaged by Recipient who did not participate in any
											meetings with the Discloser and who developed such without having had any
											access to, or the benefit of, Discloser’s Confidential Information.
										</li>
										<li>
											<u>Confidentiality Covenants.</u> Recipient hereby agrees that during the Term
											and at all times thereafter it will not, except to exercise its rights or
											perform its obligations under this Agreement:
											<ol id="list2" type="i">
												<li>
													disclose Confidential Information of the Discloser:
													<ol id="list2" type="A">
														<li>
															in the case the Customer to any person, except to its Permitted Users
															that have a “need to know” for the purposes of receiving or providing
															the Services and that have entered into written agreements no less
															protective of such Confidential Information than this Agreement; or
														</li>
														<li>
															in the case of Agnostiq to Agnostiq’s employees, independent
															contractors, advisors, consultants, agents and its affiliates, that
															have a “need to know” for the purposes of receiving or providing the
															Services and that have entered into written agreements no less
															protective of such Confidential Information than this Agreement and to
															its subcontractors and contractors to perform the Services or to its
															subcontractors for the purpose of providing the Services;
														</li>
													</ol>
												</li>
												<li>
													use Confidential Information of the Discloser other than to exercise its
													rights or perform its obligations under this Agreement; or
												</li>
												<li>
													alter or remove from any Confidential Information of the Discloser any
													proprietary legend.
												</li>
												<p>
													Each Party will take industry standard precautions to safeguard the other
													Party’s Confidential Information, which will in any event be at least as
													stringent as the precautions that the Recipient takes to protect its own
													Confidential Information of a similar type.
												</p>
											</ol>
										</li>
										<li>
											<u>Exceptions to Confidentiality.</u> Notwithstanding Section 8(b), Recipient
											may disclose Discloser’s Confidential Information: (i) to the extent that such
											disclosure is required by applicable law or by the order of a court or similar
											judicial or administrative body, provided that, except to the extent
											prohibited by law, the Recipient promptly notifies the Discloser in writing of
											such required disclosure and cooperates with the Discloser to seek an
											appropriate protective order; (ii) to its legal counsel and other professional
											advisors if and to the extent such persons need to know such Confidential
											Information in order to provide applicable professional advisory services in
											connection with the Party’s business; or (iii) in the case of Agnostiq, to
											potential assignees, acquirers or successors of Agnostiq if and to the extent
											such persons need to know such Confidential Information in connection with a
											potential sale, merger, amalgamation or other corporate transaction involving
											the business or assets of Agnostiq.
										</li>
										<li>
											<u>Return or Destruction.</u> Upon the termination or expiration of this
											Agreement and all Order Forms under this Agreement, each Party will promptly
											return to the other Party or destroy all Confidential Information (excluding
											any Customer Data which is addressed in Section 11(d) of the other Party in
											its possession or control within a reasonable amount of time in accordance
											with the Recipient’s data destruction practices). Notwithstanding the
											foregoing, Agnostiq may retain any electronically archived Customer’s
											Confidential Information, provided that such retained information remains
											subject to the confidentiality obligations in this Agreement.
										</li>
										<li>
											<u>Injunction and Other Equitable Relief.</u> Each Party acknowledges and
											agrees that a breach or threatened breach by such Party of any of its
											obligations under Section 8 would cause the other Party irreparable harm for
											which monetary damages would not be an adequate remedy and agrees that, in the
											event of such breach or threatened breach, the other Party will be entitled to
											equitable relief, including a restraining order, an injunction, specific
											performance, and any other relief that may be available from any court,
											without any requirement to post a bond or other security, or to prove actual
											damages or that monetary damages are not an adequate remedy.Such remedies are
											not exclusive and are in addition to all other remedies that may be available
											at law, in equity or otherwise.
										</li>
									</ol>
								</li>
								<li id="list1">
									<b>9. Warranty; Disclaimer; Indemnity</b>
									<ol id="list2" type="a">
										<li>
											<u>Customer Warranty.</u> Customer represents and warrants to, and covenants
											with Agnostiq that: (i) Customer Data will only contain Personal Information
											in respect of which Customer has provided all notices and disclosures
											(including to each Permitted User), obtained all applicable third party
											consents and permissions and otherwise has all authority, in each case, as
											required by applicable laws including applicable privacy laws, to enable
											Agnostiq to provide the Services, including with respect to the collection,
											storage, access, use, disclosure, Processing and transmission of Personal
											Information, including by or to Agnostiq and to or from all applicable third
											parties; (ii) Customer will implement reasonable and appropriate measures
											designed to help secure Customer’s and its Permitted Users’ access to and use
											of the Services; (iii) Customer will not use the Covalent Cloud Services for
											personal, family or household purposes; (iv) Customer and its Permitted Users
											will comply with all applicable laws; (v) Customer will not permit any
											Permitted User to access and use the Services from Russia, China, or any
											country: (A) subject to any embargo by the United States or Canada; or (B) on
											the Office of Foreign Assets Control (“<b>OFAC</b>”) of the US Department of
											the Treasury list or on the U.S. Department of Commerce’s Denied Persons List
											or Entity List, or on the U.S. Treasury Department’s list of Specially
											Designated Nationals; and (vi) Customer will comply with Section 12(e).
										</li>
										<li>
											<u>GENERAL DISCLAIMER.</u> AGNOSTIQ DOES NOT WARRANT THAT THE SERVICES WILL BE
											UNINTERRUPTED OR THAT THE SERVICES OR (OR ANY PART THEREOF), WILL BE ERROR
											FREE OR THAT ALL ERRORS CAN OR WILL BE CORRECTED; NOR DOES IT MAKE ANY
											WARRANTY AS TO THE RESULTS THAT MAY BE OBTAINED FROM USE OF THE SERVICES.
											EXCEPT AS SPECIFICALLY PROVIDED IN THIS AGREEMENT, SERVICES (OR ANY PART
											THEREOF), AND ANY OTHER PRODUCTS AND SERVICES PROVIDED BY AGNOSTIQ TO CUSTOMER
											ARE PROVIDED “AS IS” AND “AS AVAILABLE”. ANY REPRESENTATION OR WARRANTY OF OR
											CONCERNING ANY THIRD PARTY PRODUCTS IS STRICTLY BETWEEN CUSTOMER AND THE THIRD
											PARTY. CUSTOMER ACKNOWLEDGES THAT IF CUSTOMER CHOOSES TO SUBMIT ANY CUSTOMER
											INPUT TO THE SERVICES, CUSTOMER DOES SO ENTIRELY AT ITS OWN RISK. TO THE
											EXTENT PERMITTED BY APPLICABLE LAW, AGNOSTIQ HEREBY DISCLAIMS ALL EXPRESS,
											IMPLIED, COLLATERAL OR STATUTORY WARRANTIES, REPRESENTATIONS AND CONDITIONS,
											WHETHER WRITTEN OR ORAL, INCLUDING ANY IMPLIED WARRANTIES OR CONDITIONS OF
											MERCHANTABILITY, MERCHANTABLE QUALITY, COMPATIBILITY, TITLE, NON-INFRINGEMENT,
											SECURITY, RELIABILITY, COMPLETENESS, QUIET ENJOYMENT, ACCURACY, QUALITY,
											INTEGRATION OR FITNESS FOR A PARTICULAR PURPOSE OR USE, OR ANY WARRANTIES OR
											CONDITIONS ARISING OUT OF COURSE OF DEALING OR USAGE OF TRADE. WITHOUT
											LIMITING THE GENERALITY OF ANY OF THE FOREGOING, AGNOSTIQ EXPRESSLY DISCLAIMS
											ANY REPRESENTATION, CONDITION OR WARRANTY THAT ANY COVALENT MATERIALS,
											CUSTOMER IP OR OTHER CONTENT PROVIDED TO CUSTOMER IN CONNECTION WITH
											CUSTOMER’S USE OF SERVICES (OR ANY PART THEREOF) IS ACCURATE, OR CAN OR SHOULD
											BE RELIED UPON BY CUSTOMER FOR ANY PURPOSE WHATSOEVER.
											<p style={{ marginTop: '8px' }}>
												CUSTOMER AND PERMITTED USERS ARE RESPONSIBLE FOR ALL DECISIONS MADE, ADVICE
												GIVEN, ACTIONS TAKEN, AND FAILURES TO TAKE ACTION BASED ON ANY CUSTOMER’S OR
												PERMITTED USERS’ USE OF THE COVALENT CLOUD SERVICES. COVALENT CLOUD SERVICES
												USE ARTIFICIAL INTELLIGENCE AND MACHINE LEARNING MODELS THAT GENERATE
												PREDICTIONS BASED ON PATTERNS IN DATA. CUSTOMER OUTPUT GENERATED BY AN
												ARTIFICIAL INTELLIGENCE OR MACHINE LEARNING MODEL IS PROBABILISTIC AND
												SHOULD BE EVALUATED FOR ACCURACY AS APPROPRIATE FOR CUSTOMER’S OR PERMITTED
												USERS’ USE CASE, INCLUDING BY EMPLOYING HUMAN REVIEW OF SUCH CUSTOMER
												OUTPUT. GIVEN THE PROBABILISTIC NATURE OF ARTIFICIAL INTELLIGENCE AND
												MACHINE LEARNING, USE OF ANY AGNOSTIQ PROPERTY MAY IN SOME SITUATIONS RESULT
												IN INCORRECT CUSTOMER OUTPUT THAT DOES NOT ACCURATELY REFLECT REAL PEOPLE,
												PLACES, OR FACTS. CUSTOMER WILL EVALUATE THE ACCURACY OF ANY CUSTOMER OUTPUT
												AS APPROPRIATE FOR ITS USE CASE, INCLUDING BY USING HUMAN REVIEW OF THE
												CUSTOMER OUTPUT AND CUSTOMER IP. DUE TO THE NATURE OF MACHINE LEARNING,
												CUSTOMER OUTPUT MAY NOT BE UNIQUE ACROSS USERS AND THE SERVICES OR ANY OTHER
												AGNOSTIQ PROPERTY MAY GENERATE THE SAME OR SIMILAR CUSTOMER OUTPUT FOR
												AGNOSTIQ OR A THIRD PARTY. OTHER CUSTOMERS MAY ALSO ASK SIMILAR QUESTIONS
												AND RECEIVE THE SAME RESPONSE. RESPONSES THAT ARE REQUESTED BY AND GENERATED
												FOR OTHER USERS ARE NOT CONSIDERED CUSTOMER IP. WITHOUT LIMITING THE
												FOREGOING, CUSTOMER IS RESPONSIBLE FOR IMPLEMENTING SAFEGUARDS TO PROTECT
												THE SECURITY AND INTEGRITY OF ITS AND PERMITTED USERS’ COMPUTER SYSTEM AND
												NAY CUSTOMER PROPERTY. AGNOSTIQ DOES NOT GUARANTEE OR WARRANT THAT ANY
												COMPONENT OF SERVICES OR ANY OTHER AGNOSTIQ PROPERTY IS COMPATIBLE WITH
												CUSTOMER’S COMPUTER SYSTEM OR THAT THE SERVICES OR ANY LINKS FROM ANY
												COMPONENT OF THE SERVICES, WILL BE FREE OF DISABLING DEVICES. AGNOSTIQ
												RESERVES THE RIGHT, BUT HAS NO OBLIGATION, TO MONITOR OR TO TAKE ANY ACTION
												REGARDING DISPUTES BETWEEN CUSTOMER AND ANY OTHER USER AND WILL HAVE NO
												LIABILITY FOR CUSTOMER’S OR ITS PERMITTED USERS’ INTERACTIONS OR ANY
												DISPUTES WITH OTHER USERS OR FOR ANY USER’S ACTION OR INACTION. CUSTOMER IS
												SOLELY RESPONSIBLE FOR ITS CONDUCT ON THE SERVICES AND ITS (OR ITS PERMITTED
												USERS) INTERACTIONS WITH OTHER USERS.
											</p>
										</li>
										<li>
											<u>Customer Indemnity.</u> Customer will defend, indemnify and hold harmless
											Agnostiq, its employees, officers, directors, affiliates, agents, contractors,
											successors, and assigns against any and all Losses directly or indirectly
											arising from or in connection with any Claim from a third party: (i) regarding
											Customer Property; (ii) alleging Customer’s breach of Section 1(d), Section
											3(b), Section 3(c), Section 5(b), Section 9(a) or Section 12(e); (iii) arising
											from Customer’s and Permitted Users’ unauthorised use of the Services; (iv)
											arising from Customer’s breach or violation of applicable law; (v) alleging
											that a Customer Application or any other Customer Property infringes any
											proprietary or personal right of a third party; (vii) relating to the
											functionality of, the use of, or the inability to use the Customer
											Application, including any claims of product liability or misleading
											advertising related to the Customer Application or any other Customer
											Property; or (viii) use of the Services (or any part thereof) by Customer or
											any Permitted User in combination or integration with any third party
											software, Customer Application or service. Customer will fully cooperate with
											Agnostiq in the defense of any claim defended by Customer pursuant to its
											indemnification obligations under this Agreement and will not settle any such
											claim without the prior written consent of Agnostiq.
										</li>
										<li>
											<u>Agnostiq Indemnity.</u> Agnostiq will defend, indemnify and hold harmless
											Customer, its employees, officers, directors, affiliates, agents, contractors,
											successors, and assigns against any and all Losses directly or indirectly
											arising from or in connection with any Claim from a third party finally
											awarded by a court of competent jurisdiction that the access to or use by the
											Customer or any Permitted User of the Covalent Cloud Services as permitted
											pursuant to this Agreement, infringes, violates or misappropriates any
											Intellectual Property Right of such third party in Canada and United States.
											The obligations of Agnostiq in this Section 9(d) will not apply to the extent
											that the Claim by the third party is: (A) based on the unauthorized use by the
											Customer (or any Permitted User) of Covalent Cloud Services or any Agnostiq
											Property by Customer or any Permitted User; (B) the based on Customer’s
											indemnities in Section 9(c); (B); (C) based on Modifications to the Covalent
											Cloud Services or any Agnostiq Property made by a party other than Agnostiq;
											or (D) based on Customer’s (or any Permitted User) use of the Covalent Cloud
											Services, the Services, Agnostiq Property (or any part thereof) in combination
											or integration with any third party software, application or service, if such
											Claim would not have arisen but for such combination or integration. THIS
											SECTION 9(d) REPRESENTS THE SOLE AND EXCLUSIVE LIABILITY OF AGNOSTIQ FOR THE
											INFRINGEMENT, VIOLATION, OR MISAPPROPRIATION OF THE INTELLECTUAL PROPERTY
											RIGHTS OF A THIRD PARTY UNDER THIS AGREEMENT.
										</li>
										<li>
											<u>IP Remedy.</u> If the Services are, or in Agnostiq’s opinion is likely to
											be, claimed to infringe, misappropriate, or otherwise violate any third-party
											Intellectual Property Right, or if Customer’s use of any portion of the
											Services are enjoined or threatened to be enjoined, Agnostiq may, at its
											option and sole cost and expense:
											<ol id="list2" type="i">
												<li>
													obtain the right for the Customer to continue to use the affected Covalent
													Cloud Services materially as contemplated by this Agreement;
												</li>
												<li>
													Modify or replace the Covalent Cloud Services, in whole or in part, to
													seek to make the Covalent Cloud Services (as so modified or replaced)
													non-infringing while providing materially equivalent features and
													functionality, in which case such modifications or replacements will
													constitute the Covalent Cloud Services under this Agreement; or
												</li>
												<li>
													if Agnostiq determines that neither of the foregoing two options are
													reasonably available, by written notice to Customer, terminate this
													Agreement, require Customer to immediately cease all use of the Covalent
													Cloud Services or part or feature thereof and provide pro rata refund of
													any unused prepaid Fees for the terminated Covalent Cloud Services, if
													applicable.
													<p style={{ marginTop: '8px' }}>
														THE FOREGOING IS IN LIEU OF ANY REPRESENTATION, COVENANTS OR WARRANTIES
														OF NONINFRINGEMENT, WHICH ARE DISCLAIMED.
													</p>
												</li>
											</ol>
										</li>
										<li>
											Indemnification Procedure: The indemnifying Party’s obligations as set forth
											above are expressly conditioned upon each of the foregoing: (i) the
											indemnified Party promptly notifying the indemnifying Party in writing of any
											threatened or actual claim or suit, provided, however, that failure to give
											prompt notice will not relieve the indemnifying Party of any liability
											hereunder (except to the extent the indemnifying Party has suffered actual
											material prejudice by such failure); (ii) the indemnifying Party having sole
											control of the defense or settlement of any claim or suit (provided the
											indemnifying Party may not settle any claim without the indemnified Party’s
											written consent unless it unconditionally releases the indemnified Party of
											all liability); and (iii) the indemnified Party (at the indemnifying Party’s
											expense) reasonably cooperating with the indemnifying Party to facilitate the
											settlement or defense of any claim or suit.
										</li>
									</ol>
								</li>
								<li id="list1">
									<b>10. Limitation of Liabilities</b>
									<ol id="list2" type="a">
										<li>
											AMOUNT: EXCEPT AS OTHERWISE PROVIDED IN SECTION 10(c), TO THE MAXIMUM EXTENT
											PERMITTED UNDER APPLICABLE LAW, IN NO EVENT WILL THE TOTAL AGGREGATE LIABILITY
											OF EITHER PARTY IN CONNECTION WITH OR UNDER THIS AGREEMENT, WHETHER IN
											CONTRACT, TORT (INCLUDING NEGLIGENCE), OR OTHERWISE, EXCEED THE AMOUNT OF FEES
											PAID BY CUSTOMER FOR THE COVALENT CLOUD SERVICES IN THE 12 MONTH PERIOD
											IMMEDIATELY PRECEDING THE EVENT GIVING RISE TO THE CLAIM. FOR GREATER
											CERTAINTY, THE EXISTENCE OF ONE OR MORE CLAIMS UNDER THIS AGREEMENT WILL NOT
											INCREASE THIS MAXIMUM LIABILITY AMOUNT.
										</li>
										<li>
											TYPE: EXCEPT AS OTHERWISE PROVIDED IN SECTION 10(c), TO THE MAXIMUM EXTENT
											PERMITTED UNDER APPLICABLE LAW, IN NO EVENT WILL EITHER PARTY BE LIABLE TO THE
											OTHER PARTY FOR ANY: (I) SPECIAL, EXEMPLARY, PUNITIVE, INDIRECT, INCIDENTAL OR
											CONSEQUENTIAL DAMAGES; (II) LOST OR LOSS OF (1) SAVINGS, (2) PROFIT, (3) DATA,
											(4) USE, OR (5) GOODWILL; (III) BUSINESS INTERRUPTION; (IV) COSTS FOR THE
											PROCUREMENT OF SUBSTITUTE PRODUCTS OR SERVICES; (V) PERSONAL INJURY OR DEATH;
											OR (VI) PERSONAL OR PROPERTY DAMAGE ARISING OUT OF OR IN ANY WAY CONNECTED TO
											THE SERVICES OR THIS AGREEMENT, REGARDLESS OF CAUSE OF ACTION OR THE THEORY OF
											LIABILITY, WHETHER IN CONTRACT, TORT (INCLUDING NEGLIGENCE), OR OTHERWISE, AND
											EVEN IF NOTIFIED IN ADVANCE OF THE POSSIBILITIES OF SUCH DAMAGES.
										</li>
										<li>
											EXCEPTIONS: THE EXCLUSIONS AND LIMITATIONS IN SECTIONS 10(a) AND 10(b) DO NOT
											APPLY TO LIMIT: (I) CUSTOMER’S OBLIGATIONS UNDER SECTION 9(c)(CUSTOMER
											INDEMNITY) AND AGNOSTIQ’S OBLIGATIONS UNDER 9(d) (AGNOSTIQ INDEMNITY); (II)
											CUSTOMER’S OBLIGATIONS UNDER SECTIONS 1(d), 3(b), 3(c), 5(b) OR 12(e); (III)
											EITHER PARTY’S BREACH OF SECTION 8 (CONFIDENTIAL INFORMATION) (PROVIDED THAT
											AGNOSTIQ’S LIABILITY FOR AN ACCIDENTAL OR UNLAWFUL DESTRUCTION, LOSS,
											ALTERATION, UNAUTHORIZED DISCLOSURE OF, OR ACCESS TO CUSTOMER DATA, RESULTING
											FROM A BREACH OF SECTION 8 (CONFIDENTIAL INFORMATION) IS LIMITED TO
											US$20,000.00) (“<b>DATA BREACH LIABILITY CAP</b>”); (IV) CUSTOMER’S PAYMENT
											OBLIGATIONS IN THIS AGREEMENT; OR (V) A PARTY’S GROSS NEGLIGENCE, WILFUL
											MISCONDUCT OR FRAUD.
										</li>
									</ol>
								</li>
								<li id="list1">
									<b>11. Term and Termination</b>
									<ol id="list2" type="a">
										<li>
											Term and Subscription Term. The term of this Agreement commences on the
											Effective Date and continues until the stated term in all Order Forms have
											expired or have otherwise been terminated the (“<b>Term</b>”). Subscription to
											the Covalent Cloud Services commence on the subscription start date and are
											for the Subscription Term as set forth in the applicable Order Form. Except as
											otherwise specified in an Order Form, subscriptions to the Covalent Cloud
											Services will automatically renew for additional terms equal to the expiring
											Subscription Term, unless and until either Party gives the other notice of
											non-renewal at least thirty (30) days prior to the end of the then-current
											Subscription Term.
										</li>
										<li>
											Termination for Convenience. Except as otherwise agreed to in the Order Form
											or an applicable Addenda, Customer may terminate this Agreement at any time
											for any reason by discontinuing the use of the Services. Agnostiq may
											terminate this Agreement for any reason by providing Customer prior advance
											notice. Provided that upon any termination by a Party pursuant to this Section
											11(b): (i) Customer will not be entitled to a refund of any pre-paid Fees; and
											(ii) if Customer has not already paid all applicable Fees for the then-current
											Term, any such Fees that are outstanding will become immediately due and
											payable.
										</li>
										<li>
											Termination for Cause. Either Party may, in addition to other relief terminate
											this Agreement for cause: (i) upon 30 days written notice to the other Party
											of a material breach if such breach remains uncured at the expiration of such
											period; or (ii) if the other Party becomes the subject of a petition in
											bankruptcy or any other proceeding relating to insolvency, receivership,
											liquidation or assignment for the benefit of creditors. Notwithstanding the
											foregoing, Agnostiq may terminate this Agreement immediately upon notice to
											Customer: (A) if Customer breaches Sections 1(d) or Section 12(e) or as
											otherwise permitted in this Agreement; (B) if there are changes in
											relationships with third party technology providers outside of Agnostiq’s
											control; or (C) to comply with applicable law or government requests.
										</li>
										<li>
											Effect of Termination: Upon expiration or earlier termination of this
											Agreement:
											<ul id="list2">
												<li>
													Customer will immediately cease (and ensure that all Permitted Users
													immediately cease) accessing or using the Services. Within 30 calendar
													days following termination, Agnostiq will delete or otherwise render
													inaccessible any Customer Data that remains in the hardware or systems
													used by Agnostiq to provide the Services. Notwithstanding the foregoing,
													Agnostiq will have no obligation to delete or otherwise render
													inaccessible any Customer Data, where not permissible by applicable law
													applicable to Agnostiq;
												</li>
												<li>all Order Forms and Addenda will terminate;</li>
												<li>
													al Fees due and payable, any amounts due to Agnostiq are immediately due
													and are to be immediately paid by Customer to Agnostiq; and
												</li>
												<li>
													other than as otherwise provided for in this Agreement, no expiration or
													termination will affect or relieve Customer’s obligation to pay all Fees
													that may have become due before such expiration or termination or entitle
													the Customer to any refund.
												</li>
											</ul>
										</li>
										<li>
											Survival. The following Sections, together with any other provision of this
											Agreement which expressly or by its nature survives termination or expiration,
											or which contemplates performance or observance subsequent to termination or
											expiration of this Agreement, will survive expiration or termination of this
											Agreement for any reason: Section 2 (Ownership; Reservation of Rights),
											Section 3 (Privacy), Section 7 (Fees and Payment), Section 8 (Confidential
											Information), Section 9 (Warranty; Disclaimer; Indemnity), Section 10
											(Limitation of Liabilities), Section 11(e) (Survival), and Section 12 (General
											Provisions).
										</li>
									</ol>
								</li>
								<li id="list1">
									<b>12. General Provisions</b>
									<ol id="list2" type="a">
										<li>
											<u>Notices.</u> Notices sent to either Party will be effective when delivered
											in writing and in person or by email (the day of sending by email), one day
											after being sent by overnight courier, or five days after being sent by first
											class mail postage prepaid to the official contact designated by the Party to
											whom a notice is being given. Notices must be sent: (i) if to Agnostiq, to the
											following address: [X] Email: [X] and (ii) if to Customer, to the current
											postal or email address that Agnostiq has on file with respect to Customer.
											Agnostiq may change its contact information by posting the new contact
											information on Agnostiq’s website or by giving notice thereof to Customer.
											Customer is solely responsible for keeping its contact information on file
											with Agnostiq current at all times during the Term.
										</li>
										<li>
											<u>Publicity.</u> Agnostiq may, with the prior approval of Customer, refer to
											Customer as a customer of Agnostiq in announcements, press or marketing
											releases, publications, presentations, case studies and other public
											statements and on Agnostiq’s website and other online channels (collectively,
											“<b>Publicity</b>”). If Publicity is approved by Customer, then Agnostiq may
											use Customer’s name, logo and trademark in conjunction with any Publicity and
											disclose the existence of this Agreement and any testimonials received from
											Customer in any such Publicity. Customer grants Agnostiq a limited, perpetual,
											fully paid-up, irrevocable, non-exclusive, non-transferable, and
											non-sublicensable license to use its logo and trademarks in connection with
											any Publicity.
										</li>
										<li>
											<u>Termination for Cause.</u> Either Party may, in addition to other relief
											terminate this Agreement for cause: (i) upon 30 days written notice to the
											other Party of a material breach if such breach remains uncured at the
											expiration of such period; or (ii) if the other Party becomes the subject of a
											petition in bankruptcy or any other proceeding relating to insolvency,
											receivership, liquidation or assignment for the benefit of creditors.
											Notwithstanding the foregoing, Agnostiq may terminate this Agreement
											immediately upon notice to Customer: (A) if Customer breaches Sections 1(d) or
											Section 12(e) or as otherwise permitted in this Agreement; (B) if there are
											changes in relationships with third party technology providers outside of
											Agnostiq’s control; or (C) to comply with applicable law or government
											requests.
										</li>
										<li>
											<u>Assignment.</u> Neither party will assign this Agreement to any third party
											without the other party’s prior written consent. Agnostiq may assign this
											Agreement without Customer’s consent: (i) in connection with a merger,
											acquisition or sale of all or substantially all of Agnostiq’s assets; or (ii)
											to any affiliate or as part of a corporate reorganization; and effective upon
											such assignment, the assignee is deemed substituted for Agnostiq as a party to
											this Agreement and Agnostiq is fully released from all of its obligations and
											duties to perform under this Agreement. Any purported assignment or delegation
											by a Party in violation of this Section will be null and void. This Agreement
											will inure to the benefit of and be binding upon the Parties, their permitted
											successors and permitted assignees.
										</li>
										<li>
											<u>Governing Law and Attornment.</u> This Agreement and any action related
											thereto will be governed by and construed in accordance with the laws of the
											Province of Ontario and the federal laws of Canada applicable therein, without
											regard to conflicts of law principles. The Parties will initiate any lawsuits
											in connection with this Agreement in Toronto, Ontario, Canada, and irrevocably
											attorn to the exclusive personal jurisdiction and venue of the courts sitting
											therein. The U.N. Convention on Contracts for the International Sale of Goods
											will not apply to this Agreement. This choice of jurisdiction does not prevent
											Agnostiq from seeking injunctive relief with respect to a violation of
											Intellectual Property Rights or confidentiality obligations in any appropriate
											jurisdiction.
										</li>
										<li>
											<u>Export Restrictions.</u> The Services may not be used in or for the benefit
											of, exported, or re-exported (a) into any U.S. embargoed countries
											(collectively, the “<b>Embargoed Countries</b>”) or (b) to anyone on the U.S.
											Treasury Department’s list of Specially Designated Nationals, any other
											restricted party lists (existing now or in the future) identified by the
											Office of Foreign Asset Control, or the U.S. Department of Commerce Denied
											Persons List or Entity List, or any other restricted party lists
											(collectively, “<b>Restricted Party Lists</b>”). Without liming the foregoing,
											Customer will not directly or indirectly export, re-export or import all or
											any portion of the Services without first obtaining all required licenses,
											permits and permissions. Agnostiq makes no representation or warranty that the
											Services may be exported without Customer first obtaining appropriate licenses
											or permits under applicable law, or that any such license or permit has been,
											will be, or can be obtained.
										</li>
										<li>
											<u>Construction.</u> Except as otherwise provided in this Agreement, the
											Parties’ rights and remedies under this Agreement are cumulative and are in
											addition to, and not in substitution for, any other rights and remedies
											available at law or in equity or otherwise. The terms “include” and
											“including” mean, respectively, “include without limitation” and “including
											without limitation.” The headings of sections of this Agreement are for
											reference purposes only and have no substantive effect. The terms “consent” or
											“discretion”, means the right of a Party to withhold such consent or exercise
											such discretion, as applicable, arbitrarily and without any implied obligation
											to act reasonably or explain its decision to the other Party.
										</li>
										<li>
											<u>Force Majeure.</u> Neither Party will be liable for delays caused by any
											event or circumstances beyond that Party’s s reasonable control, including
											acts of God, acts of government, flood, fire, earthquakes, civil unrest, acts
											of terror, strikes or other labour problems (other than those involving that
											Party’s employees), Internet service failures or delays, or the unavailability
											or Modification by third parties of telecommunications or hosting
											infrastructure or third party websites (“<b>Force Majeure</b>”).
										</li>
										<li>
											<u>Severability.</u> Any provision of this Agreement found by a tribunal or
											court of competent jurisdiction to be invalid, illegal or unenforceable will
											be severed from this Agreement and all other provisions of this Agreement will
											remain in full force and effect.
										</li>
										<li>
											<u>Waiver.</u> A waiver of any provision of this Agreement must be in writing
											and a waiver in one instance will not preclude enforcement of such provision
											on other occasions.
										</li>
										<li>
											<u>Independent Contractors.</u> Agnostiq’s relationship to Customer is that of
											an independent contractor, and neither Party is an agent or partner of the
											other. Neither Party will have, and neither Party will represent to any third
											party that it has, any authority to act on behalf of the other Party.
										</li>
										<li>
											<u>No Third Party Beneficiaries.</u> Except as set forth in Section 9(c) and
											9(d), and except for Agnostiq’s licensors, nothing in this Agreement, express
											or implied, is intended to or will confer upon any person other than the Party
											and their respective successors and permitted assigns any legal or equitable
											right, benefit or remedy of any nature under or by reason of this Agreement.
										</li>
										<li>
											<u>Entire Agreement.</u> This Agreement (including all Order Forms),
											constitute the entire agreement between the Parties with respect to the
											subject matter of this Agreement and supersedes all prior or contemporaneous
											agreements, representations or other communications between the Parties,
											whether written or oral. Any terms and conditions appearing on a purchase
											order or similar document issued by Customer, or in Customer’s procurement,
											invoicing, or vendor onboarding portal: (i) do not apply to the Services; (ii)
											do not override or form a part of this Agreement (including without limitation
											any Order Form); and (iii) are void.
										</li>
										<li>
											<u>Order of Precedence.</u> In the event of any conflict or inconsistency
											among the following documents, the order of precedence will be: (1) these
											Terms of Service; (2) the applicable Order Form; and (3) the Documentation.
											The Addenda may contain additional or different terms from the body of this
											Agreement, and in such case, the Addenda will control.
										</li>
										<li>
											<u>AMENDMENTS.</u> AGNOSTIQ MAY UNILATERALLY AMEND THIS AGREEMENT, IN WHOLE OR
											IN PART FROM TIME TO TIME (EACH, AN “AMENDMENT”), BY GIVING CUSTOMER PRIOR
											NOTICE OF SUCH AMENDMENT OR POSTING NOTICE OF SUCH AMENDMENT ON THE WEBSITE.
											UNLESS OTHERWISE INDICATED BY AGNOSTIQ, ANY SUCH AMENDMENT WILL BECOME
											EFFECTIVE AS OF THE DATE THE NOTICE OF SUCH AMENDMENT IS PROVIDED TO CUSTOMER
											OR IS POSTED ON AGNOSTIQ’S WEBSITE (WHICHEVER IS THE EARLIER). CUSTOMER’S
											CONTINUED USE OF THE SERVICES AFTER ANY CHANGE MEANS CUSTOMER AGREES TO SUCH
											CHANGE.
										</li>
										<li>
											<u>English Language.</u> It is the express wish of the Parties that this
											Agreement and all related documents be drawn up in English. C’est la volonté
											expresse des parties que la présente convention ainsi que les documents qui
											s’y rattachent soient rédigés en anglais.
										</li>
									</ol>
								</li>
								<li id="list1">
									<b>13. Definitions</b>
									<p>
										Unless the context requires otherwise, capitalized terms used in this Agreement
										have the meaning ascribed to them in this Section 13:
									</p>
									<ul id="list2">
										<li>
											“<b>Account Information</b>” means information about Customer that Customer
											provides to Agnostiq in connection with the creation or administration of
											Customer User Account. For example, Account Information includes names,
											usernames, phone numbers, email addresses and billing information associated
											with Customer User Account, Services or Customer’s subscription to the
											Covalent Cloud Services.
										</li>
										<li>
											“<b>Addenda</b>” means any addenda prepared and executed in accordance with
											the terms of this Agreement (each, an “Addendum”, and collectively, the
											“Addenda”), all as amended from time to time.
										</li>
										<li>
											“<b>Agnostiq Property</b>” has the meaning in Section 2.
										</li>
										<li>
											“<b>API Key</b>” has the meaning in Section 1(b)(i).
										</li>
										<li>
											“<b>Claim</b>” means any actual, threatened, or potential civil, criminal,
											administrative, regulatory, arbitral or investigative demand, allegation,
											action, suit, investigation or proceeding, or any other claim or demand.
										</li>
										<li>
											“<b>Content</b>” means software (including machine images), data, text, audio,
											video, or images.
										</li>
										<li>
											“<b>Covalent Cloud API</b>” means Agnostiq proprietary application program
											interface and any related Documentation all of which are designed to
											facilitate Customer’s access to and use of the Covalent Cloud Services.
										</li>
										<li>
											“<b>Covalent Cloud Services</b>” has the meaning in Section 1.
										</li>
										<li>
											“<b>Covalent Metadata</b>” has the meaning in Section 2(d).
										</li>
										<li>
											“<b>Criteria</b>” has the meaning in Section 5.
										</li>
										<li>
											“<b>Customer Application</b>” means any Customer application that Customer has
											built using Customer Input and that is hosted by Agnostiq via the Covalent
											Cloud Services.
										</li>
										<li>
											“<b>Customer Data</b>” means any data, information, content, records, and
											files, including Personal Information, that Customer (or any of its Permitted
											Users) loads, makes available to and is accessed by, transmits to or enters
											into the Services, including Account Information.
										</li>
										<li>
											“<b>Customer Input</b>” has the meaning in Section 2.
										</li>
										<li>
											“<b>Customer IP</b>” has the meaning in Section 2. The term “Customer IP” does
											not include any Covalent Materials.
										</li>
										<li>
											“<b>Customer Output</b>” has the meaning in Section 2.
										</li>
										<li>
											“<b>Customer Property</b>” means Customer IP and Customer Applications. The
											term “Customer Property” does not include any Agnostiq Property.
										</li>
										<li>
											“<b>Customer User Account</b>” has the meaning in Section 5.
										</li>
										<li>
											“<b>Deliverable</b>” means a deliverable provided to Customer as a result of
											the Professional Services.
										</li>
										<li>
											“<b>Documentation</b>” means Agnostiq’s user guides and other end user
											documentation for the applicable Services available on the online help feature
											of the Services, as may be updated by Agnostiq from time to time.
										</li>
										<li>
											“<b>End Customer</b>” means an end user who seeks or acquires a right to use
											or redistribute Customer Application or otherwise accesses or uses the
											Covalent Cloud Services under Customer User Account.
										</li>
										<li>
											“<b>Feedback</b>” has the meaning in Section 2.
										</li>
										<li>
											“<b>Fees</b>” has the meaning in Section 7.
										</li>
										<li>
											“<b>Free Trial</b>” has the meaning in Section 1.
										</li>
										<li>
											“<b>High Risk Activities</b>” means activities that has a: (A) high risk of
											high risk of physical harm death, serious personal injury, or severe
											environmental or property damage; (B) high risk of economic harm; or (C) high
											risk government decision making, including multi-level marketing; gambling;
											payday lending; automated determinations of eligibility for credit,
											employment; educational institutions; or public assistance services; military
											or warfare; the creation or operation of weaponry or weapons development;
											management or operation of critical infrastructure in energy, transportation,
											and water, law enforcement or criminal justice; migration or asylum.
										</li>
										<li>
											“<b>Intellectual Property Rights</b>” means any and all registered and
											unregistered rights granted, applied for or otherwise now or hereafter in
											existence under or related to any patent, copyright, trademark, trade secret,
											database protection or other intellectual property rights laws, and all
											similar or equivalent rights or forms of protection, in any part of the world.
										</li>
										<li>
											“<b>Losses</b>” means any and all damages, fines, penalties, deficiencies,
											losses, liabilities (including settlements and judgments), costs, and expenses
											(including interest, court costs, reasonable fees and expenses of lawyers,
											accountants, and other experts and professionals, or other reasonable fees and
											expenses of litigation or other proceedings or of any Claim, default, or
											assessment).
										</li>
										<li>
											“<b>Modifications</b>” means modifications, improvements, customizations,
											patches, bug fixes, updates, enhancements, aggregations, compilations,
											derivative works, translations and adaptations, and “Modify” has a
											corresponding meaning.
										</li>
										<li>
											“<b>Order Form</b>” means any ordering document, online registration, order
											description or order confirmation referencing this Agreement including any
											product specific terms, supplements, or Addenda thereto.
										</li>
										<li>
											“<b>Permitted User</b>” means those Customer’s employees, independent
											contractors of Customer and End Customers of Customer, authorized by Customer
											on Customer’s behalf to access and use the Services.
										</li>
										<li>
											“<b>Personal Information</b>” means information about an identifiable
											individual.
										</li>
										<li>
											“<b>Privacy Law</b>” means: (i) all federal and provincial privacy laws
											applicable to Agnostiq or Customer, including the Personal Information
											Protection and Electronic Documents Act, S.C. 2000, c. 5, (“PIPEDA”), the
											Personal Information Protection Act, R.S.A. 2003, c. P-6.5, the Personal
											Information Protection Act, R.S.B.C. 20003, c. 63 and an Act respecting the
											protection of personal information in the private sector, CQLR, c. P-39.1, as
											amended, updated, re-enacted or replaced from time to time; and (ii) any other
											applicable laws regarding the Processing of Personal Information.
										</li>
										<li>
											“<b>Privacy Policy</b>” has the meaning in Section 3.
										</li>
										<li>
											“<b>Process</b>” or “<b>Processing</b>” means to create, access, receive,
											collect, gather, procure, obtain, receive, acquire, use, transmit, store,
											process, record, disclose, transfer, adapt, alter, retrieve, release, retain,
											dispose of, destroy, manage or otherwise handle Personal Information.
										</li>
										<li>
											“<b>Professional Services</b>” means implementation and configuration services
											provided by Agnostiq in connection with the Service, as described more fully
											in an Order Form.
										</li>
										<li>
											“<b>Services</b>” means: (i) the Professional Services; (ii) Support Services;
											(iii) Covalent Cloud Services, including any Free Trial; and (iv) any
											associated offline components associated with the services described in the
											foregoing subsections, as described in the Documentation. The term “Services”
											excludes Third Party Services.
										</li>
										<li>
											“<b>Subscription Term</b>” means the term of each subscription to the Covalent
											Cloud Services as specified in the applicable Order Form.
										</li>
										<li>
											“<b>Support Services</b>” has the meaning in Section 6.
										</li>
										<li>
											“<b>Supporting Evidence</b>” means documents Customer provides as evidence
											that Customer Application meets the Criteria, including audit reports,
											standard operating procedures, incident response plans, penetration test
											reports, data protection impact assessments, data flow diagrams, and system
											design or architecture diagrams. With the exception of documents or
											information Customer: (i) have otherwise made public, or (ii) consent to being
											public, Agnostiq will treat Supporting Evidence as Customer’s Confidential
											Information.
										</li>
										<li>
											“<b>Term</b>” has the meaning in Section 11.
										</li>
										<li>
											“<b>Third Party Services</b>” has the meaning in Section 1(g).
										</li>
									</ul>
								</li>
							</ul>
						</Box>
					</Box>
				</Box>
			</div>
		</Modal>
	);
}
