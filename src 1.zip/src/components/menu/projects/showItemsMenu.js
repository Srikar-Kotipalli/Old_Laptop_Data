/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Button from '@mui/material/Button';
import Checkbox from '@mui/material/Checkbox';
import Typography from '@mui/material/Typography';
import Avatar from '@mui/material/Avatar';
import Icon from '../../icon';
import checkbox from '../../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../../assets/checkboxes/checkboxChecked.svg';
import showIcon from '../../../assets/actions/show.svg';
import caretDown from '../../../assets/arrows/caretDown.svg';
import archiveIcon from '../../../assets/actions/archive.svg';

export default function ShowItemsMenu(props) {
	const { setShowArchived, showArchived, setMultipleItems, setAllSelected } = props;
	const [anchorEl, setAnchorEl] = React.useState(null);
	const open = Boolean(anchorEl);
	const handleClick = event => {
		setAnchorEl(event.currentTarget);
	};
	const handleClose = () => {
		setAnchorEl(null);
		setShowArchived(prevState => !prevState);
		if (setAllSelected) setAllSelected(false);
		if (setMultipleItems) setMultipleItems([]);
	};

	return (
		<>
			<Button
				sx={{
					'&:hover': {
						backgroundColor: '#1C1C46',
						border: '1px solid #6473FF'
					},
					lineHeight: '1.9',
					height: '32.9px',
					paddingTop: 0.3
				}}
				variant="outlined"
				size="small"
				startIcon={
					<Avatar src={showIcon} sx={{ width: 16, height: 12, marginBottom: '0.15rem' }} />
				}
				endIcon={<Avatar src={caretDown} sx={{ width: 16, height: 16 }} />}
				onClick={handleClick}
			>
				<Typography variant="h2">{showArchived ? 'Showing: Archived' : 'Show'}</Typography>
			</Button>
			<Menu
				id="basic-menu"
				anchorEl={anchorEl}
				open={open}
				onClose={() => setAnchorEl(null)}
				PaperProps={{
					style: {
						transform: 'translateX(0%) translateY(10%)'
					}
				}}
			>
				<MenuItem sx={{ width: '180px' }} onClick={handleClose} data-testid="archivedAction">
					<Checkbox
						icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
						checked={showArchived}
						checkedIcon={<Icon src={checkboxChecked} alt="checkboxChecked" type="pointer" />}
						size="small"
						data-testid="checkbox"
					/>
					<Icon src={archiveIcon} type="static" alt="archiveIcon" />
					<Typography variant="subtitle2">Archived</Typography>
				</MenuItem>
			</Menu>
		</>
	);
}
