/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
/* eslint-disable react/button-has-type */
/* eslint-disable max-len */

import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import React from 'react';
import './style.css';
import ResultSection from '../Result';
import { dateFormatter } from '../../../utils/utils';
import GraphRuntime from '../../../utils/GraphRuntime';

function Overview(props) {
	const {
		latticeDetails,
		inputs,
		result,
		codeOutput,
		resultObject,
		description,
		codeObject,
		error
	} = props;

	return (
		<Box>
			<Box sx={{ mt: 2 }}>
				{description && (
					<>
						<Box>
							<Typography className="overviewhead" sx={{ pb: 0.5 }}>
								Description
							</Typography>
							<ResultSection
								Overview="false"
								description="true"
								value={description}
								hideCopy
								label="Description"
							/>
						</Box>
						<Divider sx={{ bgcolor: '#ffffff1f', mt: 2 }} />
					</>
				)}
				<Box sx={{ mt: 2 }}>
					<Typography className="overviewhead">Runtime</Typography>
					<GraphRuntime
						startTime={latticeDetails?.started_at}
						endTime={latticeDetails?.completed_at}
						className="overviewsubhead"
					/>
				</Box>
				<Box sx={{ mt: 2 }}>
					<Typography className="overviewhead">Start time - End time</Typography>
					<Typography className="overviewsubhead">
						{latticeDetails.started_at ? dateFormatter(`${latticeDetails.started_at}Z`) : ''} -
						{latticeDetails.completed_at ? dateFormatter(`${latticeDetails.completed_at}Z`) : ''}
					</Typography>
				</Box>
				{error && (
					<Box sx={{ mt: 2 }}>
						<ResultSection
							value={error}
							objectValue={error}
							label="Error"
							className="overviewhead"
						/>
					</Box>
				)}
				{inputs && (
					<Box sx={{ mt: 2 }}>
						<ResultSection
							value={inputs}
							objectValue={inputs}
							label="Input"
							className="overviewhead"
						/>
					</Box>
				)}
				{result && latticeDetails?.status === 'COMPLETED' && (
					<Box sx={{ mt: 2 }}>
						<ResultSection
							value={result}
							objectValue={resultObject}
							label="Result"
							className="overviewhead"
						/>
					</Box>
				)}
				{codeOutput && (
					<Box sx={{ mt: 2 }}>
						<ResultSection
							value={codeOutput}
							name="code"
							objectValue={codeObject}
							label="Code"
							className="overviewhead"
						/>
					</Box>
				)}
			</Box>
		</Box>
	);
}

export default Overview;
