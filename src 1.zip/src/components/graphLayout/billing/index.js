/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import { Grid, Typography, Box } from '@mui/material';
import Icon from '../../icon';
import CostIcon from '../../../assets/billing/cost.svg';
import BarIcon from '../../../assets/billing/bar.svg';

function BillingGraph() {
	return (
		<Grid item xs={5} sx={{ marginTop: '20px' }}>
			<Box
				p={2}
				sx={{
					display: 'flex',
					flexDirection: 'column',
					alignItems: 'flex-start',
					height: '214px',
					borderRadius: '8px',
					border: '1px solid',
					borderColor: theme => theme.palette.background.blue03
				}}
			>
				<Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
					<Box
						mr={1}
						sx={{
							display: 'flex',
							alignItems: 'center',
							justifyContent: 'center',
							width: '24px',
							height: '24px',
							background: theme => theme.palette.background.covalentPurple,
							borderRadius: '8px',
							border: '1px solid',
							borderColor: theme => theme.palette.background.blue05
						}}
					>
						<Icon src={CostIcon} />
					</Box>
					<Typography variant="h2" sx={{ color: theme => theme.palette.text.secondary }}>
						Monthly Breakdown
					</Typography>
				</Box>
				<Box
					sx={{
						height: '100%',
						width: '100%',
						display: 'flex',
						flexDirection: 'column',
						alignItems: 'center',
						justifyContent: 'center'
					}}
				>
					<Icon src={BarIcon} />
					<Typography sx={{ textAlign: 'center' }}>
						Breakdown will be shown once costs are incurred
					</Typography>
				</Box>
			</Box>
		</Grid>
	);
}

export default BillingGraph;
