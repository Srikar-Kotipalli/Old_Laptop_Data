/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable react/jsx-no-useless-fragment */

import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import TableSortLabel from '@mui/material/TableSortLabel';
import './style.css';
import { TableBody } from '@mui/material';

export default function TableHeader(props) {
	const { header, order, orderBy, onSort } = props;
	return (
		<TableBody>
			{!!header.length && (
				<TableRow className="tableHeader" sx={{ '& td': { border: 0 } }}>
					{header.map(h => (
						<TableCell
							sx={{ paddingLeft: h.id === 'title' ? '0.65rem' : '0rem' }}
							width={h.width}
							key={h.id}
							colSpan={h.colSpan || 1}
							align={h.align || 'center'}
							data-testid="tableHeader"
						>
							<TableSortLabel
								active={orderBy === h.id}
								direction={orderBy === h.id ? order : 'asc'}
								onClick={() => onSort(h.id)}
								disabled={h.id === 'tags'}
								data-testid="tableSort"
							>
								{h.label}
							</TableSortLabel>
						</TableCell>
					))}
				</TableRow>
			)}
		</TableBody>
	);
}
