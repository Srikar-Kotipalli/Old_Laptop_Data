/* eslint-disable */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableRow from '@mui/material/TableRow';
import DispatchRow from './dispatchRow';
import ExperimentRow from './experimentRow';
import ProjectRow from './projectRow';
import AllTableHeader from './tableheader';
import TableFooter from './tableFooter';
import NoRecordsFound from './noRecordsFound';
import MoreRecords from './moreRecords';
import { ProjectContext } from '../../../containers/projects/projectContext';
import './style.css';

export default function AllListView() {
	const projectContext = React.useContext(ProjectContext);
	const { allItems, sidebarId, openSidebar } = projectContext;
	function getBorderStyle(list) {
		return list?.isOpen && !list?.isLoader;
	}
	return (
		<>
			<Table data-testid="allListView" width="100%">
				<AllTableHeader />
				<TableBody>
					{allItems &&
						allItems.map((list, allListIndex) => (
							<React.Fragment key={list.id}>
								{/* List Project Items and it's hierarchy */}
								{list.type === 'Project' && (
									<React.Fragment key={list.id}>
										<TableRow
											sx={{
												borderLeft:
													getBorderStyle(list) && list?.hierarchyListItems
														? '1px solid #6473FF'
														: '',
												borderRight:
													getBorderStyle(list) && list?.hierarchyListItems
														? '1px solid #6473FF'
														: '',
												borderTop:
													getBorderStyle(list) && list?.hierarchyListItems
														? '1px solid #6473FF'
														: '',
												backgroundColor:
													list?.isOpen &&
													list?.hierarchyListItems?.filter(e => e.isOpen === true)?.length === 0
														? '#1c1c46'
														: ''
											}}
										>
											<ProjectRow list={list} allListIndex={allListIndex} />
										</TableRow>
										{list?.isOpen &&
											!list?.isLoader &&
											list.hierarchyListItems &&
											list.hierarchyListItems.map((listItems, listHierarchyIndex) => (
												<React.Fragment key={listItems.id}>
													{listItems.type === 'Experiment' && (
														<React.Fragment key={listItems.id}>
															<TableRow
																data-testid="projectExperiment"
																sx={{
																	borderLeft: getBorderStyle(list) ? '1px solid #6473FF' : '',
																	borderRight: getBorderStyle(list) ? '1px solid #6473FF' : '',
																	borderBottom:
																		getBorderStyle(list) &&
																		!listItems?.isOpen &&
																		listHierarchyIndex === list.hierarchyListItems.length - 1 &&
																		list.hierarchyListItems.length ===
																			list.hierarchyListItemsTotalCount
																			? '1px solid #6473FF'
																			: '',
																	backgroundColor:
																		listItems?.isOpen ||
																		(openSidebar && sidebarId === listItems?.id)
																			? '#1c1c46'
																			: ''
																}}
															>
																<ExperimentRow
																	experiment={listItems}
																	allListIndex={allListIndex}
																	listHierarchyIndex={listHierarchyIndex}
																	type="experimentProject"
																/>
															</TableRow>
															{listItems?.isOpen &&
																listItems.dispatches &&
																listItems.dispatches.map((dispatch, index) => (
																	<TableRow
																		data-testid="projectExperimentDispatch"
																		key={dispatch.id}
																		sx={{
																			borderLeft: getBorderStyle(listItems)
																				? '1px solid #6473FF'
																				: '',
																			borderRight: getBorderStyle(listItems)
																				? '1px solid #6473FF'
																				: '',
																			borderBottom:
																				listItems?.isOpen &&
																				!listItems?.isLoader &&
																				listHierarchyIndex === list.hierarchyListItems.length - 1 &&
																				index === listItems?.dispatches.length - 1 &&
																				listItems.dispatchesTotalCount ===
																					listItems.dispatches.length &&
																				list.hierarchyListItems.length ===
																					list.hierarchyListItemsTotalCount
																					? '1px solid #6473FF'
																					: ''
																		}}
																	>
																		<DispatchRow
																			dispatch={dispatch}
																			hierarchyType="projectExperimentDispatch"
																			indentType="doubleHierarchy"
																		/>
																	</TableRow>
																))}
															{listItems?.isOpen &&
																!listItems?.isLoader &&
																listItems.dispatches &&
																listItems.dispatches.length === 0 && (
																	<NoRecordsFound
																		style={{
																			borderLeft: getBorderStyle(listItems)
																				? '1px solid #6473FF'
																				: '',
																			borderRight: getBorderStyle(listItems)
																				? '1px solid #6473FF'
																				: '',
																			borderBottom:
																				listHierarchyIndex === list.hierarchyListItems.length - 1 &&
																				getBorderStyle(listItems)
																					? '1px solid #6473FF'
																					: ''
																		}}
																	/>
																)}
															{listItems?.isOpen &&
																!listItems?.isLoader &&
																listItems.dispatches &&
																listItems.dispatchesTotalCount > listItems.dispatches.length && (
																	<MoreRecords
																		style={{
																			borderLeft: getBorderStyle(listItems)
																				? '1px solid #6473FF'
																				: '',
																			borderRight: getBorderStyle(listItems)
																				? '1px solid #6473FF'
																				: '',
																			borderBottom:
																				listHierarchyIndex === list.hierarchyListItems.length - 1 &&
																				getBorderStyle(listItems)
																					? '1px solid #6473FF'
																					: ''
																		}}
																		leftVal="4.1rem"
																		index={allListIndex}
																		type="allProjectExperiments"
																		open={true}
																		secondaryIndex={listHierarchyIndex}
																		mainType="Project"
																		count={listItems.dispatches.length + 5}
																		leftValText="0.1rem"
																	/>
																)}
														</React.Fragment>
													)}
													{listItems.type === 'Dispatch' && (
														<TableRow
															data-testid="projectDispatch"
															key={listItems.id}
															sx={{
																borderLeft: getBorderStyle(list) ? '1px solid #6473FF' : '',
																borderRight: getBorderStyle(list) ? '1px solid #6473FF' : '',
																borderBottom:
																	getBorderStyle(list) &&
																	listHierarchyIndex === list?.hierarchyListItems.length - 1 &&
																	list?.hierarchyListItems.length ===
																		list?.hierarchyListItemsTotalCount
																		? '1px solid #6473FF'
																		: ''
															}}
														>
															<DispatchRow
																dispatch={listItems}
																indentType="singleHierarchy"
																hierarchyType="projectDispatch"
															/>
														</TableRow>
													)}
												</React.Fragment>
											))}
										{list?.isOpen &&
											!list?.isLoader &&
											list.hierarchyListItems &&
											list.hierarchyListItems.length === 0 && (
												<NoRecordsFound
													style={{
														borderLeft: getBorderStyle(list) ? '1px solid #6473FF' : '',
														borderRight: getBorderStyle(list) ? '1px solid #6473FF' : '',
														borderBottom: getBorderStyle(list) ? '1px solid #6473FF' : ''
													}}
												/>
											)}
										{list?.isOpen &&
											!list?.isLoader &&
											list.hierarchyListItems &&
											list.hierarchyListItemsTotalCount > list.hierarchyListItems.length && (
												<MoreRecords
													style={{
														borderLeft: getBorderStyle(list) ? '1px solid #6473FF' : '',
														borderRight: getBorderStyle(list) ? '1px solid #6473FF' : '',
														borderBottom: getBorderStyle(list) ? '1px solid #6473FF' : ''
													}}
													leftVal="2.3rem"
													mainType="Project"
													type="allItems"
													index={allListIndex}
													open={true}
													secondaryIndex=""
													count={list.hierarchyListItems.length + 5}
													leftValText="0.2rem"
												/>
											)}
									</React.Fragment>
								)}
								{/* List Experiment Items and it's hierarchy */}
								{list.type === 'Experiment' && (
									<React.Fragment key={list.id}>
										<TableRow
											sx={{
												borderLeft:
													getBorderStyle(list) && list?.hierarchyListItems
														? '1px solid #6473FF'
														: '',
												borderRight:
													getBorderStyle(list) && list?.hierarchyListItems
														? '1px solid #6473FF'
														: '',
												borderTop:
													getBorderStyle(list) && list?.hierarchyListItems
														? '1px solid #6473FF'
														: '',
												backgroundColor:
													list?.isOpen || (openSidebar && sidebarId === list?.id) ? '#1c1c46' : ''
											}}
											data-testid="allExperiment"
										>
											<ExperimentRow
												experiment={list}
												allListIndex={allListIndex}
												type="experiment"
											/>
										</TableRow>
										{list?.isOpen &&
											list.hierarchyListItems &&
											list.hierarchyListItems.map((dispatch, index) => (
												<TableRow
													data-testid="experimentDispatch"
													key={dispatch.id}
													sx={{
														borderLeft: getBorderStyle(list) ? '1px solid #6473FF' : '',
														borderRight: getBorderStyle(list) ? '1px solid #6473FF' : '',
														borderBottom:
															getBorderStyle(list) &&
															index === list?.hierarchyListItems.length - 1 &&
															list.hierarchyListItemsTotalCount === list.hierarchyListItems.length
																? '1px solid #6473FF'
																: ''
													}}
												>
													<DispatchRow
														dispatch={dispatch}
														indentType="singleHierarchy"
														hierarchyType="experimentDispatch"
													/>
												</TableRow>
											))}
										{list?.isOpen &&
											!list?.isLoader &&
											list.hierarchyListItems &&
											list.hierarchyListItems.length === 0 && (
												<NoRecordsFound
													style={{
														borderLeft: getBorderStyle(list) ? '1px solid #6473FF' : '',
														borderRight: getBorderStyle(list) ? '1px solid #6473FF' : '',
														borderBottom: getBorderStyle(list) ? '1px solid #6473FF' : ''
													}}
												/>
											)}
										{list?.isOpen &&
											!list?.isLoader &&
											list.hierarchyListItems &&
											list.hierarchyListItemsTotalCount > list.hierarchyListItems.length && (
												<MoreRecords
													style={{
														borderLeft: getBorderStyle(list) ? '1px solid #6473FF' : '',
														borderRight: getBorderStyle(list) ? '1px solid #6473FF' : '',
														borderBottom: getBorderStyle(list) ? '1px solid #6473FF' : ''
													}}
													leftVal="2.2rem"
													mainType="Experiment"
													index={allListIndex}
													open={true}
													count={list.hierarchyListItems.length + 5}
													leftValText="0.2rem"
												/>
											)}
									</React.Fragment>
								)}
								{/* List Dispatch Items and it's hierarchy */}
								{list.type === 'Dispatch' && (
									<TableRow key={list.id}>
										<DispatchRow dispatch={list} index={allListIndex} hierarchyType="dispatch" />
									</TableRow>
								)}
							</React.Fragment>
						))}
					{allItems && allItems.length === 0 && <NoRecordsFound />}
				</TableBody>
			</Table>
			<TableFooter />
		</>
	);
}
