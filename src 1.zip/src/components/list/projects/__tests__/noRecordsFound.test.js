import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
import NoRecordsFound from '../noRecordsFound';

describe('no records found', () => {
	test('renders no records found view', () => {
		render(<NoRecordsFound />);
		const element = screen.getByTestId('noRecordsFound');
		expect(element).toBeInTheDocument();
	});
});
