// /* eslint-disable import/no-unused-modules */
// /* eslint-disable react/jsx-curly-brace-presence */
// /*
//  * Copyright 2022 Agnostiq Inc.
//  * Note: This file is subject to a proprietary license agreement entered into between
//  * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
//  * access and use this file is subject to the terms and conditions of such agreement.
//  * Please ensure you carefully review such agreements and, if you have any questions
//  * please reach out to Agnostiq at: [support@agnostiq.com].
//  */
// import * as React from 'react';
// import TableCell from '@mui/material/TableCell';
// import { Stack } from '@mui/material';
// import Icon from '../../icon';
// import downloadIcon from '../../../assets/download.svg';
// import { capitalizeName } from '../../../utils/utils';
// import { BillingContext } from '../../../containers/settings/billing/billingContext';

// export default function BillingTableRow(props) {
// 	const billingContext = React.useContext(BillingContext);
// 	const { downloadInvoice } = billingContext;
// 	const { invoice } = props;
// 	return (
// 		<>
// 			<TableCell align="left">{invoice?.issued_date}</TableCell>
// 			<TableCell align="left">{invoice?.id}</TableCell>
// 			<TableCell align="left">{capitalizeName(invoice?.external_issuing_type)}</TableCell>
// 			<TableCell align="left">{`$${((parseInt(invoice?.total_amount_cents, 10) || 0) / 100).toFixed(
// 				2
// 			)} ${invoice?.total_amount_currency}`}</TableCell>
// 			<TableCell align="left">{invoice?.payment_status ? 'Paid' : 'Pending'}</TableCell>
// 			<TableCell align="left">
// 				<Stack direction={'row'}>
// 					<Icon
// 						src={downloadIcon}
// 						alt="downloadIcon"
// 						type="pointer"
// 						clickHandler={() => downloadInvoice(invoice?.id)}
// 					/>
// 				</Stack>
// 			</TableCell>
// 		</>
// 	);
// }
