import React from 'react';
import { Grid, Typography, Box } from '@mui/material';
import CopyButton from '../copyButton';
import Sync from '../syntaxHiglighter';

export default function UsageBlock({ heading, code, margin, className }) {
	return (
		// eslint-disable-next-line object-shorthand
		<Grid item container xs={10} sx={{ margin: margin }}>
			<Grid
				item
				xs={12}
				sx={{ borderRadius: '8px 8px 0px 0px', backgroundColor: '#1C1C46', height: '41px' }}
			>
				<Typography pl={2} pt={1} sx={{ color: '#FFF' }}>
					{heading}
				</Typography>
			</Grid>
			<Grid item container xs={12} sx={{ backgroundColor: 'rgba(11, 11, 17, 0.9)' }}>
				<Grid item xs={11} py={2} pl={2}>
					<Box sx={{ marginLeft: '-6px' }}>
						{' '}
						<Sync code={code} className={className} />
					</Box>
				</Grid>
				<Grid item xs={1} pt={2}>
					<Grid
						m="auto"
						pl={0.5}
						pt={0.4}
						sx={{
							width: '2rem',
							borderColor: theme => theme.palette.background.blue05,
							borderRadius: '8px'
						}}
					>
						<CopyButton content={code} borderEnable={false} />
					</Grid>
				</Grid>
			</Grid>
		</Grid>
	);
}
