/* eslint-disable import/no-unused-modules */
import React from 'react';
import { Grid, Typography, Box } from '@mui/material';
import './style.css';

export default function Ioblock({ data }) {
	return (
		<Grid container direction="row" xs={10} mt="1rem" marginBottom={2}>
			<Grid
				item
				xs={12}
				sx={{ borderRadius: '8px 8px 0px 0px', backgroundColor: '#1C1C46', height: '41px' }}
			>
				<Typography pl={2} pt={1}>
					I/O
				</Typography>
			</Grid>
			<Grid
				item
				xs={12}
				sx={{
					backgroundColor: 'rgba(11, 11, 17, 0.9)',
					minHeight: '307px',
					borderLeft: '1px solid #303067',
					borderRight: '1px solid #303067',
					borderBottom: '1px solid #303067'
				}}
			>
				<Box pt="1rem" pl="2rem" pr="1rem" pb="1rem">
					<Typography variant="h2">{data}</Typography>
				</Box>
			</Grid>
		</Grid>
	);
}
