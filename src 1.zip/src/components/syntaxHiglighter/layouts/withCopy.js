/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import Box from '@mui/material/Box';
import CopyButton from '../../copyButton';
import SyntaxHighlighter from '../index';

function SyntaxHighlight({ src }) {
	return (
		<Box
			sx={{
				marginTop: '16px',
				position: 'relative',
				background: theme => theme.palette.background.black01,
				borderRadius: '8px',
				border: '1px solid',
				borderColor: theme => theme.palette.background.blue03
			}}
		>
			<SyntaxHighlighter src={src} />
			<Box
				sx={{
					padding: '1px 0px 0px 1px',
					width: '24px',
					height: '24px',
					position: 'absolute',
					top: 15,
					right: 15,
					border: '1px solid',
					borderColor: theme => theme.palette.background.blue03,
					borderRadius: '8px'
				}}
			>
				<CopyButton content={src} />
			</Box>
		</Box>
	);
}

export default SyntaxHighlight;
