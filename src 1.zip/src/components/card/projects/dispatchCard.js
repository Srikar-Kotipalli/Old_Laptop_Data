/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable react/jsx-no-undef */
/* eslint-disable no-unused-vars */
import React, { memo } from 'react';
import { Link } from 'react-router-dom';
import Tooltip from '@mui/material/Tooltip';
import Card from '@mui/material/Card';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import CardContent from '@mui/material/CardContent';
import { useSelector } from 'react-redux';
import dispatchIcon from '../../../assets/dispatch/dispatchIcon.svg';
import pinIcon from '../../../assets/actions/pin.svg';
import Icon from '../../icon/index';
import ContextMenu from '../../menu/projects/contextMenu';
import './style.css';
import RuntimeTooltip from '../../tooltip/runTimeTooltip';
import EllipsisToolTip from '../../tooltip/ellipsisTooltip';
import { statusIcon } from '../../../utils/statusIcons';
import { ProjectContext } from '../../../containers/projects/projectContext';
import { highlightedDispatchesList } from '../../../api/experiments/dispatchApi';
import { allSharedItemsList } from '../../../api/shared/sharedApi';
import CustomInputBase from '../../inputBase/projects';
import { capitalizeName } from '../../../utils/utils';
import useDidMountEffect from '../../../utils/useDidMountEffect';

function DispatchCard(props) {
	// Live refresh
	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);

	const projectContext = React.useContext(ProjectContext);
	const { isAction, isMoved } = projectContext;
	const { onPin, shareScreen, setOpenLoader } = props;

	// highlighted dispatches view api and state variables.
	const [highlightedDispatches, setHighlightedDispatches] = React.useState([]);
	const highlightedDispatchesListApi = () => {
		if (shareScreen) {
			const bodyParameters = {
				count: 4,
				offset: 0
			};

			allSharedItemsList(bodyParameters)
				.then(response => setHighlightedDispatches(response.items))
				.catch(error => {
					console.log(error);
				});
		} else {
			highlightedDispatchesList(4, 'PINNED')
				.then(response => {
					setHighlightedDispatches(response);
					if (setOpenLoader) {
						setOpenLoader(false);
					}
				})
				.catch(error => {
					console.log(error);
					if (setOpenLoader) {
						setOpenLoader(false);
					}
				});
		}
	};

	const highlightedDispatchesListApiLiveRefresh = () => {
		if (shareScreen) {
			const bodyParameters = {
				count: 4,
				offset: 0
			};

			allSharedItemsList(bodyParameters)
				.then(response => setHighlightedDispatches(response.items))
				.catch(error => {
					console.log(error);
				});
		} else {
			highlightedDispatchesList(4, 'PINNED')
				.then(response => {
					setHighlightedDispatches(response);
				})
				.catch(error => {
					console.log(error);
				});
		}
	};

	React.useEffect(() => {
		highlightedDispatchesListApi();
	}, [isAction, isMoved]);

	useDidMountEffect(() => {
		highlightedDispatchesListApiLiveRefresh();
	}, [liveRefresh]);

	// dispatch.isPinned ? 'Unpin' : 'Pin'
	const pinnedFn = pinned => {
		if (pinned) {
			return 'Unpin';
		}
		return 'Pin';
	};

	return (
		<Grid container spacing={2} data-testid="gridView">
			{highlightedDispatches.map(dispatch => (
				<Grid item xs={6} sm={3} md={3} lg={3} xl={3} xxl={3} key={dispatch.id}>
					<Card square className="cardContainer">
						<CardContent>
							<Grid container className="cardContent">
								<Grid item xs={!shareScreen ? 9 : 10} className="avatarContainer">
									<Icon src={dispatchIcon} type="static" alt="dispatchIcon" />
									{dispatch.isAdd ? (
										<CustomInputBase type="dispatch" listItem={dispatch} location="grid" />
									) : (
										<Link
											style={{ color: '#CBCBD7', textDecoration: 'none' }}
											to={`/graph/${dispatch.id}`}
											state={{}}
										>
											<EllipsisToolTip
												type="grid"
												value={dispatch.title}
												variant="subtitle1"
												paddingTop="1px"
											/>
										</Link>
									)}
								</Grid>
								{dispatch && !shareScreen ? (
									<Grid item xs={3} className="actionContainer">
										<Tooltip placement="top" title={pinnedFn(dispatch.isPinned)}>
											<Grid className={dispatch.isPinned && 'pinIcon'}>
												<Icon
													src={pinIcon}
													type="pointer"
													status={dispatch.isPinned && 'active'}
													clickHandler={() => onPin(dispatch)}
													alt="pinIcon"
												/>
											</Grid>
										</Tooltip>
										<Grid
											className="iconPinContainer"
											container
											spacing={0}
											direction="row"
											justifyContent="center"
											alignItems="center"
										>
											<ContextMenu
												dispatch={dispatch}
												type="dispatch"
												view="grid"
												location="card"
												margin={0}
												highlightedDispatches={highlightedDispatches}
												setHighlightedDispatches={setHighlightedDispatches}
											/>
										</Grid>
									</Grid>
								) : (
									<Grid item xs={2}>
										<Tooltip title={capitalizeName(dispatch?.shared[0].sharedByName) || ''}>
											<Avatar
												sx={{
													width: '24px',
													height: '24px',
													fontSize: '12px',
													position: 'unset',
													float: 'right',
													bgcolor: '#8B31FF',
													color: 'white'
												}}
											>
												{capitalizeName(dispatch?.shared[0].sharedByName?.slice(0, 1)) || ''}
											</Avatar>
										</Tooltip>
									</Grid>
								)}
							</Grid>
							<Grid container>
								<Grid item xs={7} className="timerContainer">
									{statusIcon(dispatch.status, !shareScreen ? 'dashboard' : 'sharemeScreen')}
									<Typography variant="subtitle2" className="progressText">
										<RuntimeTooltip value={dispatch.runTime} placement="bottom" />
									</Typography>
								</Grid>
								<Grid item xs={5} className="progressContainer">
									<Typography className="progressRatio" variant="subtitle2">
										{dispatch.completedElectrons}/{dispatch.totalElectrons}
									</Typography>
								</Grid>
							</Grid>
						</CardContent>
					</Card>
				</Grid>
			))}
		</Grid>
	);
}

export default memo(DispatchCard);
