/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import PropTypes from 'prop-types';
import { Grid, Typography, Box, Divider } from '@mui/material';
import Tooltip from '@mui/material/Tooltip';
import HintIcon from '../../../assets/actions/hint.svg';
import Icon from '../../icon';
import CostIcon from '../../../assets/billing/cost.svg';
import Loader from '../../loader';
import OverflowTooltip from '../../tooltip/overflowTooltip';

const convertTotalPayable = (payableAmountMicrodollars, payableAmount) => {
	let finalAmount;
	if (payableAmountMicrodollars < 0) finalAmount = '$0.00 USD';
	else finalAmount = payableAmount;
	return finalAmount;
};

function CustomCharges({ title, charges }) {
	return (
		<Grid
			container
			sx={{
				display: 'flex',
				alignItems: 'center',
				justifyContent: 'center'
			}}
		>
			<Grid item xs={4.6} sx={{ display: 'flex' }}>
				<Typography
					variant="h2"
					sx={{ marginRight: title === 'Credits' ? 1 : 0, marginTop: '4px', marginBottom: '14px' }}
				>
					{title}
				</Typography>
				{title === 'Credits' && (
					<Tooltip
						placement="right"
						title="Your account credits represent prepaid funds for accessing features."
					>
						<span>
							<Icon src={HintIcon} padding="0px 0px 1px 0px" />
						</span>
					</Tooltip>
				)}
			</Grid>
			<Grid item xs={4.6} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
				<OverflowTooltip
					position="right"
					color={title === 'Credits' ? theme => theme.palette.text.success : null}
					height="16.8px"
					fontSize="14px"
					length={20}
					title={charges || '-'}
					marginBottom="14px"
				/>
			</Grid>
		</Grid>
	);
}

function BillingCard(props) {
	const { openLoader, charges } = props;

	return (
		<Grid
			item
			xs={12}
			sx={{
				marginTop: '20px',
				minHeight: '234px'
			}}
		>
			{/* {openLoader && (
				<Loader isFetching={openLoader} width="100%" position="relative" height="100%" />
			)} */}
			<Box
				sx={{
					display: 'flex',
					alignItems: 'center',
					justifyContent: 'center',
					height: '100%',
					width: '100%',
					borderRadius: '8px',
					border: '1px solid',
					borderColor: theme => theme.palette.background.blue03
				}}
			>
				{openLoader && (
					<Loader isFetching={openLoader} width="100%" position="relative" height="100%" />
				)}
				{!openLoader && (
					<>
						<Box
							sx={{
								display: 'flex',
								flexDirection: 'column',
								alignItems: 'center',
								justifyContent: 'center',
								height: '100%',
								width: '50%'
								// background: 'green'
							}}
						>
							{/* <Typography variant="h2">Current Plan Name</Typography> */}
							<Box sx={{ marginBottom: '15px', display: 'flex' }}>
								<OverflowTooltip
									fontSize="32px"
									length={20}
									title={convertTotalPayable(
										charges?.billing_periods?.all_time?.subtotal_in_microdollars,
										charges?.billing_periods?.all_time?.display_price
									)}
								/>
							</Box>
							{charges?.billing_periods ? (
								<Typography variant="h2">Total Payable</Typography>
							) : (
								<>
									<Typography variant="h1">-</Typography>
									<Typography variant="h2">No cost incurred</Typography>
								</>
							)}
						</Box>
						<Divider
							sx={{
								width: '1px',
								height: '162px',
								backgroundColor: theme => theme.palette.background.blue03
							}}
						/>
						<Box
							sx={{
								display: 'flex',
								flexDirection: 'column',
								alignItems: 'center',
								justifyContent: 'center',
								height: '100%',
								width: '50%'
							}}
						>
							<Box
								sx={{
									display: 'flex',
									alignItems: 'center',
									width: '100%',
									marginBottom: '20px'
								}}
							>
								<Box mt={2} sx={{ marginLeft: '29px', display: 'flex', alignItems: 'center' }}>
									<Box
										mr={1}
										sx={{
											display: 'flex',
											alignItems: 'center',
											justifyContent: 'center',
											width: '24px',
											height: '24px',
											background: theme => theme.palette.background.covalentPurple,
											borderRadius: '8px',
											border: '1px solid',
											borderColor: theme => theme.palette.background.blue05
										}}
									>
										<Icon src={CostIcon} type="static" />
									</Box>
									<Typography variant="h2" sx={{ color: theme => theme.palette.text.secondary }}>
										Split Up
									</Typography>
								</Box>
							</Box>
							<Box
								sx={{
									display: 'flex',
									flexDirection: 'column',
									alignItems: 'center',
									justifyContent: 'center',
									width: '100%'
								}}
							>
								<CustomCharges
									title="This Month"
									charges={charges?.billing_periods?.current?.display_price}
								/>
								<CustomCharges
									title="Prev Month"
									charges={charges?.billing_periods?.previous?.display_price}
								/>
								<CustomCharges title="Credits" charges={charges?.discounts?.total_display_price} />
							</Box>
						</Box>
					</>
				)}
			</Box>
		</Grid>
	);
}

BillingCard.propTypes = {
	openLoader: PropTypes.bool.isRequired,
	charges: PropTypes.shape({
		billing_account_id: PropTypes.string,
		billing_periods: PropTypes.shape({
			current: PropTypes.object,
			previous: PropTypes.object,
			all_time: PropTypes.object
		}),
		discounts: PropTypes.shape({
			total_display_price: PropTypes.string,
			remaining_display_price: PropTypes.string,
			total_in_microdollars: PropTypes.number,
			remaining_in_microdollars: PropTypes.number,
			external_ids: PropTypes.arrayOf(PropTypes.string)
		}),
		display_price: PropTypes.string,
		from_date: PropTypes.string,
		subtotal_in_microdollars: PropTypes.number,
		to_date: PropTypes.string
	})
};

BillingCard.defaultProps = {
	charges: null
};

export default BillingCard;
