/* eslint-disable no-unused-expressions */
import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';
import RightArrow from '../../../assets/marketplace/arrow.svg';

export default function GoButton({
	text,
	bgcolor,
	hardwareId,
	solverId,
	tabvalue,
	variant,
	type,
	onClick
}) {
	const navigate = useNavigate();
	const { allMySolvers } = useSelector(state => state.solver);
	const { allMyHardwares } = useSelector(state => state.hardware);
	const { accessRequests } =
		type === 'solver'
			? useSelector(state => state.solverAdmin)
			: useSelector(state => state.hardwareAdmin);
	const [showRequestButton, setShowRequestButton] = useState(true);

	const handleClick = () => {
		if (tabvalue === 'Hardware') {
			navigate(`/marketplace/hardware/${hardwareId}`);
		} else if (tabvalue === 'Solvers') {
			navigate(`/marketplace/solvers/${solverId}`);
			window.scrollTo({
				top: 0,
				behavior: 'smooth'
			});
		} else {
			if (type === 'hardware') {
				navigate(`/marketplace/hardware/${hardwareId}`);
			} else {
				navigate(`/marketplace/solvers/${solverId}`);
				window.scrollTo({
					top: 0,
					behavior: 'smooth'
				});
			}
		}
	};
	const isDisabled = () => {
		if (text === 'Request Access') {
			if (type === 'solver') {
				const alreadyInSolvers = allMySolvers?.findIndex(
					e => e?.solverId === parseInt(solverId, 10)
				);
				const inRequests = accessRequests?.findIndex(
					e => e?.solverId === parseInt(solverId, 10) && !e?.isDenied
				);
				if (alreadyInSolvers !== -1 || inRequests !== -1) return true;
				return false;
			}
			const alreadyInHardwares = allMyHardwares?.findIndex(
				e => e?.hardwareId === parseInt(hardwareId, 10)
			);
			const inRequests = accessRequests?.findIndex(
				e => e?.hardwareId === parseInt(hardwareId, 10) && !e?.isDenied
			);
			if (alreadyInHardwares !== -1 || inRequests !== -1) return true;
			return false;
		}
		return false;
	};

	useEffect(() => {
		if (text === 'Request Access' && isDisabled() === true) {
			setShowRequestButton(false);
		} else {
			setShowRequestButton(true);
		}
	});
	return (
		<Button
			variant={variant}
			sx={{
				display: !showRequestButton ? 'none' : null,
				fontSize: '12px',
				height: '22px',
				background: bgcolor,
				':hover': {
					background: bgcolor ? '#3633ff' : ''
				},
				'&:disabled': {
					background: theme => theme.palette.background.covalentPurple,
					color: theme => theme.palette.text.secondary,
					border: '1px solid',
					borderColor: theme => theme.palette.background.blue04,
					borderRadius: '70px'
				}
			}}
			disabled={isDisabled()}
			onClick={() => {
				text === 'Request Access' ? onClick() : handleClick();
			}}
			endIcon={<img src={RightArrow} alt="rightArrow" />}
		>
			{text}
		</Button>
	);
}
