/* eslint-disable eqeqeq */
/* eslint-disable react/jsx-boolean-value */
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Box from '@mui/material/Box';
import Download from '../../../assets/marketplace/download.svg';
import Chips from './chips';
import GoButton from './cardButton';
import MarketplaceChip from '../../marketplace/chip/marketplaceChip';
import { addAccessRequestSolver } from '../../../redux/solverAdminSlice';
import { addAccessRequestHardware } from '../../../redux/hardwareAdminSlice';
import MarketplaceDialogBox from '../../dialogBox/marketplace/index';
import CustomisedSnackbar from '../../snackbar/projects/index';
import SolverImage from '../../../assets/marketplace/image.svg';
import HardwareImage from '../../../assets/marketplace/image4.svg';

function MarketplaceCard({
	technology,
	downloads,
	name,
	per,
	price,
	content,
	cardimage,
	hardwareimage,
	statusimage,
	chipdata,
	tabvalue,
	hardwareId,
	solverId,
	type,
	// eslint-disable-next-line no-unused-vars
	category,
	solverImage
}) {
	const [isSolver, setIsSolver] = useState(false);
	const dispatch = useDispatch();
	const { user } = useSelector(state => state.common);
	const { solverdata, data } = useSelector(state => state.marketplace);
	const { allMySolvers } = useSelector(state => state.solver);
	const { allMyHardwares } = useSelector(state => state.hardware);
	const [openDialogBox, setOpenDialogBox] = useState(false);
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState(false);

	const navigate = useNavigate();
	const onViewDetailsClick = () => {
		if (tabvalue === 'Solvers') navigate('/marketplace/solvers');
		else navigate('/marketplace/hardware');
	};

	useEffect(() => {
		setIsSolver(false);
		if (type === 'solver') {
			setIsSolver(true);
		}
	});

	const onRequestAccess = () => {
		let tempArray = {};
		const allMySolverHardware = type === 'solver' ? [...allMySolvers] : [...allMyHardwares];
		const mainData = type === 'solver' ? { ...solverdata } : { ...data };
		let index = '';
		if (type === 'solver')
			index = allMySolverHardware?.findIndex(e => e?.solverId === parseInt(solverId, 10));
		else index = allMySolverHardware?.findIndex(e => e?.hardwareId === parseInt(hardwareId, 10));
		if (index == -1) {
			let i = '';
			if (type === 'solver')
				i = mainData?.details?.findIndex(e => e?.solverId === parseInt(solverId, 10));
			else i = mainData?.details?.findIndex(e => e?.hardwareId === parseInt(hardwareId, 10));
			if (i != -1) tempArray = { ...mainData?.details[i] };
			tempArray['requestDate'] = new Date().toISOString();
			if (user?.attributes) {
				if (user?.attributes['custom:isOrganisation'] === 'True')
					tempArray['requestedBy'] = user?.attributes['custom:organisationName'];
				else tempArray['requestedBy'] = user?.attributes?.given_name;
			}
			if (type === 'solver') dispatch(addAccessRequestSolver({ solver: tempArray }));
			else dispatch(addAccessRequestHardware({ hardware: tempArray }));
			setOpenDialogBox(false);
			setOpenSnackbar(true);
			setSnackbarMessage('Access Requested Successfully!');
		} else {
			setOpenDialogBox(false);
			setOpenSnackbar(true);
			setSnackbarMessage('Access granted already!');
		}
	};

	return (
		<>
			<MarketplaceDialogBox
				openDialogBox={openDialogBox}
				setOpenDialogBox={setOpenDialogBox}
				title="Confirm Request"
				message="Are you sure you want to request access?"
				confirmButtonTitle="Request Access"
				handler={onRequestAccess}
			/>
			<CustomisedSnackbar
				testId="solversSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			<Card
				sx={{
					borderTopLeftRadius: 0,
					borderTopRightRadius: 0,
					borderBottomRightRadius: 8,
					borderBottomLeftRadius: 8
				}}
			>
				{cardimage ? (
					<CardMedia sx={{ height: 116 }} image={cardimage} />
				) : type === 'solver' ? (
					<CardMedia sx={{ height: 116 }} image={SolverImage} />
				) : (
					<CardMedia sx={{ height: 116 }} image={HardwareImage} />
				)}

				<CardContent sx={{ background: 'rgba(28, 28, 70, 0.4)' }}>
					<Box
						sx={{
							display: 'flex',
							justifyContent: 'space-between',
							alignItems: 'center',
							padding: '2px 0px 0px 10px',
							height: '28px',
							background: isSolver ? 'rgba(139, 49, 255, 0.4)' : 'rgba(48, 48, 103, 0.7)',
							borderRadius: '4px',
							marginBottom: '5px'
						}}
					>
						<Box sx={{ width: '80%' }}>{technology}</Box>
						<Box
							sx={{
								display: 'flex',
								allignItems: 'center',
								gap: '4px',
								width: '42px',
								height: '16px'
							}}
						>
							<Box>
								<img src={Download} style={{ marginBottom: '5px' }} alt="download" />
							</Box>
							<Box sx={{ fontSize: '10px', fontWeight: '500', color: '#FFF' }}>{downloads}</Box>
						</Box>
					</Box>
					<Box
						sx={{
							display: 'flex',
							justifyContent: 'space-between',
							height: '78.5px'
						}}
					>
						<Box>
							<Box
								sx={{
									display: 'flex',
									padding: '8px 0 8px 2px'
								}}
							>
								<Box sx={{ marginRight: '8px' }}>
									{type === 'solver' ? (
										<img src={solverImage} alt="hardwareImage" />
									) : (
										<img src={hardwareimage} alt="solverImage" />
									)}
								</Box>
								<Box sx={{ marginRight: '8px' }}>{name}</Box>
								<Box>
									<img src={statusimage} alt="statusImage" />
								</Box>
							</Box>
							{chipdata ? (
								<Box sx={{ marginLeft: '-2px' }}>
									{type === 'solver' ? (
										<Box marginLeft="-7px">
											<MarketplaceChip items={chipdata} isExpandable={false} />
										</Box>
									) : (
										<Chips chipdata={chipdata} />
									)}
								</Box>
							) : type === 'solver' ? (
								<Box sx={{ height: '49px' }} />
							) : (
								<Box sx={{ height: '32px' }} />
							)}
						</Box>
						<Box sx={{ display: 'grid', placeItems: 'center', paddingRight: '3px' }}>
							<Box>
								<Box sx={{ color: '#FFF', fontWeight: '500', fontSize: '14px' }}>${price}</Box>
								<Box sx={{ fontSize: '10px', color: '#86869A' }}> per {per}</Box>
							</Box>
						</Box>
					</Box>
					<Box
						sx={{
							margin: '12px 0 0 6px',
							fontSize: '14px',
							height: '66px',
							display: 'grid',
							placeItems: 'center',
							textAlign: 'left'
						}}
					>
						{content}
					</Box>

					<Box
						sx={{ width: '100%', display: 'grid', placeitems: 'center', padding: '12px 0 5px 0' }}
					>
						<Box
							sx={{
								backgroundColor: '#222249',
								height: '1px',
								margin: '5px 0 5px 0px'
							}}
						/>
					</Box>

					<Box
						sx={{ display: 'flex', justifyContent: 'space-between', padding: '10px 3px 12px 3px' }}
					>
						<GoButton
							text="View Details"
							type={type}
							hardwareId={hardwareId}
							tabvalue={tabvalue}
							solverId={solverId}
							onClick={onViewDetailsClick}
							variant="outlined"
						/>
						<GoButton
							text="Request Access"
							bgcolor="#5552FF"
							type={type}
							hardwareId={hardwareId}
							tabvalue={tabvalue}
							solverId={solverId}
							variant="contained"
							onClick={() => setOpenDialogBox(true)}
						/>
					</Box>
				</CardContent>
			</Card>
		</>
	);
}

export default MarketplaceCard;
