/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Skeleton from '@mui/material/Skeleton';
import CopyButton from '../../copyButton';
import OverflowTooltip from '../../tooltip/overflowTooltip';

function AddressCard({ address, isLoading }) {
	return (
		<Box
			sx={{
				width: '100%',
				height: '88px',
				padding: '20px 10px',
				border: '1px solid',
				borderRadius: '8px',
				borderColor: theme => theme.palette.background.blue03,
				backgroundColor: theme => theme.palette.background.blue12
			}}
		>
			<Typography sx={{ color: theme => theme.palette.text.secondary }}>Address</Typography>
			{isLoading ? (
				<Skeleton variant="rounded" width="80%" height={14} sx={{ marginTop: '7px' }} />
			) : (
				<Box sx={{ display: 'flex', alignItems: 'center' }}>
					<OverflowTooltip
						fontSize="12px"
						color={theme => theme.palette.text.gray03}
						length={60}
						title={address}
					/>
					{address !== 'Address Not Found !' && (
						<CopyButton content={address} margin="0px 0px 0px 5px" />
					)}
				</Box>
			)}
		</Box>
	);
}

export default AddressCard;
