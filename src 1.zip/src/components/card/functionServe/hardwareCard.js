/* eslint-disable react/no-array-index-key */
/* eslint-disable react/jsx-boolean-value */
import React from 'react';
import { Typography, Box, Grid } from '@mui/material';
import Divider from '@mui/material/Divider';
import Skeleton from '@mui/material/Skeleton';
import Icon from '../../icon';
// import img from '../../../../assets/actions/add.svg';
import sucess from '../../../assets/SuccessIcon.svg';
import theme from '../../../theme';
import covalent from '../../../assets/icons/covalent-tag.svg';
import nvidia from '../../../assets/nvidia.svg';
import CopyButton from '../../copyButton/index';

function StyledDivider() {
	return (
		<Divider
			sx={{ borderColor: theme.palette.background.blue03 }}
			orientation="vertical"
			variant="middle"
			flexItem
		/>
	);
}

function HardwareCard({ data, isLoading }) {
	return (
		<Grid
			container
			width="100%"
			display="flex"
			justifyContent="space-between"
			alignSelf="center"
			padding="10px 20px 10px 20px"
			height="100%"
		>
			{/* First Part */}
			<Grid item xs={4} alignSelf="center">
				<Box display="flex" pb="6px">
					{isLoading ? (
						<Skeleton
							variant="rounded"
							width={130}
							height={20}
							sx={{ margin: '0px 0px 3px 0px' }}
						/>
					) : (
						<>
							<Typography fontWeight="bold" color={theme.palette.text.secondary} fontSize="16px">
								{data?.title}
							</Typography>
							<Box sx={{ padding: '0px 4px 0px 4px' }}>
								<Icon src={sucess} alt="sucess" />
							</Box>
							<CopyButton
								content={data?.title}
								borderEnable={false}
								placement="top"
								bgColor={theme.palette.background.blue14}
								padding="4px"
								display="flex"
							/>
						</>
					)}
				</Box>
				<Grid container display="flex">
					{isLoading ? (
						<Skeleton variant="rounded" width={170} height={27} sx={{ margin: '0px' }} />
					) : (
						data?.tags.map((tag, tagIndex) => (
							<Box
								key={tagIndex}
								bgcolor="#1C1C46B2"
								border="0.5px solid #303067"
								borderRadius="4px"
								mr="12px"
							>
								<Grid item padding="0px 1px 0px 1px">
									{/* <Icon src={tag} alt={`Tag ${tagIndex + 1}`} /> */}
									{tag === 'covalent' && <Icon src={covalent} alt="nvidia" />}
									{tag === 'nvidia' && <Icon src={nvidia} alt="nvidia" />}
									{tag === 'GPU' && (
										<Typography fontSize="14px" fontWeight="bold" mt="2px" p="1px">
											GPU
										</Typography>
									)}
								</Grid>
							</Box>
						))
					)}
				</Grid>
			</Grid>

			{/* Divider */}
			<StyledDivider />

			{/* Cost */}
			<Grid item xs={3} alignSelf="center" padding="0px 20px">
				<Typography
					sx={{
						color: theme.palette.text.blue01,
						fontSize: '12px',
						paddingBottom: '8px'
					}}
				>
					Cost
				</Typography>
				<Typography
					sx={{
						fontSize: '18px',
						fontWeight: 'bold'
					}}
				>
					{isLoading ? (
						<Skeleton variant="rounded" width={80} height={27} sx={{ margin: '0px' }} />
					) : (
						data?.cost
					)}
				</Typography>
			</Grid>

			{/* Divider */}
			<StyledDivider />

			{/* Second Part */}
			<Grid
				item
				pt="5px"
				xs={4}
				alignSelf="center"
				padding="10px 0px 10px 25px"
				height="100%"
				sx={{ display: 'flex', justifyContent: 'space-around', flexDirection: 'column' }}
			>
				{Object.entries(data?.parameters).map(([key, value], paramIndex) => (
					<Box
						key={paramIndex}
						sx={{
							display: 'flex',
							justifyContent: 'space-between',
							spacing: 2
						}}
					>
						<Box sx={{ padding: '0px 0px 0px 0px', width: '50%' }}>
							<Typography sx={{ color: theme.palette.text.gray03, fontSize: '12px' }}>
								{key}
							</Typography>
						</Box>
						<Box sx={{ padding: '0px 0px 0px 0px', width: '50%' }}>
							{isLoading ? (
								<Skeleton
									variant="rounded"
									width={80}
									height={18}
									sx={{ margin: '0px 0px 3px 0px' }}
								/>
							) : (
								<Typography fontSize="14px">{value}</Typography>
							)}
						</Box>
					</Box>
				))}
			</Grid>
		</Grid>
	);
}

export default HardwareCard;
