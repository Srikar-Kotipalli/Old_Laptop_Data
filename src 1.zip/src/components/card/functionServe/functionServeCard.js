/* eslint-disable no-unused-vars */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import moment from 'moment';
import { useNavigate } from 'react-router-dom';
import CopyButton from '../../copyButton';
import Icon from '../../icon';
import LockIcon from '../../../assets/actions/lock.svg';
import { functionServeStatus } from '../../../utils/statusIcons';
// import DeleteIcon from '../../../assets/actions/deleteRed.svg';
import OverflowTooltip from '../../tooltip/overflowTooltip';
import { Capitalize, DateTimeSeparatorFunctionServe } from '../../../utils/utils';
import routes from '../../../constants/routes.json';

function FunctionServeCard({ data }) {
	const navigate = useNavigate();
	const navigateTo = () => {
		navigate(`${routes?.FUNCTION_SERVE}/${data?.id}/Overview`, { state: { functionVal: data } });
	};

	const calculateExpiryDate = () => {
		return moment(new Date(data?.created_at)).add(data?.executor?.time_limit, 'seconds');
	};

	const getEndpointCount = list => {
		return Array.isArray(list) ? list?.length : 0;
	};

	return (
		<Box
			mb={1.5}
			onClick={navigateTo}
			sx={{
				cursor: 'pointer',
				display: 'flex',
				justifyContent: 'space-between',
				padding: '15px',
				width: '98.5%',
				background: theme => theme.palette.background.blue08,
				height: '104px',
				border: '1px solid',
				borderColor: theme => theme.palette.background.blue03,
				borderRadius: '6px',
				'&:hover': {
					backgroundColor: theme => theme.palette.background.blue17
				}
			}}
		>
			<Box id="left" sx={{ width: '50%' }}>
				<Box id="titleSection" sx={{ display: 'flex', alignItems: 'center' }}>
					<Typography variant="h2" sx={{ color: theme => theme.palette.text.gray04 }}>
						{data?.title}
					</Typography>
					<Box pl={1}>
						<CopyButton content={data?.title} title="Copy name" placement="top" />
					</Box>
					{Array.isArray(data?.inference_keys) && data?.inference_keys?.length > 0 && (
						<Icon src={LockIcon} margin="0px 0px 0px 3px" />
					)}
					{functionServeStatus(data?.status)}
				</Box>
				<Box id="idSection" mt={0.5} sx={{ display: 'flex', alignItems: 'center' }}>
					<Typography
						variant="h3"
						sx={{ color: theme => theme.palette.text.blue01, fontFamily: 'DM Mono' }}
					>
						{data?.id}
					</Typography>
					<Box ml={1}>
						<CopyButton content={data?.id} placement="top" />
					</Box>
				</Box>
				<Box id="descriptionSection" mt={0.5}>
					<OverflowTooltip
						fontSize="12px"
						title={data?.description}
						length={400}
						color={theme => theme.palette.text.gray03}
					/>
				</Box>
			</Box>
			<Box
				mr={3}
				id="centerSection"
				sx={{
					height: '100%',
					display: 'flex',
					flexDirection: 'column',
					justifyContent: 'space-between'
				}}
			>
				<DateTimeSeparatorFunctionServe title="Created Date" date={data?.created_at} />
				<DateTimeSeparatorFunctionServe
					title="Expiration"
					date={data?.expires_at || calculateExpiryDate()}
				/>
				<DateTimeSeparatorFunctionServe
					title="Endpoints"
					date={getEndpointCount(data?.endpoints)}
				/>

				{/* <TimeComponent title="Created Date" value={dateTimeSeparator(data?.createdAt)} />
				<TimeComponent title="Expiration" value={dateTimeSeparator(data?.expirationTime)} />
				<TimeComponent title="Endpoints" value={data?.endpoints} /> */}
			</Box>
			{/* <Box
				id="RightSection"
				sx={{
					width: '10%',
					height: '100%',
					display: 'flex',
					flexDirection: 'column',
					justifyContent: 'center',
					alignItems: 'center'
				}}
			>
				<Icon
					margin="0px 0px 0px 30px"
					src={DeleteIcon}
					alt="Delete icon"
					clickHandler={() => onDelete(data.title)}
				/>
			</Box> */}
		</Box>
	);
}

export default FunctionServeCard;
