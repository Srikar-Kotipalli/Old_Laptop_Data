/* eslint-disable react/jsx-boolean-value */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import CopyButton from '../../copyButton';
import BasicButton from '../../basicButton';
import OverflowTooltip from '../../tooltip/overflowTooltip';
import { testEndpointFunction } from '../../../api/functionServe/functionServeApi';
import ResultPane from '../../resultPane';

function EndpointCard({
	message,
	endpoint,
	selectedEndpoint,
	selectEndPoint,
	invokeUrl,
	functionId,
	apiKey,
	setOpenSnackbar,
	setSnackbarMessage,
	disableInteractions
}) {
	const [open, setOpen] = useState(false);
	const [data, setData] = useState({});

	const handleClickTest = () => {
		testEndpointFunction(`${invokeUrl}${endpoint?.route}`, apiKey)
			.then(res => {
				setOpen(true);
				setData(res);
			})
			.catch(err => {
				console.log(err);
				setOpenSnackbar(true);
				setSnackbarMessage('Something went wrong, please contact the administrator');
			});
	};

	const onClickTestEndpoint = e => {
		e?.stopPropagation();
		if (!disableInteractions) {
			handleClickTest();
		}
	};

	return (
		<Box
			sx={{
				display: 'flex',
				alignItems: 'center',
				marginTop: '10px',
				width: '98%',
				height: '88px',
				padding: '10px',
				border: '1px solid',
				borderRadius: '8px',
				cursor: 'pointer',
				borderColor: theme => theme.palette.background.blue03,
				backgroundColor:
					selectedEndpoint?.endpoint_fn === endpoint?.endpoint_fn
						? theme => theme.palette.background.qElectronList
						: 'transparent',
				'&:hover': {
					backgroundColor: theme => theme.palette.background.covalentPurple
				}
			}}
			onClick={() => selectEndPoint(endpoint)}
		>
			<Box sx={{ width: '60%' }}>
				<Box sx={{ display: 'flex', alignItems: 'center' }}>
					<OverflowTooltip
						fontSize="14px"
						length={50}
						color={theme => theme.palette.text.blue01}
						title={endpoint?.route}
					/>
					{/* <Typography variant="h2" sx={{ color: theme => theme.palette.text.blue01 }}>
						{endpoint?.endpoint}
					</Typography> */}
					<CopyButton
						margin="0px 0px 0px 5px"
						content={`${invokeUrl?.replace(functionId, endpoint?.endpoint_fn)}${endpoint?.route}`}
					/>
				</Box>
				<Box
					sx={{
						cursor: 'default',
						display: '-webkit-box',
						WebkitLineClamp: 2,
						WebkitBoxOrient: 'vertical',
						overflow: 'hidden',
						textOverflow: 'ellipsis'
					}}
				>
					{/* <OverflowTooltip
						fontSize="14px"
						length={50}
						color={theme => theme.palette.text.gray03}
						title="Prompt the LLM to generate a text response of specified length"
					/> */}
					<Typography variant="h2" sx={{ color: theme => theme.palette.text.gray03 }}>
						{endpoint?.description}
					</Typography>
				</Box>
			</Box>
			<Box
				id="buttonBox"
				sx={{ width: '40%', display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}
			>
				<BasicButton
					disabled={endpoint?.test_endpoint_enabled || disableInteractions}
					title="Test Endpoint"
					message={message}
					onClick={e => {
						onClickTestEndpoint(e);
					}}
				/>
			</Box>
			<ResultPane open={open} setOpen={setOpen} data={data} />
		</Box>
	);
}

export default EndpointCard;
