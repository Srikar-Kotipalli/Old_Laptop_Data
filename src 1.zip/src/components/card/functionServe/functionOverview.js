/* eslint-disable no-unused-vars */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';
import Tooltip from '@mui/material/Tooltip';
import Skeleton from '@mui/material/Skeleton';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import { useNavigate } from 'react-router-dom';
import OverflowTooltip from '../../tooltip/overflowTooltip';
import CopyButton from '../../copyButton';
import Launch from '../../../assets/actions/launch.svg';
import ArrowRight from '../../../assets/arrows/arrowRight.svg';
import Icon from '../../icon';
import { functionServeStatus, statusIcon } from '../../../utils/statusIcons';
import { DateTimeSeparator, timeFormatter } from '../../../utils/utils';
import routes from '../../../constants/routes.json';
import HardwareCard from './hardwareCard';

function MetricGrid({
	title,
	value,
	link,
	handleClickLink,
	isLoading,
	type,
	width,
	cardWidth = '30px'
}) {
	return (
		<Box display="flex" flexDirection="row" height="18px" justifyContent="space-between">
			<Typography
				fontSize="12px"
				sx={{
					color: theme => theme.palette.text.blue01,
					width
				}}
			>
				{title}
			</Typography>
			<div style={{ display: 'flex', marginLeft: '10px', width: cardWidth }}>
				{isLoading ? (
					<Skeleton variant="rounded" width={cardWidth} height={20} sx={{ marginTop: '2px' }} />
				) : (
					<>
						{type === 'date' ? (
							<DateTimeSeparator date={value} />
						) : (
							<Typography
								fontSize="14px"
								fontWeight="700"
								sx={{ whiteSpace: 'nowrap', alignSelf: 'center' }}
							>
								{value}
							</Typography>
						)}

						{link && (
							<Icon
								src={Launch}
								display="flex"
								alt="Source"
								padding="3px"
								margin="0px 0px 0px 3px"
								title="Source"
								clickHandler={handleClickLink}
								bgColor={theme => theme.palette.background.blue14}
								placement="right"
							/>
						)}
					</>
				)}
			</div>
		</Box>
	);
}

export function FunctionOverviewCard(props) {
	const navigate = useNavigate();
	const { disableInteractions } = useSelector(state => state.functionServe);
	const { data, onTearDown, isLoading } = props;

	const calculateExpiryDate = () => {
		return moment(new Date(data?.created_at)).add(data?.executor?.time_limit, 'seconds');
	};

	const handleClickSource = () => {
		if (data?.root_dispatch_id) {
			navigate(`${routes.GRAPH}/${data?.root_dispatch_id}`);
		}
	};

	const handleClickTeardown = () => {
		if (!disableInteractions) onTearDown();
	};

	return (
		<Box
			sx={{
				width: '100%',
				height: '151px',
				minWidth: '592px',
				padding: '16px 15px',
				border: '1px solid',
				borderRadius: '8px',
				borderColor: theme => theme.palette.background.blue03,
				backgroundColor: theme => theme.palette.background.blue12
			}}
		>
			<Grid container justifyContent="space-between" flexDirection="column" height="100%">
				<Grid
					sx={{ display: 'flex', justifyContent: 'space-between', height: '47px', width: '100%' }}
				>
					<Grid item xs={9} display="flex" justifyContent="space-between" flexDirection="column">
						{isLoading ? (
							<Skeleton
								variant="rounded"
								width={460}
								height={20}
								sx={{ margin: '3px 0px 0px 8px' }}
							/>
						) : (
							<Box sx={{ display: 'flex', alignItems: 'center' }}>
								<OverflowTooltip
									fontSize="14px"
									color={theme => theme.palette.text.blue01}
									length={48}
									title={data?.invoke_url !== null ? data?.invoke_url : 'Address Not Found !'}
									fontFamily="DM Mono"
								/>
								{data?.invoke_url !== null && (
									<CopyButton content={data?.invoke_url} margin="0px 10px 0px 7px" />
								)}
								{functionServeStatus(data?.status)}
							</Box>
						)}
						{isLoading ? (
							<Skeleton
								variant="rounded"
								width={135}
								height={20}
								sx={{ margin: '3px 0px 0px 8px' }}
							/>
						) : (
							<OverflowTooltip
								fontSize="12px"
								color={theme => theme.palette.text.gray03}
								length={50}
								title={data?.description || ''}
							/>
						)}
					</Grid>
					<Grid item xs={2}>
						<Button
							disabled={disableInteractions}
							sx={{
								width: '90px',
								height: '30px',
								border: !disableInteractions ? '0.5px solid #FF6464' : '0.5px solid #86869A',
								borderRadius: '4px',
								background: !disableInteractions
									? theme => theme.palette.background.failed20
									: theme => theme.palette.background.gray0333,
								padding: '2px 16px',
								color: theme => theme.palette.text.failed,
								':disabled': {
									color: theme => theme.palette.text.gray03
								}
							}}
							onClick={handleClickTeardown}
						>
							Teardown
						</Button>
					</Grid>
				</Grid>
				<Grid sx={{ display: 'flex', height: '42px' }}>
					<Grid sx={{ display: 'flex', justifyContent: 'space-between', flexDirection: 'column' }}>
						<MetricGrid
							title="Created"
							width="60px"
							cardWidth="125px"
							type="date"
							value={data?.created_at}
							addDivider
							isLoading={isLoading}
						/>
						<MetricGrid
							title="Expiration"
							width="60px"
							type="date"
							cardWidth="125px"
							value={data?.expires_at || calculateExpiryDate()}
							addDivider
							isLoading={isLoading}
						/>
					</Grid>
					<Divider
						sx={{
							width: '1px',
							height: '42px',
							margin: '0px 30px',
							backgroundColor: theme => theme.palette.background.blue03
						}}
					/>
					<Grid sx={{ display: 'flex', justifyContent: 'space-between', flexDirection: 'column' }}>
						<MetricGrid
							title="Running Duration"
							value={timeFormatter(data?.executor?.time_limit)}
							cardWidth="30px"
							addDivider
							isLoading={isLoading}
							width="105px"
						/>
						<MetricGrid
							width="40px"
							title="Source"
							cardWidth="85px"
							value={data?.root_dispatch_id ? 'Workflow' : 'None'}
							link={!!data?.root_dispatch_id}
							handleClickLink={handleClickSource}
							isLoading={isLoading}
						/>
					</Grid>
				</Grid>
			</Grid>
		</Box>
	);
}

export function FunctionEnvironmentCard(props) {
	const { environmentDetails, isLoading } = props;
	const navigate = useNavigate();

	// navigate to specific environment detail page
	const navigateTo = event => {
		event.stopPropagation();
		if (environmentDetails) {
			if (environmentDetails?.envId !== 0) {
				navigate(`${routes?.ENVIRONMENTS}/${environmentDetails?.envId}`);
			}
		}
	};

	return (
		<Box
			sx={{
				width: '100%',
				minWidth: '592px',
				padding: '10px 20px',
				margin: '10px 0px',
				border: '1px solid',
				borderRadius: '8px',
				display: 'flex',
				justifyContent: 'space-between',
				borderColor: theme => theme.palette.background.blue03,
				cursor: isLoading ? 'default' : 'pointer',
				'&:hover': {
					backgroundColor: isLoading ? 'none' : theme => theme.palette.background.covalentPurple
				}
			}}
			disabled={isLoading}
			onClick={e => !isLoading && navigateTo(e)}
		>
			<Box display="flex">
				<Typography
					sx={{ color: theme => theme.palette.text.gray03, fontSize: '16px', display: 'flex' }}
				>
					Environment Name :{' '}
					{isLoading ? (
						<Skeleton
							variant="rounded"
							width={170}
							height={20}
							sx={{ margin: '3px 0px 0px 8px' }}
						/>
					) : (
						<Box sx={{ display: 'flex' }}>
							<span style={{ color: '#FFF', marginLeft: '8px' }}>
								{' '}
								{environmentDetails?.envName || ''}
							</span>
							<Tooltip title={environmentDetails?.status} placement="bottom">
								<Box ml={0.7}>
									{statusIcon(environmentDetails?.status, '0px 0px 2px 0px', 'env')}
								</Box>
							</Tooltip>
							<CopyButton content={environmentDetails?.envName} margin="0px 10px 0px 7px" />
						</Box>
					)}
				</Typography>
			</Box>
			<Icon
				disabled={isLoading}
				padding="4px"
				bgColor="#08081a"
				src={ArrowRight}
				title="View Environment"
				margin="1.6px 0px 0px 16px"
				type="cursor"
			/>
		</Box>
	);
}

export function FunctionHardwareCard({ data, isLoading }) {
	return (
		<Box
			display="flex"
			sx={{
				width: '100%',
				minWidth: '592px',
				height: '126px',
				// padding: '20px 10px',
				margin: '10px 0px',
				border: '1px solid',
				borderRadius: '8px',
				borderColor: theme => theme.palette.background.blue03,
				backgroundColor: theme => theme.palette.background.blue12
				// commented for the timebeing as there is no interaction
				// '&:hover': {
				// 	backgroundColor: theme => theme.palette.background.covalentPurple
				// }
			}}
		>
			<HardwareCard data={data} isLoading={isLoading} />
		</Box>
	);
}
