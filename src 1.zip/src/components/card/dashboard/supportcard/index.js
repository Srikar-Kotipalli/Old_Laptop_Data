import { Grid, Typography } from '@mui/material';
import React from 'react';
import Icon from '../../../icon';
import SupportIcon from '../../../../assets/dashboard/support.svg';

function SupportCard({ title, link }) {
	return (
		<Grid container item xs={3} direction="row" alignItems="center">
			<Icon src={SupportIcon} alt="support" />
			<Typography
				pl={1}
				variant="h2"
				sx={{
					display: 'flex',
					cursor: 'pointer',
					'&:hover': {
						textDecoration: 'underline',
						color: theme => theme.palette.text.secondary
					}
				}}
				onClick={link ? () => window.open(`${link}`, '_blank') : null}
			>
				{title}
			</Typography>
		</Grid>
	);
}

export default SupportCard;
