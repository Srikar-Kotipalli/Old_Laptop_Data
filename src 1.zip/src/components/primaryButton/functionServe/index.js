/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import PropTypes from 'prop-types';
import Icon from '../../icon';

function CustomButton({
	onClick,
	title,
	bgColor,
	color,
	width,
	cursor,
	borderRadius,
	borderColor,
	hoverColor,
	fontSize,
	height,
	startIcon,
	endIcon,
	padding,
	disabled,
	margin,
	maxWidth
}) {
	return (
		<Box
			display="flex"
			justifyContent="space-between"
			alignItems="center"
			disabled={disabled}
			onClick={onClick}
			sx={{
				height,
				margin,
				width,
				maxWidth,
				backgroundColor: bgColor || 'rgba(218, 195, 255, 0.10)',
				border: '0.2px solid',
				borderColor: borderColor || 'rgba(173, 123, 255, 0.70)',
				borderRadius,
				cursor: cursor || 'pointer',
				padding,
				':hover': {
					color: hoverColor
				}
			}}
		>
			<Box display="flex" alignItems="center">
				{startIcon && (
					<Icon type={cursor || 'pointer'} display="flex" src={startIcon} padding="0px" />
				)}
				<Typography color={color} variant="subtitle2" fontSize={fontSize} pr={1} pl={1}>
					{title}
				</Typography>
			</Box>
			{endIcon && (
				<Icon
					display="flex"
					height="14px"
					width="14px"
					type={cursor || 'pointer'}
					src={endIcon}
					padding="0px"
				/>
			)}
		</Box>
	);
}

CustomButton.propTypes = {
	width: PropTypes.string,
	height: PropTypes.string,
	title: PropTypes.string.isRequired,
	fontSize: PropTypes.string,
	borderRadius: PropTypes.string,
	padding: PropTypes.string,
	disabled: PropTypes.bool,
	maxWidth: PropTypes.string,
	margin: PropTypes.string,
	bgColor: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
	borderColor: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
	color: PropTypes.oneOfType([PropTypes.string, PropTypes.func])
};

CustomButton.defaultProps = {
	width: '218px',
	height: '32px',
	fontSize: '12px',
	bgColor: 'rgba(218, 195, 255, 0.10)',
	borderColor: 'rgba(173, 123, 255, 0.70)',
	color: theme => theme.palette.text.white01,
	borderRadius: '4px',
	padding: '2px 6px',
	disabled: false,
	maxWidth: '218px',
	margin: '0px'
};

export default CustomButton;
