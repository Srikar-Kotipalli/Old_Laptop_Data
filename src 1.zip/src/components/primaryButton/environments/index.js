/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { Button, Typography } from '@mui/material';
import React from 'react';

function BorderButton({ title, img, padding, paddingLeft, handler, overallMargin }) {
	return (
		<Button
			variant="outlined"
			sx={{
				'&:hover': {
					backgroundColor: theme => theme.palette.background.covalentPurple,
					color: '#FFFFFF',
					borderRadius: '25px',
					borderColor: theme => theme.palette.background.blue05
				},
				display: 'flex',
				justifyContent: 'center',
				borderRadius: '25px',
				height: '32px',
				margin: overallMargin
			}}
			onClick={handler}
		>
			<img src={img} alt={title} />
			<Typography variant="h2" pt={padding || 0} pl={paddingLeft}>
				{title}
			</Typography>
		</Button>
	);
}

export default BorderButton;
