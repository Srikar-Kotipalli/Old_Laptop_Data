/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import CustomScroll from 'react-custom-scroll';
import PropTypes from 'prop-types';
import './index.css';

const CustomScrolls = ({ variant = 'dark', children }) => {
	return (
		<CustomScroll
			className={variant === 'light' ? 'light' : null}
			heightRelativeToParent="calc(100%)"
			allowOuterScroll
		>
			{children}
		</CustomScroll>
	);
};

CustomScrolls.propTypes = {
	variant: PropTypes.oneOf(['light', 'dark']),
	children: PropTypes.node.isRequired
};

CustomScrolls.defaultProps = {
	variant: 'dark'
};

export default CustomScrolls;
