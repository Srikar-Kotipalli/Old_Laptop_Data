import React, { forwardRef } from 'react';
import { OverlayScrollbarsComponent, useOverlayScrollbars } from 'overlayscrollbars-react';
import 'overlayscrollbars/overlayscrollbars.css';

const CustomScrollbars = forwardRef(({ children, variant = 'dark' }, ref) => {
	useOverlayScrollbars({
		defer: true,
		events: {
			initialized: () => {
				setBodyOverlayScrollbarsApplied(true);
			},
			destroyed: () => {
				setBodyOverlayScrollbarsApplied(false);
			}
		},
		options: {
			scrollbars: {
				theme: 'os-theme-light',
				position: 'absolute'
			}
		}
	});

	return (
		<OverlayScrollbarsComponent
			ref={ref} // Pass the ref to OverlayScrollbarsComponent
			className="overlayscrollbars-react"
			defer
			options={{ scrollbars: { theme: variant === 'dark' ? 'os-theme-dark' : 'os-theme-light' } }}
		>
			{children}
		</OverlayScrollbarsComponent>
	);
});

export default CustomScrollbars;
