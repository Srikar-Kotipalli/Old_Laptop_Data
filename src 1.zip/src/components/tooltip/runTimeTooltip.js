/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React from 'react';
import Tooltip from '@mui/material/Tooltip';
import { tooltipTimeFormatter, timeFormatter } from '../../utils/utils';

function RunTimeTooltip(props) {
	const { value, placement } = props;
	return (
		<Tooltip title={value || value === 0 ? tooltipTimeFormatter(value) : ''} placement={placement}>
			<span>{value || value === 0 ? timeFormatter(value) : ' '}</span>
		</Tooltip>
	);
}

export default RunTimeTooltip;
