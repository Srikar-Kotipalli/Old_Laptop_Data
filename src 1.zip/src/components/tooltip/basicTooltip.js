/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useRef, useEffect } from 'react';

const OverflowTooltipB = ({ text }) => {
	const [isOverflowing, setIsOverflowing] = useState(false);
	const containerRef = useRef(null);
	const contentRef = useRef(null);

	useEffect(() => {
		const container = containerRef.current;
		const content = contentRef.current;

		if (container && content) {
			// Check if content is overflowing
			if (
				container.offsetWidth < content.offsetWidth ||
				container.offsetHeight < content.offsetHeight
			) {
				setIsOverflowing(true);
			} else {
				setIsOverflowing(false);
			}
		}
	}, [text]);

	return (
		<div
			style={{
				fontSize: '14px',
				position: 'relative',
				overflow: 'hidden',
				whiteSpace: 'nowrap',
				textOverflow: isOverflowing ? 'initial' : 'ellipsis'
			}}
			ref={containerRef}
		>
			<div
				style={{
					display: 'inline-block',
					verticalAlign: 'top'
				}}
				ref={contentRef}
			>
				{text}
			</div>
		</div>
	);
};

export default OverflowTooltipB;
