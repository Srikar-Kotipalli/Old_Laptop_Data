/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import { ProjectContext } from '../../../containers/projects/projectContext';

export default function DeletableTags(props) {
	const projectContext = React.useContext(ProjectContext);
	const { deleteTags } = projectContext;
	const { tags, deleteTagss, variant } = props;
	return (
		<Stack direction="row" spacing={1}>
			{tags.map(tag => (
				<Chip
					variant="filled"
					size="small"
					label={tag}
					key={tag}
					onDelete={() => (variant === 'shared' ? deleteTagss(tag) : deleteTags(tag))}
				/>
			))}
		</Stack>
	);
}
