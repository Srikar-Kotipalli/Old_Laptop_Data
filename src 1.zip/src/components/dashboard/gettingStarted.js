/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useRef } from 'react';
import { Box, Typography } from '@mui/material';
import { GettingStartedCard } from '../card/dashboard/revampedcards';
import GettingStartedIcon from '../../assets/dashboard/documentation/gettingStarted.svg';
import Guides from '../../assets/dashboard/documentation/guides.svg';
import ApiRef from '../../assets/dashboard/documentation/apiRef.svg';
import Blog from '../../assets/dashboard/documentation/blog.svg';
import Documentation from '../../assets/dashboard/documentation/documentation.svg';
import CustomScrollbars from '../customScroll/v2';

function GettingStarted() {
	const gettingStarted = [
		{
			img: GettingStartedIcon,
			heading: 'Quick Start',
			goTo: process.env.REACT_APP_GETTING_STARTED_GETTING_STARTED,
			iconPadding: '0 5px 0 5px'
		},
		{
			img: Guides,
			heading: 'Tutorials',
			goTo: process.env.REACT_APP_GETTING_STARTED_TUTORIALS
		},
		{
			img: Blog,
			heading: 'Covalent Blog',
			goTo: process.env.REACT_APP_GETTING_STARTED_COVALENT_BLOG
		},
		{
			img: ApiRef,
			heading: 'API Reference',
			goTo: process.env.REACT_APP_GETTING_STARTED_API_REFERENCE
		},
		{
			img: Documentation,
			heading: 'Documentation',
			goTo: process.env.REACT_APP_GETTING_STARTED_DOCUMENTATION
		}
	];
	const ref = useRef(null);
	// const handleRightClick = () => {
	// 	ref.current.scrollLeft += 60;
	// };

	// const handleLeftClick = () => {
	// 	ref.current.scrollLeft += -60;
	// };
	return (
		<Box
			sx={{
				border: theme => `1px solid ${theme.palette.background.covalentPurple}`,
				borderRadius: '8px',
				padding: '22px',
				height: '141px',
				width: '100%',
				cursor: 'pointer'
			}}
		>
			<div style={{ display: 'flex', justifyContent: 'space-between', margin: '0 0 27px 0' }}>
				<Typography
					sx={{ color: theme => theme.palette.text.secondary, fontSize: '16px', fontWeight: '400' }}
				>
					Documentation
				</Typography>
				{/* <SeeAll
					havePagination
					rightClick={handleRightClick}
					leftClick={handleLeftClick}
					haveSeeall={false}
				/> */}
			</div>
			<Box>
				<CustomScrollbars>
					<Box
						ref={ref}
						sx={{
							whiteSpace: 'nowrap',
							// overflowX: 'auto',
							paddingBottom: '16px',
							scrollBehavior: 'smooth'
						}}
					>
						{gettingStarted?.map(item => {
							return (
								<GettingStartedCard
									img={item?.img}
									heading={item?.heading}
									goTo={item?.goTo}
									key={item?.heading}
								/>
							);
						})}
					</Box>
				</CustomScrollbars>
			</Box>
		</Box>
	);
}

export default GettingStarted;
