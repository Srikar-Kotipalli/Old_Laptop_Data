/* eslint-disable quotes */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useEffect } from 'react';
// import { Box, Typography, Link, Tooltip, useTheme } from '@mui/material';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import { useSelector } from 'react-redux';
import useDidMountEffect from '../../utils/useDidMountEffect';
import { getActivityList } from '../../api/activity/activityApi';
// import { getTimeDifference, stringReducer } from '../../utils/utils';
// import { statusTitle } from '../../utils/statusIcons';
import ActivityList from '../sidebar/projects/activityList';
import Loader from '../loader';

function RevampedActivityList() {
	// const theme = useTheme();
	const [activityList, setActivityList] = useState([]);
	const [openActivityLoader, setOpenActivityLoader] = useState(false);
	// Live refresh
	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);

	useEffect(() => {
		setOpenActivityLoader(true);
		getActivityList(20)
			.then(payload => {
				const activityListPayload = payload?.items?.map(e => {
					return { ...e, sub_category: e.sub_category || 'Blank' };
				});
				setOpenActivityLoader(false);
				setActivityList(activityListPayload);
			})
			.catch(error => {
				setOpenActivityLoader(false);
				console.log(error);
			});
	}, []);

	useDidMountEffect(() => {
		getActivityList(20)
			.then(payload => {
				const activityListPayload = payload?.items?.map(e => {
					return { ...e, sub_category: e.sub_category || 'Blank' };
				});
				setActivityList(activityListPayload);
			})
			.catch(error => {
				console.log(error);
			});
	}, [liveRefresh]);
	return (
		<>
			{openActivityLoader && (
				<Loader
					isFetching={openActivityLoader}
					position="relative"
					width="100%"
					height="calc(100% - 80px)"
				/>
			)}
			{activityList?.length > 0 && !openActivityLoader && (
				<ActivityList items={activityList} height="250px" isDashboard />
			)}
			{activityList?.length === 0 && !openActivityLoader && (
				<Box
					sx={{ display: 'flex', height: '100%', alignItems: 'center', justifyContent: 'center' }}
				>
					<Typography>No recent activity</Typography>
				</Box>
			)}
		</>
	);
}

export default RevampedActivityList;
