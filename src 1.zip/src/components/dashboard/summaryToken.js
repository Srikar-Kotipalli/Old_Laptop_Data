/* eslint-disable no-unused-vars */
/* eslint-disable quotes */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useEffect, useContext } from 'react';

import {
	Skeleton,
	Box,
	Grid,
	Typography,
	Tooltip,
	InputAdornment,
	IconButton,
	Input,
	tooltipClasses
} from '@mui/material';
import { withStyles } from '@mui/styles';
import { Auth } from 'aws-amplify';
import { useDispatch, useSelector } from 'react-redux';
import { dispatchOverview } from '../../api/experiments/dispatchApi';
import { setDispatches, setIsOverview } from '../../redux/tourSlice';

import { SummaryCard } from '../card/dashboard/revampedcards';
import Icon from '../icon';
import CostImage from '../../assets/cost.svg';
import Refresh from '../../assets/tokenReset.svg';
import SettingsCopyButton from '../copyButton/settings';
import VisibilityOff from '../../assets/hardware/visibilityOff.svg';
import VisibilityOn from '../../assets/hardware/visibilityOn.svg';
import { getUserCharges } from '../../api/billing/billingApi';
import { getUserAPIKey } from '../../api/users/apiKey';
import { DashboardContext } from '../../containers/dashboard/contexts/DashboardContext';

function SummaryToken({
	headingImg,
	heading,
	value,
	isStartAdornReqd,
	startAdornFunction,
	type,
	TooltipColor,
	width,
	height,
	fontSize,
	iconWidth,
	iconHeight,
	CopyIcon,
	CopiedIcon,
	paddingVal,
	inputMargin,
	hidebuttonMargin,
	isLoading
}) {
	const [visible, setVisible] = useState(false);
	return type === 'dashboard' ? (
		<Box
			sx={{
				borderRadius: '8px',
				padding: '10px',
				background: theme => theme.palette.background.dashboardCard,
				boxShadow: '0px 4px 7px 0px rgba(0, 0, 0, 0.35);',
				height: '100%'
			}}
		>
			<Box sx={{ display: 'flex', marginBottom: '-5px' }}>
				<Icon src={headingImg} />
				<Typography
					sx={{
						marginLeft: '5px',
						display: 'flex',
						alignItems: 'center',
						color: theme => theme.palette.text.blue01,
						fontWeight: '700',
						fontSize: '14px'
					}}
				>
					{heading}
				</Typography>
			</Box>
			<Box sx={{ display: 'flex', mt: '15px' }}>
				{isLoading ? (
					<Skeleton
						variant="rounded"
						width={320}
						height={32}
						sx={{
							display: 'flex',
							marginRight: '4px',
							padding: '8px 12px',
							borderRadius: '60px',
							pt: 1.5
						}}
					/>
				) : (
					<Input
						sx={{
							display: 'flex',
							alignItems: 'center',
							justifyContent: 'center',
							textAlign: 'center',
							marginRight: '4px',
							padding: '8px 12px',
							pt: 1.5,
							width: '320px',
							height: '32px',
							background: theme => theme.palette.background.default,
							border: theme => `1px solid ${theme.palette.background.blue03}`,
							borderRadius: '60px',
							fontSize: visible ? '12px' : '14px',

							color: theme => theme.palette.text.primary,
							'&MuiInput-input.Mui-disabled': {}
						}}
						disabled={false}
						inputProps={{ readOnly: true }}
						disableUnderline
						value={visible ? value : '*********************************'}
						startAdornment={
							isStartAdornReqd ? (
								<InputAdornment position="start">
									<Tooltip title="Click to refresh API Key" placement="top">
										<Grid>
											<Icon
												padding="0 0 6px 0"
												src={Refresh}
												alt="refresh"
												// type="pointer"
												clickHandler={() => startAdornFunction()}
											/>
										</Grid>
									</Tooltip>
								</InputAdornment>
							) : null
						}
						endAdornment={
							<InputAdornment position="end">
								<Tooltip title={visible ? 'Hide' : 'Unhide'} placement="top">
									<Grid>
										<Icon
											padding="0 0 6px 0"
											src={visible ? VisibilityOn : VisibilityOff}
											alt="visibilityOff"
											type="pointer"
											clickHandler={() => setVisible(prev => !prev)}
										/>
									</Grid>
								</Tooltip>
							</InputAdornment>
						}
					/>
				)}

				<Box
					sx={{
						padding: '6px',
						border: theme => `1px solid ${theme.palette.background.blue03}`,
						borderRadius: '8px',
						width: '32px',
						height: '32px',
						display: 'flex',
						alignItems: 'center'
					}}
				>
					<SettingsCopyButton
						content={value}
						copyIcon={CopyIcon}
						copiedIcon={CopiedIcon}
						title="Copy"
					/>
				</Box>
			</Box>
		</Box>
	) : (
		<Box sx={{ display: 'flex' }}>
			<Tooltip
				componentsProps={{
					popper: {
						sx: {
							[`& .${tooltipClasses.arrow}`]: {
								color: TooltipColor || null
							},
							[`& .${tooltipClasses.tooltip}`]: {
								backgroundColor: TooltipColor || null
							}
						}
					}
				}}
				placement="top"
				title={visible ? value : ''}
			>
				<Input
					sx={{
						margin: inputMargin || '0 10px 0 0',
						padding: '8px 12px',
						pt: !visible ? 1.5 : 1,
						width: width || '100%',
						height: height || '32px',
						background: '#08081A',
						border: '1px solid #303067',
						borderRadius: '60px',
						fontSize: fontSize || '14px',
						color: '#CBCBD7',
						transition: 'width 0.3s ease-in-out',
						'&MuiInput-input.Mui-disabled': {}
					}}
					disabled={false}
					disableUnderline
					value={visible ? value : '*************************************'}
					startAdornment={
						isStartAdornReqd && (
							<InputAdornment position="start">
								<IconButton size="small">
									<img src={reactIcon} alt="reactIcon" role="presentation" />
								</IconButton>
							</InputAdornment>
						)
					}
				/>
			</Tooltip>
			<Box
				sx={{
					margin: hidebuttonMargin || '0 10px 0 0',
					padding: paddingVal || '3px 4px',
					border: '1px solid #303067',
					borderRadius: '8px',
					width: iconWidth || '32px',
					height: iconHeight || '32px'
				}}
			>
				<Tooltip title={visible ? 'Hide' : 'Unhide'} placement="top">
					<Grid>
						<Icon
							// src={visible ? visibilityOn : visibilityOff}
							src={visible ? VisibilityOn : VisibilityOff}
							alt="visibilityOff"
							type="pointer"
							clickHandler={() => setVisible(prev => !prev)}
						/>
					</Grid>
				</Tooltip>
			</Box>
			<Box
				sx={{
					padding: paddingVal || '3px 4px',
					border: '1px solid #303067',
					borderRadius: '8px',
					width: iconWidth || '32px',
					height: iconHeight || '32px'
				}}
			>
				<SettingsCopyButton
					content={value}
					copyIcon={CopyIcon}
					copiedIcon={CopiedIcon}
					title="Copy"
				/>
			</Box>
		</Box>
	);
}

export default SummaryToken;
