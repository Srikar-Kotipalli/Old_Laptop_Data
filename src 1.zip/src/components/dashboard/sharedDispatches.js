/* eslint-disable object-shorthand */
/* eslint-disable quotes */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useEffect } from 'react';

import { Box, Typography, Grid } from '@mui/material';
import { SharedDispatchCard, SeeAll } from '../card/dashboard/revampedcards';
import { allSharedItemsList } from '../../api/shared/sharedApi';
import Loader from '../loader';

function SharedDispatches() {
	const [sharedList, setSharedList] = useState([]);
	const [openLoader, setOpenLoader] = useState(false);
	const [itemsOffset, setItemsOffset] = useState(0);
	const itemsCount = 4;
	const [currentPage, setCurrentPage] = useState(1);
	const [disableLeft, setDisableLeft] = useState(true);
	const [disableRight, setDisableRight] = useState(false);
	const [tabCount, setTabCount] = useState(0);

	const bodyParameters = {
		count: itemsCount,
		offset: itemsOffset
	};
	const itemsListApi = () => {
		setOpenLoader(true);

		allSharedItemsList(bodyParameters)
			.then(response => {
				setSharedList(response?.items);
				setTabCount(Math.ceil(response.count / itemsCount));
				if (Math.ceil(response?.items?.length < itemsCount)) {
					setDisableLeft(true);
					setDisableRight(true);
				}
				if (response?.count === 4) {
					setDisableRight(true);
				}
			})
			.catch(error => {
				console.log(error);
			})
			.finally(() => {
				setOpenLoader(false);
			});
	};

	useEffect(() => {
		if (currentPage === tabCount) {
			setDisableRight(true);
		}

		itemsListApi();
		return () => {
			setOpenLoader(false); // Cancel the loader if it is still open
		};
	}, []);

	useEffect(() => {
		allSharedItemsList(bodyParameters)
			.then(response => setSharedList(response?.items))
			.catch(error => {
				console.log(error);
			})
			.finally(() => {
				setOpenLoader(false);
			});
	}, [itemsOffset]);

	const leftClick = () => {
		if (currentPage === 1) {
			setDisableLeft(true);
		}
		if (!disableLeft) {
			setSharedList([]);
			setOpenLoader(true);
			setCurrentPage(currentPage - 1);
			setItemsOffset(itemsOffset - itemsCount);
			setDisableRight(false);
			if (currentPage - 1 === 1) {
				setDisableLeft(true);
			}
		}
	};

	const rightClick = () => {
		if (currentPage === tabCount) {
			setDisableRight(true);
		}
		if (!disableRight) {
			setSharedList([]);
			setOpenLoader(true);
			setCurrentPage(currentPage + 1);
			setDisableLeft(false);
			if (sharedList.length + 1 > itemsCount) {
				setItemsOffset(itemsOffset + itemsCount);
			}
		}
		if (currentPage + 1 === tabCount) {
			setDisableRight(true);
		}
	};

	return (
		<Box
			sx={{
				border: theme => `1px solid ${theme.palette.background.blue03}`,
				width: '100%',
				height: '141px',
				padding: '20px',
				borderRadius: '8px'
			}}
		>
			<Box sx={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
				<Typography
					sx={{
						fontSize: '14px',
						color: theme => theme.palette.text.secondary,
						lineHeight: '18.23px'
					}}
				>
					Shared Dispatches
				</Typography>
				<SeeAll
					goto="/shared"
					leftClick={leftClick}
					rightClick={rightClick}
					leftClickDisable={disableLeft}
					rightClickDisable={disableRight}
					havePagination
					color={theme => theme.palette.text.primary}
				/>
			</Box>
			<Grid container>
				{openLoader && (
					<Loader isFetching={openLoader} position="relative" width="100%" height="100%" />
				)}
				{!openLoader &&
					sharedList?.map((dispatch, index) => {
						const paddingStyles =
							index % 2 === 0 ? { paddingRight: '5px' } : { paddingLeft: '5px' };

						return (
							<Grid item xs={6} sx={{ paddingBottom: '10px', ...paddingStyles }} key={dispatch.id}>
								<SharedDispatchCard
									name={dispatch?.title}
									status={dispatch?.status}
									sharedWith={dispatch?.shared[0]?.sharedByEmail}
								/>
							</Grid>
						);
					})}
				{(!sharedList || sharedList?.length === 0) && !openLoader ? (
					<Grid container mt={2} direction="row" justifyContent="center" alignItems="center">
						<Typography>No workflows shared</Typography>
					</Grid>
				) : null}
			</Grid>
		</Box>
	);
}

export default SharedDispatches;
