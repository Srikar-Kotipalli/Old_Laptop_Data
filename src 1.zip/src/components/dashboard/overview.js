/* eslint-disable react/jsx-props-no-spreading */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useEffect } from 'react';
import { Auth } from 'aws-amplify';
import { Grid, MenuItem, Select, Typography, SvgIcon } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { dispatchOverview } from '../../api/experiments/dispatchApi';
import { getUserCharges } from '../../api/billing/billingApi';
import useDidMountEffect from '../../utils/useDidMountEffect';
import Cost from '../../assets/dashboard/cost.svg';
import Experiments from '../../assets/dashboard/experiments.svg';
import DashboardCard from '../card/dashboard';
import Button from '../primaryButton/index';
import { startAndEndDate } from '../../utils/utils';
import { setDispatches, setIsOverview } from '../../redux/tourSlice';
import Loader from '../loader';

function CustomIcon(props) {
	return (
		// eslint-disable-next-line react/jsx-props-no-spreading
		<SvgIcon {...props} style={{ transform: 'translateY(20%)' }}>
			<svg width="16" height="16" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path
					d="M8 10.9998L3 5.9998L3.7 5.2998L8 9.59981L12.3 5.2998L13 5.9998L8 10.9998Z"
					fill="#CBCBD7"
				/>
			</svg>
		</SvgIcon>
	);
}

function Overview(props) {
	const [selected, setSelected] = useState('All time');
	const [dates, setDates] = useState({ startDate: '', endDate: '' });
	const [overviewData, setOverviewData] = useState({});
	const [openLoader, setOpenLoader] = useState(false);
	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);
	const { setTutorialsOpen } = props;
	const dispatch = useDispatch();

	useEffect(() => {
		setOpenLoader(true);
		const isVisted = sessionStorage.getItem('eventTriggered');
		dispatchOverview(dates.startDate, dates.endDate)
			.then(response => {
				setOverviewData(response);
				dispatch(setDispatches({ dispatches: response?.dispatches || 0 }));
				dispatch(setIsOverview({ isOverview: true }));
				if (!response?.dispatches && !isVisted) {
					setTutorialsOpen(true);
					sessionStorage.setItem('eventTriggered', 'true');
					// If the event has not been triggered, and the condition is met
				}
			})
			.catch(error => {
				console.error(error);
				dispatch(setDispatches({ dispatches: 0 }));
				dispatch(setIsOverview({ isOverview: true }));
			})
			.finally(() => {
				setOpenLoader(false);
				if (isVisted === 'true') {
					setTutorialsOpen(false);
				}
			});
	}, [dates?.startDate, dates?.endDate]);

	// get user charges
	const [charges, setCharges] = useState(null);
	useEffect(() => {
		Auth.currentAuthenticatedUser().then(user => {
			const res = user?.attributes;
			const userID = res && res['custom:userID'];
			setOpenLoader(true);
			getUserCharges(userID)
				.then(payload => {
					if (payload) {
						setCharges(payload);
					}
					setOpenLoader(false);
				})
				.catch(() => {
					setCharges(null);
					setOpenLoader(false);
				});
		});
	}, []);

	useDidMountEffect(() => {
		dispatchOverview(dates.startDate, dates.endDate)
			.then(response => {
				setOverviewData(response);
			})
			.catch(error => {
				console.error(error);
			});
	}, [liveRefresh]);

	const selectionChangeHandler = event => {
		setSelected(event.target.value);
		startAndEndDate(event.target.value, setDates, dates);
	};

	const getButtonWidth = () => {
		if (selected?.length > 8) return '8.5rem';
		else if (selected?.length < 6) return '6rem';
		return '7rem';
	};

	return (
		<>
			<Grid container direction="row" justifyContent="space-between" alignItems="center" mt={3}>
				<Typography sx={{ color: theme => theme.palette.text.secondary }} variant="header20">
					Overview
				</Typography>
				<Grid item sx={{ display: 'flex' }}>
					<Button
						variant="outlined"
						sx={{
							'&:hover': {
								backgroundColor: theme => theme?.palette?.background?.covalentPurple,
								borderRadius: '25px',
								borderColor: theme => theme?.palette?.background?.blue05
							},
							display: 'flex',
							justifyContent: 'center',
							borderRadius: '25px',
							height: '32px',
							marginLeft: '0.2rem',
							marginRight: '2rem',
							border: '1px solid #CBCBD7'
						}}
						color="white"
						handler={() => setTutorialsOpen(true)}
						title="Get Started"
					/>
					<Select
						IconComponent={CustomIcon}
						value={selected}
						onChange={selectionChangeHandler}
						variant="outlined"
						size="small"
						className="shownBtn"
						sx={{
							background: theme => theme.palette.background.paper,
							borderRadius: '200px',
							padding: '0rem 1rem',
							width: getButtonWidth(),
							lineHeight: '1.9',
							height: '32.9px',
							color: 'white',
							'.MuiOutlinedInput-notchedOutline': {
								borderColor: theme => theme.palette.background.blue05
							},
							'&.Mui-focused .MuiOutlinedInput-notchedOutline': {
								borderColor: theme => theme.palette.background.blue05
							},
							'&:hover .MuiOutlinedInput-notchedOutline': {
								borderColor: theme => theme.palette.background.blue05
							},
							'&:hover': {
								background: theme => theme.palette.background.covalentPurple
							},
							'.MuiSvgIcon-root ': {
								fill: 'transparent !important'
							}
						}}
					>
						<MenuItem value="All time">All time</MenuItem>
						<MenuItem value="Last month">Last month</MenuItem>
						<MenuItem value="This month">This month</MenuItem>
						<MenuItem value="This week">This week</MenuItem>
						<MenuItem value="Today">Today</MenuItem>
					</Select>
				</Grid>
			</Grid>
			{openLoader && (
				<Grid container direction="row" justifyContent="space-between">
					<Loader isFetching={openLoader} width="100%" position="relative" height="8.95rem" />
				</Grid>
			)}

			{!openLoader && (
				<Grid
					container
					pt={2}
					direction="row"
					columnGap={0}
					rowGap={2}
					justifyContent="space-between"
				>
					<DashboardCard title="Cost" img={Cost} value={charges?.display_price || 0} />
					<DashboardCard
						title="Dispatches"
						img={Experiments}
						value={overviewData?.dispatches || 0}
					/>
					<DashboardCard title="Running" img={Experiments} value={overviewData?.runnning || 0} />
				</Grid>
			)}
		</>
	);
}

export default Overview;
