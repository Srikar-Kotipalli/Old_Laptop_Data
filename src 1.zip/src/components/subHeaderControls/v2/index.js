/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import { Box, Grid, SvgIcon, Select, MenuItem, Button, Typography } from '@mui/material';
// import { useNavigate } from 'react-router-dom';
import ascending from '../../../assets/marketplace/ascending.svg';
import SearchInput from '../../inputBase/projects/searchInput';
import { Capitalize } from '../../../utils/utils';
import 'react-datepicker/dist/react-datepicker.css';

function CustomIcon(props) {
	return (
		// eslint-disable-next-line react/jsx-props-no-spreading
		<SvgIcon {...props} style={{ transform: 'translateY(10%)' }}>
			<svg
				width="16"
				height="16"
				viewBox="0 0 16 22"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					d="M8 10.9998L3 5.9998L3.7 5.2998L8 9.59981L12.3 5.2998L13 5.9998L8 10.9998Z"
					fill="#CBCBD7"
				/>
			</svg>
		</SvgIcon>
	);
}

function SubHeaderControls({
	filterComponent,
	sortComponent,
	width,
	sort,
	filterBy,
	setSortBy,
	searchKey,
	setSearchKey,
	sortTitle,
	filterTitles,
	setFilterBy,
	displaySearchFirst = false
}) {
	// cancel search
	const cancelSearch = () => {
		setSearchKey('');
	};

	const handleSortClick = () => {
		setSortBy(sort === 'ASC' ? 'DESC' : 'ASC');
	};

	const selectionChangeHandler = event => {
		setFilterBy(event?.target?.value);
	};

	return (
		<Box sx={{ width }}>
			<Grid
				container
				direction="row"
				justifyContent={displaySearchFirst ? 'space-between' : 'flex-end'}
				alignItems="center"
				mt={3}
				width="100%"
			>
				{displaySearchFirst && (
					<Box sx={{ display: 'flex' }}>
						<SearchInput
							sx={{
								border: theme => `1px solid ${theme?.palette?.background?.blue03}`,
								borderRadius: '20px',
								width: '260px',
								height: '32.69px',
								'&.Mui-focused ': {
									border: theme => `1px solid ${theme.palette.background.blue05}`
								},
								'&:hover': {
									border: theme => `1px solid ${theme.palette.text.gray04}`
								}
								// mt:'10rem'
							}}
							value={searchKey || ''}
							onChange={e => setSearchKey(e?.target?.value)}
							cancelSearch={cancelSearch}
						/>
					</Box>
				)}
				<Box sx={{ display: 'flex' }}>
					{sortComponent && (
						<Grid container maxWidth="fit-content">
							<Button
								variant="outlined"
								sx={{
									'&:hover': {
										backgroundColor: theme => theme?.palette?.background?.covalentPurple,
										color: theme => theme?.palette?.text?.secondary,
										borderRadius: '25px',
										borderColor: theme => theme?.palette?.background?.blue05
									},
									display: 'flex',
									justifyContent: 'center',
									borderRadius: '25px',
									height: '32px',
									width: '140px',
									marginLeft: '0.2rem',
									marginRight: '2rem'
								}}
								endIcon={
									<img
										src={ascending}
										alt={sort}
										style={{ transform: sort === 'DESC' ? 'rotate(180deg)' : '' }}
									/>
								}
								onClick={handleSortClick}
							>
								<Typography
									pt={0}
									variant="popUpDispatch"
									sx={{ color: theme => theme?.palette?.background?.blue09 }}
								>
									{sortTitle}
								</Typography>
							</Button>
						</Grid>
					)}
					{filterComponent && (
						<Box
							sx={{ paddingRight: '27px' }}
							display="flex"
							direction="row"
							justifyContent="space-between"
							spacing={3}
						>
							<Select
								IconComponent={CustomIcon}
								value={filterBy}
								onChange={selectionChangeHandler}
								className="tableHeaderSelect"
								sx={{
									fontSize: '14px',
									background: theme => theme?.palette?.background?.paper,
									borderRadius: '200px',
									width: '100px',
									height: '32px',
									color: theme => theme?.palette?.background?.blue09,
									'&:hover': {
										backgroundColor: theme => theme?.palette?.background?.covalentPurple,
										color: theme => theme?.palette?.text?.secondary,
										borderRadius: '25px',
										borderColor: theme => theme?.palette?.background?.blue05
									},
									'.MuiOutlinedInput-notchedOutline': {
										borderColor: theme => theme?.palette?.background?.blue05
									},
									'&.Mui-focused .MuiOutlinedInput-notchedOutline': {
										borderColor: theme => theme?.palette?.background?.blue05
									},
									'&:hover .MuiOutlinedInput-notchedOutline': {
										borderColor: theme => theme?.palette?.background?.blue05
									},
									'.MuiSvgIcon-root ': {
										fill: 'transparent !important'
									}
								}}
							>
								{filterTitles?.map((e, index) => (
									<MenuItem key={e} sx={{ fontSize: '14px' }} value={filterTitles[index]}>
										{Capitalize(filterTitles[index])}
									</MenuItem>
								))}
							</Select>
						</Box>
					)}
					{!displaySearchFirst && (
						<SearchInput
							sx={{
								border: theme => `1px solid ${theme?.palette?.background?.blue03}`,
								borderRadius: '20px',
								width: '260px',
								height: '32.69px',
								'&.Mui-focused ': {
									border: theme => `1px solid ${theme.palette.background.blue05}`
								},
								'&:hover': {
									border: theme => `1px solid ${theme.palette.text.gray04}`
								}
								// mt:'10rem'
							}}
							value={searchKey || ''}
							onChange={e => setSearchKey(e?.target?.value)}
							cancelSearch={cancelSearch}
						/>
					)}
				</Box>
			</Grid>
		</Box>
	);
}

export default SubHeaderControls;
