/* eslint-disable react/no-unescaped-entities */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useEffect } from 'react';
import Joyride from 'react-joyride';
import { Typography, Grid, Box } from '@mui/material';
import { useNavigate, useLocation } from 'react-router-dom';
import { useMount } from 'react-use';
import { useSelector, useDispatch } from 'react-redux';
import {
	setTourState,
	setTourActive,
	setDispatchID,
	setTourRun,
	setIsOverview,
	setIsRecent,
	setTourSteps
} from '../../redux/tourSlice';
import dispatchJoy from '../../assets/dispatchJoy.svg';
import covalentExperimentsIcon from '../../assets/logos/covalentExperimentsIcon.svg';
import covalentSharedIcon from '../../assets/folderIcons/shared.svg';
import covalentHardwareIcon from '../../assets/hardware/covalentHardwareIcon.svg';
import EnvironmentsIcon from '../../assets/logos/environments.svg';
import settings from '../../assets/helperMenu/settings.svg';
import SupportIcon from '../../assets/dashboard/support.svg';
import './style.css';

function TitleGrid({ title, icon }) {
	return (
		<Box display="flex" direction="row">
			<img src={icon || dispatchJoy} alt="titleIcon" />
			<Typography pl={1} mt={0.5} sx={{ fontSize: '14px', fontWeight: 700 }}>
				{title}
			</Typography>
		</Box>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default function Tour() {
	const currentpath = window.location.pathname;

	const dispatch = useDispatch();
	const location = useLocation();
	const navigate = useNavigate();
	const { run, steps, isCompleted, dispatches, dispatchID } = useSelector(state => state.tour);
	window.addEventListener('popstate', () => {
		// Check if the current location is the homepage
		if (location.pathname === '/') {
			dispatch(setTourState({ isCompleted: true }));
			dispatch(setTourActive({ tourActive: false }));
		}
	});

	const getNewSteps = () => {
		let newSteps = [];
		if (dispatchID !== null && dispatches !== 0) {
			newSteps = [
				{
					target: '#apiKey',
					content: (
						<Grid p={0}>
							<TitleGrid title="Your Unique API Key" />
							<Typography variant="h2" mt={1}>
								This key is exclusively yours! Use it to execute your dispatches. Simply click the
								button provided to copy it.
							</Typography>
						</Grid>
					),
					disableBeacon: true
				},
				{
					target: '#act',
					content: (
						<Grid p={0}>
							<TitleGrid title="Activity List" />
							<Typography variant="h2" mt={1}>
								Keep track of your dispatches. The timeline shows each action's status in a
								sequential manner.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'top',
					spotlightClicks: false
				},
				{
					target: '#SupportLinks',
					content: (
						<Grid p={0}>
							<TitleGrid title="Helpful Links" icon={SupportIcon} />
							<Typography variant="h2" mt={1}>
								Curious about Covalent? Dive into our API docs and Github projects through these
								links.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'right'
				},
				{
					target: '#getStartedButton',
					content: (
						<Grid p={0}>
							<TitleGrid title="First Dispatch Guide" icon={SupportIcon} />
							<Typography variant="h2" mt={1}>
								Let's make your first dispatch a success! Follow the easy instructions on this page.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'bottom',
					spotlightClicks: false
				},
				{
					target: '#appWalkthrough',
					content: (
						<Grid p={0}>
							<TitleGrid title="Get Started" />
							<Typography variant="h2" mt={1}>
								Running dispatches have never been easier, please follow the instructions below to
								execute your first dispatch!
							</Typography>
						</Grid>
					),
					placement: 'right',
					disableBeacon: true
				},
				{
					target: '#appWalkthrough',
					content: (
						<Grid p={0}>
							<TitleGrid title="Projects" icon={covalentExperimentsIcon} />
							<Typography variant="h2" mt={1}>
								Organize your dispatches into projects and experiments for easy access. You can pin,
								delete, and perform other actions on your workflows using the menu options on this
								page.
							</Typography>
						</Grid>
					),
					placement: 'right',
					disableBeacon: true
				},
				{
					target: '#graph',
					content: (
						<Grid p={0}>
							<TitleGrid title="Workflows" />
							<Typography variant="h2" mt={1}>
								Explore detailed information about the workflow graph-lattice and electron and their
								metadata.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'auto'
				},
				{
					target: '#appWalkthrough',
					content: (
						<Grid p={0}>
							<TitleGrid title="Shared Dispatches" icon={covalentSharedIcon} />
							<Typography variant="h2" mt={1}>
								Discover dispatches shared by other users. Check out the recently shared ones
								showcased in the cards above.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'right'
				},
				{
					target: '#appWalkthrough',
					content: (
						<Grid p={0}>
							<TitleGrid title="Hardware" icon={covalentHardwareIcon} />
							<Typography variant="h2" mt={1}>
								Examine the variety of hardware available to execute your workflows.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'right'
				},
				{
					target: '#appWalkthrough',
					content: (
						<Grid p={0}>
							<TitleGrid title="Environments" icon={EnvironmentsIcon} />
							<Typography variant="h2" mt={1}>
								Manage environments for your dispatches. View, create, or edit as needed. Set a
								default environment to run all your workflows.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'right'
				},
				{
					target: '#appWalkthrough',
					content: (
						<Grid p={0}>
							<TitleGrid title="Settings" icon={settings} />
							<Typography variant="h2" mt={1}>
								Review user details and actions. Browse the list of hardware, and stay tuned to the
								pricing space for upcoming updates.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'right'
				}
			];
		} else {
			newSteps = [
				{
					target: '#apiKey',
					content: (
						<Grid p={0}>
							<TitleGrid title="Your Unique API Key" />
							<Typography variant="h2" mt={1}>
								This key is exclusively yours! Use it to execute your dispatches. Simply click the
								button provided to copy it.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'right'
				},
				{
					target: '#act',
					content: (
						<Grid p={0}>
							<TitleGrid title="Activity List" />
							<Typography variant="h2" mt={1}>
								Keep track of your dispatches. The timeline shows each action's status in a
								sequential manner.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'top',
					spotlightClicks: false
				},
				{
					target: '#SupportLinks',
					content: (
						<Grid p={0}>
							<TitleGrid title="Helpful Links" icon={SupportIcon} />
							<Typography variant="h2" mt={1}>
								Curious about Covalent? Dive into our API docs and Github projects through these
								links.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'right'
				},
				{
					target: '#getStartedButton',
					content: (
						<Grid p={0}>
							<TitleGrid title="First Dispatch Guide" />
							<Typography variant="h2" mt={1}>
								Let's make your first dispatch a success! Follow the easy instructions on this page.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'bottom',
					spotlightClicks: false
				},
				{
					target: '#appWalkthrough',
					content: (
						<Grid p={0}>
							<TitleGrid title="Get Started" />
							<Typography variant="h2" mt={1}>
								Running dispatches have never been easier, please follow the instructions below to
								execute your first dispatch!
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'right'
				},
				{
					target: '#appWalkthrough',
					content: (
						<Grid p={0}>
							<TitleGrid title="Projects" icon={covalentExperimentsIcon} />
							<Typography variant="h2" mt={1}>
								Organize your dispatches into projects and experiments for easy access. You can pin,
								delete, and perform other actions on your workflows using the menu options on this
								page.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'right'
				},
				{
					target: '#appWalkthrough',
					content: (
						<Grid p={0}>
							<TitleGrid title="Shared Dispatches" icon={covalentSharedIcon} />
							<Typography variant="h2" mt={1}>
								Discover dispatches shared by other users. Check out the recently shared ones
								showcased in the cards above.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'right'
				},
				{
					target: '#appWalkthrough',
					content: (
						<Grid p={0}>
							<TitleGrid title="Hardware" icon={covalentHardwareIcon} />
							<Typography variant="h2" mt={1}>
								Examine the variety of hardware available to execute your workflows.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'right'
				},
				{
					target: '#appWalkthrough',
					content: (
						<Grid p={0}>
							<TitleGrid title="Environments" icon={EnvironmentsIcon} />
							<Typography variant="h2" mt={1}>
								Manage environments for your dispatches. View, create, or edit as needed. Set a
								default environment to run all your workflows.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'right'
				},
				{
					target: '#appWalkthrough',
					content: (
						<Grid p={0}>
							<TitleGrid title="Settings" icon={settings} />
							<Typography variant="h2" mt={1}>
								Review user details and actions. Browse the list of hardware, and stay tuned to the
								pricing space for upcoming updates.
							</Typography>
						</Grid>
					),
					disableBeacon: true,
					placement: 'right'
				}
			];
		}
		return newSteps;
	};

	useEffect(() => {
		const newSteps = getNewSteps();
		dispatch(
			setTourSteps({
				steps: newSteps
			})
		);
	}, [dispatches, dispatchID]);

	useMount(() => {
		const newSteps = getNewSteps();
		dispatch(
			setTourState({
				run: currentpath === '/',
				steps: newSteps,
				stepIndex: 0,
				isCompleted: currentpath !== '/'
			})
		);
	});

	const handleCallback = data => {
		const { action, index, type } = data;
		if (dispatchID === null && dispatches === 0) {
			if (action === 'close' || action === 'reset') {
				dispatch(setTourState({ isCompleted: true }));
				dispatch(setTourActive({ tourActive: false }));
				if (currentpath !== '/') {
					dispatch(setIsOverview({ isOverview: false }));
					dispatch(setIsRecent({ isRecent: false }));
				}
			} else if (index === 3) {
				if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate('/');
					if (data?.step?.target === '#getStartedButton') {
						setTimeout(() => dispatch(setTourRun({ run: true })), 100);
					} else dispatch(setTourRun({ run: true }));
				} else if (type === 'step:after') navigate('/gettingstarted');
			} else if (index === 4) {
				if (action === 'prev' && currentpath === '/gettingstarted') {
					/* empty */
				} else if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate('/gettingstarted');
					setTimeout(() => dispatch(setTourRun({ run: true })), 50);
				} else if (type === 'step:after') navigate('/projects');
			} else if (index === 5) {
				if (action === 'prev' && currentpath === '/projects') {
					/* empty */
				} else if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate('/projects');
					setTimeout(() => dispatch(setTourRun({ run: true })), 100);
				} else if (type === 'step:after') navigate('/shared');
			} else if (index === 6) {
				if (action === 'prev' && currentpath === '/shared') {
					/* empty */
				} else if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate('/shared');
					setTimeout(() => dispatch(setTourRun({ run: true })), 100);
				} else if (type === 'step:after') navigate('/hardware');
			} else if (index === 7) {
				if (action === 'prev' && currentpath === '/hardware') {
					/* empty */
				} else if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate('/hardware');
					setTimeout(() => dispatch(setTourRun({ run: true })), 100);
				} else if (type === 'step:after') navigate('/environments');
			} else if (index === 8) {
				if (action === 'prev' && currentpath === '/environments') {
					/* empty */
				} else if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate('/environments');
					setTimeout(() => dispatch(setTourRun({ run: true })), 100);
				} else if (type === 'step:after') navigate('/settings');
			} else if (index === 9) {
				if (action === 'prev' && currentpath === '/settings') {
					/* empty */
				} else if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate('/settings');
					setTimeout(() => dispatch(setTourRun({ run: true })), 100);
				} else if (type === 'step:after') {
					navigate('/');
					dispatch(setTourState({ isCompleted: true }));
					dispatch(setTourActive({ tourActive: false }));
					dispatch(setDispatchID({ dispatchID: null }));
					dispatch(setTourActive({ dispatches: 0 }));
					dispatch(setIsOverview({ isOverview: false }));
					dispatch(setIsRecent({ isRecent: false }));
				}
			}
		} else {
			if (action === 'close' || action === 'reset') {
				dispatch(setTourState({ isCompleted: true }));
				dispatch(setTourActive({ tourActive: false }));
				if (currentpath !== '/') {
					dispatch(setIsOverview({ isOverview: false }));
					dispatch(setIsRecent({ isRecent: false }));
				}
			} else if (index === 3) {
				if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate('/');
					if (data?.step?.target === '#getStartedButton') {
						setTimeout(() => dispatch(setTourRun({ run: true })), 100);
					} else dispatch(setTourRun({ run: true }));
				} else if (type === 'step:after') navigate('/gettingstarted');
			} else if (index === 4) {
				if (action === 'prev' && currentpath === '/gettingstarted') {
					/* empty */
				} else if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate('/gettingstarted');
					setTimeout(() => dispatch(setTourRun({ run: true })), 50);
				} else if (type === 'step:after') navigate('/projects');
			} else if (index === 5) {
				if (action === 'prev' && currentpath === '/projects') {
					/* empty */
				} else if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate('/projects');
					setTimeout(() => dispatch(setTourRun({ run: true })), 100);
				} else if (type === 'step:after') navigate(`/graph/${dispatchID}`);
			} else if (index === 6) {
				if (action === 'prev' && currentpath === `/graph/${dispatchID}`) {
					/* empty */
				} else if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate(`/graph/${dispatchID}`);
					setTimeout(() => dispatch(setTourRun({ run: true })), 100);
				} else if (type === 'step:after') navigate('/shared');
			} else if (index === 7) {
				if (action === 'prev' && currentpath === '/shared') {
					/* empty */
				} else if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate('/shared');
					setTimeout(() => dispatch(setTourRun({ run: true })), 100);
				} else if (type === 'step:after') navigate('/hardware');
			} else if (index === 8) {
				if (action === 'prev' && currentpath === '/hardware') {
					/* empty */
				} else if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate('/hardware');
					setTimeout(() => dispatch(setTourRun({ run: true })), 100);
				} else if (type === 'step:after') navigate('/environments');
			} else if (index === 9) {
				if (action === 'prev' && currentpath === '/environments') {
					/* empty */
				} else if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate('/environments');
					setTimeout(() => dispatch(setTourRun({ run: true })), 100);
				} else if (type === 'step:after') navigate('/settings');
			} else if (index === 10) {
				if (action === 'prev' && currentpath === '/settings') {
					/* empty */
				} else if (action === 'prev') {
					dispatch(setTourRun({ run: false }));
					navigate('/settings');
					setTimeout(() => dispatch(setTourRun({ run: true })), 100);
				} else if (type === 'step:after') {
					navigate('/');
					dispatch(setTourState({ isCompleted: true }));
					dispatch(setTourActive({ tourActive: false }));
					dispatch(setDispatchID({ dispatchID: null }));
					dispatch(setTourActive({ dispatches: 0 }));
					dispatch(setIsOverview({ isOverview: false }));
					dispatch(setIsRecent({ isRecent: false }));
				}
			}
		}
	};

	return isCompleted ? null : (
		// <Grid
		// 	onClick={e => e.stopPropagation()}
		// 	sx={{
		// 		position: 'fixed',
		// 		top: 0,
		// 		left: 0,
		// 		height: '100%',
		// 		width: '100%',
		// 		backgroundColor: 'transparent',
		// 		zIndex: 25
		// 		// pointerEvents: 'none'
		// 	}}
		// >
		// 	<Outlet />
		<Joyride
			floaterProps={{
				style: { paddingTop: '0px' }
			}}
			className="__floater.__floater__open"
			callback={handleCallback}
			continuous
			run={run}
			steps={steps}
			spotlightClicks
			showProgress
			scrollDuration={550}
			disableCloseOnEsc
			disableOverlayClose
			locale={{
				last: 'Close'
			}}
			styles={{
				options: {
					arrowColor: 'rgb(28, 28, 70)',
					backgroundColor: 'rgb(28, 28, 70)',
					primaryColor: 'rgb(28, 28, 70)',
					textColor: 'white',
					padding: '0px',
					spotlightShadow: '0 0 15px rgba(0, 0, 0, 0.5)'
				},
				spotlight: {
					borderRadius: 16,
					position: 'absolute',
					border: '3px solid #CBCBD7'
				},
				tooltip: {
					padding: '0px',
					height: 'auto',
					width: '299px',
					borderRadius: 24,
					//	border: '1px solid #CBCBD7',
					paddingBottom: '1rem'
				},
				tooltipContainer: {
					textAlign: 'left',
					padding: '0.2rem 0.7rem',
					zIndex: 3000
				},
				tooltipContent: {
					padding: '3px 10px 10px 10px',
					justifyContent: 'left'
				},
				tooltipFooter: {
					marginTop: 0,
					paddingRight: '1rem'
				},
				buttonNext: {
					width: '100.5px',
					height: '35px',
					backgroundColor: '#08081A',
					borderRadius: '25px',
					border: '1px solid #6473FF',
					cursor: 'pointer',
					fontSize: '14px',
					fontFamily: 'DM sans'
				},
				buttonBack: {
					width: '75px',
					height: '35px',
					borderRadius: '25px',
					cursor: 'pointer',
					fontSize: '14px',
					fontFamily: 'DM sans',
					color: '#ffffff'
				},
				buttonClose: {
					height: 8,
					padding: 15,
					position: 'absolute',
					right: 5,
					top: -5,
					width: 8
				},
				floater: {
					padding: '0px'
				}
			}}
		/>
		// </Grid>
	);
}
