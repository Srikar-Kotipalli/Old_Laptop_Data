/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import { useDebounce } from 'use-debounce';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import Menu from '@mui/material/Menu';
import Typography from '@mui/material/Typography';
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import Divider from '@mui/material/Divider';
import Icon from '../../icon';
import {
	allItemsList,
	addEditProject,
	addEditExperiment
} from '../../../api/experiments/dispatchApi';
import loader from '../../../assets/loaders/moveLoader.svg';
import arrowRightAltIcon from '../../../assets/arrows/arrowRight.svg';
import projectIcon from '../../../assets/folderIcons/projectIcon.svg';
import experimentIcon from '../../../assets/folderIcons/moveSubFolders.svg';
import addIcon from '../../../assets/actions/add.svg';
import caretDownIcon from '../../../assets/arrows/caretDown.svg';
import MiniMoreLoader from '../../../assets/loaders/loader.svg';
import EllipsisDefaultTooltip from '../../tooltip/ellipsisTooltip';
import './style.css';
import CustomInputBase from '../../inputBase/projects';
import SearchInput from '../../inputBase/projects/searchInput';
import DialogBox from '../../dialogBox/index';
import { ProjectContext } from '../../../containers/projects/projectContext';
import CustomisedSnackbar from '../../snackbar/projects';

function StyledDivider() {
	return <Divider orientation="vertical" variant="middle" flexItem />;
}
export default function MoveItemsMenu(props) {
	const {
		open,
		setMoveMenu,
		anchorEl,
		type,
		dispatch,
		experiment,
		view,
		valueForTab,
		tabstoHide,
		totalItems
	} = props;
	const [value, setValue] = React.useState(valueForTab);
	const [allItems, setAllItems] = React.useState([]);
	const [openLoader, setOpenLoader] = React.useState(false);
	const [count, setCount] = React.useState(5);
	const [moveLoader, setMoveLoader] = React.useState(false);
	const [listCount, setListCount] = React.useState(0);
	const [searchKey, setSearchKey] = React.useState('');
	const [searchValue] = useDebounce(searchKey, 1000);
	const [openSnackbar, setOpenSnackbar] = React.useState(false);
	const [snackbarMessage, setSnackbarMessage] = React.useState('');
	const [isItemSelected, setIsItemSelected] = React.useState(false);
	const [openDialogBox, setOpenDialogBox] = React.useState(false);
	const [totalItemsToMove, setTotalItemsToMove] = React.useState(totalItems);
	const { itemsToMove, multipleSelectedItems } = React.useContext(ProjectContext);
	React.useEffect(() => {
		if (type === 'multiselect') {
			setTotalItemsToMove(multipleSelectedItems.length);
		} else {
			setTotalItemsToMove(1);
		}
	}, []);

	// to get the title for move menu based on number of items
	const getTitleForMoveMenu = () => {
		if (totalItemsToMove === 1) {
			if (type === 'dispatch') return ` Move ${dispatch?.title} to ...`;
			else if (type === 'experiment') return ` Move ${experiment?.title} to ...`;
		}
		return `Move ${totalItemsToMove} items to ...`;
	};

	// to check and disable the parent list item
	const checkParentItem = id => {
		if (totalItemsToMove === 1) {
			const currentItem = experiment || dispatch;
			if (currentItem?.parentId === id) {
				return true;
			}
		}
		return false;
	};

	const selectedArray = allItems.filter(obj => {
		return obj.isSelected === true;
	});

	const handleTabChange = (_event, newValue) => {
		setCount(5);
		setAllItems([]);
		setIsItemSelected(false);
		setValue(newValue);
	};

	const closeMoveMenu = () => {
		setMoveMenu(!open);
		setCount(5);
		setValue('experiments');
	};

	const showMore = () => {
		setMoveLoader(true);
		setCount(prevState => prevState + 2);
	};

	const addItem = listType => {
		const data = allItems;
		const entry = {
			completedElectrons: '0',
			count: 0,
			id: Math.random(),
			lastUpdated: new Date(),
			name: '',
			runTime: null,
			startTime: null,
			status: '',
			tags: '',
			totalElectrons: '0',
			type: listType === 'experiments' ? 'Experiment' : 'Project',
			isAdd: true,
			isSelected: false
		};
		const addedEntry = data.filter(e => e.isAdd === true).length;
		if (addedEntry < 1) {
			data.unshift(entry);
			setAllItems([...data]);
		} else {
			setOpenSnackbar(true);
			setSnackbarMessage('Add one item at a time!');
		}
	};

	const itemsListApi = signal => {
		if (searchValue?.length === 0 || searchValue?.length >= 3) {
			setOpenLoader(true);
		} else {
			setOpenLoader(false);
		}
		const bodyParameters = {
			count,
			filterBy: value,
			offset: 0,
			direction: 'DESC',
			sort: 'LASTUPDATED',
			search: searchKey,
			showArchived: false
		};
		if (searchValue?.length === 0 || searchValue?.length >= 3) {
			allItemsList(bodyParameters, signal)
				.then(response => {
					setListCount(response.count);
					setAllItems(response.items);
				})
				.catch(error => {
					setAllItems([]);
					setOpenLoader(false);
					setMoveLoader(false);
					console.log(error);
				})
				.finally(() => {
					setOpenLoader(false);
					setMoveLoader(false);
				});
		}
	};

	React.useEffect(() => {
		const controller = new AbortController();
		const signal = controller.signal;
		itemsListApi(signal);
		return () => {
			controller.abort();
		};
	}, [value, count, searchValue]);

	const cancelSearch = () => {
		setSearchKey('');
		setOpenLoader(true);
	};

	const setSelected = index => {
		const selectedIndex = allItems.findIndex(e => e.isSelected === true);
		const selectedData = allItems;
		if (selectedIndex !== -1) selectedData[selectedIndex].isSelected = false;
		if (!selectedData[index].isAdd) {
			if (index === selectedIndex) {
				selectedData[index].isSelected = false;
				setIsItemSelected(false);
			} else {
				selectedData[index].isSelected = true;
				setIsItemSelected(true);
			}
			setAllItems([...selectedData]);
		}
	};

	const dialogBoxHandler = () => {
		setOpenDialogBox(true);
	};

	const moveItems = () => {
		let moveItemsList = [];
		let moveType = null;
		if (type === 'multiselect') {
			const multipleItems = multipleSelectedItems.map(({ id }) => id);
			moveItemsList = multipleItems;
		} else {
			if (experiment) moveItemsList.push(experiment?.id);
			else moveItemsList.push(dispatch?.id);
		}
		const moveTo = allItems.filter(e => e.isSelected === true);
		if (moveTo.length === 0) moveType = 'dispatches';
		else if (moveTo.length > 0 && moveTo[0].type === 'Experiment') moveType = 'experiment';
		else moveType = 'project';
		itemsToMove(moveType, moveItemsList, moveTo, view);
		closeMoveMenu();
	};

	const addListItem = (textValue, action, typeValue, currentValue) => {
		let parameter = null;
		let addData = allItems;
		// save project and experiment
		if (
			(typeValue === 'project' || typeValue === 'experiment') &&
			action === 'save' &&
			(textValue !== null || textValue !== '')
		) {
			parameter = {
				id: null,
				title: textValue
			};
		} else if (
			// Cancel adding of a project
			(typeValue === 'project' || typeValue === 'experiment') &&
			action === 'close'
		) {
			addData = addData.filter(e => e.id !== currentValue.id);
			setOpenSnackbar(true);
			setSnackbarMessage(`Adding ${typeValue} cancelled`);
		}
		// api call
		if (action === 'save') {
			let addItems = null;
			// choose API based on project/experiment
			addItems = typeValue === 'project' ? addEditProject : addEditExperiment;
			setOpenLoader(true);
			addItems(parameter)
				.then(response => {
					if (response.status) {
						addData[0].id = response.id;
						addData[0].title = textValue;
						addData[0].isAdd = false;
						addData[0].lastUpdated = new Date();
						setAllItems([...addData]);
					}
					setOpenSnackbar(true);
					setSnackbarMessage(response.message);
					setOpenLoader(false);
				})
				.catch(error => {
					setOpenSnackbar(true);
					setSnackbarMessage(error.response.data.detail[0].msg);
					setOpenLoader(false);
				});
		} else {
			setAllItems([...addData]);
		}
	};

	return (
		<>
			<CustomisedSnackbar
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
				multipleSelectedItems={multipleSelectedItems}
				action="move"
				testId="moveSnackbar"
			/>
			<Menu
				className="moveMenu"
				data-testid="moveItemsMenu"
				variant="menu"
				anchorEl={anchorEl}
				open={open}
				// eslint-disable-next-line react/jsx-boolean-value
				autoFocus={true}
				onClose={closeMoveMenu}
				PaperProps={{
					sx: {
						width: '344px'
					}
				}}
			>
				<Grid item xs={12}>
					<Typography variant="subtitle2" sx={{ paddingLeft: '1.2rem', paddingTop: '0.5rem' }}>
						{getTitleForMoveMenu()}
					</Typography>
				</Grid>
				<Grid item xs={11} pl={2} pt={1}>
					<SearchInput
						// the border is added here to eliminate the harsh transition of border active on focus..DELETE THIS COMMENT AFTER READING
						sx={{ border: '1px solid #303067', borderRadius: '20px', backgroundColor: ' #08081a' }}
						value={searchKey || ''}
						onChange={e => setSearchKey(e.target.value)}
						cancelSearch={cancelSearch}
					/>
				</Grid>
				<Grid item xs={12}>
					<TabContext value={value}>
						<TabList onChange={handleTabChange}>
							{tabstoHide === 'experiment' ? null : (
								<Tab
									label="Experiments"
									value="experiments"
									sx={{ width: '50%' }}
									data-testid="experimentsTab"
								/>
							)}
							<StyledDivider />
							<Tab
								label="Projects"
								value="projects"
								sx={{ width: '49%' }}
								data-testid="projectsTab"
							/>
						</TabList>
					</TabContext>
				</Grid>
				<Grid sx={{ height: '225px', overflow: 'auto' }}>
					{openLoader && (
						<Grid className="moveLoaderContainer">
							<Icon src={loader} type="static" alt="loaderIcon" />
						</Grid>
					)}
					{!openLoader && (
						<List>
							{allItems.length === 0 && (
								<Typography
									className="listHeading"
									color="textPrimary"
									variant="subtitle2"
									sx={{ display: 'flex', paddingLeft: '22%' }}
								>
									No records found
								</Typography>
							)}
							{allItems.map((listItems, listItemsIndex) => (
								<ListItemButton
									component="div"
									key={listItems.id || listItems.name}
									onClick={() => (listItems.isAdd ? '' : setSelected(listItemsIndex))}
									sx={{ backgroundColor: listItems.isSelected ? '#1C1C46' : '' }}
									disabled={checkParentItem(listItems.id)}
								>
									<Icon
										src={value === 'experiments' ? experimentIcon : projectIcon}
										type="static"
										alt="projectIcon"
										padding="0px 3px 2px 0px"
									/>
									{listItems.isAdd === true ? (
										<CustomInputBase
											location="move"
											action="move"
											data={allItems}
											type={value === 'experiments' ? 'experiment' : 'project'}
											listItem={listItems}
											addItem={addListItem}
										/>
									) : (
										<EllipsisDefaultTooltip
											variant="subtitle2"
											value={listItems.title}
											type="menu"
										/>
									)}
								</ListItemButton>
							))}
							{allItems.length !== 0 && allItems.length < listCount && (
								<ListItemButton onClick={showMore} component="div">
									{moveLoader ? (
										<Icon src={MiniMoreLoader} type="static" alt="moveLoader" />
									) : (
										<Icon
											src={caretDownIcon}
											type="pointer"
											alt="caretDown"
											padding="0px 3px 2px 0px"
										/>
									)}
									<Typography variant="subtitle2" color="textPrimary">
										Show more
									</Typography>
								</ListItemButton>
							)}
						</List>
					)}
				</Grid>
				<Grid container direction="row" sx={{ paddingBottom: '10px' }}>
					<Grid item xs={6}>
						<Button
							variant="outlined"
							data-testid="addButton"
							disabled={openLoader || moveLoader}
							onClick={() => addItem(value)}
							sx={{
								paddingLeft: '3px',
								marginLeft: '11px',
								'&:hover': {
									backgroundColor: '#1C1C46',
									color: '#FFFFFF',
									borderRadius: '25px',
									border: '1px solid #6473FF'
								},
								borderColor: '#323267'
							}}
						>
							<img src={addIcon} alt="add" style={{ paddingBottom: '2px' }} />
							<Typography
								sx={{ paddingBottom: '0.5px', paddingLeft: '4px' }}
								color="textPrimary"
								variant="subtitle2"
								data-testid="addText"
							>
								Add{value === 'experiments' ? ' Experiment' : ' Project'}
							</Typography>
						</Button>
					</Grid>
					<Grid item xs={6} display="flex" justifyContent="center">
						<Button
							sx={{
								'&:hover': {
									backgroundColor: '#1C1C46',
									color: '#FFFFFF',
									borderRadius: '25px',
									border: '1px solid #6473FF'
								},
								borderColor: '#323267'
							}}
							onClick={dialogBoxHandler}
							variant="outlined"
							data-testid="moveButton"
							disabled={openLoader || moveLoader}
						>
							<img
								src={arrowRightAltIcon}
								alt="arrowRightAltIcon"
								style={{ paddingBottom: '2px' }}
							/>
							<Typography
								sx={{ paddingBottom: '0.5px', paddingLeft: '4px' }}
								color="textPrimary"
								variant="subtitle2"
							>
								{isItemSelected ? 'Move' : 'Move to root'}
							</Typography>
						</Button>
					</Grid>
					<DialogBox
						totalItems={totalItemsToMove}
						openDialogBox={openDialogBox}
						setOpenDialogBox={setOpenDialogBox}
						icon={arrowRightAltIcon}
						type={type}
						title="Move"
						handler={moveItems}
						message="Are you sure about moving"
						selected={selectedArray}
					/>
				</Grid>
			</Menu>
		</>
	);
}
