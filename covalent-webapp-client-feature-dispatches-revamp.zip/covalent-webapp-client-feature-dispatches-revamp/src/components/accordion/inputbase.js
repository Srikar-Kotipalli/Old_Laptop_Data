/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import Tooltip from '@mui/material/Tooltip';
import TextField from '@mui/material/TextField';
import Icon from '../icon';
import closeIcon from '../../assets/checkmarks/closeError.svg';
import tickIcon from '../../assets/checkmarks/checkmarkSuccess.svg';

export default function InputBase({ data, setData, variant, setName, name }) {
	const [text, setText] = React.useState(variant === 'description' ? data.description : name);
	const textInput = React.useRef(null);

	React.useEffect(() => {
		textInput.current.focus();
	}, []);

	const onChange = e => {
		const newValue = e.target.value;
		setText(newValue);
		if (setName) setName(newValue);
	};

	const onFocus = event => {
		const target = event.target;
		setTimeout(() => target.select(), 0);
	};
	const onClose = () => {
		if (variant === 'description') {
			setData({ ...data, isDescAdd: false });
		} else setData({ ...data, isAddTitle: false });
	};

	const onAddition = () => {
		if (variant === 'description') {
			setData({ ...data, description: text, isDescAdd: false });
		} else {
			setData({ ...data, isAddTitle: false });
			if (setName) setName(text);
		}
	};

	return (
		<TextField
			variant="standard"
			data-testid="inputBase"
			name="text"
			placeholder={text}
			value={text}
			style={{ width: variant === 'description' ? '60%' : '80%' }}
			type="text"
			onChange={e => onChange(e)}
			onFocus={e => onFocus(e)}
			inputRef={textInput}
			InputProps={{
				autoComplete: 'off',
				style: {
					fontSize: variant === 'description' ? '14px' : '16px',
					paddingBottom: '1px',
					paddingTop: '3px'
				},
				disableUnderline: true,
				endAdornment: (
					<>
						<Tooltip
							title={
								text === null || text === '' || text === undefined
									? 'Please enter a valid text to save'
									: 'Please click to save'
							}
							placement="top"
						>
							<span>
								<Icon
									disabled={text === null || text === '' || text === undefined}
									src={tickIcon}
									type="pointer"
									alt="tickIcon"
									clickHandler={onAddition}
								/>
							</span>
						</Tooltip>
						<Tooltip
							title={
								(text === null || text === '' || text === undefined) &&
								(name === '' || name === null || name === undefined)
									? 'Please enter a valid text'
									: 'Please click to cancel the action'
							}
							placement="top"
						>
							<span>
								<Icon
									disabled={
										(text === null || text === '' || text === undefined) &&
										(name === '' || name === null || name === undefined)
									}
									src={closeIcon}
									type="pointer"
									alt="closeIcon"
									clickHandler={onClose}
								/>
							</span>
						</Tooltip>
					</>
				)
			}}
		/>
	);
}
