/* eslint-disable import/no-unused-modules */
import React from 'react';
import {
	Accordion,
	AccordionSummary,
	AccordionDetails,
	Grid,
	Typography,
	Tooltip
} from '@mui/material';
import ExpandMoreIcon from '../../../assets/arrows/caretDown.svg';
import ExpandLessIcon from '../../../assets/arrows/caretUp.svg';
import YamlEditor from '../../aceEditor';
import Icon from '../../icon';

function EnvAccordion({ expanded, handleChange, yamlContent, height, header }) {
	return (
		<Accordion disableGutters expanded={expanded}>
			<AccordionSummary aria-controls="panel-content" id="panel-header">
				<Grid container justifyContent="space-between" direction="row">
					<Typography fontSize="20px" color="rgba(255, 255, 255, 1)">
						{!header ? 'Environment Preview (Read only)' : header }
					</Typography>
					<Tooltip title={!expanded ? 'Expand' : 'Collapse'}>
						<div>
							<Icon
								src={!expanded ? ExpandMoreIcon : ExpandLessIcon}
								clickHandler={handleChange}
								style={{ padding: '0.3px 0px 0px 0px' }}
							/>
						</div>
					</Tooltip>
				</Grid>
			</AccordionSummary>
			<AccordionDetails>
				<Grid>
					{/* Code Editor Component */}
					<YamlEditor
						value={yamlContent}
						// eslint-disable-next-line react/jsx-boolean-value
						readOnly={true}
						style={{ height: height || '75vh' }}
					/>
				</Grid>
			</AccordionDetails>
		</Accordion>
	);
}

export default EnvAccordion;
