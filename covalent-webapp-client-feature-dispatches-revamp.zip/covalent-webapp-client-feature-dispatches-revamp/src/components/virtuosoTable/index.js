/* eslint-disable react/no-unstable-nested-components */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useEffect } from 'react';
import { TableVirtuoso } from 'react-virtuoso';
import { Grid, TableRow } from '@mui/material';

// ------------------------------------------------------------------------------------------------------------------------------------------------------------
// READ ME
// 1. height props can be the based on the number of rows you need (set height based on the number of rows you want to see)
// 2. limit props can be the rows u need to see on ui (for example if 10 rows set limit as 10 )
// limit prop is responsible for making table height dynamic if the data length is less than limit i.e.,(to have dynamic height if row count is less than limit)
// -------------------------------------------------------------------------------------------------------------------------------------------------------------

function VirtuosoTable(props) {
	const {
		ResultsTableHead,
		RenderRows,
		data,
		sortOrder,
		sortColumn,
		editSecretName,
		mode,
		handleChangeSort,
		limit, // limit props can be the number of rows u need to see on ui (for example if 10 rows set limit as 10 )
		height, // set height based on the number of rows you want to see
		onEditIconHandler,
		onDeleteIconHandler,
		fetchMoreData,
		bgColor,
		TableComponents
	} = props;
	const [gridHeight, setGridHeight] = useState(null);

	const calculateGridHeight = dataList => {
		let calculatedHeight = height;

		if (dataList?.length <= limit) {
			const baseHeight = 90;
			calculatedHeight = baseHeight + dataList.length * 35;
		}

		return calculatedHeight;
	};

	useEffect(() => {
		setGridHeight(calculateGridHeight(data));
	}, [data]);

	return (
		<Grid container item p={0} m={0} xs={12} sx={{ height: gridHeight }}>
			<TableVirtuoso
				style={{ width: '200%' }}
				data={data}
				endReached={fetchMoreData || ''}
				components={TableComponents || ''}
				overscan={700}
				fixedHeaderContent={() => (
					<TableRow
						style={{
							marginBottom: '5px',
							background: bgColor || '#08081a',
							cursor: 'default'
						}}
					>
						{data && data?.length > 0 && (
							<ResultsTableHead order={sortOrder} orderBy={sortColumn} onSort={handleChangeSort} />
						)}
					</TableRow>
				)}
				itemContent={(index, user) => (
					<RenderRows
						user={user}
						index={index}
						editSecretName={editSecretName}
						mode={mode}
						onEditIconHandler={onEditIconHandler}
						onDeleteIconHandler={onDeleteIconHandler}
					/>
				)}
			/>
		</Grid>
	);
}

// VirtuosoTable.propTypes = {
// 	ResultsTableHead: PropTypes.elementType.isRequired,
// 	RenderRows: PropTypes.elementType.isRequired,
// 	data: PropTypes.arrayOf(PropTypes.object).isRequired,
// 	sortOrder: PropTypes.string.isRequired,
// 	sortColumn: PropTypes.string.isRequired,
// 	handleChangeSort: PropTypes.func.isRequired,
// 	limit: PropTypes.number.isRequired,
// 	height: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired
// };

export default VirtuosoTable;
