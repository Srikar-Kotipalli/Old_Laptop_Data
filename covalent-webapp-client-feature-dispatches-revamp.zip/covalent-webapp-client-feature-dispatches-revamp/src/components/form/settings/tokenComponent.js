/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable import/no-unused-modules */
/* eslint-disable react/jsx-boolean-value */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useEffect, useState } from 'react';
import { Tooltip, tooltipClasses } from '@mui/material';
import Grid from '@mui/material/Grid';
import { Auth } from 'aws-amplify';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import { withStyles } from '@mui/styles';
import InputAdornment from '@mui/material/InputAdornment';
import Input from '@mui/material/Input';
import IconButton from '@mui/material/IconButton';
import Icon from '../../icon';
import visibilityOff from '../../../assets/hardware/visibilityOff.svg';
import visibilityOn from '../../../assets/hardware/visibilityOn.svg';
import reactIcon from '../../../assets/reset.svg';
import SettingsCopyButton from '../../copyButton/settings';
import { getUserAPIKey } from '../../../api/users/apiKey';
import useLength from '../../../utils/useLength';

function TokenComponent(props) {
	const [token, setToken] = useState('');
	const [tokenValue, setTokenValue] = useState('');
	const [visible, setVisible] = useState(false);

	// call to custom hook useLength
	const maxWidth = useLength({ xs: '200px', s: '200px', m: '260px', l: '270px', xl: '310px' });

	useEffect(() => {
		Auth.currentAuthenticatedUser().then(user => {
			const res = user?.attributes;
			const userID = res && res['custom:userID'];
			getUserAPIKey(userID)
				.then(payload => {
					if (payload) {
						setToken(payload[payload.length - 1].api_key);
						setTokenValue(payload[payload.length - 1].api_key);
					} else setToken('API key yet to be generated,please contact administrator');
				})
				.catch(() => {
					setToken('API key yet to be generated,please contact administrator');
				});
		});
	}, []);

	const {
		copyIcon,
		copiedIcon,
		width,
		height,
		isStartAdornReqd,
		fontSize,
		iconWidth,
		iconHeight,
		mxval,
		paddingVal,
		status,
		from,
		isDisabled,
		TooltipColor,
		copyEnable
	} = props;
	const DisabledInput = withStyles({
		root: {
			'& .MuiInput-input.Mui-disabled': {
				color: '#CBCBD7',
				WebkitTextFillColor: '#CBCBD7'
			}
		}
	})(Input);

	// get the input field value
	const getValueForInputField = () => {
		if (status && status === 'NA') return '';
		else if (from === 'settings') {
			if (visible) return token;
			return '*********************************';
		}
		return token;
	};

	return (
		<Box>
			<Grid container alignItems="center">
				{from === 'settings' && isDisabled === false && (
					<Typography sx={{ fontSize: '12px', paddingRight: '2px' }}>API Key</Typography>
				)}
				<Tooltip
					componentsProps={{
						popper: {
							sx: {
								[`& .${tooltipClasses.arrow}`]: {
									color: TooltipColor || null
								},
								[`& .${tooltipClasses.tooltip}`]: {
									backgroundColor: TooltipColor || null
								}
							}
						}
					}}
					placement="top"
					title={visible ? token : ''}
				>
					<DisabledInput
						sx={{
							padding: '8px 12px',
							pt: !visible ? 1.5 : 1,
							width: width || maxWidth,
							height: height || '32px',
							background: '#08081A',
							border: '1px solid #303067',
							borderRadius: '60px',
							fontSize: fontSize || '14px',
							color: '#CBCBD7',
							transition: 'width 0.3s ease-in-out',
							'&MuiInput-input.Mui-disabled': {}
						}}
						disabled={isDisabled}
						disableUnderline
						value={getValueForInputField()}
						onChange={e => console.log(e)}
						startAdornment={
							isStartAdornReqd ? (
								<InputAdornment position="start">
									<IconButton size="small">
										<img src={reactIcon} alt="reactIcon" role="presentation" />
									</IconButton>
								</InputAdornment>
							) : (
								<></>
							)
						}
					/>
				</Tooltip>

				<Box
					sx={{
						padding: paddingVal || '3px 4px',
						border: '1px solid #303067',
						borderRadius: '8px',
						width: iconWidth || '32px',
						height: iconHeight || '32px',
						mx: mxval || 1
					}}
				>
					{status && status === 'NA' ? (
						<></>
					) : (
						<>
							{from !== 'settings' ? (
								<SettingsCopyButton
									content={token}
									copyIcon={copyIcon}
									copiedIcon={copiedIcon}
									title="Copy"
								/>
							) : (
								<>
									<Tooltip title={visible ? 'Hide' : 'Unhide'} placement="top">
										<Grid>
											<Icon
												src={visible ? visibilityOn : visibilityOff}
												alt="visibilityOff"
												type="pointer"
												clickHandler={() => setVisible(prev => !prev)}
											/>
										</Grid>
									</Tooltip>
								</>
							)}
						</>
					)}
				</Box>

				{copyEnable && status !== 'NA' && (
					<Box
						sx={{
							padding: paddingVal || '3px 4px',
							border: '1px solid #303067',
							borderRadius: '8px',
							width: iconWidth || '32px',
							height: iconHeight || '32px'
						}}
					>
						<SettingsCopyButton
							content={tokenValue}
							copyIcon={copyIcon}
							copiedIcon={copiedIcon}
							title="Copy"
						/>
					</Box>
				)}
			</Grid>
		</Box>
	);
}

export default TokenComponent;
