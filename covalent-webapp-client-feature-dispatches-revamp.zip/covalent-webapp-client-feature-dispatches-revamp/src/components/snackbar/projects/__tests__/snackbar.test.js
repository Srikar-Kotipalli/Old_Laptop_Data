/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import '@testing-library/jest-dom';
import { render, screen, fireEvent } from '@testing-library/react';
import React from 'react';
import CustomisedSnackbar from '..';

describe('CustomisedSnackbar', () => {
	const mockAnchorEl = document.createElement('button');
	const open = Boolean(mockAnchorEl);
	test('CustomisedSnackbar  rendered', () => {
		const handleClick = jest.fn();
		render(
			<CustomisedSnackbar
				open={open}
				testId="projectSnackbar"
				message="Project added"
				action="addItem"
				multipleSelectedItems={[1, 2]}
				onClick={handleClick}
				onClose={handleClick}
				clickHandler={handleClick}
			/>
		);
		const element = screen.getByTestId('projectSnackbar');
		expect(element).toHaveTextContent(/Project added/i);
	});

	test('close snackbar', () => {
		const handleClick = jest.fn();
		render(
			<CustomisedSnackbar
				open={open}
				testId="projectSnackbar"
				message="Project added"
				action="addItem"
				multipleSelectedItems={[1, 2]}
				onClick={handleClick}
				onClose={handleClick}
				clickHandler={handleClick}
			/>
		);
		const element = screen.getByTestId('closeSnackbar');
		fireEvent.click(element);
		expect(handleClick).toBeCalledTimes(1);
	});

	test('undo action snackbar', () => {
		const handleClick = jest.fn();
		render(
			<CustomisedSnackbar
				open={open}
				testId="pinSnackbar"
				message="Project added"
				action="pin"
				multipleSelectedItems={[2]}
				onClick={handleClick}
				onClose={handleClick}
				clickHandler={handleClick}
			/>
		);
		const button = screen.getByRole('button', {
			name: /Undo/i
		});
		fireEvent.click(button);
		expect(handleClick).toBeCalledTimes(1);
	});
});
