import React from 'react';
import { Box, Chip, Stack, Tooltip, Typography } from '@mui/material';
import './style.css';

function OrganizationHardwareChip() {
	return (
		<Box>
			<Stack direction="row" spacing={1}>
				<Chip
					className="orgChip"
					label={
						<Tooltip title="python">
							<Typography variant="h3">python</Typography>
						</Tooltip>
					}
				/>
				<Chip
					className="orgChip"
					label={
						<Tooltip title="react">
							<Typography variant="h3">react</Typography>
						</Tooltip>
					}
				/>
				<Chip
					className="orgChip"
					label={
						<Tooltip title="rust">
							<Typography variant="h3">rust</Typography>
						</Tooltip>
					}
				/>
			</Stack>
		</Box>
	);
}

export default OrganizationHardwareChip;
