/* eslint-disable no-unused-vars */
import * as React from 'react';
import { Box, Typography, MenuItem, Select } from '@mui/material';
import TextField from '@mui/material/TextField';
import { makeStyles } from '@mui/styles';
import visibilityOff from '../../../assets/hardware/visibilityOff.svg';
import visibilityOn from '../../../assets/hardware/visibilityOn.svg';
import Icon from '../../icon';
import { getRandomInt } from '../../../utils/utils';

const useStyles = makeStyles({
	icon: { color: 'white' },
	root: { color: 'white' },
	notchedOutline: {
		borderWidth: '1px',
		borderColor: '#303067 !important',
		borderRadius: '60px'
	}
});

function LoginInput(props) {
	const {
		fieldName,
		placeholderTxt,
		placeholderValue,
		type,
		name,
		autoComplete,
		id,
		value,
		handleChange,
		handleEnter,
		typeInput,
		error,
		width,
		height
	} = props;
	const [isVisible, setIsVisible] = React.useState(false);
	const classes = useStyles();

	React.useEffect(() => {
		if (value === '') setIsVisible(false);
	}, [value]);

	// to get the type for text field
	const getTypeForTextField = () => {
		if (typeInput === 'password' && value !== '') {
			if (isVisible) return 'text';
			return 'password';
		}
		return typeInput;
	};

	// to return the visibility images on toggle
	const toggleVisibility = () => {
		if (isVisible) return visibilityOn;
		return visibilityOff;
	};

	return (
		<Box display="flex" flexDirection="column">
			<Typography
				variant="h1"
				sx={{
					fontSize: '14px',
					mb: 1,
					paddingLeft: '2px',
					color: 'textSecondary'
				}}
			>
				{fieldName}
			</Typography>
			{type === 'field' ? (
				<TextField
					id={id || `${name}-${getRandomInt(1, 100)}`}
					label={placeholderTxt}
					placeholder={placeholderValue}
					variant="outlined"
					sx={{
						px: 0.2,
						py: 2,
						pt: '5px',
						width: width || '300px',
						height: height || '32px',
						fontSize: '14px',
						color: error ? 'error' : 'textSecondary',
						'& .Mui-focused .MuiOutlinedInput-notchedOutline': {
							borderColor: '#6473ff !important'
						},
						'& .MuiOutlinedInput-notchedOutline': {
							width: width || '300px',
							height: height || '40px'
						},
						'& input::placeholder': {
							fontSize: '14px',
							color: '#CBCBD7'
						},
						'& .MuiFormHelperText-root': {
							marginTop: '6px',
							marginLeft: '-1px'
						},
						'& .MuiOutlinedInput-root': {
							paddingRight: '10px',
							paddingLeft: '10px',
							paddingTop: '7px'
						},
						'& .MuiInputLabel-root': {
							color: '#86869A',
							fontSize: '14px',
							marginTop: '-3px'
						},
						'& .MuiInputLabel-root.Mui-focused': {
							color: '#6473ff',
							top: '6px',
							left: '5px'
						},
						'& .MuiInputLabel-shrink': {
							top: '6px'
						}
					}}
					helperText={error}
					error={!!error}
					disabled={false}
					autoComplete={autoComplete || 'new-password'}
					name={name || placeholderTxt || 'name'}
					onChange={e => handleChange(e.target.value)}
					value={value || ''}
					// defaultValue={value || ''}
					onKeyPress={event => {
						if (event.key === 'Enter') {
							handleEnter();
						}
					}}
					type={getTypeForTextField()}
					InputProps={{
						endAdornment:
							typeInput === 'password' && value !== '' ? (
								<Icon
									src={toggleVisibility()}
									alt="off/on"
									clickHandler={() => setIsVisible(prevState => !prevState)}
									type="pointer"
									padding="0px 0px 3.5px 6px"
								/>
							) : null,
						classes: {
							notchedOutline: classes.notchedOutline
						}
					}}
				/>
			) : (
				<Select
					labelId="demo-simple-select-label"
					id="demo-simple-select"
					displayEmpty
					value={value}
					renderValue={option =>
						option == null ? 'Organization' : option ? 'Organization' : 'Individual'
					}
					onChange={e => handleChange(e.target.value)}
					sx={{
						fontSize: '14px',
						width: width || '300px',
						height: height || '32px',
						borderRadius: '60px',
						border: '1px solid #303067',
						px: 1.2,
						mt: 0.8
					}}
					inputProps={{
						classes: {
							icon: classes.icon
							// root: classes.icon
						}
					}}
					className="dropdownSelect"
				>
					<MenuItem value sx={{ fontSize: '14px' }}>
						Organization
					</MenuItem>
					<MenuItem value={false} sx={{ fontSize: '14px' }}>
						Individual
					</MenuItem>
				</Select>
			)}
		</Box>
	);
}

export default LoginInput;
