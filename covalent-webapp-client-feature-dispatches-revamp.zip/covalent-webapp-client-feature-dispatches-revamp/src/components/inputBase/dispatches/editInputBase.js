/* eslint-disable prefer-const */
/* eslint-disable react/jsx-no-duplicate-props */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';
import Tooltip from '@mui/material/Tooltip';
import TextField from '@mui/material/TextField';
import Icon from '../../icon';
import closeIcon from '../../../assets/checkmarks/closeError.svg';
import tickIcon from '../../../assets/checkmarks/checkmarkSuccess.svg';

// eslint-disable-next-line import/no-unused-modules
export default function EditInputBase(props) {
	const { editLatticeName, dispatch } = props;

	const [text, setText] = React.useState(dispatch?.name);

	const [error, setError] = React.useState('');
	let textInput = React.useRef(null);

	React.useEffect(() => {
		textInput.current.focus();
	}, []);

	const onChange = e => {
		const newValue = e.target.value;
		if (!newValue.match(/[%<>\\$'"]/)) {
			setText(newValue);
			setError('');
		} else {
			setError('Forbidden characters not allowed');
		}
	};
	const onFocus = event => {
		const target = event.target;
		setTimeout(() => target.select(), 0);
	};
	return (
		<TextField
			variant="standard"
			data-testid="inputBase"
			helperText={error}
			error={!!error}
			name="text"
			value={text}
			style={{ width: '80%' }}
			inputProps={{
				maxLength: 50,
				autoComplete: 'off',
				style: {
					fontSize: '14px',
					paddingBottom: '1px'
				}
			}}
			type="text"
			onChange={e => onChange(e)}
			onFocus={e => onFocus(e)}
			inputRef={textInput}
			onKeyDown={e => e.key === 'Enter' && text !== '' && editLatticeName(text, 'save', dispatch)}
			InputProps={{
				disableUnderline: true,
				endAdornment: (
					<>
						<Tooltip
							title={
								text === null || text === '' || text === undefined
									? 'Please enter a valid text to save'
									: 'Please click to save'
							}
							placement="top"
						>
							<span>
								<Icon
									disabled={text === null || text === '' || text === undefined}
									src={tickIcon}
									type="pointer"
									alt="tickIcon"
									clickHandler={e => {
										e?.stopPropagation();
										editLatticeName(text, 'save', dispatch);
									}}
								/>
							</span>
						</Tooltip>
						<Tooltip title="Please click to cancel the action" placement="top">
							<span>
								<Icon
									src={closeIcon}
									type="pointer"
									alt="closeIcon"
									clickHandler={e => {
										e?.stopPropagation();
										editLatticeName(text, 'close', dispatch);
									}}
								/>
							</span>
						</Tooltip>
					</>
				)
			}}
		/>
	);
}
