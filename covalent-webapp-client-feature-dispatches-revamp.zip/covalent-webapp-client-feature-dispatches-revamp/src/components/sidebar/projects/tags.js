/* eslint-disable react/jsx-no-useless-fragment */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import Chip from '@mui/material/Chip';
import Grid from '@mui/material/Grid';
import { Box } from '@mui/material';
import { makeStyles } from '@mui/styles';
import TagsInput from '../../inputBase/projects/tagsInput';
import editIcon from '../../../assets/actions/edit.svg';
import { ProjectContext } from '../../../containers/projects/projectContext';
import { addEditDeleteTags } from '../../../api/experiments/dispatchApi';
import './style.css';
import loader from '../../../assets/loaders/moveLoader.svg';
import Icon from '../../icon';

const useStyles = makeStyles({
	chipRoot: {
		marginRight: '5px',
		marginBottom: '5px',
		'& .MuiChip-label': {
			padding: '0px 2px 0px 4px'
		},
		'& .MuiChip-icon': {
			order: 1,
			marginRight: '4px',
			cursor: 'pointer'
		},
		'& .MuiChip-deleteIcon': {
			order: 2,
			color: '#9999b2'
		}
	},
	addChip: {
		marginRight: '5px',
		marginBottom: '5px',
		'& .MuiChip-label': {
			padding: '0px 7px 0px 7px'
		}
	}
});

export default function Tags(props) {
	const projectContext = React.useContext(ProjectContext);
	const { setOpenProjectSnackbar, setSnackbarMessage, postTagAddition } = projectContext;
	const { sidebarTags, type, setExperimentData } = props;
	const [isLoading, setIsLoading] = React.useState(false);
	const [editableText, setEditableText] = React.useState('');
	const classes = useStyles();
	const addTags = () => {
		const editData = sidebarTags;
		editData.isAddTag = true;
		setEditableText('');
		setExperimentData({ ...editData });
	};

	const saveSidebarTags = (text, action, _types, _listItem, crudAction) => {
		const addData = sidebarTags;
		if (action === 'save') {
			let parameter = null;
			let tagsArray = text.trim().replace(/ +/g, ' ').toLowerCase().split(/,+/);
			tagsArray = tagsArray.filter(e => e !== '');
			tagsArray = tagsArray.map(e => e.trim());
			const stringLength = tagsArray.map(w => w.length);
			if (stringLength.filter(e => e > 25).length > 0) {
				setOpenProjectSnackbar(true);
				setSnackbarMessage('Tags should be less than 25 chars');
			} else if (tagsArray.filter(e => e === ' ' || e === undefined).length > 0) {
				setOpenProjectSnackbar(true);
				setSnackbarMessage('Tags cannot be empty strings');
			} else {
				const finalTags = addData.tags;
				if (crudAction === 'edit') {
					const index = finalTags?.indexOf(editableText);
					finalTags?.splice(index, 1);
				}
				parameter = {
					id: addData.id,
					tags: [...new Set([...finalTags, ...tagsArray])]
				};
				setIsLoading(true);
				addEditDeleteTags(parameter)
					.then(() => {
						addData.tags = [...new Set([...finalTags, ...tagsArray])];
						addData.isAddTag = false;
						postTagAddition(sidebarTags, addData.tags, crudAction);
						setExperimentData({ ...addData });
						setOpenProjectSnackbar(true);
						setIsLoading(false);
						setSnackbarMessage(
							`Tag${crudAction === 'edit' ? ' edited' : '(s) added'} successfully!`
						);
					})
					.catch(() => {
						setOpenProjectSnackbar(true);
						setIsLoading(false);
						setSnackbarMessage('Something went wrong,please contact the administrator!');
					});
			}
		} else {
			addData.isAddTag = false;
			setExperimentData({ ...addData });
		}
	};

	const deleteTags = tags => {
		const deletableTags = sidebarTags;
		let index = null;
		if (deletableTags?.tags.length > 0) index = deletableTags?.tags?.indexOf(tags);
		setIsLoading(true);
		if (index !== -1) {
			deletableTags?.tags?.splice(index, 1);
			const parameter = {
				id: deletableTags.id,
				tags: [...deletableTags.tags]
			};
			addEditDeleteTags(parameter)
				.then(() => {
					postTagAddition(sidebarTags, deletableTags?.tags, 'delete');
					setExperimentData({ ...deletableTags });
					setOpenProjectSnackbar(true);
					setIsLoading(false);
					setSnackbarMessage('Tag deleted successfully!');
				})
				.catch(() => {
					setOpenProjectSnackbar(true);
					setIsLoading(false);
					setSnackbarMessage('Something went wrong,please contact the administrator');
				});
		}
	};

	const editTags = tagText => {
		const editData = sidebarTags;
		editData.isAddTag = true;
		setEditableText(tagText);
		setExperimentData({ ...editData });
	};

	return (
		<Box>
			{isLoading && (
				<Icon
					src={loader}
					padding="0px 0px 5% 45%"
					width="27px"
					height="27px"
					type="static"
					alt="loaderIcon"
				/>
			)}
			{sidebarTags?.isAddTag && !isLoading ? (
				<Grid
					sx={{
						height: isLoading ? null : '7.7vh'
					}}
				>
					<TagsInput
						type={type}
						listItem={sidebarTags}
						saveSidebarTags={saveSidebarTags}
						editableText={editableText}
						setEditableText={setEditableText}
					/>
				</Grid>
			) : (
				<Grid
					container
					direction="row"
					spacing={2}
					alignItems="start"
					sx={{
						overflowY: 'auto',
						height: isLoading ? null : '7.7vh',
						marginTop: '0px',
						padding: '0px 0px 0px 16px'
					}}
				>
					{!isLoading && (
						<Box>
							{sidebarTags?.tags &&
								sidebarTags?.tags.map(tags => (
									<Chip
										classes={{
											root: classes.chipRoot
										}}
										variant="filled"
										size="small"
										label={tags}
										key={tags}
										onDelete={() => deleteTags(tags)}
										icon={
											<span>
												<Icon
													src={editIcon}
													clickHandler={() => editTags(tags)}
													padding="1px 0px 1px 1px"
												/>
											</span>
										}
									/>
								))}
							{!sidebarTags?.isAdd && (
								<Chip
									classes={{
										root: classes.addChip
									}}
									variant="filled"
									size="small"
									label="+add"
									sx={{ backgroundColor: '#08081A' }}
									onClick={() => addTags()}
								/>
							)}
						</Box>
					)}
				</Grid>
			)}
		</Box>
	);
}
