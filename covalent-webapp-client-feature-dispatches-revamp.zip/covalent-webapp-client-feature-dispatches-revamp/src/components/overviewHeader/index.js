/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import { Avatar, Box, Grid, Stack, Typography } from '@mui/material';
import Icon from '../icon';

function OverviewHeader({ data, image }) {
	return (
		<Grid container p={0} mt={4} alignItems="center">
			<Grid item xs={4} p={0}>
				<Stack direction="row" spacing={2} alignItems="center">
					{image ? (
						<Box>
							<Icon src={image} alt="env image" width="82px" height="82px" type="static" />
						</Box>
					) : (
						<Avatar
							sx={{
								bgcolor: theme => theme.palette.background.blue13,
								width: '82px',
								height: '82px',
								color: theme => theme.palette.text.primary,
								borderRadius: '20px'
							}}
							variant="rounded"
						>
							S
						</Avatar>
					)}
					<Box>
						{data?.name && (
							<Typography
								variant="h5"
								sx={{ color: theme => theme.palette.text.gray04, cursor: 'default' }}
							>
								{data?.name}
							</Typography>
						)}
						{data?.desc && (
							<Typography variant="h2" mt={2} sx={{ cursor: 'default' }}>
								{data?.desc}
							</Typography>
						)}
					</Box>
				</Stack>
			</Grid>
		</Grid>
	);
}

export default OverviewHeader;
