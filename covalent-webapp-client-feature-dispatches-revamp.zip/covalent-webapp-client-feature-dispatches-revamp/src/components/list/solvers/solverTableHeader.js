/* eslint-disable react/jsx-no-useless-fragment */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import { TableHead } from '@mui/material';
import TableSortLabel from '@mui/material/TableSortLabel';
import Checkbox from '@mui/material/Checkbox';
import Box from '@mui/material/Box';
import Icon from '../../icon';
import checkbox from '../../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../../assets/checkboxes/checkboxChecked.svg';
import checkboxDisabled from '../../../assets/checkboxes/checkboxdisabled.svg';
import ContextMenu from '../../menu/projects/contextMenu';
import '../projects/style.css';
import { ProjectContext } from '../../../containers/projects/projectContext';
import { SOLVERS_HEADER } from '../../../constants/tableHeaderConstants';

function SolverTableHeader({
	headerCellHeight,
	checkAllHandler,
	selectAll,
	order,
	orderBy,
	onSort
}) {
	const projectContext = React.useContext(ProjectContext);
	const header = SOLVERS_HEADER;
	const { showArchived, addMode } = projectContext;
	return (
		<>
			{!!header.length && (
				<TableHead sx={{ height: headerCellHeight, '& th': { border: 0 } }}>
					<TableRow className="tableHeader" sx={{ '& td': { border: 0 } }}>
						<TableCell
							align="left"
							sx={{
								width: '7%'
							}}
						>
							<Box display="flex" flexDirection="row">
								<Checkbox
									data-testid="headerCheckbox"
									size="small"
									sx={{ padding: '5px 0px 0px 5px' }}
									checked={selectAll}
									onChange={e => checkAllHandler(e)}
									icon={
										<Icon
											src={!showArchived && !addMode ? checkbox : checkboxDisabled}
											alt="checkbox"
											type="pointer"
										/>
									}
									checkedIcon={<Icon src={checkboxChecked} alt="checkboxChecked" type="pointer" />}
									disabled={showArchived || addMode}
								/>
								<Box sx={{ paddingTop: '5px', paddingLeft: '6px' }}>
									<ContextMenu type="multiselect" />
								</Box>
							</Box>
						</TableCell>
						{header.map(h => (
							<TableCell
								sx={{ paddingLeft: h.id === 'title' ? '0.65rem' : '0rem' }}
								width={h.width}
								key={h.id}
								colSpan={h.colSpan || 1}
								align={h.align || 'center'}
								data-testid="tableHeader"
							>
								<TableSortLabel
									active={orderBy === h.id}
									direction={orderBy === h.id ? order : 'asc'}
									onClick={() => onSort(h.id)}
									disabled={h.id === 'tags'}
									data-testid="tableSort"
								>
									{h.label}
								</TableSortLabel>
							</TableCell>
						))}
					</TableRow>
				</TableHead>
			)}
		</>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default SolverTableHeader;
