/* eslint-disable camelcase */
/* eslint spaced-comment: ["error", "always"] */
/* eslint-disable react/jsx-curly-brace-presence */
/* eslint no-inline-comments: "error" */

import React from 'react';
import { Table, TableBody, TableRow, Box } from '@mui/material';
import BillingTableHeader from './tableHeader';
import BillingTableRow from './tableRow';
import BillingTableFooter from './tableFooter';
import NoRecordsFound from './noRecordsFound';
import { BillingContext } from '../../../containers/settings/billing/billingContext';
import Loader from '../../loader';

function BillingTable() {
	const billingContext = React.useContext(BillingContext);
	const { invoices, invoicesLoader } = billingContext;

	return (
		<>
			<Table width="100%">
				<BillingTableHeader />
				<TableBody>
					{!invoicesLoader &&
						invoices &&
						invoices.map((invoice, index) => (
							<TableRow key={invoice?.external_invoice_id} data-testid="billingListView">
								<BillingTableRow invoice={invoice} index={index} hierarchyType="dispatch" />
							</TableRow>
						))}
				</TableBody>
			</Table>
			{invoicesLoader && (
				<Box mt={7}>
					<Loader isFetching={invoicesLoader} position="relative" width="75%" height="100%" />
				</Box>
			)}
			<BillingTableFooter />
			{!invoicesLoader && invoices?.length === 0 && <NoRecordsFound />}
		</>
	);
}

export default BillingTable;
