/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import Grid from '@mui/material/Grid';
import Avatar from '@mui/material/Avatar';
import { Tooltip, Box } from '@mui/material';
import { Link } from 'react-router-dom';
import Icon from '../../icon';
import dispatchIcon from '../../../assets/dispatch/dispatchIcon.svg';
import './style.css';
import { capitalizeName, dateFormatter } from '../../../utils/utils';
import { statusIcon } from '../../../utils/statusIcons';
import RuntimeTooltip from '../../tooltip/runTimeTooltip';
import EllipsisDefaultTooltip from '../../tooltip/ellipsisTooltip';
import CopyButton from '../../copyButton';
import ListTagsShared from '../../shared/listTagsShared';
import OverflowTooltip from '../../tooltip/overflowTooltip';
import useLength from '../../../utils/useLength';

export default function DispatchRow(props) {
	const { dispatch, showArchived, filterTags } = props;

	// call to custom hook useLength
	const len = useLength({ xs: 12, s: 23, m: 28, l: 28, xl: 45 });

	return (
		<>
			<TableCell width="25%" align="left">
				<Box display="flex" flexDirection="row" ml={1}>
					<Box paddingTop="1px">
						<Icon src={dispatchIcon} alt="dispatchIcon" type="static" padding="0px 3px 3.5px 0px" />
					</Box>
					<Box marginLeft={1}>
						<Link
							style={{ color: '#CBCBD7', textDecoration: 'none' }}
							to={`/graph/${dispatch.id}`}
							state={{
								userId: dispatch?.ownerId
							}}
						>
							{/* <Grid container sx={{ width: '190%' }}> */}
							<OverflowTooltip
								title={dispatch.title}
								length={len}
								position="top-start"
								width="100%"
							/>
							{/* </Grid> */}
						</Link>
					</Box>
				</Box>
			</TableCell>
			<TableCell align="right" width="10%" sx={{ paddingRight: '3rem' }}>
				<Box display="flex" flexDirection="row" justifyContent="space-between">
					{statusIcon(dispatch.status, '0px 3px 3.5px 0px', 'dashboard')}
					<EllipsisDefaultTooltip
						variant="subtitle2"
						value={`${dispatch?.completedElectrons}/${dispatch?.totalElectrons}`}
						type="dispatch"
						width="80px"
						attribute="electron"
						paddingLeft="3px"
						paddingBottom="2px"
					/>
				</Box>
			</TableCell>
			<TableCell align="left" width="20%">
				<ListTagsShared items={dispatch} showArchived={showArchived} filterTags={filterTags} />
			</TableCell>
			<TableCell align="left" width="5%">
				<RuntimeTooltip value={dispatch.runTime} placement="top" />
			</TableCell>
			<TableCell align="left" width="11%">
				{dispatch.startTime ? dateFormatter(dispatch.startTime) : ''}
			</TableCell>
			<TableCell align="left" width="11%">
				{dateFormatter(dispatch.lastUpdated)}
			</TableCell>

			<TableCell align="left" width="2%">
				<Tooltip title={capitalizeName(dispatch?.shared[0].sharedByName) || ''}>
					<Avatar
						sx={{
							width: 24,
							height: 24,
							fontSize: 12,
							bgcolor: '#8B31FF',
							color: 'white'
						}}
					>
						{capitalizeName(dispatch?.shared[0].sharedByName?.slice(0, 1)) || ''}
					</Avatar>
				</Tooltip>
			</TableCell>
			<TableCell align="left" width="5%" sx={{ paddingRight: '0.5rem' }}>
				<Grid style={{ paddingLeft: '10px' }}>
					<CopyButton content={dispatch.title} />
				</Grid>
			</TableCell>
		</>
	);
}
