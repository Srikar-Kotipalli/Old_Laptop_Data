/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableRow from '@mui/material/TableRow';
import DispatchRow from './dispatchRow';
import DispatchTableHeader from './tableheader';
import './style.css';
import TableFooter from './tableFooter';
import NoRecordsFound from './noRecordsFound';
import { ProjectContext } from '../../../containers/projects/projectContext';

export default function DispatchesListView() {
	const projectContext = React.useContext(ProjectContext);
	const { allItems } = projectContext;

	return (
		<>
			<Table width="100%">
				<DispatchTableHeader />
				<TableBody>
					{allItems &&
						allItems.map((dispatch, index) => (
							<TableRow key={dispatch.id} data-testid="dispatchListView">
								<DispatchRow dispatch={dispatch} index={index} hierarchyType="dispatch" />
							</TableRow>
						))}
					{allItems && allItems.length === 0 && <NoRecordsFound />}
				</TableBody>
			</Table>
			<TableFooter />
		</>
	);
}
