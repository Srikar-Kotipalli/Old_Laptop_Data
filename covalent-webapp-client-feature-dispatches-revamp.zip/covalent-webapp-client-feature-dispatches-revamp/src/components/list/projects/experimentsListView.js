/* eslint-disable react/jsx-boolean-value */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableRow from '@mui/material/TableRow';
import DispatchRow from './dispatchRow';
import ExperimentRow from './experimentRow';
import TableHeader from './tableheader';
import TableFooter from './tableFooter';
import NoRecordsFound from './noRecordsFound';
import MoreRecords from './moreRecords';
import './style.css';
import { ProjectContext } from '../../../containers/projects/projectContext';

export default function ExperimentsListView() {
	function getBorderStyle(experiment) {
		return experiment?.isOpen && !experiment?.isLoader;
	}
	const projectContext = React.useContext(ProjectContext);
	const { allItems, sidebarId, openSidebar } = projectContext;
	return (
		<>
			<Table data-testid="experimentsList" width="100%">
				<TableHeader />
				<TableBody>
					{allItems &&
						allItems.map((experiment, allExperimentIndex) => (
							<React.Fragment key={experiment.id}>
								{experiment.type === 'Experiment' && (
									<React.Fragment key={experiment.id}>
										<TableRow
											sx={{
												borderLeft:
													getBorderStyle(experiment) && experiment?.hierarchyListItems
														? '1px solid #6473FF'
														: '',
												borderRight:
													getBorderStyle(experiment) && experiment?.hierarchyListItems
														? '1px solid #6473FF'
														: '',
												borderTop:
													getBorderStyle(experiment) && experiment?.hierarchyListItems
														? '1px solid #6473FF'
														: '',
												borderRadius: '8px',
												backgroundColor:
													experiment?.isOpen || (openSidebar && sidebarId === experiment?.id)
														? '#1c1c46'
														: ''
											}}
										>
											<ExperimentRow
												experiment={experiment}
												allListIndex={allExperimentIndex}
												type="experiment"
											/>
										</TableRow>
										{experiment?.isOpen &&
											!experiment?.isLoader &&
											experiment.hierarchyListItems &&
											experiment.hierarchyListItems.map((dispatch, index) => (
												<TableRow
													data-testid="experimentDispatch"
													key={dispatch.id}
													sx={{
														borderLeft: getBorderStyle(experiment) ? '1px solid #6473FF' : '',
														borderRight: getBorderStyle(experiment) ? '1px solid #6473FF' : '',
														borderBottom:
															experiment?.isOpen &&
															!experiment?.isLoader &&
															index === experiment.hierarchyListItems.length - 1 &&
															experiment.hierarchyListItems.length ===
																experiment.hierarchyListItemsTotalCount
																? '1px solid #6473FF'
																: ''
													}}
												>
													<DispatchRow
														dispatch={dispatch}
														index={allExperimentIndex}
														secondaryIndex={index}
														indentType="singleHierarchy"
													/>
												</TableRow>
											))}
										{experiment?.isOpen &&
											!experiment?.isLoader &&
											experiment.hierarchyListItems &&
											experiment.hierarchyListItems.length === 0 && (
												<NoRecordsFound
													style={{
														borderLeft: getBorderStyle(experiment) ? '1px solid #6473FF' : '',
														borderRight: getBorderStyle(experiment) ? '1px solid #6473FF' : '',
														borderBottom: getBorderStyle(experiment) ? '1px solid #6473FF' : ''
													}}
												/>
											)}
										{experiment?.isOpen &&
											!experiment?.isLoader &&
											experiment.hierarchyListItems &&
											experiment.hierarchyListItemsTotalCount >
												experiment.hierarchyListItems.length && (
												<MoreRecords
													style={{
														borderLeft: getBorderStyle(experiment) ? '1px solid #6473FF' : '',
														borderRight: getBorderStyle(experiment) ? '1px solid #6473FF' : '',
														borderBottom: getBorderStyle(experiment) ? '1px solid #6473FF' : ''
													}}
													leftVal="2.2rem"
													mainType="Experiment"
													index={allExperimentIndex}
													open={true}
													count={experiment.hierarchyListItems.length + 5}
													leftValText="0.1rem"
												/>
											)}
									</React.Fragment>
								)}
								{experiment.type === 'Dispatch' && (
									<TableRow key={experiment.id}>
										<DispatchRow dispatch={experiment} index={allExperimentIndex} />
									</TableRow>
								)}
							</React.Fragment>
						))}
					{allItems && allItems.length === 0 && <NoRecordsFound />}
				</TableBody>
			</Table>
			<TableFooter />
		</>
	);
}
