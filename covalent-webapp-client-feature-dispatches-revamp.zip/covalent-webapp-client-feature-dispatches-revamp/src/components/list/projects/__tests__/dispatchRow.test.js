/* eslint-disable react/jsx-no-constructed-context-values */
/* eslint-disable testing-library/no-node-access */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
import DispatchRow from '../dispatchRow';
import { ProjectContext } from '../../../../containers/projects/projectContext';

const dispatch = {
	title: 'Dispatch Eta',
	tags: ['react', 'aws', 'python', '2+'],
	status: 'COMPLETED',
	completedElectrons: '10',
	totalElectrons: '10',
	startTime: '03 Feb, 12:05:38',
	lastUpdated: '03 Feb, 12:05:38',
	runTime: '1h 14m 20s',
	isPinned: true
};

const timeFormatter = jest.fn();
const dateFormatter = jest.fn();

describe('dispatch Row', () => {
	test('renders dispatchRow', () => {
		render(
			<DispatchRow
				dispatch={dispatch}
				timeFormatter={timeFormatter}
				dateFormatter={dateFormatter}
			/>
		);
		const element = screen.getByTestId('dispatchRow');
		expect(element).toBeInTheDocument();
	});

	test('calls onCheckbox function on clicking checkbox', () => {
		const handleClick = jest.fn();
		render(
			<ProjectContext.Provider value={{ onCheckboxChecked: handleClick }}>
				<DispatchRow
					dispatch={dispatch}
					timeFormatter={timeFormatter}
					dateFormatter={dateFormatter}
				/>
			</ProjectContext.Provider>
		);
		const element = screen.getByTestId('dispatchCheckbox').querySelector('input[type="checkbox"]');
		expect(element).toBeInTheDocument();
		fireEvent.click(element);
		expect(handleClick).toBeCalledTimes(1);
	});
});
