/* eslint-disable react/jsx-no-constructed-context-values */
/* eslint-disable testing-library/no-node-access */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
import ProjectRow from '../projectRow';

const project = {
	id: '626a470fc265a015b9ae9445',
	title: 'Steel Grouse Big Deal',
	count: 5,
	lastUpdated: '2022-04-28T13:19:35.131000',
	type: 'Project',
	isAdd: true
};

describe('project Row', () => {
	test('renders projectRow', () => {
		render(<ProjectRow list={project} />);
		const element = screen.getByTestId('projectRow');
		expect(element).toBeInTheDocument();
	});
	test('renders inputbase for new added project', () => {
		render(<ProjectRow list={project} />);
		const element = screen.getByTestId('inputBase');
		expect(element).toBeInTheDocument();
		const elementType = element.querySelector('input');
		expect(elementType).toBeInTheDocument();
		fireEvent.change(elementType, { target: { value: 'User' } });
		const inputValue = screen.getByDisplayValue('User');
		expect(inputValue).toBeInTheDocument();
	});
});
