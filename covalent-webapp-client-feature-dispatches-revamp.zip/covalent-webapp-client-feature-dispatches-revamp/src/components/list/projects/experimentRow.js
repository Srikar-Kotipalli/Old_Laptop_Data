/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import { Box } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import ContextMenu from '../../menu/projects/contextMenu';
import Icon from '../../icon';
import experimentIcon from '../../../assets/folderIcons/folderClosed.svg';
import experimentSidebarOpen from '../../../assets/folderIcons/experimentSidebarOpen.svg';
import experimentOpen from '../../../assets/folderIcons/experimentsOpen.svg';
import checkbox from '../../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../../assets/checkboxes/checkboxChecked.svg';
import checkboxDisabled from '../../../assets/checkboxes/checkboxdisabled.svg';
import checkboxCheckedDisabled from '../../../assets/checkboxes/checkboxCheckedDisabled.svg';
import loader from '../../../assets/loaders/loader.svg';
import caretDown from '../../../assets/arrows/caretDown.svg';
import caretRight from '../../../assets/arrows/caretRight.svg';
import caretRightDisabled from '../../../assets/arrows/caretRightDisabled.svg';
import './style.css';
import { dateFormatter } from '../../../utils/utils';
import { statusIcon } from '../../../utils/statusIcons';
import RuntimeTooltip from '../../tooltip/runTimeTooltip';
import EllipsisDefaultTooltip from '../../tooltip/ellipsisTooltip';
import CustomInputBase from '../../inputBase/projects';
// eslint-disable-next-line import/no-named-as-default
import ListTags from '../../tags/projects/listTags';
import { ProjectContext } from '../../../containers/projects/projectContext';
import OverflowTooltip from '../../tooltip/overflowTooltip';
import useLength from '../../../utils/useLength';

// eslint-disable-next-line import/no-unused-modules
export default function ExperimentRow(props) {
	const { experiment, type, allListIndex, listHierarchyIndex } = props;
	const projectContext = React.useContext(ProjectContext);
	const {
		sidebarHandler,
		openSidebar,
		sidebarId,
		showArchived,
		searchValue,
		tagsToFilter,
		onCheckboxChecked,
		handleOpenAllProjects,
		handleOpenExperiments
	} = projectContext;

	const typeFn = () => {
		if (type === 'experimentProject') {
			return 'openHierarchyInsideProject';
		}
		return 'openExperiment';
	};

	const closeTypeFn = () => {
		if (type === 'experimentProject') {
			return 'closeHierarchyInsideProject';
		}
		return 'closeExperiment';
	};

	// call to custom hook useLength
	const len = useLength({ xs: 12, s: 23, m: 28, l: 28, xl: 45 });

	// to get experiment icon based on the open/close state
	const getExperimentIcon = () => {
		if (experiment?.isOpen && !experiment?.isLoader)
			return <Icon src={experimentOpen} type="static" padding="0px 3px 3.5px 0px" />;
		return <Icon src={experimentIcon} type="static" padding="0px 3px 3.5px 0px" />;
	};

	return (
		<>
			<TableCell
				align="left"
				sx={{
					width: '7%'
				}}
			>
				<Box
					display="flex"
					flexDirection="row"
					paddingLeft={type === 'experimentProject' ? '1.9rem' : '1%'}
				>
					<Box sx={{ paddingTop: '1px' }}>
						<Checkbox
							icon={
								<Icon
									src={
										!showArchived && !experiment.isOpen && !experiment.isAdd
											? checkbox
											: checkboxDisabled
									}
									alt="checkbox"
									type="pointer"
								/>
							}
							checkedIcon={
								<Icon
									src={experiment.isOpen ? checkboxCheckedDisabled : checkboxChecked}
									alt="checkboxChecked"
									type="pointer"
								/>
							}
							data-testid="projectExperimentCheckbox"
							disabled={experiment.isOpen || showArchived || experiment.isAdd}
							size="small"
							value={experiment.id}
							checked={experiment.isChecked}
							onChange={e => onCheckboxChecked(e, experiment)}
						/>
					</Box>
					<Box
						align="left"
						sx={{
							paddingBottom: '3px',
							paddingTop: '4px',
							paddingLeft: '0.3rem'
						}}
					>
						{!(searchValue?.length >= 3 || tagsToFilter.length > 0) ? (
							// eslint-disable-next-line react/jsx-no-useless-fragment
							<>
								{experiment?.isOpen && !experiment?.isLoader && (
									<Icon
										src={caretDown}
										alt="caretDown"
										clickHandler={
											type === 'experimentProject'
												? () =>
														handleOpenAllProjects(
															allListIndex,
															'allProjectExperiments',
															false,
															listHierarchyIndex,
															'list',
															5
														)
												: () => handleOpenExperiments(allListIndex, false, 'list', 5)
										}
										type="pointer"
										testId={typeFn()}
										padding="5px 3px 3.5px 3px"
									/>
								)}

								{experiment?.isOpen && experiment?.isLoader && (
									<Icon src={loader} alt="runningIcon" type="static" padding="5px 3px 3.5px 3px" />
								)}
								{!experiment?.isOpen && !experiment?.isLoader && (
									<Icon
										src={experiment?.isAdd ? caretRightDisabled : caretRight}
										clickHandler={
											type === 'experimentProject'
												? () =>
														handleOpenAllProjects(
															allListIndex,
															'allProjectExperiments',
															true,
															listHierarchyIndex,
															'list',
															5
														)
												: () => handleOpenExperiments(allListIndex, true, 'list', 5)
										}
										type="pointer"
										alt="caretRight"
										disabled={experiment?.isAdd}
										testId={closeTypeFn()}
										padding="5px 3px 3.5px 3px"
									/>
								)}
							</>
						) : (
							// eslint-disable-next-line react/jsx-no-useless-fragment
							<></>
						)}
					</Box>
				</Box>
			</TableCell>
			<TableCell
				width="20%"
				align="left"
				data-testid="experimentRow"
				sx={{
					'&:hover': {
						cursor: !showArchived ? 'pointer' : 'default'
					}
				}}
			>
				<Box display="flex" flexDirection="row">
					<Box style={{ paddingTop: '1px' }}>
						{openSidebar && sidebarId === experiment?.id ? (
							<Icon src={experimentSidebarOpen} type="static" padding="0px 3px 3.5px 0px" />
						) : (
							// eslint-disable-next-line react/jsx-no-useless-fragment
							<>{getExperimentIcon()}</>
						)}
					</Box>
					<Box style={{ paddingLeft: '6px' }}>
						{experiment.isAdd ? (
							<CustomInputBase type={type} listItem={experiment} />
						) : (
							// <Grid
							// 	container
							// 	// sx={{ width: '100%' }}
							// 	// onClick={() => {
							// 	// 	if (!showArchived) sidebarHandler(experiment.id, experiment.type);
							// 	// }}
							// >
							<OverflowTooltip
								title={experiment.title}
								length={len}
								position="top-start"
								width="100%"
								clickHandle={() => {
									if (!showArchived) sidebarHandler(experiment.id, experiment.type);
								}}
							/>
							// </Grid>
						)}
					</Box>
				</Box>
			</TableCell>
			<TableCell align="left" width="8%">
				<Box display="flex" flexDirection="row">
					{statusIcon(experiment.status, '0px 3px 3.5px 0px', 'dashboard')}
					<EllipsisDefaultTooltip
						variant="subtitle2"
						value={`${experiment.completedElectrons}/${experiment.totalElectrons}`}
						paddingLeft="3px"
						attribute="electron"
						paddingBottom="2px"
						width="80px"
						type="dispatch"
					/>
				</Box>
			</TableCell>
			<TableCell align="left" width="28%">
				<ListTags items={experiment} type={type} />
			</TableCell>
			<TableCell width="9%" align="left">
				<RuntimeTooltip value={experiment.runTime} placement="top" />
			</TableCell>
			<TableCell align="left" width="12%">
				{experiment.startTime && dateFormatter(`${experiment.startTime}Z`)}
			</TableCell>
			<TableCell align="left" width="12%">
				{experiment.lastUpdated && dateFormatter(`${experiment.lastUpdated}Z`)}
			</TableCell>
			<TableCell width="2%" />
			<TableCell align="left" width="2%" />
			<TableCell width="2%" align="left">
				<ContextMenu
					type="experiment"
					experiment={experiment}
					rowType="experimentRow"
					disabled={experiment.isOpen}
					margin={1}
				/>
			</TableCell>
		</>
	);
}
