/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';
import { makeStyles } from '@mui/styles';
import TableCell from '@mui/material/TableCell';
import Box from '@mui/material/Box';
import TableRow from '@mui/material/TableRow';
import { ProjectContext } from '../../../containers/projects/projectContext';
import caretDown from '../../../assets/arrows/caretDown.svg';
import loader from '../../../assets/loaders/loader.svg';
import Icon from '../../icon';
import './style.css';

export default function MoreRecords(props) {
	const projectContext = React.useContext(ProjectContext);
	const { handleOpenExperiments, handleOpenAllProjects } = projectContext;
	const { style, leftVal, mainType, index, type, open, secondaryIndex, count, leftValText } = props;
	const [isOpen, setIsOpen] = React.useState(false);
	const useStyles = makeStyles(() => ({
		tableRow: {
			'&:hover': {
				backgroundColor: 'transparent'
			}
		}
	}));
	const classes = useStyles();
	const onClickShowMore = () => {
		setIsOpen(true);
		if (mainType === 'Project') {
			handleOpenAllProjects(index, type, open, secondaryIndex, 'showmore', count, setIsOpen);
		} else {
			handleOpenExperiments(index, open, 'showmore', count, setIsOpen);
		}
	};
	return (
		<TableRow sx={style} data-testid="morerecords" className={classes.tableRow}>
			<TableCell
				sx={{
					cursor: 'pointer',
					paddingLeft: leftVal,
					width: '7%'
				}}
				align="left"
				onClick={onClickShowMore}
			>
				<Box display="flex" flexDirection="row">
					{!isOpen ? (
						<Icon
							src={caretDown}
							type="pointer"
							alt="caretDown"
							testId="show more records"
							padding="1px 0px 0px 2.5px"
						/>
					) : (
						<Icon src={loader} padding="1px 0px 0px 2.5px" alt="runningIcon" type="static" />
					)}
				</Box>
			</TableCell>
			<TableCell width="20%" align="left" sx={{ cursor: 'pointer' }} onClick={onClickShowMore}>
				<Box sx={{ paddingLeft: leftValText }}>
					{mainType === 'Project' ? 'Show more items' : 'Show more dispatches'}
				</Box>
			</TableCell>
		</TableRow>
	);
}
