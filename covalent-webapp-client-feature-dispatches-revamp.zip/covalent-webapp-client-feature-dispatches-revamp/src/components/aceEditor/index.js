/* eslint-disable import/no-unused-modules */
import React from 'react';
import AceEditor from 'react-ace';
import 'ace-builds/webpack-resolver';
import 'ace-builds/src-noconflict/mode-yaml';
import 'ace-builds/src-noconflict/theme-merbivore_soft';
import './style.css';

function YamlEditor({ value, readOnly, style, height, color, onChange, backgroundColor }) {
	return (
		<AceEditor
			mode="yml"
			theme="merbivore_soft"
			readOnly={readOnly}
			className={readOnly ? 'custom-editor' : ''}
			value={value}
			onChange={onChange}
			editorProps={{ $blockScrolling: true }}
			style={{
				width: 'auto',
				height: height || 'auto',
				color: color || '#CBCBD7',
				overflow: 'hidden',
				// fontFamily: 'DM Sans !important',
				backgroundColor: backgroundColor || '#0B0B11',
				...style // Merge the provided style props
			}}
		/>
	);
}

export default YamlEditor;
