/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable no-else-return */
import * as React from 'react';
import Modal from '@mui/material/Modal';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import LoginInput from '../../inputBase/projects/loginInput';

export default function ResetPasswordDialogBox(props) {
	const {
		openDialogBox,
		handleClose,
		password,
		setPassword,
		errorPassword,
		validateInput,
		rePassword,
		setRePassword,
		errorRePassword,
		oldPassword,
		setOldPassword,
		errorOldPassword
	} = props;
	return (
		<Modal
			open={openDialogBox}
			onClose={() => handleClose(false)}
			aria-labelledby="modal-modal-title"
			aria-describedby="modal-modal-description"
			data-testid="ResetPasswordDialogBox"
		>
			<Box
				sx={{
					position: 'absolute',
					top: '50%',
					left: '50%',
					transform: 'translate(-50%, -50%)',
					bgcolor: 'background.paper',
					border: '1px solid #6473FF',
					borderRadius: '24px',
					boxShadow: 24,
					p: 2
				}}
			>
				<Stack spacing={3.3}>
					<LoginInput
						fieldName="Old Password"
						value={oldPassword}
						handleChange={setOldPassword}
						placeholderTxt="Enter old password"
						type="field"
						typeInput="password"
						error={errorOldPassword}
						handleEnter={validateInput}
					/>
					<LoginInput
						fieldName="Password"
						value={password}
						handleChange={setPassword}
						placeholderTxt="Enter a password"
						type="field"
						typeInput="password"
						error={errorPassword}
						handleEnter={validateInput}
					/>
					<LoginInput
						fieldName="Confirm Password"
						value={rePassword}
						handleChange={setRePassword}
						placeholderTxt="Re-enter password"
						type="field"
						typeInput="password"
						error={errorRePassword}
						handleEnter={validateInput}
					/>
					<Button
						variant="contained"
						disableElevation
						sx={{
							width: '226px',
							height: '32px',
							background: ' #5552FF',
							borderRadius: '70px',
							borderColor: '#303067',
							color: '#ffffff',
							my: 3,
							padding: '8px 16px',
							':hover': {}
						}}
						onClick={() => validateInput()}
					>
						Reset Password
					</Button>
				</Stack>
			</Box>
		</Modal>
	);
}
