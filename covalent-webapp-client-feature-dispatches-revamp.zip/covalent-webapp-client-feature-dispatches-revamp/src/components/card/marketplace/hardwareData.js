/* eslint-disable max-len */
/* eslint-disable import/no-unused-modules */
import Image2 from '../../../assets/marketplace/image2.svg';
import Image3 from '../../../assets/marketplace/image3.svg';
import Image4 from '../../../assets/marketplace/image4.svg';
import Hardware from '../../../assets/marketplace/chip.svg';
import Status from '../../../assets/marketplace/online.svg';

export const data = {
	hardwareDetails: {
		tagsHeading: 'Tags/ Categories',
		aboutHardware: {
			content:
				'OrganizationHardwareVelit suscipit laboriosam rem quibusdam. Nostrum voluptas labore eaque quos. Maiores ratione fugit temporibus.',
			points: [
				{
					id: 1,
					point:
						'Velit suscipit laboriosam rem quibusdam. Nostrum voluptas labore eaque quos. Maiores ratione fugit temporibus.'
				},
				{
					id: 2,
					point:
						'Velit suscipit laboriosam rem quibusdam. Nostrum voluptas labore eaque quos. Maiores ratione fugit temporibus.'
				}
			]
		},
		usage: 'ctc.plugins.SomeHardware(num_cpus=23)',
		description: [
			// eslint-disable-next-line quotes
			{
				id: 1,
				point:
					'Covalent is Teradata\'s design system used to create Teradata branded experiences. This space is intended to be used to support developers creating coded experiences for Teradata products. Currently we are only supporting angular and a library of web components.'
			},
			{
				id: 2,
				point:
					'Vision: To build an atomic, reusable component platform for Teradata to consume, while collaborating in an open source model.  '
			}
		]
	},
	details: [
		{
			id: 1,
			type: 'hardware',
			category: 'API Management',
			hardwareId: 0,
			technology: 'IonZ Quantum',
			per: 'shot',
			downloads: 345,
			name: 'onZ_Montreal',
			content:
				'Quantum hardware with 128 qubit counts and 99.8% fidelity rate, ideal for advanced quantum computing tasks.',
			price: 0.0325,
			// cardimage: Image1,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'onZ_Montreal',
				label: 'OM',
				desc: 'Quantum hardware with 128 qubit counts and 99.8% fidelity rate, ideal for advanced quantum computing tasks.',
				count: '345',
				created_date: '2-10-2022',
				last_build: '1-6-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 2,
			type: 'hardware',
			category: 'Finance',
			hardwareId: 1,
			technology: 'NVDIA',
			per: 'hour',
			downloads: 500,
			name: 'NVDIA_GTX2070',
			content: 'High-performance GPU for machine learning and deep learning tasks.',
			price: 0.55,
			cardimage: Image2,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'NVDIA_GTX2070',
				label: 'NG',
				desc: 'High-performance GPU for machine learning and deep learning tasks.',
				count: '500',
				created_date: '2-10-2022',
				last_build: '12-6-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 50,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 3,
			type: 'hardware',
			category: 'Code Quality',
			hardwareId: 2,
			technology: 'IBM Quantum',
			per: 'hour',
			downloads: 180,
			name: 'IBMQ_Manila',
			content:
				'Quantum hardware with 80 qubit counts and 99.7% fidelity rate, perfect for quantum algorithm development.',
			price: 0,
			cardimage: Image3,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'IBMQ_Manila',
				label: 'IM',
				desc: 'Quantum hardware with 80 qubit counts and 99.7% fidelity rate, perfect for quantum algorithm development.',
				count: '180',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 4,
			type: 'hardware',
			category: 'Code Review',
			hardwareId: 3,
			technology: 'IntelCloud',
			per: 'hour',
			downloads: 450,
			name: 'IntelCloud_XeonGold',
			content: 'High capacity CPUs for complex computational tasks.',
			price: 0.85,
			cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'IntelCloud_XeonGold',
				label: 'IX',
				desc: 'High capacity CPUs for complex computational tasks.',
				count: '450',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 5,
			type: 'hardware',
			category: 'Healthcare',
			hardwareId: 4,
			technology: 'IonZ Quantum',
			per: 'shot',
			downloads: 300,
			name: 'IonZ_Vancouver',
			content:
				'Quantum hardware with 110 qubit counts and 99.7% fidelity rate, suitable for high precision quantum tasks.',
			price: 0.0275,
			// cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'IonZ_Vancouver',
				label: 'IV',
				desc: 'Quantum hardware with 110 qubit counts and 99.7% fidelity rate, suitable for high precision quantum tasks.',
				count: '300',
				created_date: '2-10-2022',
				last_build: '13-6-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 6,
			type: 'hardware',
			category: 'Dependency Management',
			hardwareId: 5,
			technology: 'AMD',
			per: 'hour',
			downloads: 480,
			name: 'AMD_Radeon6900XT',
			content: 'High-end GPU for machine learning, visualization, and computing tasks.',
			price: 0.45,
			// cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'AMD_Radeon6900XT',
				label: 'AR',
				desc: 'High-end GPU for machine learning, visualization, and computing tasks.',
				count: '480',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 7,
			type: 'hardware',
			category: 'Portfolio',
			hardwareId: 6,
			technology: 'Azure Quantum',
			per: 'hour',
			downloads: 225,
			name: 'Azure_Quantum5',
			content:
				'Quantum hardware with 100 qubit counts and 99.8% fidelity rate, suitable for advanced quantum computing.',
			price: 0,
			cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'Azure_Quantum5',
				label: 'AQ',
				desc: 'Quantum hardware with 100 qubit counts and 99.8% fidelity rate, suitable for advanced quantum computing.',
				count: '225',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 8,
			type: 'hardware',
			category: 'IDEs',
			hardwareId: 7,
			technology: 'OpenHPC',
			per: 'hour',
			downloads: 360,
			name: 'OpenHPC_Center1',
			content: 'HPC center offering high-capacity computing power for complex computational tasks.',
			price: 0.95,
			cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'OpenHPC_Center1',
				label: 'HPC',
				desc: 'HPC center offering high-capacity computing power for complex computational tasks.',
				count: '360',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 9,
			type: 'hardware',
			category: 'Learning',
			hardwareId: 8,
			technology: 'IBM Quantum',
			per: 'shot',
			downloads: 210,
			name: 'IBMQ_Cairo',
			content:
				'Quantum hardware with 2 qubit counts and 99.9% fidelity rate, ideal for research in quantum physics with smaller queue times',
			price: 0.035,
			cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'IBMQ_Cairo',
				label: 'IC',
				desc: 'Quantum hardware with 2 qubit counts and 99.9% fidelity rate, ideal for research in quantum physics with smaller queue times',
				count: '210',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 10,
			type: 'hardware',
			category: 'Localization',
			hardwareId: 9,
			technology: 'QuantumCloud',
			per: 'hour',
			downloads: 400,
			name: 'QuantumCloud_4',
			content:
				'Quantum hardware with 120 qubit counts and 99.8% fidelity rate, perfect for advanced quantum algorithm development.',
			price: 0,
			// cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'QuantumCloud_4',
				label: 'QC',
				desc: 'Quantum hardware with 120 qubit counts and 99.8% fidelity rate, perfect for advanced quantum algorithm development.',
				count: '400',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 11,
			type: 'hardware',
			category: 'Mobile',
			hardwareId: 10,
			technology: 'NVDIA',
			per: 'hour',
			downloads: 450,
			name: 'NVDIA_GTX3080',
			content: 'Premium GPU for high-end machine learning and deep learning tasks.',
			price: 0.65,
			cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'NVDIA_GTX3080',
				label: 'NG',
				desc: 'Premium GPU for high-end machine learning and deep learning tasks.',
				count: '450',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 12,
			type: 'hardware',
			category: 'Project Management',
			hardwareId: 11,
			technology: 'AWS Quantum',
			per: 'ahot',
			downloads: 280,
			name: 'AWS_Quantum3',
			content:
				'Quantum hardware with 130 qubit counts and 99.9% fidelity rate, suitable for complex quantum computing tasks.',
			price: 0.0375,
			// cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'AWS_Quantum3',
				label: 'AQ',
				desc: 'Quantum hardware with 130 qubit counts and 99.9% fidelity rate, suitable for complex quantum computing tasks.',
				count: '280',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 13,
			type: 'hardware',
			category: 'Security',
			hardwareId: 12,
			technology: 'IntelCloud',
			per: 'hour',
			downloads: 500,
			name: 'IntelCloud_XeonGold',
			content: 'High-performance CPUs ideal for intense computational tasks.',
			price: 0.75,
			cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'IntelCloud_XeonGold',
				label: 'IX',
				desc: 'High-performance CPUs ideal for intense computational tasks.',
				count: '500',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 14,
			type: 'hardware',
			category: 'Monitoring',
			hardwareId: 13,
			technology: 'HPC Solutions',
			per: 'hour',
			downloads: 420,
			name: 'HPC_Solutions_Center1',
			content: 'High-capacity HPC center for advanced computational requirements.',
			price: 0.95,
			// cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'HPC_Solutions_Center1',
				label: 'HPC',
				desc: 'High-capacity HPC center for advanced computational requirements.',
				count: '420',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 15,
			type: 'hardware',
			category: 'Monitoring',
			hardwareId: 14,
			technology: 'IBM Quantum',
			per: 'sjot',
			downloads: 250,
			name: 'IBMQ_Jakarta',
			content:
				'Quantum hardware with 105 qubit counts and 99.7% fidelity rate, perfect for quantum algorithm development.',
			price: 0.032,
			cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'IBMQ_Jakarta',
				label: 'IJ',
				desc: 'Quantum hardware with 105 qubit counts and 99.7% fidelity rate, perfect for quantum algorithm development.',
				count: '250',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 16,
			type: 'hardware',
			category: 'Monitoring',
			hardwareId: 15,
			technology: 'AMD',
			per: 'hour',
			downloads: 550,
			name: 'AMD_Ryzen9',
			content: 'High-performance CPU for complex computational tasks.',
			price: 0.6,
			cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'AMD_Ryzen9',
				label: 'AR',
				desc: 'High-performance CPU for complex computational tasks.',
				count: '550',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 17,
			type: 'hardware',
			category: 'Monitoring',
			hardwareId: 16,
			technology: 'Azure Quantum',
			per: 'hour',
			downloads: 290,
			name: 'Azure_Quantum6',
			content:
				'Quantum hardware with 90 qubit counts and 99.8% fidelity rate, suitable for advanced quantum computing.',
			price: 0,
			cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'Azure_Quantum6',
				label: 'AQ',
				desc: 'Quantum hardware with 90 qubit counts and 99.8% fidelity rate, suitable for advanced quantum computing.',
				count: '290',
				created_date: '2-10-2022',
				last_build: '1-6-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 18,
			type: 'hardware',
			category: 'Monitoring',
			hardwareId: 17,
			technology: 'Google Quantum',
			per: 'shot',
			downloads: 320,
			name: 'Google_Quantum4',
			content:
				'Quantum hardware with 115 qubit counts and 99.7% fidelity rate, perfect for advanced quantum computing tasks.',
			price: 0.03,
			// cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'Google_Quantum4',
				label: 'GQ',
				desc: 'Quantum hardware with 115 qubit counts and 99.7% fidelity rate, perfect for advanced quantum computing tasks.',
				count: '320',
				created_date: '2-10-2022',
				last_build: '5-6-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 19,
			type: 'hardware',
			category: 'Monitoring',
			hardwareId: 18,
			technology: 'QuantumHPC',
			per: 'hour',
			downloads: 400,
			name: 'QuantumHPC_Center1',
			content:
				'HPC center offering high-capacity quantum computing power for complex computational tasks.',
			price: 1.0,
			cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'QuantumHPC_Center1',
				label: 'QC',
				desc: 'HPC center offering high-capacity quantum computing power for complex computational tasks.',
				count: '400',
				created_date: '2-10-2022',
				last_build: '5-4-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		},
		{
			id: 20,
			type: 'hardware',
			category: 'Monitoring',
			hardwareId: 19,
			technology: 'IBM Quantum',
			per: 'shot',
			downloads: 270,
			name: 'IBMQ_Singapore',
			content:
				'Quantum hardware with 125 qubit counts and 99.7% fidelity rate, ideal for advanced quantum tasks.',
			price: 0.0355,
			cardimage: Image4,
			hardwareimage: Hardware,
			statusimage: Status,
			chipdata: [
				{ key: 0, label: 'python' },
				{ key: 1, label: 'react' },
				{ key: 2, label: 'rust' },
				{ key: 3, label: '+2' }
			],

			headData: {
				name: 'BMQ_Singapore',
				label: 'IX',
				desc: 'Quantum hardware with 125 qubit counts and 99.7% fidelity rate, ideal for advanced quantum tasks.',
				count: '270',
				created_date: '2-10-2022',
				last_build: '12-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			}
		}
	]
};

export default data;
