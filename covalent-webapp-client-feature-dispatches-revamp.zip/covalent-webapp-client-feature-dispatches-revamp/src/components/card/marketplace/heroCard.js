/* eslint-disable import/no-unused-modules */
import React from 'react';
import { Box } from '@mui/material';
import HeroCard from './index';
import Hardware from '../../../assets/marketplace/hardwareLogo.svg';
import Solver from '../../../assets/marketplace/solversLogo.svg';

function CardList() {
	const data = [
		{
			title: 'Hardware',
			description: 'Velit suscipit laboriosam rem quibusdam. Nostrum voluptas labore eaque quos.',
			content: 'Total Hardware: ',
			count: '30',
			imageUrl: Hardware,
			backgroundColor: 'linear-gradient(to right, #303067, #5552FF, #08081A)'
		},
		{
			title: 'Solvers',
			description: 'Velit suscipit laboriosam rem quibusdam. Nostrum voluptas labore eaque quos.',
			content: 'Total Solvers: ',
			count: '30',
			imageUrl: Solver,
			backgroundColor: 'linear-gradient(270deg, #08081A, #5552FF, #AD7BFF)'
		}
		// Add more data objects as needed
	];

	return (
		<Box sx={{ display: 'flex', placeItems: 'center', marginTop: '1rem', gap: '4rem' }}>
			{data.map(item => (
				<HeroCard
					key={item.title}
					title={item.title}
					description={item.description}
					content={item.content}
					count={item.count}
					imageUrl={item.imageUrl}
					backgroundColor={item.backgroundColor}
				/>
			))}
		</Box>
	);
}

export default CardList;
