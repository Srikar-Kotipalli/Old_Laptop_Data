/* eslint-disable react/no-array-index-key */
/* eslint-disable no-shadow */
/* eslint-disable react/jsx-props-no-spreading */
import React, { useEffect, useState } from 'react';
import { DragDropContext, Draggable } from 'react-beautiful-dnd';
import { Box, Typography, Grid, Tooltip, Input } from '@mui/material';
import DragIndicatorIcon from '@mui/icons-material/DragIndicator';
import Edit from '../../../../assets/actions/edit.svg';
import Close from '../../../../assets/checkmarks/closeError.svg';
import Success from '../../../../assets/checkmarks/checkmarkSuccess.svg';
import Delete from '../../../../assets/actions/delete.svg';
import Icon from '../../../icon';
import OverflowTooltip from '../../../tooltip/overflowTooltip';
import StrictModeDroppable from './strictModeDroppable';

function PipInfoCard({
	data,
	value,
	maxHeight,
	editIcon,
	deleteIcon,
	editHandle,
	deleteHandle,
	onDragEnd,
	variant,
	isEditing,
	setIsEditing,
	newDelimeter
}) {
	const [icon, setIcon] = useState(false);
	const [newText, setNewText] = useState(new Array(data?.length).fill(''));
	const [delimiter] = useState(newDelimeter || '==');

	useEffect(() => {
		if (value) setIcon(true);
	}, [value]);

	const handleEditClick = index => {
		// Reset all other indices to false
		const updatedEditing = new Array(data?.length).fill(false);
		updatedEditing[index] = true;
		setIsEditing(updatedEditing);

		// Set the initial text for editing
		const updatedText = [...newText];
		updatedText[index] = data[index];
		setNewText(updatedText);
	};

	const handleSaveClick = index => {
		// Ensure that index is valid, and editHandle is a function
		if (typeof editHandle === 'function' && index >= 0 && index < data?.length) {
			// Call the editHandle function with the appropriate arguments
			editHandle(index, newText[index]);

			// Reset the edit mode for the clicked item to false
			const updatedEditing = [...isEditing];
			updatedEditing[index] = false;
			setIsEditing(updatedEditing);
		}
	};

	const handleCancelEditClick = index => {
		// Set the edit mode for the clicked item to false
		const updatedEditing = [...isEditing];
		updatedEditing[index] = false;
		setIsEditing(updatedEditing);
	};

	const handleDragEnd = result => {
		if (!result.destination) {
			// Item was dropped outside a valid droppable area
			return;
		}
		// uncomment the next two lines if edit needs to be disabled when reordering
		// const updatedEditing = new Array(data?.length).fill(false);
		// setIsEditing(updatedEditing);
		const { source, destination } = result;
		const reorderedData = Array.from(data);

		// Remove the item from the source index
		const [movedItem] = reorderedData.splice(source.index, 1);

		// Insert the item at the destination index
		reorderedData.splice(destination.index, 0, movedItem);
		onDragEnd(reorderedData);
	};

	if (data?.length === 0) {
		return <Typography ml={1}>No Records Found</Typography>;
	}

	return (
		<DragDropContext onDragEnd={handleDragEnd}>
			<StrictModeDroppable droppableId="pipInfoCardDroppable" direction="vertical">
				{provided => (
					<div {...provided.droppableProps} ref={provided.innerRef}>
						{data?.map((packageInfo, index) => {
							const [packageName, packageVersion] = packageInfo.split(delimiter);
							return variant === 'dnd' ? (
								<Draggable
									key={index}
									draggableId={`pipInfoCardItem-${index}`}
									index={index}
									isDragDisabled={isEditing?.some(item => item === true)}
								>
									{props => (
										<div {...props.draggableProps} {...props.dragHandleProps} ref={props.innerRef}>
											{!isEditing[index] ? (
												<Grid container sx={{ overflowY: 'auto' }} mb={1} ml={1}>
													<Grid item xs={12}>
														<Box
															sx={{
																width: '100%',
																backgroundColor: 'rgba(48, 48, 103, 0.2)',
																border: '1px solid #1C1C46',
																borderRadius: '7px',
																display: 'flex',
																justifyContent: 'space-between',
																alignItems: 'center',
																height: '30px'
															}}
														>
															<Box display="flex" alignItems="center">
																{icon ? (
																	<DragIndicatorIcon
																		sx={{
																			background: '#303067',
																			borderRadius: '8px',
																			padding: '3px',
																			height: '30px'
																		}}
																	/>
																) : (
																	''
																)}
																<Box sx={{ paddingLeft: '7px' }}>
																	<OverflowTooltip title={packageName} length={15} />
																</Box>
															</Box>
															<Box display="flex" alignItems="center">
																<Box paddingRight="7px">
																	<OverflowTooltip title={packageVersion} length={11} />
																</Box>
																{editIcon ? (
																	<Tooltip title="Edit">
																		<div>
																			<Icon
																				bgColor="#2a2a5c"
																				padding="4px"
																				src={Edit}
																				alt="Edit"
																				clickHandler={() => handleEditClick(index)}
																			/>
																		</div>
																	</Tooltip>
																) : (
																	''
																)}
																{deleteIcon ? (
																	<Tooltip title="Delete">
																		<div>
																			<Icon
																				bgColor="#2a2a5c"
																				padding="4px"
																				src={Delete}
																				alt="Delete"
																				clickHandler={() => deleteHandle(index)}
																			/>
																		</div>
																	</Tooltip>
																) : (
																	''
																)}
															</Box>
														</Box>
													</Grid>
												</Grid>
											) : (
												<Grid container sx={{ overflowY: 'auto' }} mb={1} ml={1}>
													<Box
														sx={{
															width: '100%',
															backgroundColor: 'rgba(48, 48, 103, 0.2)',
															border: '1px solid #1C1C46',
															borderRadius: '7px',
															display: 'flex',
															justifyContent: 'space-between',
															alignItems: 'center',
															height: '30px'
														}}
													>
														<Input
															type="text"
															disableUnderline
															sx={{
																backgroundColor: 'transparent',
																fontSize: '14px',
																paddingLeft: '10px',
																width: '90%'
															}}
															value={newText[index]}
															autoFocus={isEditing[index]}
															onChange={e => {
																// Update the edited text for the clicked item
																const updatedText = [...newText];
																updatedText[index] = e.target.value;
																setNewText(updatedText);
															}}
															onKeyDown={event => {
																if (event.key === 'Enter') {
																	handleSaveClick(index);
																}
															}}
														/>
														<div
															style={{
																display: 'flex',
																alignItems: 'center',
																justifyContent: 'space-between',
																marginLeft: '10px' // Add margin for space between icons and input
															}}
														>
															<Icon
																src={Success}
																alt="Save"
																clickHandler={() => handleSaveClick(index)}
															/>
															<Icon
																src={Close}
																alt="Close"
																clickHandler={() => handleCancelEditClick(index)}
															/>
														</div>
														{/* <Icon
    													src={Success}
    													alt="Close"
    													clickHandler={() => handleSaveClick(index)}
    												/>
    												<Icon
    													src={Close}
    													alt="Close"
    													clickHandler={() => handleCancelEditClick(index)}
    												/> */}
													</Box>
												</Grid>
											)}
										</div>
									)}
								</Draggable>
							) : (
								<Grid
									key={index}
									container
									spacing={2}
									sx={{ maxHeight: maxHeight || '200px', overflowY: 'auto' }}
									mb={2}
								>
									<Grid item xs={12}>
										<Box
											sx={{
												backgroundColor: 'rgba(48, 48, 103, 0.2)',
												border: '1px solid #1C1C46',
												borderRadius: '7px',
												textAlign: 'center',
												display: 'flex',
												justifyContent: 'space-between',
												padding: '3%',
												height: '26px'
											}}
										>
											<Box display="flex" alignItems="center">
												<Box sx={{ paddingLeft: '7px' }}>
													<OverflowTooltip title={packageName} length={15} />
												</Box>
											</Box>
											<Box display="flex" alignItems="center">
												<Box paddingRight="7px">
													<OverflowTooltip title={packageVersion} length={11} />
												</Box>
											</Box>
										</Box>
									</Grid>
								</Grid>
							);
						})}
						{provided.placeholder}
					</div>
				)}
			</StrictModeDroppable>
		</DragDropContext>
	);
}

export default PipInfoCard;
