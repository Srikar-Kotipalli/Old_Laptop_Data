/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import { Grid, Tooltip } from '@mui/material';
import React from 'react';
import Icon from '../../../icon';
import pinIcon from '../../../../assets/actions/pin.svg';
import { statusIcon } from '../../../../utils/statusIcons';
import dispatchIcon from '../../../../assets/dispatch/dispatchIcon.svg';
import OverflowTooltip from '../../../tooltip/overflowTooltip';
import useLength from '../../../../utils/useLength';

function SimpleDashboardCard(props) {
	const { data, pin, onPin } = props;

	// call to custom hook useLength
	const len = useLength({ xs: 12, s: 14, m: 20, l: 18, xl: 25 });

	return (
		<Grid
			item
			xs={3.79}
			sx={{
				background: theme => theme.palette.background.paper,
				borderRadius: '6px',
				border: '1px solid',
				borderColor: theme => theme.palette.background.covalentPurple
			}}
			p={2}
		>
			{' '}
			<Grid container direction="row" alignItems="center" p={0} justifyContent="space-between">
				<Grid item xs={10.5} container direction="row" alignItems="center">
					{statusIcon(data.status)}
					<Grid container item xs={10} direction="row" pl={1}>
						<Icon src={dispatchIcon} />
						<OverflowTooltip title={data?.title || ''} id={data?.id} length={len} />
					</Grid>
				</Grid>
				{pin && (
					<Tooltip placement="top" title={data && data.isPinned ? 'Unpin' : 'Pin'}>
						<Grid className={data && data.isPinned ? 'pinIcon' : null}>
							<Icon
								src={pinIcon}
								type="pointer"
								status={data.isPinned && data.isPinned === true ? 'active' : null}
								clickHandler={() => onPin(data)}
								alt="pinIcon"
							/>
						</Grid>
					</Tooltip>
				)}
			</Grid>
		</Grid>
	);
}

export default SimpleDashboardCard;
