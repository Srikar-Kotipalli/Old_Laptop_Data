/* eslint-disable react/jsx-no-constructed-context-values */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
// eslint-disable-next-line import/extensions
import DispatchCard from '../dispatchCard';

const dispatch = [
	{
		id: '626a46ffc265a015b9ae941c',
		title: 'Yellooow Brass Afghan Hound',
		totalElectrons: 8,
		completedElectrons: 4,
		status: 'RUNNING',
		startTime: '2022-01-01T21:12:00',
		lastUpdated: '2022-01-01T21:12:00',
		parentId: 'None',
		type: 'Dispatch',
		isPinned: false,
		tags: ['react', 'rust', 'node', 'js'],
		runTime: 30
	},
	{
		id: '626a46ffc265a015b9ae941c',
		title: 'Yellow Brass Afghan Hooound',
		totalElectrons: 8,
		completedElectrons: 8,
		status: 'COMPLETED',
		startTime: '2022-01-01T21:12:00',
		lastUpdated: '2022-01-01T21:12:00',
		parentId: 'None',
		type: 'Dispatch',
		isPinned: false,
		tags: ['react', 'rust', 'node', 'js'],
		runTime: 70
	},
	{
		id: '626a46ffc265a015b9ae941c',
		title: 'Yellow Brass Afghaaan Hound',
		totalElectrons: 8,
		completedElectrons: 8,
		status: 'COMPLETED',
		startTime: '2022-01-01T21:12:00',
		lastUpdated: '2022-01-01T21:12:00',
		parentId: 'None',
		type: 'Dispatch',
		isPinned: false,
		tags: ['react', 'rust', 'node', 'js'],
		runTime: 3800
	},
	{
		id: '626a46ffc265a015b9ae941c',
		title: 'Yellow Brassss Afghan Hound',
		totalElectrons: 8,
		completedElectrons: 4,
		status: 'NEW',
		startTime: '2022-01-01T21:12:00',
		lastUpdated: '2022-01-01T21:12:00',
		parentId: 'None',
		type: 'Dispatch',
		isPinned: false,
		tags: ['react', 'rust', 'node', 'js'],
		runTime: 86405
	},
	{
		id: '626a46ffc265a015b9ae941c',
		title: 'Yellowww Brassss Afghan Hound',
		totalElectrons: 8,
		completedElectrons: 4,
		status: 'FAILED',
		startTime: '2022-01-01T21:12:00',
		lastUpdated: '2022-01-01T21:12:00',
		parentId: 'None',
		type: 'Dispatch',
		isPinned: false,
		tags: ['react', 'rust', 'node', 'js'],
		runTime: 172803
	}
];

const memoDispatch = [
	{
		id: '626a46fge265a015b9ae941c',
		title: 'Red Brass Afghan Hound',
		totalElectrons: 8,
		completedElectrons: 4,
		status: 'COMPLETED',
		startTime: '2022-01-01T21:12:00',
		lastUpdated: '2022-01-01T21:12:00',
		parentId: 'None',
		type: 'Dispatch',
		isPinned: false,
		tags: ['react', 'rust', 'node', 'js'],
		runTime: 235600
	}
];

describe('dispatchCard', () => {
	test('renders dispatch Card', () => {
		const handleClick = jest.fn();
		render(
			<DispatchCard
				highlightedDispatchesList={dispatch}
				timeFormatter={handleClick}
				dateFormatter={handleClick}
			/>
		);
		const element = screen.getByTestId('gridView');
		expect(element).toBeInTheDocument();
	});
	test('renders pinIcon', () => {
		render(<DispatchCard highlightedDispatchesList={dispatch} alt="pinIcon" />);
		const element = screen.getAllByAltText('pinIcon');
		expect(element).toHaveLength(5);
	});
	test('calls pin function onclick', () => {
		const handleClick = jest.fn();
		render(<DispatchCard highlightedDispatchesList={dispatch} onPin={handleClick} alt="pinIcon" />);
		const element = screen.getAllByAltText('pinIcon');
		element.forEach(x => fireEvent.click(x));
		expect(handleClick).toBeCalledTimes(5);
	});
	test('check for memoized component', () => {
		const { rerender } = render(<DispatchCard highlightedDispatchesList={dispatch} />);
		rerender(<DispatchCard highlightedDispatchesList={memoDispatch} />);
	});
});
