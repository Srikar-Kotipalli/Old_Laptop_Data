/* eslint-disable react/jsx-no-useless-fragment */
/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
/* eslint-disable react/button-has-type */

import React, { useState } from 'react';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import CopyButton from '../../copyButton';
import SyntaxHighlighter from '../../syntaxHiglighter';
import CodeView from '../codeView';

function ResultSection(props) {
	const {
		label,
		value,
		Overview,
		name,
		height,
		hideCopy,
		objectValue,
		description,
		isHardwarePage,
		className
	} = props;
	const [showMore, setShowMore] = useState(false);
	const [viewMoreValue, setViewMoreValue] = useState();

	const codeOpen = data => {
		setShowMore(true);
		setViewMoreValue(data);
	};

	const codeViewClose = () => {
		setShowMore(false);
	};

	const isHardwareSubString = () => {
		if (isHardwarePage) {
			return `${String(value).substring(0, 150)}`;
		}
		return `${String(value).substring(0, 33)}`;
	};

	return (
		<Box>
			{!Overview && <Typography className={className || 'innertypohead'}>{label}</Typography>}
			<Paper
				sx={{
					background: description ? 'transparent' : Overview && '#1C1C46',
					borderRadius: Overview && '8px',
					padding: description ? 0 : 1,
					boxShadow: description && 'none',
					overflow: description ? '' : 'auto',
					overflowWrap: 'anywhere',
					height: height || null
				}}
			>
				<Grid container direction="row">
					<Grid item xs={10.5}>
						{description ? (
							<Typography variant="h2" className="onelineWarp">
								{value}
							</Typography>
						) : (
							<SyntaxHighlighter src={isHardwareSubString()} />
						)}
					</Grid>
					{!hideCopy && (
						<Grid item xs={1.5} sx={{ textAlign: 'right' }}>
							<Box>
								<CopyButton content={objectValue} borderEnable="true" title="Copy python object" />
							</Box>
						</Grid>
					)}
				</Grid>
				{value?.length > 33 && !isHardwarePage && (
					<button
						className="showmorebtn"
						style={{ marginTop: name === 'code' && '0px', cursor: 'pointer' }}
						onClick={() => codeOpen(value)}
					>
						View more
					</button>
				)}
			</Paper>

			{showMore && (
				<CodeView
					description={description}
					codeViewClose={codeViewClose}
					codeViewPopup={showMore}
					value={viewMoreValue}
					label={label}
				/>
			)}
		</Box>
	);
}

export default ResultSection;
