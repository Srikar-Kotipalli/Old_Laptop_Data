/* eslint-disable func-names */
import React, { useState, useRef } from 'react';
import { Box, Typography } from '@mui/material';
import cloudUploadIcon from '../../../../assets/cloudUploadIcon.svg';
import './style.css';
import Icon from '../../../icon';

function UploadComponent() {
	const [dragActive, setDragActive] = useState(false);
	const [fileName, setFileName] = useState();
	// ref
	const inputRef = useRef(null);

	// handle drag events
	const handleDrag = function (e) {
		e.preventDefault();
		e.stopPropagation();
		if (e.type === 'dragenter' || e.type === 'dragover') {
			setDragActive(true);
		} else if (e.type === 'dragleave') {
			setDragActive(false);
		}
	};

	// triggers when file is dropped
	const handleDrop = function (e) {
		setFileName(e.dataTransfer.files[0]);
		e.preventDefault();
		e.stopPropagation();
		setDragActive(false);
	};

	// triggers when file is selected with click
	const handleChange = function (e) {
		setFileName(e.target.files[0]);
		e.preventDefault();
	};

	// triggers the input when the button is clicked
	const onButtonClick = () => {
		inputRef.current.click();
	};

	return (
		<Box sx={{ textAlign: 'center', ml: 5 }}>
			<Typography
				sx={{
					fontWeight: '400',
					fontSize: '20px',
					lineHeight: '26px',
					color: '#FFFFFF'
				}}
			>
				Upload Image
			</Typography>
			<Typography
				sx={{
					fontWeight: '400',
					fontSize: '14px',
					lineHeight: '18px',
					my: 2,
					color: '#FFFFFF'
				}}
			>
				PNG, JPG & PDF allowed
			</Typography>
			<form id="form-file-upload" onDragEnter={handleDrag} onSubmit={e => e.preventDefault()}>
				<input ref={inputRef} type="file" id="input-file-upload" multiple onChange={handleChange} />
				<label
					id="label-file-upload"
					htmlFor="input-file-upload"
					className={dragActive ? 'drag-active' : ''}
				>
					<div>
						<Icon src={cloudUploadIcon} clickHandler={onButtonClick} />
						{fileName && (
							<Typography sx={{ color: '#CBCBD7', fontSize: '14px', my: 2 }}>
								{fileName?.name}
							</Typography>
						)}
						<Typography sx={{ color: '#CBCBD7', fontSize: '14px', my: 2 }}>
							Drag and drop or browse to choose a file
						</Typography>
					</div>
				</label>
				{dragActive && (
					<div
						id="drag-file-element"
						onDragEnter={handleDrag}
						onDragLeave={handleDrag}
						onDragOver={handleDrag}
						onDrop={handleDrop}
					/>
				)}
			</form>
		</Box>
	);
}

export default UploadComponent;
