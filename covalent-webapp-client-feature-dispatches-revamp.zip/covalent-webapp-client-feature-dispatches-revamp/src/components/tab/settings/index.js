import * as React from 'react';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import Divider from '@mui/material/Divider';

function StyledDivider() {
	return (
		<Divider sx={{ borderColor: '#303067' }} orientation="vertical" variant="middle" flexItem />
	);
}

function SettingsTab(props) {
	const { value, handleTabChange } = props;
	return (
		<TabContext value={value}>
			<TabList
				onChange={handleTabChange}
				TabIndicatorProps={{
					style: {
						display: 'none'
					}
				}}
				sx={{
					padding: 0,
					'& .MuiTabs-scroller': { paddingRight: 0, paddingLeft: 0 }
				}}
			>
				<Tab
					label="Account"
					value="account"
					sx={{
						padding: 0,
						alignItems: 'self-start',
						minWidth: '5em',
						'&.Mui-selected': {
							minWidth: '5em' // Adjust width for the selected state if needed
						}
					}}
				/>
				<StyledDivider />
				{/* <Tab
					label="Hardware"
					value="hardware"
					sx={{
						padding: 0,
						px: 2,
						minWidth: '5em',
						'&.Mui-selected': {
							minWidth: '5em' // Adjust width for the selected state if needed
						}
					}}
				/>
				<StyledDivider /> */}
				<Tab
					label="Billing"
					value="billing"
					sx={{
						padding: 0,
						minWidth: '5em',
						'&.Mui-selected': {
							minWidth: '5em' // Adjust width for the selected state if needed
						}
					}}
				/>
				{/* <StyledDivider />
				<Tab
					label="Notifications"
					value="notifications"
					sx={{
						padding: 0,
						px: 2,
						alignItems: 'self-end',
						minWidth: '5em',
						'&.Mui-selected': {
							minWidth: '5em' // Adjust width for the selected state if needed
						}
					}}
				/> */}
			</TabList>
		</TabContext>
	);
}

export default SettingsTab;
