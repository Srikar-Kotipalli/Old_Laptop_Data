/* eslint-disable no-unused-vars */
import React from 'react';
import InfiniteScroll from 'react-infinite-scroll-component';

function InfiniteScrollWrapper({ items, fetchMoreData, hasMore, children, isFetching, Loader }) {
	return (
		<InfiniteScroll
			dataLength={items.length}
			next={fetchMoreData}
			hasMore={hasMore}
			loader={Loader}
			scrollThreshold={0.7}
			scrollableTarget="scrollContainerId"
			height="60vh"
		>
			{children}
		</InfiniteScroll>
	);
}

export default InfiniteScrollWrapper;
