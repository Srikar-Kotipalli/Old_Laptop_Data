import React, { useState, useRef } from 'react';
import { Box, Tooltip, Typography, Skeleton } from '@mui/material';
import Expanded from '../../../assets/graph/Expanded.svg';
import Collapsed from '../../../assets/graph/collapsed.svg';
import CopyButton from '../../../components/copyButton/index';
import SyntaxHighlighter from '../../../components/syntaxHiglighter';
import Icon from '../../../components/icon';

const copyObject = obj => {
	return `
		import pickle
		import base64		
		string_object = "${obj}"		
		decoded_object = base64.b64decode(string_object)		
		deserialized_object = pickle.loads(decoded_object)		
		print(deserialized_object)`;
};

function CodeAccordion({
	heading = 'Code',
	code,
	containerWidth = '65%',
	haveHeading = true,
	codeCopy,
	normalCopy,
	accordionBorder = 'none',
	forValue,
	isFetching
}) {
	const [expanded, setExpanded] = useState(false);
	const codeRef = useRef(null);

	const codeLines = typeof code === 'string' ? code?.trim()?.split('\n')?.length : [];

	const toggleExpand = () => {
		if (codeRef?.current) {
			codeRef.current.scrollTo(0, 0);
		}
		setExpanded(!expanded);
	};

	const getCodeHeight = val => {
		if (forValue === 'node') {
			if (val) return '300px';
			return '100px';
		} else if (val) return '200px';
		return '150px';
	};

	return (
		<>
			{haveHeading ? (
				<Box sx={{ marginBottom: '15px' }}>
					<Typography variant="graphCodeAccordion" sx={{ cursor: 'default' }}>
						{heading}
					</Typography>
				</Box>
			) : null}
			<Box
				ref={codeRef}
				sx={{
					width: containerWidth,
					background: '#1C1C46',
					borderRadius: '8px',
					pb: '1rem',
					border: accordionBorder,
					justifyContent: 'space-between',
					height: getCodeHeight(expanded),
					textOverflow: expanded ? 'clip' : 'ellipsis',
					overflow: expanded ? 'auto' : 'hidden',
					cursor: 'pointer',
					transition: 'all .3s'
				}}
				display="flex"
				flexDirection="row"
				onClick={codeLines > (forValue === 'node' ? 4 : 7) ? toggleExpand : null}
			>
				{isFetching ? (
					<Box ml={2.3} mt={2}>
						<Skeleton width={300} />
						<Skeleton width={200} />
						<Skeleton width={100} />
					</Box>
				) : (
					<>
						<Box
							sx={{
								paddingTop: '16px',
								paddingLeft: '16px',
								paddingBottom: '16px'
							}}
							width="53vw"
						>
							<SyntaxHighlighter src={String(code)?.trim()} />
						</Box>
						{code && code !== 'None' && (
							<Box
								sx={{
									cursor: 'pointer',
									display: 'flex',
									justifyContent: 'flex-end',
									padding: '16px 16px 0 0'
								}}
							>
								<CopyButton
									content={normalCopy ? codeCopy : copyObject(codeCopy)}
									borderEnable={false}
									placement="top"
									padding="5px"
									bgColor="#08081a"
								/>
								<Tooltip title={expanded ? 'View less' : 'View more'} placement="top">
									<Box sx={{ marginLeft: '10px' }}>
										{codeLines > (forValue === 'node' ? 4 : 7) && (
											<Icon src={expanded ? Expanded : Collapsed} alt="button" />
										)}
									</Box>
								</Tooltip>
							</Box>
						)}
					</>
				)}
			</Box>
		</>
	);
}

export default CodeAccordion;
