/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import { Box, Typography, Skeleton } from '@mui/material';
// import CopyButton from '../../../assets/graph/CopyButton.svg';
import OverflowTooltip from '../../../components/tooltip/overflowTooltip';
import CopyButton from '../../../components/copyButton';
import Qelectron from '../../../assets/graph/qelectron.svg';

function QelectronCard({ name, nodeID, isFetching, type = 'default' }) {
	return (
		<Box>
			<Box
				sx={{
					display: 'flex',
					flexDirection: 'row',
					width: type === 'qelectron' ? '100%' : '80%',
					justifyContent: type === 'qelectron' && 'space-between',
					margin: '0 0 -30px 0'
				}}
			>
				<Box sx={{ display: 'flex' }}>
					<img src={Qelectron} alt="qelctron" />
					<Typography
						sx={{
							color: '#CBCBD7',
							fontSize: '16px',
							fontWeight: '400',
							width: '200px',
							margin: '3px 15px 0 10px'
						}}
					>
						{isFetching === true ? (
							<Skeleton variant="rounded" width={130} height={25} />
						) : (
							// <>{name}</>

							<OverflowTooltip title={name} length={25} />
						)}
					</Typography>
				</Box>
				{isFetching ? (
					<Skeleton variant="rounded" width={130} height={25} sx={{ marginLeft: '0px' }} />
				) : (
					<Box
						sx={{
							display: 'flex',
							borderRadius: '8px',
							border: '1px solid #303067'
							// ,marginLeft: '140px'
						}}
					>
						<Box
							sx={{
								minWidth: '50px',
								padding: '2px 6px 2px 12px',
								display: 'flex',
								alignItems: 'center'
							}}
						>
							<OverflowTooltip title={nodeID?.toString()} length={15} />
						</Box>
						<Box
							sx={{
								borderLeftStyle: 'solid',
								borderLeftColor: '#303067',
								borderTopColor: 'transparent',
								borderBottomColor: 'transparent',
								borderRightColor: 'transparent',
								display: 'flex',
								alignItems: 'center',
								padding: '3px'
							}}
						>
							<CopyButton content={nodeID} borderEnable={false} />
						</Box>
					</Box>
				)}
			</Box>
		</Box>
	);
}

export default QelectronCard;
