/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable camelcase */
import React, { useContext } from 'react';
import { Box, Typography, Skeleton } from '@mui/material';
import { GraphContext } from '../contexts/GraphContext';
import GraphRuntime from '../../../utils/GraphRuntime';
import { Prettify } from '../../../utils/utils';
import { statusColor } from '../../../components/icon/misc';

const getFormattedValue = (value, heading, fontSize, latticeDetails) => {
	if (heading === 'Status' && value) {
		return (
			<Typography
				sx={{
					fontSize: '16px',
					color: statusColor(value),
					whiteSpace: 'pre-line !important',
					cursor: 'default'
				}}
			>
				{value === 'NEW_OBJECT'
					? latticeDetails?.status === 'FAILED'
						? 'Canceled'
						: 'Starting'
					: Prettify(String(value))}
			</Typography>
		);
	}
	return (
		<Typography
			sx={{
				color: '#CBCBD7',
				fontSize: fontSize || '20px',
				fontWeight: '500',
				marginBottom: '3px',
				cursor: 'default'
			}}
		>
			{value || '-'}
		</Typography>
	);
};

function NodeData({
	value,
	heading,
	imgSrc,
	started_at,
	completed_at,
	type,
	isLoading,
	fontSize,
	variant,
	sklHeight,
	sklWidth
}) {
	const { latticeDetails } = useContext(GraphContext);
	return (
		<Box sx={{ display: 'flex' }}>
			<Box sx={{ display: 'grid', placeItems: 'center' }}>
				<img src={imgSrc} alt="placeholderimg" />
			</Box>
			{type === 'onlyTitle' && (
				<Box sx={{ marginLeft: '8px' }}>
					<Typography
						sx={{
							color: '#AEB6FF',
							fontSize: variant === 'regular' ? '12px' : '14px',
							fontWeight: variant === 'regular' ? null : '700',
							margin: '5px 0 0 0',
							cursor: 'default'
						}}
					>
						{heading}
					</Typography>
				</Box>
			)}
			{type === 'titleValue' && (
				<Box sx={{ marginLeft: '8px' }}>
					{isLoading ? (
						<Skeleton variant="rounded" width={sklWidth || 60} height={sklHeight || 30} />
					) : heading === 'Runtime' && started_at ? (
						<GraphRuntime
							startTime={started_at}
							endTime={completed_at}
							className="overviewsubhead"
							sx={{ fontSize: fontSize || '20px', color: '#CBCBD7', cursor: 'default' }}
						/>
					) : (
						getFormattedValue(value, heading, fontSize, latticeDetails)
					)}
					<Typography
						sx={{ color: '#86869A', fontSize: '12px', fontWeight: '400', cursor: 'default' }}
					>
						{heading}
					</Typography>
				</Box>
			)}
		</Box>
	);
}

export default NodeData;
