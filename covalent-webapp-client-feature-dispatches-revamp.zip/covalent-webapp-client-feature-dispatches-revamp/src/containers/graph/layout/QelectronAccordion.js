/* eslint-disable no-unused-vars */
/* eslint-disable react/jsx-boolean-value */
/* eslint-disable no-unneeded-ternary */
/* eslint-disable max-len */
/* eslint-disable react/no-array-index-key */
import React, { useState, useEffect, useContext, useRef } from 'react';

import {
	Accordion,
	AccordionSummary,
	AccordionDetails,
	Box,
	Grid,
	Typography,
	Skeleton
} from '@mui/material';
import { differenceInSeconds } from 'date-fns';
import humanizeDuration from 'humanize-duration';
import { GraphContext } from '../contexts/GraphContext';
import NodeDetailViewAccordionHeader from './NodeDetailViewAccordionHeader';
import NodeCard from './NodeCard';
import GraphTab from '../../../components/tab/graph';
import CodeAccordion from './CodeAccordion';
import QelectronList from './QelectronList';
import { Prettify } from '../../../utils/utils';
import './style.css';
import QelectronCard from './QelectronCard';
import Icon from '../../../components/icon';
import ArrowLeft from '../../../assets/arrows/arrowLeft.svg';
import ArrowRight from '../../../assets/arrows/arrowRight.svg';

// eslint-disable-next-line import/no-unused-modules
export const humanize = humanizeDuration.humanizer({
	largest: 4,
	round: true,
	delimiter: ' ',
	spacer: '',
	units: ['d', 'h', 'm', 's'],
	language: 'shortEn',
	languages: {
		shortEn: {
			y: () => 'y',
			mo: () => 'mo',
			w: () => 'w',
			d: () => 'd',
			h: () => 'h',
			m: () => 'm',
			s: () => 's',
			ms: () => 'ms'
		}
	}
});
function QelectronAccordion({ accordionMargin = '0px' }) {
	const {
		getQelectronAssets,
		qelectronCircuit,
		qelectronResult,
		nodeJobs,
		selectedJob,
		selectedJobDetails,
		isFetchingSelectedJobDetails,
		setSelectedJob,
		nodeData
	} = useContext(GraphContext);
	const [expanded, setExpanded] = React.useState(true);
	const [selectedExecutorIndex, setSelectedExecutorIndex] = useState(0);
	const [tabValue, setTabValue] = useState('Result');
	const [selectedJobIndex, setSelectedJobIndex] = useState(0);
	const qelectronListRef = useRef(null);

	const handleSeeAllClick = () => {
		if (qelectronListRef.current) {
			qelectronListRef.current.scrollIntoView({
				behavior: 'smooth'
			});
		}
	};

	const handlePrevClick = () => {
		if (selectedJobIndex > 0) {
			setSelectedJobIndex(selectedJobIndex - 1);

			const newSelectedJob = nodeJobs[selectedJobIndex - 1].circuit_id;
			setSelectedJob(newSelectedJob);
		}
	};

	// Handle next job click
	const handleNextClick = () => {
		if (selectedJobIndex < nodeJobs.length - 1) {
			setSelectedJobIndex(selectedJobIndex + 1);

			const newSelectedJob = nodeJobs[selectedJobIndex + 1].circuit_id;
			setSelectedJob(newSelectedJob);
		}
	};

	const onTabChange = (_e, val) => {
		setTabValue(val);
	};

	// eslint-disable-next-line consistent-return
	const backendColorMapping = {};
	const generateUniqueColor = () => {
		// Generate a unique color here (you can use any method to generate unique colors)
		// For simplicity, let's assume you have a list of colors and you want to cycle through them
		const colorsList = [
			'rgba(173, 123, 255, 0.50)',
			'rgba(218, 195, 255, 0.28)',
			'rgba(173, 123, 255, 0.28)',
			'rgba(109, 124, 255, 0.28)',
			'rgba(85, 216, 153, 0.28)',
			'rgba(255, 193, 100, 0.28)'
			// Add more colors as needed
		];

		const uniqueColor = colorsList[Object.keys(backendColorMapping).length % colorsList.length];
		return uniqueColor;
	};

	// eslint-disable-next-line consistent-return
	const getRandomColor = backendName => {
		if (backendName) {
			if (backendColorMapping[backendName]) {
				return backendColorMapping[backendName];
			}
			// Generate a unique color for the backend name
			const uniqueColor = generateUniqueColor();
			backendColorMapping[backendName] = uniqueColor; // Store the color in the mapping
			return uniqueColor;
		}
	};

	const formatList = res => {
		const resultData = [];
		if (res && res?.length > 0) {
			res?.forEach(e => {
				const data = {};
				data['circuit_id'] = e?.circuit_id;
				data['start_time'] = e?.start_time;
				data['executor'] = Prettify(e?.selected_qexecutor?.name);
				data['status'] = e?.status;
				data['backend'] = Prettify(e?.selected_qexecutor?.attributes?.backend);
				data['backendColor'] = getRandomColor(Prettify(e?.selected_qexecutor?.attributes?.backend));
				resultData.push(data);
			});
		}
		return resultData;
	};

	const qubit = (heading, value) => {
		return (
			<Box>
				<Typography sx={{ color: '#86869A', fontSize: '12px', fontWeight: '400' }}>
					{heading}
				</Typography>
				{isFetchingSelectedJobDetails && <Skeleton variant="rounded" width={80} height={20} />}
				{!isFetchingSelectedJobDetails && (
					<Typography sx={{ color: ' #CBCBD7', fontSize: '14px', fontWeight: '400' }}>
						{value}
					</Typography>
				)}
			</Box>
		);
	};

	const getGates = (input, isLoading) => {
		return (
			input &&
			Object?.entries(input)?.length > 0 &&
			Object?.entries(input)
				.map(([key, value]) => [Number(key), String(value)])
				.map((info, index) => (
					<Grid item xs={3} key={index}>
						{qubit(`No. ${info[0]} Qubit Gates`, info[1])}
					</Grid>
				))
		);
	};

	const calculateAvgRuntime = result => {
		// eslint-disable-next-line no-unused-vars
		let sumOfExecutionTime = 0;
		if (result && result?.length > 0) {
			result?.forEach(circuit => {
				if (circuit?.start_time && circuit?.end_time) {
					const diff = differenceInSeconds(
						new Date(circuit?.end_time),
						new Date(circuit?.start_time)
					);
					sumOfExecutionTime += diff;
				}
			});
			const avgTime = sumOfExecutionTime / result.length;
			return humanize(avgTime * 1000);
		}
		return '0s';
	};

	const calculateShortLong = result => {
		const obj = {};
		const arr = [];
		if (result && result?.length > 0) {
			result?.forEach(circuit => {
				if (circuit?.start_time && circuit?.end_time) {
					const diff = differenceInSeconds(
						new Date(circuit?.end_time),
						new Date(circuit?.start_time)
					);
					arr.push(diff);
				}
			});
			if (arr?.length > 0) {
				arr.sort();
				obj['shortest'] = humanize(arr[0] * 1000);
				obj['longest'] = humanize(arr[arr.length - 1] * 1000);
			}
		}
		return obj;
	};

	const calculateStatus = result => {
		if (result && result?.length > 0) {
			return [result?.filter(e => e?.status === nodeData?.status)?.length, result?.length];
		}
		return [];
	};

	useEffect(() => {
		if (selectedJob) {
			getQelectronAssets(selectedJob, 'result_string');
			getQelectronAssets(selectedJob, 'circuit_string');
		}
	}, [selectedJob]);

	useEffect(() => {
		if (selectedJob && nodeJobs && nodeJobs.length > selectedJobIndex) {
			const newSelectedJob = nodeJobs[selectedJobIndex].circuit_id;
			if (newSelectedJob !== selectedJob) {
				getQelectronAssets(newSelectedJob, 'result_string');
				getQelectronAssets(newSelectedJob, 'circuit_string');

				// Update the dataList
			}
		}
	}, [selectedJobIndex, nodeJobs, selectedJob, getQelectronAssets]);

	return (
		<Accordion
			disableGutters
			expanded={expanded}
			sx={{
				border: '1px solid #303067',
				borderRadius: '8px',
				margin: accordionMargin
			}}
		>
			<AccordionSummary sx={{ cursor: 'default !important' }}>
				<Box sx={{ width: '100%' }}>
					<NodeDetailViewAccordionHeader
						name={selectedJobDetails?.circuit_name}
						nodeID={selectedJob}
						expanded={expanded}
						setExpanded={setExpanded}
						isFetching={isFetchingSelectedJobDetails}
						type="qelectron"
					/>
					<Box
						sx={{
							height: '4px',
							background: '#5552FF',
							width: 'calc(100% + 33px)',
							margin: '6px 0 0 -17px'
						}}
					/>
					<Grid
						container
						rowSpacing={2}
						sx={{
							marginTop: '39px',
							border: '1px solid #303067',
							borderRadius: '10px',
							padding: '25px 20px 25px 20px',
							marginLeft: '1px',
							width: '100%'
						}}
					>
						<Grid
							item
							xs={12}
							sm={6}
							md={4}
							sx={{ display: 'flex', justifyContent: 'center', paddingBottom: '10px' }}
						>
							<NodeCard
								title="Status"
								value={selectedJobDetails?.status}
								cardHeight="150px"
								isFetching={isFetchingSelectedJobDetails}
								statusElectrons={calculateStatus(nodeJobs)}
							/>
						</Grid>
						<Grid item xs={12} sm={6} md={4} sx={{ display: 'flex', justifyContent: 'center' }}>
							<NodeCard
								title="Avg Runtime"
								value={calculateAvgRuntime(nodeJobs)}
								runtime={calculateShortLong(nodeJobs)}
								cardHeight="150px"
								isFetching={isFetchingSelectedJobDetails}
							/>
						</Grid>
						<Grid item xs={12} sm={6} md={4} sx={{ display: 'flex', justifyContent: 'center' }}>
							<NodeCard
								title="Total Circuits"
								value={nodeJobs?.length}
								totalErrors={
									nodeJobs && nodeJobs?.length > 0
										? nodeJobs?.filter(item => item?.status === 'FAILED')?.length
										: 0
								}
								cardHeight="150px"
								isFetching={isFetchingSelectedJobDetails}
							/>
						</Grid>
					</Grid>
				</Box>
			</AccordionSummary>
			<AccordionDetails>
				<Box ref={qelectronListRef} mb={3} sx={{ display: 'flex', width: '100%' }}>
					<QelectronList
						dataList={formatList(nodeJobs)}
						setSelectedJobIndex={setSelectedJobIndex}
					/>
				</Box>
				<Box mt={4} mb={2} sx={{ marginTop: '50px' }}>
					<QelectronCard
						name={selectedJobDetails?.circuit_name}
						nodeID={selectedJob}
						isFetching={isFetchingSelectedJobDetails}
						type="qelectron"
					/>
				</Box>
				<Grid
					mb={1}
					container
					rowSpacing={2}
					sx={{
						marginTop: '39px',
						border: '1px solid #303067',
						borderRadius: '10px',
						padding: '25px 20px 25px 20px',
						marginLeft: '1px',
						width: '100%'
					}}
				>
					<Grid
						item
						xs={12}
						sm={6}
						md={3}
						sx={{ display: 'flex', justifyContent: 'center', paddingBottom: '10px' }}
					>
						<NodeCard
							title="Status"
							value={selectedJobDetails?.status}
							backend={Prettify(selectedJobDetails?.selected_qexecutor?.attributes?.backend)}
							cardHeight="74px"
							isFetching={isFetchingSelectedJobDetails}
						/>
					</Grid>
					<Grid
						item
						xs={12}
						sm={6}
						md={3}
						sx={{ display: 'flex', justifyContent: 'center', paddingBottom: '10px' }}
					>
						<NodeCard
							title="Backend"
							value={Prettify(selectedJobDetails?.selected_qexecutor?.attributes?.backend)}
							cardHeight="74px"
							isFetching={isFetchingSelectedJobDetails}
							fontSize="12px"
						/>
					</Grid>
					<Grid
						item
						xs={12}
						sm={6}
						md={3}
						sx={{ display: 'flex', justifyContent: 'center', paddingBottom: '10px' }}
					>
						<NodeCard
							title="Runtime"
							value={calculateAvgRuntime(nodeJobs)}
							runtime={calculateShortLong(nodeJobs)}
							cardHeight="74px"
							isFetching={isFetchingSelectedJobDetails}
						/>
					</Grid>
					<Grid
						item
						xs={12}
						sm={6}
						md={3}
						sx={{ display: 'flex', justifyContent: 'center', paddingBottom: '10px' }}
					>
						<NodeCard
							title="Start - End"
							date={true}
							started_at={selectedJobDetails?.start_time}
							completed_at={selectedJobDetails?.end_time}
							type="runtime"
							cardHeight="74px"
							isLoading={isFetchingSelectedJobDetails}
							fontSize="12px"
						/>
					</Grid>
				</Grid>
				<Box sx={{ width: '100%' }}>
					<GraphTab
						value={tabValue}
						onChange={onTabChange}
						firstValue="Result"
						secondValue="Circuit"
					/>

					{tabValue === 'Result' && (
						<CodeAccordion
							haveHeading={false}
							code={qelectronResult}
							containerWidth="100%"
							normalCopy
							codeCopy={qelectronResult}
							forValue="node"
						/>
					)}
					{tabValue === 'Circuit' && (
						<CodeAccordion
							haveHeading={false}
							code={qelectronCircuit}
							containerWidth="100%"
							normalCopy
							codeCopy={qelectronCircuit}
							forValue="node"
						/>
					)}
					<Grid
						container
						className="scrollbar"
						sx={{
							marginTop: '39px',
							maxHeight: '120px',
							overflowY: 'auto'
						}}
					>
						<Grid item xs={3}>
							{qubit('No. of Qubits', selectedJobDetails?.qnode_specs?.num_used_wires)}
						</Grid>

						{getGates(selectedJobDetails?.qnode_specs?.gate_sizes)}

						<Grid item xs={3}>
							{qubit('Depth', selectedJobDetails?.qnode_specs?.depth)}
						</Grid>
					</Grid>
					<Typography
						sx={{ color: '#CBCBD7', fontSize: '14px', fontWeight: '400', margin: '39px 0 15px 0' }}
					>
						Executor
					</Typography>
				</Box>
				<Box sx={{ display: 'flex' }}>
					<Box sx={{ width: '15%', paddingRight: '15px', overflow: 'auto' }}>
						{selectedJobDetails?.allowed_qexecutors?.length > 0 &&
							selectedJobDetails?.allowed_qexecutors?.map((allowedExecutorObj, index) => {
								return (
									<Box
										key={index}
										sx={{
											background: selectedExecutorIndex === index ? '#303067' : 'transparent',
											cursor: 'pointer',
											borderRadius: '6px',
											padding: '4px 10px 4px 10px',
											mb: '3px'
										}}
										onClick={() => setSelectedExecutorIndex(index)}
									>
										<Box>
											<Typography sx={{ color: '#CBCBD7', fontSize: '12px', fontWeight: '400' }}>
												{Prettify(allowedExecutorObj?.attributes?.name)}
											</Typography>
											<Box sx={{ display: 'flex', alignItems: 'center' }}>
												<Typography
													sx={{
														color:
															JSON.stringify(allowedExecutorObj) ===
															JSON.stringify(selectedJobDetails?.selected_qexecutor)
																? '#55D899'
																: '#86869A',
														fontSize: '10px',
														fontWeight: '400'
													}}
												>
													{Prettify(allowedExecutorObj?.attributes?.backend)}
												</Typography>
												{JSON.stringify(allowedExecutorObj) ===
													JSON.stringify(selectedJobDetails?.selected_qexecutor) && (
													<Box
														sx={{
															height: '5px',
															width: '5px',
															background: '#55D899',
															borderRadius: '5px',
															marginLeft: '5px'
														}}
													/>
												)}
											</Box>
										</Box>
									</Box>
								);
							})}
					</Box>
					{selectedJobDetails?.allowed_qexecutors &&
						selectedJobDetails?.allowed_qexecutors?.length > 0 && (
							<Box sx={{ width: '85%' }}>
								<CodeAccordion
									haveHeading={false}
									code={JSON.stringify(
										selectedJobDetails?.allowed_qexecutors[selectedExecutorIndex]?.attributes,
										null,
										2
									)}
									normalCopy={true}
									codeCopy={JSON.stringify(
										selectedJobDetails?.allowed_qexecutors[selectedExecutorIndex]?.attributes,
										null,
										2
									)}
									containerWidth="100%"
								/>
							</Box>
						)}
				</Box>
				<Grid
					mt={2}
					container
					xs={12}
					direction="row"
					justifyContent="space-between"
					alignItems="center"
				>
					<Grid
						item
						xs={6}
						sx={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}
					>
						{selectedJobIndex > 0 && (
							<Box
								p={1}
								sx={{
									display: 'flex',
									alignItems: 'center',
									justifyContent: 'center',
									cursor: 'pointer',
									'&:hover': {
										background: theme => theme.palette.background.blue06,
										borderRadius: '25px'
									}
								}}
								onClick={handlePrevClick}
							>
								<Icon src={ArrowLeft} alt="arrowLeft" />
								<Typography variant="h2">Previous Job</Typography>
							</Box>
						)}
					</Grid>

					<Grid
						item
						xs={6}
						sx={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}
					>
						<Box p={2} sx={{ display: 'flex', cursor: 'pointer', alignItems: 'center' }}>
							<Box
								mr={2}
								p={1}
								sx={{
									display: 'flex',
									alignItems: 'center',
									justifyContent: 'center',
									cursor: 'pointer',
									'&:hover': {
										background: theme => theme.palette.background.blue06,
										borderRadius: '25px'
									}
								}}
								onClick={handleSeeAllClick}
							>
								<Typography variant="h2">See All Jobs</Typography>{' '}
							</Box>
							{selectedJobIndex < nodeJobs.length - 1 && (
								<Box
									p={1}
									sx={{
										display: 'flex',
										alignItems: 'center',
										justifyContent: 'center',
										cursor: 'pointer',
										'&:hover': {
											background: theme => theme.palette.background.blue06,
											borderRadius: '25px'
										}
									}}
									onClick={handleNextClick}
								>
									<Typography variant="h2">Next Job</Typography>
									<Icon src={ArrowRight} alt="arrowRight" />
								</Box>
							)}
						</Box>
					</Grid>
				</Grid>
			</AccordionDetails>
		</Accordion>
	);
}

export default QelectronAccordion;
