/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import { Box, Typography, Link, Skeleton } from '@mui/material';
import CopyButton from '../../../components/copyButton/index';
import SyntaxHighlighter from '../../../components/syntaxHiglighter';
import Pane from '../../../assets/graph/pane.svg';
import './style.css';
import Icon from '../../../components/icon';
import CodePane from '../../../components/codePane';

// here we can use the codepane for single tab by only passing the value in json and omitting jsonInput

function Input({
	img,
	heading,
	json,
	isError,
	copyContent,
	value,
	jsonInput,
	handleErrorScroll,
	isLoading
}) {
	const [openCodePane, setOpenCodePane] = React.useState(false);
	const [tabValue, setTabValue] = React.useState(value === 'Input' ? 'Input' : 'Results');
	const isJsonObject = typeof json === 'object';
	const isjsonInputObject = typeof jsonInput === 'object';

	return (
		<Box>
			<Box sx={{ display: 'flex' }}>
				<Box sx={{ width: '25px', height: '24px', marginRight: '5px' }}>
					<img src={img} alt="img" />
				</Box>
				{isError ? (
					<Typography sx={{ color: '#AEB6FF', fontSize: '14px', fontWeight: '700', mt: '3px' }}>
						Error
					</Typography>
				) : (
					<Box sx={{ disaply: 'flex', alignItems: 'center' }}>
						<Typography
							sx={{ color: '#AEB6FF', fontSize: '14px', fontWeight: '700', marginTop: '2px' }}
						>
							{heading}
						</Typography>
					</Box>
				)}
			</Box>
			{isError ? (
				<Box display="flex">
					<Typography
						sx={{
							fontSize: '14px',
							fontWeight: '400',
							color: '#FF6464',
							width: 'fit-content',
							mt: '5px',
							ml: '10px'
						}}
					>
						One or more electrons failed please
						<Link
							onClick={handleErrorScroll}
							underline="always"
							sx={{
								fontSize: '14px',
								fontWeight: '400',
								color: '#FF6464',
								textDecorationColor: '#FF6464',
								pl: '2px',
								cursor: 'pointer'
							}}
						>
							click here
						</Link>{' '}
						for more details
					</Typography>
				</Box>
			) : (
				<Box
					sx={{
						// padding: '19px 11px 22px 11px',
						padding: '5px 7px',
						border: '1px solid #303067',
						borderRadius: '8px',
						marginTop: '10px'
					}}
				>
					{!isLoading && (
						<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
							<SyntaxHighlighter
								src={
									value === 'Input'
										? isjsonInputObject
											? JSON.stringify(jsonInput, null, 2)?.slice(0, 100)
											: jsonInput?.toString()?.slice(0, 100)
										: isJsonObject
										? JSON.stringify(json)?.slice(0, 100)?.replace(/\\n/g, '')
										: json?.toString()?.slice(0, 100)
								}
								className="latticeAccordion"
							/>
							{(value === 'Input'
								? jsonInput && jsonInput !== 'None'
								: json && json !== 'None') && (
								<Box sx={{ display: 'flex', alignItems: 'center' }}>
									<CopyButton
										content={copyContent}
										borderEnable={false}
										placement="top"
										bgColor="#2a2a5c"
										padding="4px"
									/>
									<Box ml={0.8} mr={1}>
										<Icon
											src={Pane}
											alt="controlPane"
											padding="4.3px"
											title="View more"
											clickHandler={() => setOpenCodePane(true)}
											bgColor="#2a2a5c"
										/>
										<CodePane
											open={openCodePane}
											setOpen={setOpenCodePane}
											json={json}
											jsonInput={jsonInput}
											tabValue={tabValue}
											setTabValue={setTabValue}
										/>
									</Box>
								</Box>
							)}
						</Box>
					)}
					{isLoading && <Skeleton variant="rounded" width="80%" height={33} />}
				</Box>
			)}
		</Box>
	);
}

export default Input;
