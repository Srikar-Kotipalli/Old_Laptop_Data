import React from 'react';
import { Grid } from '@mui/material';
import NodeDetailViewAccordion from './NodeDetailViewAccordion';
import QelectronAccordion from './QelectronAccordion';
import ElectronsList from './ElectronsList';

function DetailView({ isFetchingNodeData, nodeStatus, selectedNodeData, enableShareOption }) {
	return (
		<Grid item container direction="row" mt={2} justifyContent="space-between">
			<Grid item xs={8.6}>
				<NodeDetailViewAccordion
					isFetchingNodeData={isFetchingNodeData}
					data={selectedNodeData}
					nodeStatus={nodeStatus}
					enableShareOption={enableShareOption}
				/>
				{selectedNodeData?.contains_qelectrons ? (
					<QelectronAccordion accordionMargin="30px 0 0 0" />
				) : null}
			</Grid>
			<Grid item xs={3}>
				<ElectronsList />
			</Grid>
		</Grid>
	);
}

export default DetailView;
