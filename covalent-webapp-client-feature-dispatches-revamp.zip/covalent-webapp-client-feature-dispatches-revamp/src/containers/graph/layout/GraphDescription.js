/* eslint-disable max-len */
/* eslint-disable quotes */
import React from 'react';
import { Box, Typography } from '@mui/material';
import SyntaxHighlighter from '../../../components/syntaxHiglighter';

function GraphDescription({ code }) {
	return (
		<>
			<Typography
				sx={{ color: '#86869A', fontSize: '12px', fontWeight: '400', marginBottom: '10px' }}
			>
				Description
			</Typography>
			<Box
				sx={{
					width: '65%',
					textOverflow: 'ellipsis',
					overflow: 'auto',
					maxHeight: '150px'
				}}
			>
				<SyntaxHighlighter src={code} />
			</Box>
		</>
	);
}

export default GraphDescription;
