/* eslint-disable brace-style */
/* eslint-disable no-unused-vars */
import React, { useState, useEffect, useRef } from 'react';
import { useDebounce } from 'use-debounce';
import moment from 'moment';
import { Grid, Box, Typography } from '@mui/material';
import {
	getLatticesBatch,
	editLatticeName,
	getAssetFromUrl
} from '../../api/dispatches/latticeApi';
import ControlsHeader from './layout/controlsHeader';
import DispatchTableLayout from './layout/dispatchTableLayout';
import NoSecretsFoundIcon from '../../assets/secretsArchieveIcon.svg';
import Icon from '../../components/icon';
import covLoader from '../../assets/loaders/covLoader.svg';
import { getCurrentWeek, dateFormatter } from '../../utils/utils';
import CustomisedSnackbar from '../../components/snackbar/projects';

function Dispatches() {
	const [data, setData] = useState([]);
	const [totalCount, setTotalCount] = useState(0);
	const [loading, setLoading] = useState(true);
	const [openLoader, setOpenLoader] = useState(false);
	const [page, setPage] = useState(0);

	// handles status filter
	const [filterValue, setFilterValue] = React.useState(false);

	// handle sort and search
	const [searchKey, setSearchKey] = useState('');
	const [searchValue] = useDebounce(searchKey, 2000);
	const [sortColumn, setSortColumn] = useState('updated_at');
	const [sortOrder, setSortOrder] = useState('desc');

	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState('');

	// handle sort and search
	const onSort = column => {
		setPage(0);
		const isAsc = sortColumn === column && sortOrder === 'asc';
		setSortOrder(isAsc ? 'desc' : 'asc');
		setSortColumn(column);
	};

	// handle edit lattice name icon click
	const onClickEditIcon = id => {
		const index = data?.findIndex(obj => obj.dispatch_id === id);
		const addIndex = data?.findIndex(obj => obj?.isAdd === true);
		if (addIndex === -1) {
			data[index].isAdd = true;
			setData([...data]);
		} else {
			setOpenSnackbar(true);
			setSnackbarMessage('Please add/edit one item at a time');
		}
	};

	// handle edit lattice api call
	const triggerEditLatticeName = (text, action, dispatch) => {
		const index = data?.findIndex(i => i?.dispatch_id === dispatch?.dispatch_id);
		let parameter = null;
		const addData = data;
		if (action === 'save' && text !== null && text !== '') {
			parameter = {
				name: text,
				status: dispatch?.status
			};
			setOpenLoader(true);
			editLatticeName(dispatch?.dispatch_id, parameter)
				.then(response => {
					if (response && response?.dispatch_id === dispatch?.dispatch_id) {
						addData[index] = { ...addData[index], ...response };
						setOpenSnackbar(true);
						setSnackbarMessage('Lattice name edited successfully');
						addData[index].isAdd = false;
						setData([...addData]);
					}
					setOpenLoader(false);
				})
				.catch(() => {
					// catchError();
					setOpenLoader(false);
				});
		} else if (action === 'close') {
			setOpenLoader(false);
			addData[index].isAdd = false;
			setData([...addData]);
		}
	};

	const getValueForThisWeek = updatedAt => {
		const { first, last } = getCurrentWeek();
		const compareDate = moment(
			moment(new Date(`${updatedAt}Z`)).format('DD/MM/YYYY'),
			'DD/MM/YYYY'
		);
		const startDate = moment(first, 'DD/MM/YYYY');
		const endDate = moment(last, 'DD/MM/YYYY');
		return compareDate.isBetween(startDate, endDate, 'days', '[]') ? 'yes' : 'no';
	};

	const getAsset = async url => {
		getAssetFromUrl(url)
			.then(res => {
				return res?.data;
			})
			.catch(err => {
				return '-';
			});
	};

	useEffect(() => {
		if (page === 0) setOpenLoader(true);
		getLatticesBatch({ page, sortColumn, sortOrder, status: filterValue })
			.then(response => {
				setTotalCount(response?.metadata?.total_count);
				const list = response?.records;
				const promises = [];
				if (sortColumn === 'updated_at' && sortOrder === 'desc') {
					const dataArray = [...data];
					const thisIndex = dataArray?.findIndex(e => e?.label === 'This week');
					const pastIndex = dataArray?.findIndex(e => e?.label === 'Past Dispatches');
					const dispatchList = list?.map(item => {
						return {
							...item,
							thisWeek: item?.updated_at && getValueForThisWeek(item?.updated_at)
						};
					});

					// case 1 : No segregation found
					if (
						dataArray &&
						(!(thisIndex || thisIndex === 0) || thisIndex === -1) &&
						(!(pastIndex || pastIndex === 0) || pastIndex === -1)
					) {
						const segregatedDataA = [];
						if (dispatchList[0]?.thisWeek === 'yes') {
							// we have this week
							segregatedDataA?.push({ label: 'This week' });
							dispatchList[0]['starting'] = true;
							const indexA = dispatchList?.findIndex(e => e?.thisWeek === 'no');
							if (indexA === -1) {
								// case where there are no past dispatches
								segregatedDataA?.push(...dispatchList);
								if (page !== 0) setData(prevData => [...prevData, ...segregatedDataA]);
								else setData([...segregatedDataA]);
							} else {
								const splitArrayThisWeek = dispatchList?.slice(0, indexA);
								const splitArrayPastDis = dispatchList?.slice(indexA);
								if (splitArrayThisWeek?.length > 0)
									splitArrayThisWeek[splitArrayThisWeek.length - 1]['ending'] = true;
								if (splitArrayPastDis?.length > 0) splitArrayPastDis[0]['starting'] = true;
								segregatedDataA?.push(
									...splitArrayThisWeek,
									{ label: 'Past Dispatches' },
									...splitArrayPastDis
								);
								setData(segregatedDataA);
							}
						} else {
							// no this week
							if (dispatchList?.length > 0) {
								segregatedDataA?.push({ label: 'Past Dispatches' });
								dispatchList[0]['starting'] = true;
								// dispatchList[dispatchList.length - 1]['ending'] = true;
								segregatedDataA?.push(...dispatchList);
								if (page > 0) {
									setData(prevData => [...prevData, ...segregatedDataA]); // Append new data to existing data
								} else {
									setData(segregatedDataA);
								}
							}
						}
					}
					// case 2: This week label present, Past Dispatches label not present
					else if (
						dataArray &&
						(thisIndex || thisIndex === 0) &&
						thisIndex !== -1 &&
						(!(pastIndex || pastIndex === 0) || pastIndex === -1)
					) {
						const index = dispatchList?.findIndex(e => e?.thisWeek === 'no');
						const segregatedData = [];
						// no past dispatch , only this week
						if (index === -1) {
							if (page !== 0) setData(prevData => [...prevData, ...dispatchList]);
							else setData([...dispatchList]);
						} else {
							const splitArrayThisWeek = dispatchList?.slice(0, index);
							const splitArrayPastDis = dispatchList?.slice(index);
							if (splitArrayThisWeek?.length > 0)
								splitArrayThisWeek[splitArrayThisWeek.length - 1]['ending'] = true;
							if (splitArrayPastDis?.length > 0) splitArrayPastDis[0]['starting'] = true;
							segregatedData?.push(
								...splitArrayThisWeek,
								{ label: 'Past Dispatches' },
								...splitArrayPastDis
							);
							if (page !== 0) setData(prevData => [...prevData, ...segregatedData]);
							else setData([...segregatedData]);
						}
					}
					// case 3: Past Dispatches label is present
					else if (dataArray && (pastIndex || pastIndex === 0) && pastIndex !== -1) {
						if (page !== 0) setData(prevData => [...prevData, ...dispatchList]);
						else setData([...dispatchList]);
					}
				} else {
					if (page > 0) {
						setData(prevData => [...prevData, ...list]); // Append new data to existing data
					} else {
						// if (list.length > 0) {
						// 	list[0]['starting'] = true;
						// 	list[list.length - 1]['ending'] = true;
						// }
						setData(list);
					}
				}
				setLoading(false);
				setOpenLoader(false);
			})
			.catch(err => {
				setLoading(false);
				setOpenLoader(false);
				setOpenSnackbar(true);
				setSnackbarMessage('Something went wrong,please contact the administrator');
			});
	}, [page, sortOrder, sortColumn, filterValue]);

	const fetchMoreData = () => {
		if (data?.length < totalCount) {
			setPage(prevOffset => prevOffset + 1);
		}
	};

	return (
		<Grid>
			<CustomisedSnackbar
				testId="dispatchesSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			<ControlsHeader
				filterValue={filterValue}
				setFilterValue={setFilterValue}
				setPage={setPage}
				setSearchKey={setSearchKey}
				searchKey={searchKey}
				setData={setData}
			/>
			<Grid container xs={12}>
				{openLoader && (
					<Box
						mt={2}
						sx={{
							width: '100%',
							height: '300px',
							borderRadius: '8px',
							display: 'flex',
							justifyContent: 'center',
							alignItems: 'center',
							flexDirection: 'column',
							border: theme => `1px solid ${theme?.palette?.background?.blue03}`
						}}
					>
						<Icon type="pointer" src={covLoader} display="flex" />
					</Box>
				)}
				{!openLoader && data && data?.length > 0 && (
					<>
						<Grid
							item
							xs={11}
							id="scrollContainerId"
							mt={1}
							// sx={{ width: '60vh' }}
						>
							<DispatchTableLayout
								fetchMoreData={fetchMoreData}
								totalCount={totalCount}
								loading={loading}
								data={data}
								onSortFunction={onSort}
								sortColumn={sortColumn}
								sortOrder={sortOrder}
								onClickEditIcon={onClickEditIcon}
								triggerEditLatticeName={triggerEditLatticeName}
							/>
						</Grid>
						<Grid item xs={1}>
							Timeline
						</Grid>
					</>
				)}
				{!openLoader && data?.length === 0 && (
					<Box
						mt={2}
						sx={{
							width: '100%',
							height: '220px',
							borderRadius: '8px',
							display: 'flex',
							justifyContent: 'center',
							alignItems: 'center',
							flexDirection: 'column',
							border: theme => `1px solid ${theme?.palette?.background?.blue03}`
						}}
					>
						<Icon src={NoSecretsFoundIcon} type="static" alt="noSecretsIcon" />
						<Typography variant="h2" mt="22px">
							No Dispatches to show
						</Typography>
					</Box>
				)}
			</Grid>
		</Grid>
	);
}

export default Dispatches;
