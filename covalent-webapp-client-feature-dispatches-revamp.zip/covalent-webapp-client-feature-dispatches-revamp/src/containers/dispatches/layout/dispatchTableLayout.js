/* eslint-disable react/jsx-props-no-spreading */
/* eslint-disable no-unused-vars */
/* eslint-disable react/no-unstable-nested-components */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import useMediaQuery from '@mui/material/useMediaQuery';
import { TableRow, TableBody, Table, TableContainer, Tooltip } from '@mui/material';
import DispatchRowLayout from './dispatchRowLayout';
import TitleRowLayout from './titleRowLayout';
import DispatchHeader from './dispatchHeader';
import deleteRedIcon from '../../../assets/actions/deleteRedIcon.svg';
import TableSkeleton from '../../../components/table/tableSkeleton';
import VirtuosoTable from '../../../components/virtuosoTable';
import Icon from '../../../components/icon';

function DispatchTableLayout({
	fetchMoreData,
	totalCount,
	data,
	loading,
	sortOrder,
	sortColumn,
	onSortFunction,
	onClickEditIcon,
	triggerEditLatticeName
}) {
	const isWideScreenDesktop = useMediaQuery('(min-height: 1400px)');
	const isWideScreen = useMediaQuery('(min-height: 1000px)');
	const isMediumScreen = useMediaQuery('(min-height: 900px)');
	const isMediumScreen2 = useMediaQuery('(min-height: 850px)');
	const navigate = useNavigate();

	const handleRowClick = props => {
		const dispatchID = props?.item?.dispatch_id;
		if (dispatchID) navigate(`/graph/${dispatchID}`);
	};

	const deleteLattice = props => {
		const dispatchID = props?.item?.dispatch_id;
	};

	const TableComponents = {
		TableRow: props => (
			// <Tooltip
			// 	title={<Icon src={deleteRedIcon} clickHandler={() => deleteLattice(props)} />}
			// 	componentsProps={{
			// 		tooltip: {
			// 			sx: {
			// 				bgcolor: '#08081A !important'
			// 			}
			// 		}
			// 	}}>
			<TableRow {...props} onClick={() => handleRowClick(props)} />
		)
		// </Tooltip>
	};

	const getHeightByScreenHeight = () => {
		if (isWideScreenDesktop) {
			return '79vh';
		} else if (isWideScreen) {
			return '75vh';
		} else if (isMediumScreen) {
			return '74vh';
		} else if (isMediumScreen2) {
			return '65vh';
		}
		return '67vh';
	};

	const RenderRows = ({ user, index }) => {
		return user?.label ? (
			<TitleRowLayout title={user?.label} />
		) : (
			<DispatchRowLayout
				dispatch={user}
				onClickEditIcon={onClickEditIcon}
				triggerEditLatticeName={triggerEditLatticeName}
				keyy={index}
			/>
		);
	};

	function ResultsTableHead({ order, orderBy, onSort }) {
		return <DispatchHeader sortOrder={order} sortColumn={orderBy} onSort={onSort} />;
	}

	return (
		<TableContainer
			sx={{
				'& .MuiTableCell-root': {
					border: 0,
					padding: '0.5rem'
				}
			}}
		>
			<VirtuosoTable
				data={data}
				// eslint-disable-next-line react/jsx-no-bind
				ResultsTableHead={ResultsTableHead}
				RenderRows={RenderRows}
				sortOrder={sortOrder}
				sortColumn={sortColumn}
				handleChangeSort={onSortFunction}
				fetchMoreData={fetchMoreData}
				// overscan={700}
				bgColor="#1C1C46"
				height={getHeightByScreenHeight()}
				limit={7}
				TableComponents={TableComponents}
			/>
		</TableContainer>
		// </InfiniteScrollWrapper>
	);
}

export default DispatchTableLayout;
