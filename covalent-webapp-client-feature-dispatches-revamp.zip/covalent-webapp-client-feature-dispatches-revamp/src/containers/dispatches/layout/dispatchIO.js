/* eslint-disable no-unused-vars */
import React from 'react';
import { Box, Skeleton } from '@mui/material';
import CopyButton from '../../../components/copyButton/index';
import SyntaxHighlighter from '../../../components/syntaxHiglighter';
import Pane from '../../../assets/graph/pane.svg';
import Icon from '../../../components/icon';
import CodePane from '../../../components/codePane';

function DispatchIO({ value, copyValue, isLoading }) {
	return (
		<Box
			sx={{
				padding: '0px 9px',
				border: '0.5px solid #5552FF',
				borderRadius: '8px'
			}}
		>
			{!isLoading && (
				<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
					<SyntaxHighlighter
						src={
							typeof value === 'object'
								? JSON.stringify(value, null, 2)?.slice(0, 100)
								: value?.toString()?.slice(0, 100)
						}
						className="latticeAccordion"
					/>
					{value && value !== 'None' && (
						<Box sx={{ display: 'flex', alignItems: 'center' }}>
							{/* <CopyButton
								content={copyValue}
								borderEnable={false}
								placement="top"
								bgColor="#2a2a5c"
								padding="4px"
							/> */}
							<Box ml={0.8} mr={1}>
								<Icon
									src={Pane}
									alt="controlPane"
									padding="4.3px"
									title="View more"
									// clickHandler={() => setOpenCodePane(true)}
									bgColor="#2a2a5c"
								/>
								{/* <CodePane
                                    open={openCodePane}
                                    setOpen={setOpenCodePane}
                                    json={json}
                                    jsonInput={jsonInput}
                                    tabValue={tabValue}
                                    setTabValue={setTabValue}
                                /> */}
							</Box>
						</Box>
					)}
				</Box>
			)}
			{isLoading && <Skeleton variant="rounded" width="80%" height={33} />}
		</Box>
	);
}

export default DispatchIO;
