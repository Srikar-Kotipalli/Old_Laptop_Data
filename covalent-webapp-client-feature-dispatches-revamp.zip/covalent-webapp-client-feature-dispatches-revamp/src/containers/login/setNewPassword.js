/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */

import React, { useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { Grid, Typography, Box } from '@mui/material';
import { Auth } from 'aws-amplify';
import { withStyles } from '@mui/styles';
import { compose } from 'redux';
import LoginInput from '../../components/inputBase/projects/loginInput';
import { LoginContext } from './loginContext';
import WithMediaQuery from '../../utils/useMediaQuery';
import Icon from '../../components/icon';
import ArrowRightIcon from '../../assets/arrows/arrowRightLogin.svg';

// eslint-disable-next-line no-unused-vars
const styles = theme => ({
	container: {
		height: '100vh',
		minHeight: '100%',
		display: 'flex',
		justifyContent: 'center'
	}
});

function SetNewPassword(props) {
	const { users, isMobile } = props;
	const loginContext = useContext(LoginContext);
	const { setOpenSnackbar, setSnackbarMessage, setOpenLoader, setMode } = loginContext;
	const [firstName, setFirstName] = useState('');
	const [lastName, setLastName] = useState('');
	const [disable, setDisable] = useState(true);
	const [password, setPassword] = useState('');
	const [errorFirstname, setErrorFirstname] = React.useState('');
	const [errorLastname, setErrorLastname] = React.useState('');
	const [rePassword, setRePassword] = useState('');
	const [errorPassword, setErrorPassword] = useState('');
	const [errorRePassword, setErrorRePassword] = React.useState('');
	const navigate = useNavigate();

	useEffect(() => {
		const val = !(password && rePassword && password && rePassword);
		setErrorFirstname(firstName ? '' : errorFirstname);
		setErrorLastname(lastName ? '' : errorLastname);
		setErrorPassword(password ? '' : errorPassword);
		setErrorRePassword(rePassword ? '' : errorRePassword);
		if (rePassword !== '' && password !== rePassword) {
			setErrorRePassword('Password do not match');
		}
		setDisable(val);
	}, [password, rePassword, firstName, lastName]);

	async function completeNewPassword() {
		try {
			setOpenLoader(true);
			const user = await Auth.completeNewPassword(users, password, {
				given_name: firstName,
				family_name: lastName
			});
			if (user) {
				setOpenSnackbar(true);
				setOpenLoader(false);
				setSnackbarMessage('Password changed successfully, please login with new password!');
				const res = user?.signInUserSession;
				const accessToken = res.getAccessToken();
				const jwtAccess = accessToken.getJwtToken();
				const idToken = res.getIdToken();
				const jwtId = idToken.getJwtToken();
				localStorage.setItem('AUTH_ACCESS_TOKEN', jwtAccess);
				localStorage.setItem('AUTH_ID_TOKEN', jwtId);
				navigate('/');
			}
		} catch (error) {
			setOpenSnackbar(true);
			setOpenLoader(false);
			if (error?.message === 'User is disabled.') {
				error.message = 'You are yet to be activated. Please contact the administrator.';
			}
			setMode('login');
			setSnackbarMessage(error?.message);
		}
	}

	const validateInput = () => {
		if (!firstName) {
			setDisable(true);
			setErrorFirstname('Firstname is mandatory!');
		}
		if (!lastName) {
			setDisable(true);
			setErrorLastname('Lastname is mandatory!');
		}
		if (!password) {
			setDisable(true);
			setErrorPassword('Password is mandatory!');
		}
		if (!rePassword) {
			setDisable(true);
			setErrorRePassword('Password Confirmation is mandatory!');
		}
		if (!disable) completeNewPassword();
	};

	return (
		<Grid container display={!isMobile && 'contents'} justifyContent="center">
			<Typography
				className="head-label-requestAccess"
				fontSize={!isMobile ? '27px' : '20px'}
				width="100%"
			>
				Set up new password
			</Typography>
			<Grid
				item
				className="scroll-container"
				sx={{
					justifyContent: 'center',
					border: '1px solid #303067',
					borderRadius: '8px',
					maxHeight: isMobile ? '100vh' : '420px',
					// overflowY: isMobile && 'scroll',
					// minHeight: !isMobile && '550px',
					// paddingTop: isMobile ? '25px' : '0px',
					// position: 'absolute',
					// top: '50%',
					width: !isMobile && '468px',
					maxWidth: '468px',
					margin: isMobile ? '20px 10px 0px' : '42px 10px 0px',
					background: 'linear-gradient(309deg, #08081A -0.75%, rgba(8, 8, 26, 0.00) 108.66%)',
					boxShadow: '0px 5px 9px 0px rgba(0, 0, 0, 0.45)'
					// transform: 'translate(0%, -50%)'
				}}
				xs={12}
				md={4}
			>
				<div style={{ padding: !isMobile ? '34px 63px' : '20px' }}>
					<Stack spacing={3}>
						{!users?.firstName && (
							<LoginInput
								name="setNewFirstName"
								id="setNewFirstName"
								autoComplete="firstName"
								width="100%"
								value={firstName}
								handleChange={setFirstName}
								placeholderTxt="Enter first name"
								type="field"
								error={errorFirstname}
								handleEnter={validateInput}
							/>
						)}
						{!users?.family_name && (
							<LoginInput
								name="setNewLastName"
								id="setNewLastName"
								autoComplete="lastName"
								width="100%"
								value={lastName}
								handleChange={setLastName}
								placeholderTxt="Enter last name"
								type="field"
								error={errorLastname}
								handleEnter={validateInput}
							/>
						)}
						<LoginInput
							name="setNewPassword"
							id="setNewPassword"
							value={password}
							width="100%"
							handleChange={setPassword}
							placeholderTxt="Enter new password"
							type="field"
							typeInput="password"
							error={errorPassword}
							handleEnter={validateInput}
						/>
						<LoginInput
							name="setNewRePassword"
							id="setNewRePassword"
							value={rePassword}
							width="100%"
							handleChange={setRePassword}
							placeholderTxt="Re-enter new password"
							type="field"
							typeInput="password"
							error={errorRePassword}
							handleEnter={validateInput}
						/>
					</Stack>
					<Grid container spacing={2} sx={{ my: 2 }} minWidth="350px">
						<Grid item xs={12}>
							<Button
								variant="outlined"
								disableElevation
								sx={{
									width: '100%',
									height: '32px',
									'@media (max-width: 430px)': {
										fontSize: '14px'
									},
									borderRadius: '70px',
									backgroundColor: theme => theme.palette.background.default,
									'&:hover': {
										backgroundColor: theme => theme.palette.background.covalentPurple,
										color: theme => theme.palette.text.secondary,
										borderRadius: '70px',
										borderColor: theme => theme.palette.background.blue05
									}
								}}
								onClick={() => validateInput()}
							>
								Change password
							</Button>
						</Grid>
						<Grid item xs={12}>
							<Box>
								<Typography
									variant="h2"
									display="flex"
									alignItems="center"
									justifyContent="center"
									sx={{
										height: '32px',
										'@media (max-width: 430px)': {
											height: '40px'
										}
									}}
								>
									<Typography
										component="div"
										sx={{
											paddingLeft: '10px',
											color: '#6473FF',
											cursor: 'pointer',
											display: 'flex',
											alignItems: 'center',
											fontSize: '14px',
											'&:hover': {
												textDecoration: 'underline'
											}
										}}
										onClick={() => setMode('login')}
									>
										{' '}
										Back to Login
										<Icon rowType="experimentRow" src={ArrowRightIcon} alt="ArrowRightIcon" />
									</Typography>
								</Typography>
							</Box>
						</Grid>
					</Grid>
				</div>
			</Grid>
		</Grid>
	);
}

export default compose(
	withStyles(styles, {
		name: 'SetNewPassword'
	}),
	WithMediaQuery([['isMobile', theme => theme.breakpoints.down('sm')]])
)(SetNewPassword);
