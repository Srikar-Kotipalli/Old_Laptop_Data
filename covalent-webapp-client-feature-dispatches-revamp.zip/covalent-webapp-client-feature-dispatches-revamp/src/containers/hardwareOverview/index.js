/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import { Box } from '@mui/material';
import React, { useState } from 'react';
import { headData } from '../marketplace/marketplaceConstants';
import Breadcrumb from '../../components/breadcrumb';
import OverviewHeader from './header';
import HardwareOverviewTab from './tab';
import HardwareOverviewTabList from './overview';
import JobQueueComponent from './jobQueue';
import HardwareComponent from './hardware';
import hardwareImage from '../../assets/marketplace/chip.svg';
import AccessRequestComponent from './accessRequest';
import UserComponent from './users';
import SubHeaderControls from '../../components/marketplace/subHeaderControls';

function hardwareOverview() {
	const [value, setValue] = useState('Overview');
	const [selected, setSelected] = useState('userId');
	const [sort, setSort] = useState('asc');
	const [searchValue, setSearchValue] = React.useState('');
	const [dateRange, setDateRange] = useState([null, null]);
	const [startDate, endDate] = dateRange;
	const [toFilter, setToFilter] = useState('last_updated');

	const overviewData = [
		{
			id: 1,
			solverImage: hardwareImage,
			downloads: '100',
			name: 'ibm_kolkata_1',
			apiCalls: '2000',
			revenue: '11234',
			purchaseDate: '12 Feb, 12:05:38',
			chipData: {
				tags: ['python', 'react', 'rust', 'java']
			}
		},
		{
			id: 2,
			solverImage: hardwareImage,
			downloads: '200',
			name: 'ibm_kolkata_2',
			apiCalls: '2000',
			revenue: '11234',
			purchaseDate: '10 Feb, 12:05:38',
			chipData: {
				tags: ['python', 'react', 'rust', 'java']
			}
		},
		{
			id: 3,
			solverImage: hardwareImage,
			downloads: '300',
			name: 'ibm_kolkata_2',
			apiCalls: '2000',
			revenue: '11234',
			purchaseDate: '1 Feb, 12:05:38',
			chipData: {
				tags: ['python', 'react', 'rust', 'java']
			}
		},
		{
			id: 4,
			solverImage: hardwareImage,
			downloads: '400',
			name: 'ibm_kolkata_3',
			apiCalls: '2000',
			revenue: '11234',
			purchaseDate: '2 Feb, 12:05:38',
			chipData: {
				tags: ['python', 'react', 'rust', 'java']
			}
		},
		{
			id: 5,
			solverImage: hardwareImage,
			downloads: '500',
			name: 'ibm_kolkata_4',
			apiCalls: '2000',
			revenue: '11234',
			purchaseDate: '12 Feb, 12:05:38',
			chipData: {
				tags: ['python', 'react', 'rust', 'java']
			}
		}
	];
	// handle tab changes
	const handleTabChange = (_event, newValue) => {
		setSearchValue('');
		setValue(newValue);
	};

	return (
		<Box sx={{ mb: 4 }}>
			<Breadcrumb secondary="Hardware" name={value} to="/hardwareadmin" />
			<Box>
				<OverviewHeader data={headData} />
			</Box>
			<Box mt={3} sx={{ marginLeft: '-10px' }}>
				<HardwareOverviewTab value={value} onChange={handleTabChange} />
			</Box>
			<Box sx={{ width: { lg: '102.5%', xl: '102%', xxl: '102%' } }}>
				{value !== 'Overview' ? (
					<SubHeaderControls
						value={value}
						selected={selected}
						setSelected={setSelected}
						sort={sort}
						setSort={setSort}
						searchValue={searchValue}
						setSearchValue={setSearchValue}
						from={value === 'Users' ? 'hardwareUsers' : ''}
						dateRange={dateRange}
						setDateRange={setDateRange}
						startDate={startDate}
						endDate={endDate}
						toFilter={toFilter}
						setToFilter={setToFilter}
					/>
				) : (
					<> </>
				)}
			</Box>
			{value === 'Overview' && (
				<Box sx={{ width: '100%' }}>
					<HardwareOverviewTabList />
				</Box>
			)}

			{value === 'Hardware' && (
				<Box mt={5} sx={{ width: { xs: '94%', lg: '98.4%', xl: '98.5%', xxl: '98.8%' } }}>
					<HardwareComponent
						overviewData={overviewData}
						searchValue={searchValue}
						selected={selected}
						sort={sort}
						toFilter={toFilter}
						setToFilter={setToFilter}
					/>
				</Box>
			)}

			{value === 'Users' && (
				<Box mt={3}>
					<UserComponent
						selected={selected}
						sort={sort}
						searchValue={searchValue}
						setSearchValue={setSearchValue}
						startDate={startDate}
						endDate={endDate}
						setSelected={setSelected}
						setSort={setSort}
						toFilter={toFilter}
						setToFilter={setToFilter}
					/>
				</Box>
			)}

			{value === 'Access Requests' && (
				<Box mt={3}>
					<AccessRequestComponent
						searchValue={searchValue}
						selected={selected}
						sort={sort}
						setSelected={setSelected}
						setSort={setSort}
						toFilter={toFilter}
						setToFilter={setToFilter}
					/>
				</Box>
			)}

			{value === 'Job Queue' && (
				<Box sx={{ width: { xs: '97.5%', lg: '100.5%', xl: '100.5%', xxl: '100.5%' } }} mt={3}>
					<JobQueueComponent
						selected={selected}
						sort={sort}
						searchValue={searchValue}
						setSearchValue={setSearchValue}
						toFilter={toFilter}
					/>
				</Box>
			)}
		</Box>
	);
}

export default hardwareOverview;
