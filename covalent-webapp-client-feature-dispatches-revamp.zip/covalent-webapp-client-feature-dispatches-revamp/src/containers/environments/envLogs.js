/* eslint-disable no-unused-vars */
// components/Header.js
import React, { useState, useEffect } from 'react';
import { Box, Grid, Typography } from '@mui/material';
import Icon from '../../components/icon';
// import { useNavigate } from 'react-router-dom';
// import EnvAccordion from '../../components/accordion/environments';
import { rebuildEnvironment } from '../../api/environments/environmentsApi';
import MarketplaceDialogBox from '../../components/dialogBox/marketplace';
import CustomisedSnackbar from '../../components/snackbar/projects';
import Edit from '../../assets/actions/edit.svg';
import covLoader from '../../assets/loaders/covLoader.svg';
import NoSecretsFoundIcon from '../../assets/secretsArchieveIcon.svg';
import Button from '../../components/primaryButton';
import YamlEditor from '../../components/aceEditor';

function EnvironmentLogs({
	envId,
	envname,
	logsMessage,
	setLogsMessage,
	rebuildDisabled,
	setRebuildDisabed,
	isDataLoading,
	setIsLogsLoading,
	logError,
	setLogError
}) {
	// eslint-disable-next-line no-unused-vars
	const [openDialogBox, setOpenDialogBox] = useState(false);
	const [openSnackbar, setOpenSnackbar] = React.useState(false);
	const [snackbarMessage, setSnackbarMessage] = React.useState('');
	// const navigate = useNavigate();

	const setRebuildEnvironment = () => {
		setLogsMessage('');
		setRebuildDisabed(true);
		setIsLogsLoading(true);
		setLogError(false);
		rebuildEnvironment(envId)
			.then(_res => {
				setSnackbarMessage(`Request to rebuild the Environment ${envname} - successful`);
				setOpenSnackbar(true);
				// navigate(`/environments/${envId}`);
				// setTimeout(() => navigate(`/environments/${envId}`));
			})
			.catch(err => {
				console.log(err);
				setSnackbarMessage(
					err?.detail ? err.detail : 'Something went wrong, contact administrator'
				);
				setOpenSnackbar(true);
				setRebuildDisabed(false);
				setIsLogsLoading(false);
			});
	};

	const rebuildEnv = () => {
		setRebuildEnvironment();
		setOpenDialogBox(false);
	};

	return (
		<>
			<MarketplaceDialogBox
				openDialogBox={openDialogBox}
				setOpenDialogBox={setOpenDialogBox}
				handler={rebuildEnv}
				confirmButtonTitle="Rebuild"
				title="Rebuild Environment"
				message={`Are you sure about rebuilding ${envname} ?`}
				srcIcon={Edit}
			/>
			<CustomisedSnackbar
				testId="envSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>

			<Grid>
				<Grid item sx={{ display: 'grid', placeItems: 'flex-end', width: '97%', pb: '12px' }}>
					<Button
						bgColor="#303067"
						title="Rebuild Environment"
						hoverColor="#3633ff"
						color="#FFFFFF"
						disabled={rebuildDisabled}
						handler={() => setOpenDialogBox(true)}
						sx={{
							'&:disabled': {
								background: theme => theme?.palette?.background?.covalentPurple,
								color: theme => theme?.palette?.text?.secondary,
								border: '1px solid',
								borderColor: theme => theme?.palette?.background?.blue04,
								borderRadius: '70px'
							}
						}}
					/>
				</Grid>
				<Grid item xs={11.65} lg={11.65} xl={11.65} xxl={11.65}>
					{logError && (
						<Box
							mt={2}
							sx={{
								width: '100%',
								height: '220px',
								borderRadius: '8px',
								display: 'flex',
								justifyContent: 'center',
								alignItems: 'center',
								flexDirection: 'column',
								border: theme => `1px solid ${theme?.palette?.background?.blue03}`
							}}
						>
							<Icon src={NoSecretsFoundIcon} type="static" alt="noSecretsIcon" />
							<Typography variant="h2" mt="22px">
								No logs found
							</Typography>
						</Box>
					)}
					{!logError &&
						(isDataLoading ? (
							<Grid
								xs={12}
								container
								item
								height="20rem"
								display="flex"
								direction="column"
								justifyContent="center"
								alignContent="center"
							>
								<Icon type="pointer" margin="25px" src={covLoader} display="flex" />
								{!rebuildDisabled && 'Fetching Environment logs...'}
								{rebuildDisabled &&
									'Environment build in progress. Please wait while we retrieve the latest logs...'}
							</Grid>
						) : (
							<YamlEditor
								value={logsMessage}
								// eslint-disable-next-line react/jsx-boolean-value
								readOnly={true}
								height="60vh"
							/>
						))}
				</Grid>
			</Grid>
		</>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default EnvironmentLogs;
