/* eslint-disable import/no-unused-modules */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { useState, useEffect } from 'react';

export default function useDispatchesApi(bodyParameters, endPoint) {
	// Here, we need `limit` and `offset`.
	// `limit` is the number of records to be received in each API call.
	// `offset` is used to fetch records based on the offset value (e.g., for offset = 10, the first 10 records are omitted, and the API fetches the next 10 records).
	const [data, setData] = useState([]);
	const [totalCount, setTotalCount] = useState(0);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const [page, setPage] = useState(0);

	const fetchData = () => {
		endPoint({ ...bodyParameters, page })
			.then(response => {
				setTotalCount(response?.metadata?.total_count);
				const list = response?.records;
				if (page > 0) {
					setData(prevData => [...prevData, ...list]);
				} else {
					setData(list); // Append new data to existing data
				}

				setLoading(false);
			})
			.catch(err => {
				setError(err);
				setLoading(false);
			});
	};

	useEffect(() => {
		fetchData();
	}, [page]);

	return { data, totalCount, loading, error, fetchData, setPage };
}
