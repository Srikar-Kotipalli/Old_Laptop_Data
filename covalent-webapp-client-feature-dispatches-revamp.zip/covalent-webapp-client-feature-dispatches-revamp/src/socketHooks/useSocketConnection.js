import { useEffect, useRef, useState, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import {
	socketConnectionOpen,
	socketConnection,
	socketDisconnection,
	callAPI
} from '../redux/socketSlice';

const useSocketConnection = () => {
	const SERVICE_URL = process.env.REACT_APP_ENDPOINT_URL_WEBSOCKET;
	const socket = useRef(WebSocket);
	const dispatch = useDispatch();
	const [isConnected, setIsConnected] = useState(false);
	const [connectionId, setConnectionId] = useState(undefined);
	const token = localStorage.getItem('AUTH_ACCESS_TOKEN');

	// Event listener to when the socket opens
	const onSocketOpen = useCallback(() => {
		if (socket.current?.readyState) {
			socket.current?.send(
				JSON.stringify({
					action: 'connectionMapper',
					token: localStorage.getItem('AUTH_ACCESS_TOKEN')
				})
			);
			setIsConnected(true);
			dispatch(socketConnection());
		}
	}, []);

	// Event listener to when the socket closes
	const onSocketClosed = useCallback(() => {
		setIsConnected(false);
		dispatch(socketDisconnection(isConnected));
		// eslint-disable-next-line no-use-before-define
		reconnectSocket();
	}, []);

	function debounce(func, delay) {
		let timerId;
		// eslint-disable-next-line func-names
		return function (...args) {
			clearTimeout(timerId);
			timerId = setTimeout(() => func.apply(this, args), delay);
		};
	}

	const connectSocket = () => {
		if (socket.current?.readyState !== WebSocket.OPEN) {
			socket.current = new WebSocket(SERVICE_URL);
			socket.current.addEventListener('open', onSocketOpen);
			socket.current.addEventListener('close', onSocketClosed);
			socket.current.addEventListener('message', ({ data }) => {
				// eslint-disable-next-line no-use-before-define
				onSocketMessage(data);
			});
		}
	};

	// This function is used from the useSocketData hook :)
	const reconnectSocket = () => {
		connectSocket();
	};

	// Event listener to when the socket sends a message
	const onSocketMessage = useCallback(
		debounce(data => {
			if (data !== '') {
				const socketData = JSON.parse(data);
				socketData.reconnectSocket = reconnectSocket;
				setConnectionId(socketData?.connectionId);
				dispatch(callAPI());
				dispatch(socketConnectionOpen(socketData));
			}
		}, 3000),
		[]
	);

	useEffect(() => {
		if (token && token !== 'null' && token?.toString() !== '' && JSON?.stringify(token) !== '{}') {
			connectSocket();
		}
	}, [isConnected, connectionId, token]);
};

export default useSocketConnection;
