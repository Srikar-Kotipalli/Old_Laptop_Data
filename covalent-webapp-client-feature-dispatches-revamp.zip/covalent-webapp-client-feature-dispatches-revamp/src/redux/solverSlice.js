/* eslint-disable import/prefer-default-export */
/* eslint-disable import/no-unused-modules */
/* eslint-disable import/no-named-as-default */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
	allMySolvers: []
};

export const solverSlice = createSlice({
	name: 'common',
	initialState,
	reducers: {
		addNewSolver: (state, action) => {
			const { solver } = action.payload;
			state.allMySolvers.push(solver);
		}
	}
});

export const { addNewSolver } = solverSlice.actions;
