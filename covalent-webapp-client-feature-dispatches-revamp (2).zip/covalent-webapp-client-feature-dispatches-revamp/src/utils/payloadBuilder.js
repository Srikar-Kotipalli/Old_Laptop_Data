function HubspotPayload(
	firstName,
	lastName,
	email,
	organisation,
	announcements,
	organisationName,
	username
) {
	const bodyParams = {
		properties: [
			{
				property: 'firstname',
				value: firstName
			},
			{
				property: 'lastname',
				value: lastName
			},
			{
				property: 'username',
				value: username
			},
			{
				property: 'email',
				value: email
			},
			{
				property: 'organization_individual',
				value: organisation
			},
			{
				property: 'email_opt_in',
				value: announcements ? 'true' : 'false'
			},
			{
				property: 'covalent_app_signup',
				value: 'true'
			}
		]
	};
	if (organisation === 'Organization') {
		bodyParams?.properties?.push({
			property: 'organization_name',
			value: organisationName
		});
	}
	return bodyParams;
}

export default HubspotPayload;
