/* eslint-disable import/no-unused-modules */
/* eslint-disable no-else-return */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React from 'react';
import moment from 'moment';
import { Typography } from '@mui/material';

export const tooltipTimeFormatter = sec => {
	return `${Math.floor(sec / 60 / 60 / 24)}d ${Math.floor(sec / 60 / 60) % 24}h ${
		Math.floor(sec / 60) % 60
	}m ${`${Math.round(sec % 60)}`}s `;
};

export const timeFormatter = sec => {
	let time = '';
	const days = Math.floor(sec / (3600 * 24));
	const hours = Math.floor(sec / 3600);
	const minutes = `0${Math.floor(sec / 60) % 60}`.slice(-2);
	if (sec === 0) {
		time = '0s';
	} else if (sec > 0 && sec < 60) {
		time = '< 1min';
	} else if (sec >= 60 && sec < 3600) {
		time = `${Math.round(parseInt(minutes, 10))}m`;
	} else if (sec >= 3600 && sec < 86400) {
		time = `${Math.round(hours)}h ${Math.round(parseInt(minutes, 10))}m`;
	} else if (sec >= 86400 && sec < 172800) {
		time = '> 1 day';
	} else if (sec >= 172800) {
		time = `${Math.round(days)} days`;
	}
	return time;
};

// eslint-disable-next-line import/no-unused-modules
export const activityTimeFormatter = sec => {
	let time = '';
	const days = Math.floor(sec / (3600 * 24));
	const hours = Math.floor(sec / 3600);
	const minutes = `0${Math.floor(sec / 60) % 60}`.slice(-2);
	if (sec > 0 && sec < 60) {
		time = '< 1m';
	} else if (sec > 60 && sec < 3600) {
		time = `${Math.round(parseInt(minutes, 10))}m`;
	} else if (sec > 3600 && sec < 86400) {
		time = `${Math.round(hours)}h`;
	} else if (sec > 86400 && sec < 172800) {
		time = '> 1d';
	} else if (sec > 172800) {
		time = `${Math.round(days)}d`;
	}
	return time;
};

export const activityTimer = date => {
	const updatedDate = new Date(date);
	const currentDate = new Date();
	const dif = Math.abs(currentDate - updatedDate) / 1000;
	return timeFormatter(dif);
};

export const dateFormatter = (date, customFormat) => {
	return moment(new Date(date)).format(customFormat || 'DD MMM, HH:mm:ss');
};

// compare two arrays and return uncommon value
export const arrayCompare = (arr1, arr2) => {
	return arr1.filter(o1 => arr2.map(o2 => o2.id).indexOf(o1.id) === -1);
};

// compare two arrays and return common value
export const arrayCommonCompare = (array1, array2) => {
	return array1.some(element => {
		return array2.includes(element);
	});
};

// eslint-disable-next-line import/no-unused-modules, consistent-return
export const getButtonTextForDeleteArchive = (
	type,
	title,
	itemIsInMultiSelect,
	currentItem,
	allSelected
) => {
	if (itemIsInMultiSelect?.length > 1 || allSelected) {
		return title;
	} else {
		if (type === 'dispatch') {
			if (currentItem?.status === 'RUNNING') {
				return `Stop dispatch and ${title}`;
			}
			return title;
		} else {
			if (currentItem?.status === 'RUNNING') {
				if (currentItem?.count !== 0) {
					return `Stop all ${currentItem?.count} dispatches and ${title}`;
				}
				return `${title} ${type}`;
			} else {
				return `${title} ${currentItem?.title} and all ${currentItem?.count} of its ${
					type === 'experiment' ? 'dispatches' : 'items'
				}`;
			}
		}
	}
};

// eslint-disable-next-line import/no-unused-modules
export const experimentStatus = status => {
	function captialise(stat) {
		if (stat?.toUpperCase() === 'NEW_OBJECT') return 'New';
		else {
			const str = stat;
			if (str) return str.charAt(0) + str.slice(1).toLowerCase();
		}
		return '';
	}

	return (
		<Typography pl={1} variant="status" sx={{ color: theme => theme.palette.text.secondary }}>
			{captialise(status)}
		</Typography>
	);
};

export const startAndEndDate = (value, setDates, dates) => {
	switch (value) {
		case 'All time':
			setDates({ startDate: '', endDate: '' });
			break;
		case 'Last month':
			{
				// Get the current date
				// Get the current date
				const currentDate = new Date();

				// Calculate the start date of last month
				const lastMonthStartDate = new Date(
					currentDate.getFullYear(),
					currentDate.getMonth() - 1,
					1
				);

				// Calculate the end date of last month
				const lastMonthEndDate = new Date(
					currentDate.getFullYear(),
					currentDate.getMonth(),
					0,
					23,
					59,
					59
				);

				// Convert the dates to ISO strings and send them to the backend
				const dataToSend = {
					lastMonthStartDate: lastMonthStartDate.toISOString(),
					lastMonthEndDate: lastMonthEndDate.toISOString()
				};

				setDates({
					...dates,
					startDate: dataToSend.lastMonthStartDate,
					endDate: dataToSend.lastMonthEndDate
				});
			}
			break;
		case 'This month':
			{
				// Get the current date and time in UTC
				const now = new Date();

				// Get the start of the current month
				const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

				// Get the end of the current month
				const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);

				setDates({
					...dates,
					startDate: startOfMonth.toISOString(),
					endDate: endOfMonth.toISOString()
				});
			}
			break;
		case 'This week':
			{
				// Get current date and time
				// Get the current date and time
				const now = new Date();

				// Get the current day of the week (0-6, where 0 is Sunday and 6 is Saturday)
				const currentDay = now.getDay();

				// Calculate the start date and time of the current week
				const startDate = new Date(now);
				startDate.setDate(now.getDate() - currentDay); // Go back to Sunday
				startDate.setHours(0, 0, 0, 0); // Set the time to 00:00:00.000

				// Calculate the end date and time of the current week
				const endDate = new Date(startDate);
				endDate.setDate(startDate.getDate() + 6); // Go forward to Saturday
				endDate.setHours(23, 59, 0, 0); // Set the time to 23:59:00.000

				// Format dates for backend (assuming ISO 8601 format)
				const startOfWeekStr = startDate.toISOString();
				const endOfWeekStr = endDate.toISOString();
				setDates({
					...dates,
					startDate: startOfWeekStr,
					endDate: endOfWeekStr
				});
			}
			break;

		case 'Today':
			{
				// Get current local time
				const now = new Date();

				// Set the start date to the beginning of the day (00:00:00)
				const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());

				// Set the end date to the end of the day (23:59:59)
				const end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);

				// Convert start and end dates to ISO strings
				const startISO = start.toISOString();
				const endISO = end.toISOString();
				setDates({
					...dates,
					startDate: startISO,
					endDate: endISO
				});
			}
			break;
		default:
	}
};

export const stringReducer = (string, count) => {
	const maxLength = count || 14;

	let truncatedText = string?.slice(0, maxLength);

	if (truncatedText?.length < string?.length) {
		truncatedText += '...';
	}

	return truncatedText; // Output: "This is a long text..."
};

export const Capitalize = string => {
	const firstLetter = string?.slice(0, 1);
	// eslint-disable-next-line no-unsafe-optional-chaining
	return firstLetter + string?.slice(1).toLowerCase();
};

export const getTimeDifference = time => {
	const endTime = new Date();
	const startTime = new Date(`${time}Z`);
	return activityTimeFormatter((endTime - startTime) / 1000);
};

export const Prettify = (inputString, type) => {
	let stringWithoutUnderscores = inputString?.replace(/[_<>]/g, ' ');
	stringWithoutUnderscores = stringWithoutUnderscores?.replace(/:/g, ' ');
	if (type === 'sublattice') {
		stringWithoutUnderscores = stringWithoutUnderscores?.replace(/sublattice\s+/gi, 'Sublattice ');
	}
	stringWithoutUnderscores = stringWithoutUnderscores?.replace(/parameter/g, '');

	// Capitalize the strings
	stringWithoutUnderscores = stringWithoutUnderscores
		?.toLowerCase()
		.replace(/\b\w/g, l => l.toUpperCase());

	// Add a gap before the return statement
	if (stringWithoutUnderscores === inputString) {
		return inputString;
	}

	return stringWithoutUnderscores;
};

export const capitalizeName = name => {
	// Split the name into words
	const words = name?.split(' ');

	// Loop through each word
	for (let i = 0; i < words?.length; i++) {
		// Capitalize the first letter of each word.
		words[i] = words[i].charAt(0).toUpperCase() + words[i].slice(1);
	}

	// Join the words back together and return the capitalized name
	return words?.join(' ');
};
export const truncateMiddle = (s, start, end, omission = '…') => {
	if (!s) {
		return '';
	}
	const len = s.length;
	if ((start === 0 && end === 0) || start + end >= len) {
		return s;
	}
	if (!end) {
		return s.slice(0, start) + omission;
	}
	return s.slice(0, start) + omission + s.slice(-end);
};

export const getLocalStartTime = time => {
	const startTimeToLocal = new Date((time = `${time}Z`));
	return startTimeToLocal?.toISOString();
};

export const getQElectronCount = graph => {
	if (graph?.nodes) {
		const electrons = graph?.nodes?.filter(e => e?.contains_qelectrons);
		if (electrons?.length || electrons?.length === 0) return electrons?.length;
		return '-';
	}
	return '-';
};

export function getRandomInt(min, max) {
	min = Math.ceil(min);
	max = Math.floor(max);
	return Math.floor(Math.random() * (max - min) + min); // The maximum is exclusive and the minimum is inclusive
}

export function getCurrentWeek() {
	const currentDate = moment();

	const weekStart = currentDate.clone().startOf('isoWeek');

	const days = [];

	for (let i = 0; i <= 6; i++) {
		days.push(moment(weekStart).add(i, 'days').format('DD/MM/YYYY'));
	}
	return { first: days[0], last: days[6] };
}
