/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';

import { Grid } from '@mui/material';
import GraphTab from '../tab/graph';
import Icon from '../icon';
import Close from '../../assets/actions/close.svg';
import SyntaxHighlighter from '../syntaxHiglighter';

const style = {
	position: 'absolute',
	top: '50%',
	left: '50%',
	transform: 'translate(-50%, -50%)',
	width: '60%',
	height: '60vh',
	bgcolor: 'background.covalentPurple',
	boxShadow: 24,
	borderRadius: '8px',
	px: 5,
	py: 3
};

function CodePane({ open, setOpen, json, jsonInput, tabValue, setTabValue }) {
	// here we can use the codepane for single tab by only passing the value in json and omitting jsonInput

	const handleClose = () => {
		setOpen(false);
	};

	const onTabChange = (_e, val) => {
		setTabValue(val);
	};

	return (
		<div>
			<Modal
				open={open}
				onClose={handleClose}
				aria-labelledby="modal-modal-title"
				aria-describedby="modal-modal-description"
			>
				<Box sx={style}>
					<Grid
						container
						direction="row"
						justifyContent="space-between"
						alignItems="center"
						sx={{ height: '40px', borderBottom: '1px solid', borderBottomColor: '#464660' }}
					>
						<Box>
							<GraphTab
								value={tabValue}
								onChange={onTabChange}
								firstValue="Input"
								secondValue={json === 'None' ? '' : 'Results'}
								type="codepanel"
							/>
						</Box>
						<Icon src={Close} title="Close" clickHandler={handleClose} />
					</Grid>
					<Grid mt={2} style={{ height: '90%', overflow: 'auto', cursor: 'text' }}>
						<SyntaxHighlighter src={tabValue === 'Input' ? jsonInput : json} />
					</Grid>
				</Box>
			</Modal>
		</div>
	);
}

export default CodePane;
