/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import Divider from '@mui/material/Divider';

function StyledDivider({ dividerMargin = '0' }) {
	return (
		<Divider
			sx={{ borderColor: '#303067', margin: dividerMargin, height: '24px' }}
			orientation="vertical"
			variant="middle"
			flexItem
		/>
	);
}
function GraphTab(props) {
	const {
		value,
		onChange,
		firstValue,
		secondValue,
		thirdValue,
		fourthValue,
		pl,
		type = 'default'
	} = props;
	return (
		<TabContext value={value}>
			<TabList
				onChange={onChange}
				TabIndicatorProps={{
					style: {
						display: 'none'
					}
				}}
				sx={{
					'& .MuiTab-root.Mui-selected': {
						color: value === 'Error' && '#FF6464'
					},
					'& .MuiTab-root:hover': {
						color: '#AEB6FF'
					}
				}}
			>
				{firstValue && (
					<Tab
						label={firstValue}
						value={firstValue}
						ml={1}
						sx={{
							padding: 0,
							minWidth: '1rem !important',
							alignItems: 'self-start',
							pr: secondValue === 'Secrets' ? 1 : 0,
							color: firstValue === 'Error' ? '#FF6464' : type === 'codepanel' ? '#868698' : ''
						}}
					/>
				)}
				{secondValue && firstValue && <StyledDivider dividerMargin="10px 0 0 10px" />}
				{secondValue ? (
					<Tab
						label={secondValue}
						value={secondValue}
						sx={{
							padding: 0,
							minWidth: '1rem !important',
							px: firstValue ? 1.8 : 0,
							pl: thirdValue ? pl || 0 : 1.8,
							color: type === 'codepanel' ? '#868698' : ''
						}}
					/>
				) : null}
				{secondValue && thirdValue ? <StyledDivider dividerMargin="10px 0 0 10px" /> : null}
				{thirdValue ? (
					<Tab
						label={thirdValue}
						value={thirdValue}
						sx={{ padding: 0, px: 1.8, minWidth: '1rem !important' }}
					/>
				) : null}

				{thirdValue && fourthValue ? <StyledDivider dividerMargin="10px 0 0 10px" /> : null}
				{fourthValue ? (
					<Tab
						label={fourthValue}
						value={fourthValue}
						sx={{ padding: 0, px: 1.8, minWidth: '1rem !important' }}
					/>
				) : null}
			</TabList>
		</TabContext>
	);
}

export default GraphTab;
