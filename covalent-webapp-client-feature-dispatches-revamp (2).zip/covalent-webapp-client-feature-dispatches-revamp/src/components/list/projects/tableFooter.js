/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React from 'react';
import Grid from '@mui/material/Grid';
import Pagination from '@mui/material/Pagination';
import './style.css';
import { ProjectContext } from '../../../containers/projects/projectContext';

export default function TableFooter() {
	const projectContext = React.useContext(ProjectContext);
	const { handlePageChanges, page, totalRecords } = projectContext;

	return (
		<Grid container className="footer" data-testid="tableFooter">
			<Pagination
				sx={{
					'& .MuiPaginationItem-root': {
						'&:hover': {
							backgroundColor: theme => theme.palette.background.blue03
						}
					}
				}}
				color="primary"
				shape="rounded"
				variant="outlined"
				count={totalRecords && totalRecords > 10 ? Math.ceil(totalRecords / 10) : 1}
				page={page}
				onChange={handlePageChanges}
				showFirstButton
				showLastButton
				siblingCount={2}
				boundaryCount={2}
				data-testid="paginationItem"
			/>
		</Grid>
	);
}
