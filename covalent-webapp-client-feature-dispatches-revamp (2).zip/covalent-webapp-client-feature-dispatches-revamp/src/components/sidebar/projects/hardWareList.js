/* eslint-disable react/no-array-index-key */
import { Grid, Typography } from '@mui/material';
import React from 'react';
import { statusTitle } from '../../../utils/statusIcons';
import OverlappingIcons from '../../icon/overlappingIcons';

function HardwareList({ items }) {
	return (
		<Grid>
			<Typography
				pb={1}
				sx={{
					fontSize: theme => theme.typography.sidebar,
					color: theme => theme.typography.sidebarTitle.color
				}}
			>
				Hardware
			</Typography>
			{items.map((item, index) => {
				return (
					<Grid container pt={1} direction="row" alignItems="center" key={index}>
						<OverlappingIcons type="HARDWARE" status={item.status} />
						{statusTitle(item.status, item.title, 1)}
					</Grid>
				);
			})}
		</Grid>
	);
}

export default HardwareList;
