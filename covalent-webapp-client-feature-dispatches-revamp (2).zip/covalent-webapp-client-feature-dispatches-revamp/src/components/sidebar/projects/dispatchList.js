/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
	Table,
	TableRow,
	TableHead,
	TableCell,
	TableBody,
	Typography,
	TableContainer,
	TableSortLabel,
	Box,
	styled,
	tableCellClasses,
	tableRowClasses,
	tableBodyClasses,
	tableSortLabelClasses,
	linkClasses,
	Grid
} from '@mui/material';
import { useDebounce } from 'use-debounce';
import Icon from '../../icon';
import caretDownIcon from '../../../assets/arrows/caretDown.svg';
import MiniMoreLoader from '../../../assets/loaders/loader.svg';
import { statusIcon } from '../../../utils/statusIcons';
import ContextMenu from '../../menu/projects/contextMenu';
import SearchInput from '../../inputBase/projects/searchInput';
import { hierarchyList } from '../../../api/experiments/dispatchApi';
import EllipsisTooltip from '../../tooltip/ellipsisTooltip';
import OverlappingIcons from '../../icon/overlappingIcons';
import Loader from '../../loader';
import { ProjectContext } from '../../../containers/projects/projectContext';
import CustomInputBase from '../../inputBase/projects';

const headers = [
	{
		id: 'title',
		getter: 'title',
		label: 'Title',
		sortable: true
	},
	{
		id: 'status',
		getter: 'status',
		label: 'Status',
		sortable: true
	}
];

function ResultsTableToolbar({ query, onSearch, cancelSearch }) {
	return (
		<Grid mt={2} px={2}>
			<SearchInput
				value={query}
				onChange={e => onSearch(e)}
				sx={{
					'& ::placeholder': {
						opacity: 0.7,
						color: theme => theme.palette.text.secondary
					},
					backgroundColor: theme => theme.palette.background.paper,
					'&:hover': {
						backgroundColor: theme => theme.palette.background.paper
					},
					border: '1px solid #303067'
				}}
				cancelSearch={cancelSearch}
			/>
		</Grid>
	);
}

function ResultsTableHead({ order, orderBy, onSort }) {
	const sortDirection = val => {
		if (orderBy === val) {
			return order;
		}
		return 'asc';
	};

	return (
		<TableHead sx={{ position: 'sticky', zIndex: 19 }}>
			<TableRow>
				{headers.map(header => {
					return (
						<TableCell
							key={header.id}
							sx={theme => ({
								borderColor: `${theme.palette.background.covalentPurple}!important`
							})}
						>
							{header.sortable ? (
								<TableSortLabel
									active={orderBy === header.id}
									direction={sortDirection(header.id)}
									onClick={() => onSort(header.id)}
									sx={{
										'.Mui-active': {
											color: theme => theme.palette.text.secondary
										}
									}}
								>
									{header.label}
								</TableSortLabel>
							) : (
								header.label
							)}
						</TableCell>
					);
				})}
			</TableRow>
		</TableHead>
	);
}

const StyledTable = styled(Table)(({ theme }) => ({
	// stripe every odd body row except on select and hover
	// [`& .MuiTableBody-root .MuiTableRow-root:nth-of-type(odd):not(.Mui-selected):not(:hover)`]:
	//   {
	//     backgroundColor: theme.palette.background.paper,
	//   },

	// customize text
	[`& .${tableBodyClasses.root} .${tableCellClasses.root}, & .${tableCellClasses.head}`]: {
		fontSize: '0.75rem',
		borderColor: theme.palette.background.covalentPurple,
		paddingLeft: '2em'
	},

	// subdue header text
	[`& .${tableCellClasses.head}, & .${tableSortLabelClasses.active}`]: {
		color: theme.palette.text.tertiary,
		backgroundColor: theme.palette.background.covalentPurple
	},

	// copy btn on hover
	[`& .${tableBodyClasses.root} .${tableRowClasses.root}`]: {
		'& .copy-btn': { visibility: 'hidden' },
		'&:hover .copy-btn': { visibility: 'visible' }
	},

	// customize hover
	[`& .${tableBodyClasses.root} .${tableRowClasses.root}:hover`]: {
		backgroundColor: theme.palette.background.paper,

		[`& .${tableCellClasses.root}`]: {
			borderColor: theme.palette.background.default,
			paddingTop: 4,
			paddingBottom: 4
		},
		[`& .${linkClasses.root}`]: {
			color: theme.palette.text.secondary
		}
	},

	[`& .${tableBodyClasses.root} .${tableRowClasses.root}`]: {
		backgroundColor: theme.palette.background.covalentPurple,
		cursor: 'pointer',

		[`& .${tableCellClasses.root}`]: {
			borderColor: theme.palette.background.covalentPurple,
			paddingTop: 4,
			paddingBottom: 4
		}
		// [`& .${linkClasses.root}`]: {
		//   color: theme.palette.text.secondary,
		// },
	},

	// customize selected
	[`& .${tableBodyClasses.root} .${tableRowClasses.root}.Mui-selected`]: {
		backgroundColor: theme.palette.background.coveBlack02
	},
	[`& .${tableBodyClasses.root} .${tableRowClasses.root}.Mui-selected:hover`]: {
		backgroundColor: theme.palette.background.coveBlack01
	},

	// customize border
	[`& .${tableCellClasses.root}`]: {
		borderColor: theme.palette.background.default,
		paddingTop: 4,
		paddingBottom: 4
	},

	[`& .${tableCellClasses.root}:first-of-type`]: {
		borderTopLeftRadius: 8,
		borderBottomLeftRadius: 8
	},
	[`& .${tableCellClasses.root}:last-of-type`]: {
		borderTopRightRadius: 8,
		borderBottomRightRadius: 8
	}
}));

function DispatchList({ id, type, sortOrder, setSortOrder }) {
	const projectContext = React.useContext(ProjectContext);
	const { sidebarActions } = projectContext;
	const [searchKey, setSearchKey] = useState('');
	const [searchValue] = useDebounce(searchKey, 1000);
	const [dispatchList, setDispatchList] = useState([]);
	const [entireDispatchList, setEntireDispatchList] = useState([]);
	const [isFetching, setIsFetching] = useState(true);
	const [sortColumn, setSortColumn] = useState('status');
	const [count, setCount] = useState(10);
	const [listcount, setListcount] = useState(0);
	const [dispatchLoader, setDispatchLoader] = useState(false);
	const handleChangeSort = column => {
		setIsFetching(true);
		const isAsc = sortColumn === column && sortOrder === 'asc';
		setSortOrder(isAsc ? 'desc' : 'asc');
		setSortColumn(column);
	};

	const showMore = () => {
		setDispatchLoader(true);
		setCount(prevState => prevState + 5);
	};

	const dispatchListApi = () => {
		if (searchValue?.length === 0 || searchValue?.length >= 3) {
			if (count < 3) {
				setIsFetching(true);
			}
			hierarchyList(id, type, sortOrder, sortColumn, searchKey, count, false)
				.then(res => {
					setDispatchList(res.items);
					if (searchValue?.length === 0) {
						setEntireDispatchList(res?.items);
					}
					setListcount(res.count);
					setIsFetching(false);
				})
				.catch(() => {
					setDispatchList([]);
					if (searchValue?.length === 0) {
						setEntireDispatchList([]);
					}
					setIsFetching(false);
					console.debug(error);
				})
				.finally(() => {
					setDispatchLoader(false);
				});
		}
	};

	useEffect(() => {
		dispatchListApi();
	}, [sortColumn, sortOrder, searchValue, sidebarActions, count]);

	const onSearch = e => {
		setSearchKey(e.target.value);
		if (e.target.value.length >= 3 || e.target.value.length === 0) {
			setIsFetching(true);
		} else {
			setIsFetching(false);
		}
	};

	const cancelSearch = () => {
		setIsFetching(true);
		setSearchKey('');
	};

	return (
		<Grid sx={{ position: 'relative' }}>
			<ResultsTableToolbar query={searchKey} onSearch={onSearch} cancelSearch={cancelSearch} />
			<TableContainer sx={{ height: dispatchList.length ? '76vh' : '0vh' }}>
				<Loader isFetching={isFetching} width="100%" height="50vh" />
				<StyledTable stickyHeader>
					{dispatchList.length ? (
						<ResultsTableHead order={sortOrder} orderBy={sortColumn} onSort={handleChangeSort} />
					) : null}
					<TableBody>
						{dispatchList &&
							dispatchList.map((result, index) => (
								<TableRow
									data-tip
									data-for="logRow"
									hover
									// eslint-disable-next-line react/no-array-index-key
									key={index}
								>
									<TableCell
										sx={{
											width: 180,
											paddingLeft: '2em'
										}}
									>
										<Grid
											sx={{
												fontSize: '14px',
												display: 'flex',
												alignItems: 'center',
												width: '220px'
											}}
										>
											<OverlappingIcons type="DISPATCH" status={result.status} />
											<Grid pl={1}>
												<Typography variant="h2" sx={{ display: 'flex' }}>
													{result.isAdd ? (
														<CustomInputBase
															type="dispatch"
															listItem={result}
															location="expSidebar"
														/>
													) : (
														<Link
															style={{ color: '#CBCBD7', textDecoration: 'none' }}
															to={`/graph/${result?.id}`}
															state={{
																userId: result?.ownerId
															}}
														>
															<EllipsisTooltip
																type="dispatch"
																value={result.title}
																width="200px"
																attribute="electron"
															/>
														</Link>
													)}
												</Typography>
											</Grid>
										</Grid>
									</TableCell>
									<TableCell
										style={{
											width: '40%'
										}}
									>
										<Grid
											pl={1}
											sx={{
												display: 'flex',
												alignItems: 'center',
												fontSize: '14px',
												width: '90%',
												justifyContent: 'space-between'
											}}
										>
											{statusIcon(result.status, '1px 3px 3.5px 3px')}
											{result.completedElectrons} / &nbsp;
											{result.totalElectrons}
											<Box>
												<ContextMenu
													type="dispatch"
													dispatch={result}
													location="expSidebar"
													dispatchList={dispatchList}
													setIsFetching={setIsFetching}
													setDispatchList={setDispatchList}
													entireDispatchList={entireDispatchList}
												/>{' '}
											</Box>
										</Grid>
									</TableCell>
								</TableRow>
							))}
					</TableBody>
				</StyledTable>
				{dispatchList.length < listcount && (
					<Grid container pl={3} pt={1} onClick={showMore} direction="row">
						{dispatchLoader ? (
							<Icon src={MiniMoreLoader} type="static" alt="moveLoader" />
						) : (
							<Icon src={caretDownIcon} type="pointer" alt="caretDown" />
						)}
						{/* <Typography variant="subtitle2" color="textPrimary">
						Show more
					</Typography> */}
						<Typography variant="subtitle2" color="textPrimary">
							Show more dispatches
						</Typography>
					</Grid>
				)}
			</TableContainer>

			{!isFetching && !dispatchList.length && (
				<Typography
					sx={{
						textAlign: 'center',
						color: 'text.secondary',
						// fontSize: 'h6.fontSize',
						paddingTop: 4,
						paddingBottom: 2
					}}
				>
					No records found.
				</Typography>
			)}
		</Grid>
	);
}

export default DispatchList;
