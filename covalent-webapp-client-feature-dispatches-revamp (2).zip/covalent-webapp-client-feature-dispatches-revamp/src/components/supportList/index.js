/* eslint-disable react/no-array-index-key */
import React from 'react';
import SupportCard from '../card/dashboard/supportcard';

function SupportList({ list }) {
	return (
		<>
			{list.map((data, index) => (
				<SupportCard title={data.title} link={data.link} key={index} />
			))}
		</>
	);
}

export default SupportList;
