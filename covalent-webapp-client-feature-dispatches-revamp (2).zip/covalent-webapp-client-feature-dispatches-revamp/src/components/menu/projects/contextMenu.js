/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import Grid from '@mui/material/Grid';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Typography from '@mui/material/Typography';
import Icon from '../../icon';
import moreVerticalIcon from '../../../assets/menus/menuVerticalIcon.svg';
import moreVerticalIconDisabled from '../../../assets/menus/menuVerticalIconDisabled.svg';
import archiveIcon from '../../../assets/actions/archive.svg';
import deleteIcon from '../../../assets/actions/delete.svg';
import editIcon from '../../../assets/actions/edit.svg';
import pinIcon from '../../../assets/actions/pin.svg';
import moveIcon from '../../../assets/arrows/arrowRight.svg';
import MoveItemsMenu from './moveItemsMenu';
import DialogBox from '../../dialogBox/index';
import './style.css';
import { ProjectContext } from '../../../containers/projects/projectContext';

function ContextMenu(props) {
	const {
		type,
		dispatch,
		experiment,
		project,
		view,
		location,
		rowType,
		setExperimentData,
		disabled,
		margin,
		dispatchList,
		setDispatchList,
		setIsFetching,
		highlightedDispatches,
		setHighlightedDispatches,
		entireDispatchList
	} = props;
	const [anchorEl, setAnchorEl] = React.useState(null);
	const projectContext = React.useContext(ProjectContext);
	const {
		multipleSelectedItems,
		onPin,
		editListItem,
		onDeleteOrArchive,
		allSelected,
		setIsEdit,
		showArchived,
		setOpenProjectSnackbar,
		setSnackbarMessage
	} = projectContext;
	const [anchorElMove, setAnchorElMove] = React.useState(null);
	const [moveMenuOpen, setMoveMenu] = React.useState(false);
	const [openDialogBox, setOpenDialogBox] = React.useState(false);
	const open = Boolean(anchorEl);
	const [actionClicked, setActionClicked] = React.useState('');
	const [valueForTab, setValueForTab] = React.useState('');
	const [tabstoHide, setTabstoHide] = React.useState('');

	const checkProjectInMultiSelect = () => {
		const itemIsInMultiSelect = multipleSelectedItems.filter(el => el.type === 'Project');
		return itemIsInMultiSelect.length > 0;
	};
	const checkExperimentInMultiSelect = () => {
		const itemIsInMultiSelect = multipleSelectedItems.filter(el => el.type === 'Experiment');
		return itemIsInMultiSelect.length > 0;
	};

	const getCurrentItem = () => {
		if (type === 'dispatch') {
			return dispatch;
		} else if (type === 'experiment') {
			return experiment;
		}
		return project;
	};

	const handleClick = event => {
		setAnchorEl(event.currentTarget);
		setAnchorElMove(event.currentTarget);
	};
	const handleClose = () => {
		setAnchorEl(null);
	};

	const handleEdit = () => {
		if (location === 'expSidebar') {
			if (type === 'dispatch') {
				const index = dispatchList.findIndex(obj => obj.id === dispatch.id);
				const addIndex = dispatchList.findIndex(obj => obj?.isAdd === true);
				if (addIndex === -1) {
					dispatchList[index].isAdd = true;
					setDispatchList([...dispatchList]);
				} else {
					setOpenProjectSnackbar(true);
					setSnackbarMessage('Please add/edit one item at a time');
				}
			} else {
				const data = experiment;
				experiment.isEdit = true;
				setExperimentData({ ...data });
				setIsEdit(true);
			}
		} else if (view === 'grid') {
			const index = highlightedDispatches.findIndex(obj => obj.id === dispatch.id);
			const addIndex = highlightedDispatches.findIndex(obj => obj?.isAdd === true);
			if (addIndex === -1) {
				highlightedDispatches[index].isAdd = true;
				setHighlightedDispatches([...highlightedDispatches]);
			} else {
				setOpenProjectSnackbar(true);
				setSnackbarMessage('Please add/edit one item at a time');
			}
		} else editListItem(experiment || project || dispatch, location);
		handleClose();
	};

	const handleMove = () => {
		handleClose();
		if (type === 'multiselect') {
			setValueForTab(checkExperimentInMultiSelect() ? 'projects' : 'experiments');
			setTabstoHide(checkExperimentInMultiSelect() ? 'experiment' : '');
		} else {
			setValueForTab(type === 'experiment' ? 'projects' : 'experiments');
			setTabstoHide(type);
		}
		setMoveMenu(!moveMenuOpen);
	};

	const handlePin = () => {
		onPin(dispatch);
		handleClose();
	};

	const handleDeleteAndArchive = () => {
		setOpenDialogBox(false);
		handleClose();
		const currentItem = getCurrentItem();
		if (location === 'expSidebar') {
			setIsFetching(prevState => !prevState);
			if (currentItem.type !== 'Experiment') {
				setDispatchList([]);
			}
		}
		onDeleteOrArchive(type, currentItem, view, actionClicked, location, entireDispatchList);
	};

	const dialogBoxHandler = action => {
		setActionClicked(action);
		handleClose();
		setOpenDialogBox(true);
	};

	const handleCloseForDelete = () => {
		setOpenDialogBox(false);
		handleClose();
	};

	const getContextMenuIcon = () => {
		if (disabled === true) {
			return moreVerticalIconDisabled;
		}
		if (view !== 'grid' && location !== 'expSidebar') {
			const currentItem = getCurrentItem();
			if (
				type !== 'multiselect' &&
				(showArchived || multipleSelectedItems.length > 1 || currentItem?.isAdd)
			) {
				return moreVerticalIconDisabled;
			} else if (type === 'multiselect') {
				if (multipleSelectedItems.length > 1) {
					return moreVerticalIcon;
				}
				return moreVerticalIconDisabled;
			}
		}
		return moreVerticalIcon;
	};

	const getDisabledStatus = () => {
		if (disabled === true) {
			return true;
		}
		if (view !== 'grid' && location !== 'expSidebar') {
			if (type !== 'multiselect') {
				const currentItem = getCurrentItem();
				return showArchived || multipleSelectedItems.length > 1 || currentItem?.isAdd;
			} else if (type === 'multiselect') {
				return multipleSelectedItems.length <= 1;
			}
		}
		return false;
	};

	const dispatchPinned = () => {
		if (dispatch?.isPinned) {
			return 'Unpin';
		}
		return 'Pin';
	};

	return (
		<Grid mr={margin} className={location === 'card' ? '' : 'contextMenu'}>
			<Icon
				src={getContextMenuIcon()}
				type="pointer"
				clickHandler={handleClick}
				data-testid="contextButton"
				alt="moreVerticalIcon"
				disabled={getDisabledStatus()}
				rowType={rowType}
				view={view}
				margin="3px 0px 0px 0px"
				display="flex"
			/>
			<Menu
				variant="menu"
				anchorEl={anchorEl}
				open={open}
				onClose={handleClose}
				keepMounted={false}
				anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
				transformOrigin={{ vertical: 'top', horizontal: 'left' }}
				PaperProps={{
					style: {
						maxHeight: '300px',
						width: '170px',
						transform: 'translateX(-5px) translateY(5px)'
					}
				}}
			>
				{type === 'dispatch' &&
					type !== 'multiselect' &&
					multipleSelectedItems?.length <= 1 &&
					view !== 'grid' && (
						<MenuItem onClick={handlePin} data-testid="pinAction">
							<Icon src={pinIcon} type="static" alt="pinIcon" />
							<Typography variant="subtitle2">{dispatchPinned()}</Typography>
						</MenuItem>
					)}
				{type === 'dispatch' && type !== 'multiselect' && view === 'grid' && (
					<MenuItem onClick={handlePin} data-testid="pinAction">
						<Icon src={pinIcon} type="static" alt="pinIcon" />
						<Typography variant="subtitle2">{dispatchPinned()}</Typography>
					</MenuItem>
				)}
				{type !== 'multiselect' && (
					<MenuItem
						onClick={handleEdit}
						disabled={experiment?.isAdd || project?.isAdd}
						data-testid="editAction"
					>
						<Icon src={editIcon} type="static" alt="editIcon" />
						<Typography variant="subtitle2">Edit</Typography>
					</MenuItem>
				)}
				{type !== 'project' &&
					!(view !== 'grid' && type === 'multiselect' && checkProjectInMultiSelect()) && (
						<MenuItem
							onClick={handleMove}
							disabled={experiment?.isAdd || project?.isAdd}
							data-testid="moveAction"
						>
							<Icon src={moveIcon} type="static" alt="moveIcon" />
							<Typography variant="subtitle2">Move to</Typography>
						</MenuItem>
					)}
				<MenuItem data-testid="archiveAction" onClick={() => dialogBoxHandler('archive')}>
					<Icon src={archiveIcon} type="static" alt="archiveIcon" />
					<Typography variant="subtitle2">Archive</Typography>
				</MenuItem>
				<MenuItem data-testid="deleteAction" onClick={() => dialogBoxHandler('delete')}>
					<Icon src={deleteIcon} type="static" alt="deleteIcon" />
					<Typography variant="subtitle2">Delete</Typography>
				</MenuItem>
			</Menu>
			{moveMenuOpen && (
				<MoveItemsMenu
					open={moveMenuOpen}
					anchorEl={anchorElMove}
					type={type}
					setMoveMenu={setMoveMenu}
					dispatch={dispatch}
					experiment={experiment}
					project={project}
					view={view}
					valueForTab={valueForTab}
					tabstoHide={tabstoHide}
					location={location}
					totalItems={
						multipleSelectedItems.length > 1 && view !== 'grid' ? multipleSelectedItems.length : 1
					}
				/>
			)}
			<DialogBox
				totalItems={multipleSelectedItems.length}
				openDialogBox={openDialogBox}
				setOpenDialogBox={setOpenDialogBox}
				icon={actionClicked === 'delete' ? deleteIcon : archiveIcon}
				type={type}
				title={actionClicked === 'delete' ? 'Delete' : 'Archive'}
				handler={handleDeleteAndArchive}
				handleCloseForDelete={handleCloseForDelete}
				paddingBottom="1px"
				multipleSelectedItems={multipleSelectedItems}
				currentItem={getCurrentItem()}
				width={type === 'experiment' ? 606 : 500}
				allSelected={allSelected}
				view={view}
				location={location}
			/>
		</Grid>
	);
}

export default ContextMenu;
