import React from 'react';
import { Box, Grid, Select, MenuItem, Button, Typography, SvgIcon } from '@mui/material';
import SearchInput from '../inputBase/projects/searchInput';
import ascending from '../../assets/marketplace/ascending.svg';

function CustomIcon(props) {
	return (
		// eslint-disable-next-line react/jsx-props-no-spreading
		<SvgIcon {...props} style={{ transform: 'translateY(20%)' }}>
			<svg
				width="16"
				height="16"
				viewBox="0 0 16 16"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					d="M8 10.9998L3 5.9998L3.7 5.2998L8 9.59981L12.3 5.2998L13 5.9998L8 10.9998Z"
					fill="#CBCBD7"
				/>
			</svg>
		</SvgIcon>
	);
}

function TableHeaderFilter(props) {
	const {
		searchKey,
		selected,
		sort,
		cancelSearch,
		selectionChangeHandler,
		handleSortClick,
		setSearchKey
	} = props;

	return (
		<Box>
			<Grid
				container
				direction="row"
				justifyContent="space-between"
				alignItems="center"
				width="100%"
				pt={5}
				pb={1}
			>
				<SearchInput
					sx={{
						border: '1px solid #303067',
						borderRadius: '20px',
						width: '260px',
						height: '32px',
						'&.Mui-focused ': {
							border: '1px solid #6473ff'
						},
						'& ::placeholder': {
							color: '#CBCBD7'
						}
						// mt:'10rem'
					}}
					value={searchKey || ''}
					onChange={e => setSearchKey(e.target.value)}
					cancelSearch={cancelSearch}
				/>
				<Box sx={{ display: 'flex' }}>
					<Box sx={{ paddingRight: '37px' }} display="flex" direction="row" spacing={3}>
						<Select
							IconComponent={CustomIcon}
							value={selected}
							onChange={selectionChangeHandler}
							sx={{
								marginRight: 4,
								fontSize: '14px',
								background: '#08081A',
								borderRadius: '200px',
								padding: '0rem 1rem',
								height: '32px',
								width: '139px',
								color: '#BEBEBE',
								'.MuiOutlinedInput-notchedOutline': {
									borderColor: '#6473FF'
								},
								'&.Mui-focused .MuiOutlinedInput-notchedOutline': {
									borderColor: '#6473FF'
								},
								'&:hover .MuiOutlinedInput-notchedOutline': {
									borderColor: '#6473FF'
								},
								'.MuiSvgIcon-root ': {
									fill: 'transparent !important'
								}
							}}
						>
							<MenuItem sx={{ fontSize: '14px' }} value="last_updated">
								15th May - 15 th June
							</MenuItem>
							<MenuItem sx={{ fontSize: '14px' }} value="popular">
								15th June - 15 th July
							</MenuItem>
						</Select>
						<Select
							IconComponent={CustomIcon}
							value={selected}
							onChange={selectionChangeHandler}
							sx={{
								fontSize: '14px',
								background: '#08081A',
								borderRadius: '200px',
								padding: '0rem 1rem',
								// width: selected.length > 8 ? '9.5rem' : selected.length < 6 ? '6rem' : '8rem',
								height: '32px',
								width: '139px',
								color: '#BEBEBE',
								'.MuiOutlinedInput-notchedOutline': {
									borderColor: '#6473FF'
								},
								'&.Mui-focused .MuiOutlinedInput-notchedOutline': {
									borderColor: '#6473FF'
								},
								'&:hover .MuiOutlinedInput-notchedOutline': {
									borderColor: '#6473FF'
								},
								'.MuiSvgIcon-root ': {
									fill: 'transparent !important'
								}
							}}
						>
							<MenuItem sx={{ fontSize: '14px' }} value="last_updated">
								Last Updated
							</MenuItem>
							<MenuItem sx={{ fontSize: '14px' }} value="popular">
								Popular
							</MenuItem>
						</Select>
						<Button
							variant="outlined"
							sx={{
								'&:hover': {
									backgroundColor: theme => theme.palette.background.covalentPurple,
									color: '#FFFFFF',
									borderRadius: '25px',
									borderColor: theme => theme.palette.background.blue05
								},
								display: 'flex',
								justifyContent: 'center',
								borderRadius: '25px',
								height: '32px',
								width: '121px',
								marginLeft: '2rem'
							}}
							endIcon={
								<img
									src={ascending}
									alt={sort}
									style={{ transform: sort === 'dsc' ? 'rotate(180deg)' : '' }}
								/>
							}
							// onClick={() => sort === 'asc' ? setSort('dsc') : setSort('asc')}
							onClick={handleSortClick}
						>
							<Typography variant="h2" pt={0}>
								{sort === 'asc' ? 'Ascending' : 'Descending'}
							</Typography>
						</Button>
					</Box>
				</Box>
			</Grid>
		</Box>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default TableHeaderFilter;
