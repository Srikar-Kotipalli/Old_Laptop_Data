/* eslint-disable react/jsx-boolean-value */
import React, { useState } from 'react';
import { withStyles } from '@mui/styles';
import { Grid, Slider, Typography, Box, Divider } from '@mui/material';
import CopyButton from '../../copyButton';
import Icon from '../../icon/index';
import ClassicalOn from '../../../assets/classicalOn.svg';
import infoIcon from '../../../assets/info.svg';
import './style.css';

function HardwareInfoCard() {
	const [memory, setMemory] = useState(5);
	const [cores, setCores] = useState(5);

	const executorCode = `import covalent_cloud as ctc
cloud_executor=ctc.CloudExecutor(num_cpus=${cores},memory=${memory})`;

	const colors = {
		pink: '#E3687E',
		yellow: '#EACD62',
		orange: '#DD8354',
		blue: '#64BAF4',
		grey: '#A1A7C4'
	};

	const marks = [
		{
			value: 0,
			label: '0'
		},

		{
			value: 2,
			label: '2'
		},

		{
			value: 4,
			label: '4'
		},
		{
			value: 6,
			label: '6'
		},
		{
			value: 8,
			label: '8'
		},
		{
			value: 10,
			label: '10'
		},

		{
			value: 12,
			label: '12'
		},

		{
			value: 14,
			label: '14'
		},

		{
			value: 16,
			label: '16'
		}
	];

	const memorySliderValues = [
		{
			value: 2,
			label: '2'
		},

		{
			value: 8,
			label: '8'
		},

		{
			value: 14,
			label: '14'
		},

		{
			value: 20,
			label: '20'
		},

		{
			value: 26,
			label: '26'
		},

		{
			value: 32,
			label: '32'
		}
	];

	function valuetextCore(_event, newValue) {
		setCores(newValue);
	}

	function valuetextMemory(_event, newValue) {
		setMemory(newValue);
	}

	const CustomSlider = withStyles({
		rail: {
			backgroundImage: 'linear-gradient(.25turn, #AEB6FF, #5552FF)'
		},
		track: {
			backgroundImage: 'linear-gradient(.25turn, #AEB6FF, #5552FF)'
		},
		thumb: {
			color: '#5552FF'
		},
		markLabel: {
			color: '#86869A'
		}
	})(Slider);
	return (
		<Grid container item xs={12} className="hardwareInfoCardContainer" pl={1}>
			<Grid item xs={6} pl={1}>
				<Box sx={{ paddingTop: '10px' }}>
					<Typography sx={{ fontSize: '16px' }}>Memory (GB)</Typography>
					<CustomSlider
						step={1}
						max={32}
						min={2}
						size="small"
						aria-label="memory"
						value={memory}
						valueLabelDisplay="off"
						marks={memorySliderValues}
						// eslint-disable-next-line react/jsx-no-bind
						onChange={valuetextMemory}
					/>
				</Box>
				<Box sx={{ paddingTop: '16px' }}>
					<Typography sx={{ fontSize: '16px' }}>CPUs (virtual cores)</Typography>
					<CustomSlider
						max={16}
						min={0}
						value={cores}
						size="small"
						aria-label="cores"
						step={1}
						valueLabelDisplay="off"
						marks={marks}
						// eslint-disable-next-line react/jsx-no-bind
						onChange={valuetextCore}
					/>
				</Box>
				{/* <Box sx={{ paddingTop: '16px' }}>
					<Typography sx={{ fontSize: '16px' }}>Storage</Typography>
					<CustomSlider
						max={16}
						min={1}
						size="small"
						aria-label="storage"
						defaultValue={5}
						step={null}
						valueLabelDisplay="off"
						marks={marks}
						width="565px"
					/>
				</Box> */}
			</Grid>
			<Grid item xs={6} pl={10} pr={1.5}>
				<Grid item sx={{ paddingTop: '10px' }}>
					<Typography>AQ Cluster</Typography>
				</Grid>
				<Grid item sx={{ paddingTop: '16px' }}>
					<Icon src={ClassicalOn} type="static" alt="HardwareIcon" />
				</Grid>
				<Grid item xs={12} container direction="row" sx={{ justifyContent: 'space-between' }}>
					<Grid item xs={9} md={8} lg={9} sx={{ paddingTop: '23px' }}>
						<Typography sx={{ color: '#55D899', fontSize: '14px' }}>Online</Typography>
					</Grid>
					<Grid
						item
						xs={2}
						md={4}
						lg={3}
						sx={{ paddingTop: '26px', display: 'flex', justifyContent: 'flex-end' }}
					>
						<Box display="flex" justifyContent="center">
							<Typography sx={{ fontSize: '24px', color: '#55D899', marginRight: '20px' }}>
								Free
							</Typography>
						</Box>
					</Grid>
				</Grid>
				<Grid
					container
					item
					xs={6}
					direction="row"
					justifyContent="space-between"
					sx={{ paddingTop: '16px' }}
				>
					<Grid item xs={5}>
						<Typography sx={{ fontSize: '14px' }}>Total devices = 19</Typography>
					</Grid>
					<Grid item>
						<Divider
							sx={{
								borderColor: '#CBCBD7',
								paddingLeft: '14px',
								height: '1px',
								paddingTop: '16px'
							}}
							orientation="vertical"
							flexItem
						/>
					</Grid>
					<Grid item xs={5} sx={{ paddingLeft: '25px' }}>
						<Typography sx={{ fontSize: '14px' }}>Available = 10</Typography>
					</Grid>
					<Grid item xs={5} sx={{ display: 'flex', justifyContent: 'flex-end' }} />
					<Grid item sx={{ paddingLeft: '14px' }}>
						{/* <Typography sx={{ fontSize: '14px' }}>Storage: {4}</Typography> */}
					</Grid>
				</Grid>
				<Grid
					item
					container
					xs={12}
					direction="row"
					sx={{ alignItems: 'flex-start', marginTop: '23px' }}
				>
					<Typography sx={{ fontSize: '15px' }}>Executor code</Typography>
					<img src={infoIcon} alt="infoIcon" style={{ marginTop: '4px', marginLeft: '2px' }} />
				</Grid>

				<Grid
					container
					mt={1}
					px={1}
					pb={2}
					sx={{
						background: theme => theme.palette.background.covalentPurple,
						borderRadius: '8px'
					}}
				>
					<Grid item xs={11}>
						<Grid item xs={12} mt={2} sx={{ display: 'flex' }}>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.yellow }}>
								import&nbsp;
							</Typography>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.grey }}>
								covalent_cloud&nbsp;{' '}
							</Typography>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.yellow }}>
								as&nbsp;{' '}
							</Typography>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.blue }}>
								ctc&nbsp;
							</Typography>
						</Grid>
						<Grid item xs={12} sx={{ display: 'flex' }}>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.pink }}>
								cloud_executor&nbsp;
							</Typography>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.yellow }}>
								=&nbsp;{' '}
							</Typography>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.blue }}>
								ctc.CloudExecutor&nbsp;{' '}
							</Typography>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.yellow }}>
								(&nbsp;
							</Typography>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.pink }}>
								num_cpus&nbsp;
							</Typography>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.yellow }}>
								=&nbsp;
							</Typography>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.orange }}>
								{cores}&nbsp;
							</Typography>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.grey }}>
								,&nbsp;
							</Typography>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.pink }}>
								memory&nbsp;
							</Typography>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.yellow }}>
								=&nbsp;
							</Typography>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.orange }}>
								{memory}&nbsp;
							</Typography>
							<Typography variant="h3" sx={{ display: 'inline', color: colors.yellow }}>
								)&nbsp;
							</Typography>
						</Grid>
					</Grid>
					<Grid
						container
						item
						xs={1}
						mt={2}
						direction="row"
						justifyContent="flex-end"
						alignItems="center"
					>
						<CopyButton borderEnable={true} content={executorCode} />
					</Grid>
				</Grid>
			</Grid>
		</Grid>
	);
}

export default HardwareInfoCard;
