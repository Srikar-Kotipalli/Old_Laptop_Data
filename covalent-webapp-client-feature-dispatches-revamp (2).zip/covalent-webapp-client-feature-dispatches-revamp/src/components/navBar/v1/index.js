/* eslint-disable import/no-unused-modules */
// /* eslint-disable no-unsafe-optional-chaining */
// /* eslint-disable react/jsx-boolean-value */
// /*
//  * Copyright 2022 Agnostiq Inc.
//  * Note: This file is subject to a proprietary license agreement entered into between
//  * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
//  * access and use this file is subject to the terms and conditions of such agreement.
//  * Please ensure you carefully review such agreements and, if you have any questions
//  * please reach out to Agnostiq at: [support@agnostiq.com].
//  */
// import React, { useState, useEffect, useRef } from 'react';
// import { useNavigate, useLocation } from 'react-router-dom';
// import { useDispatch } from 'react-redux';
// import Paper from '@mui/material/Paper';
// import Tooltip from '@mui/material/Tooltip';
// import Menu from '@mui/material/Menu';
// import MenuItem from '@mui/material/MenuItem';
// import Collapse from '@mui/material/Collapse';
// import { Grid, Avatar, Typography, Box, Fade } from '@mui/material';
// import { Auth } from 'aws-amplify';
// import './style.css';
// import covalentLogo from '../../assets/logos/covalentLogo.svg';
// import MarketPlaceIcon from '../../assets/logos/marketplace.svg';
// import HomeIcon from '../../assets/logos/home.svg';
// import BranchIcon from '../../assets/logos/branch.svg';
// import HardwareAdminIcon from '../../assets/logos/hardwareAdmin.svg';
// import SolverAdminIcon from '../../assets/logos/solverAdmin.svg';
// import settings from '../../assets/helperMenu/settings.svg';
// import documentation from '../../assets/helperMenu/documentation.svg';
// import signOut from '../../assets/helperMenu/exit.svg';
// import contactus from '../../assets/helperMenu/contactus.svg';
// import Icon from '../icon';
// import { setUser } from '../../redux/commonSlice';

// function StepperMenu({ path, tail, value }) {
// 	const navigate = useNavigate();
// 	const location = useLocation();
// 	return (
// 		<Box
// 			pl={location.pathname !== path ? 0.3 : 0}
// 			sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', cursor: 'pointer' }}
// 			onClick={() => {
// 				navigate(path);
// 			}}
// 		>
// 			<Tooltip title={value} placement="right">
// 				<Box
// 					id="circle"
// 					sx={{
// 						'&:hover': {
// 							boxShadow: '0px 0px 8px 2px #5552FF'
// 						},
// 						cursor: 'pointer',
// 						width: location.pathname === path ? '10px' : '6px',
// 						height: location.pathname === path ? '10px' : '6px',
// 						borderRadius: '50%',
// 						background:
// 							location.pathname === path
// 								? theme => theme.palette.background.blue06
// 								: theme => theme.palette.text.primary
// 					}}
// 				/>
// 			</Tooltip>

// 			{tail ? (
// 				<Box
// 					// ml={0.4}
// 					id="line"
// 					sx={{
// 						width: '1px',
// 						height: '29px',
// 						background: theme => theme.palette.text.primary,
// 						cursor: 'pointer'
// 					}}
// 				/>
// 			) : null}
// 		</Box>
// 	);
// }

// function CustomMenu({ title, path, setIsMenuOpen }) {
// 	const navigate = useNavigate();
// 	const location = useLocation();

// 	return (
// 		<Grid
// 			mt={1}
// 			sx={{
// 				display: 'flex',
// 				alignItems: 'center',
// 				cursor: 'pointer'
// 			}}
// 		>
// 			<Typography
// 				variant="h3"
// 				sx={{
// 					px: 1,
// 					py: 0.3,
// 					cursor: 'pointer',
// 					borderRadius: 6,
// 					background: location.pathname === path ? theme => theme.palette.background.blue11 : null,
// 					'&:hover': {
// 						px: 1,
// 						py: 0.3,
// 						background: theme => theme.palette.background.blue11,
// 						borderRadius: 4
// 					}
// 				}}
// 				onClick={() => {
// 					setIsMenuOpen(false);
// 					navigate(path);
// 				}}
// 			>
// 				{title}
// 			</Typography>
// 		</Grid>
// 	);
// }

// function NavBar() {
// 	const loc = useLocation();
// 	const styledRoute = window.localStorage.getItem('path');
// 	const [picture, setPicture] = useState(null);
// 	const dispatch = useDispatch();
// 	const [selected, setSelected] = useState(styledRoute);
// 	const [anchorEl, setAnchorEl] = useState(null);
// 	const [avatar, setAvatar] = useState('');
// 	const [isMenuOpen, setIsMenuOpen] = useState(false);
// 	const [avatarNameTooltip, setAvatarNameTooltip] = useState('');

// 	const open = Boolean(anchorEl);
// 	const navigate = useNavigate();
// 	const collapseRef = useRef(null);

// 	useEffect(() => {
// 		const handleOutsideClick = event => {
// 			if (collapseRef.current && !collapseRef.current.contains(event.target)) {
// 				setIsMenuOpen(false);
// 			}
// 		};

// 		window.addEventListener('click', handleOutsideClick);

// 		return () => {
// 			window.removeEventListener('click', handleOutsideClick);
// 		};
// 	}, []);

// 	const onClickHandler = (value, path) => {
// 		setIsMenuOpen(false);
// 		setSelected(value);
// 		navigate(path);
// 		if (path === '/settings') setAnchorEl(null);
// 	};

// 	useEffect(() => {
// 		window.localStorage.setItem('path', loc.pathname.slice(1));
// 		if (loc?.pathname?.slice(1)?.includes('graph')) {
// 			window.localStorage.setItem('path', 'graph');
// 			setSelected('');
// 		} else {
// 			setSelected(window.localStorage.getItem('path'));
// 		}
// 	}, [loc]);

// 	useEffect(() => {
// 		Auth.currentAuthenticatedUser().then(user => {
// 			dispatch(setUser({ user }));
// 			const res =
// 				user?.attributes?.given_name || user?.attributes?.family_name || user?.attributes?.email;
// 			setAvatarNameTooltip(res?.charAt(0)?.toUpperCase() + res?.slice(1));
// 			const initial = res?.charAt(0)?.toUpperCase();
// 			setAvatar(initial);
// 			const pictureAttribute = user?.attributes?.picture;
// 			setPicture(pictureAttribute);
// 		});
// 	}, []);

// 	const handleClose = () => {
// 		setAnchorEl(null);
// 	};

// 	const handleClick = event => {
// 		setAnchorEl(event.currentTarget);
// 	};

// 	function handleSignout() {
// 		Auth.signOut()
// 			.then(() => {
// 				localStorage.setItem('AUTH_ACCESS_TOKEN', null);
// 				localStorage.setItem('AUTH_ID_TOKEN', null);
// 				window.localStorage.setItem('path', null);
// 				navigate('/login');
// 			})
// 			.catch(() => {
// 				console.log('Error signing out');
// 			});
// 	}

// 	const redirectPage = link => {
// 		window.open(`${link}`, '_blank');
// 		handleClose();
// 	};

// 	return (
// 		<Paper square className="navbar" data-testid="navbar" sx={{ zIndex: 111 }}>
// 			<Grid
// 				sx={{
// 					background: theme => theme.palette.background.blue10,
// 					width: '80%',
// 					height: '96%',
// 					borderRadius: '8px'
// 				}}
// 			>
// 				<Tooltip title="Home" placement="right">
// 					<Box pt={3} sx={{ display: 'flex', width: '100%', justifyContent: 'center' }}>
// 						<Icon
// 							src={covalentLogo}
// 							alt="covalentLogo"
// 							type="pointer"
// 							clickHandler={() => onClickHandler('', '/')}
// 						/>
// 					</Box>
// 				</Tooltip>

// 				<Grid
// 					ml={isMenuOpen ? -0.3 : -0.3}
// 					sx={{ height: '80vh' }}
// 					container
// 					elevation={0}
// 					direction="column"
// 					justifyContent="space-between"
// 					alignItems="center"
// 					className="navIcons"
// 					data-testid="covalentLogo"
// 				>
// 					<Grid item xs={6} mt={0.5} ref={collapseRef} sx={{ width: '25px' }}>
// 						<Tooltip title="Home" placement="right">
// 							<Grid
// 								elevation={0}
// 								className={
// 									isMenuOpen ||
// 									(!isMenuOpen &&
// 										(loc.pathname === '/' ||
// 											loc.pathname === '/projects' ||
// 											loc.pathname === '/hardware' ||
// 											loc.pathname === '/environments' ||
// 											loc.pathname === '/solvers'))
// 										? 'iconSelected'
// 										: 'iconActive'
// 								}
// 								marginTop={4.5}
// 								pt={0.7}
// 								id="graph"
// 							>
// 								<Icon
// 									padding="1px 0px 0px 0px"
// 									className="iconProp"
// 									src={HomeIcon}
// 									status={selected === 'projects' ? 'active' : ''}
// 									alt="homeIcon"
// 									type="pointer"
// 									clickHandler={() => {
// 										// onClickHandler('projects', '/projects');
// 										setIsMenuOpen(prev => !prev);
// 									}}
// 								/>
// 							</Grid>
// 						</Tooltip>
// 						{isMenuOpen && (
// 							<Fade in={isMenuOpen} timeout={600}>
// 								<Box mb={isMenuOpen ? -1 : 0} sx={{ position: 'relative', marginBottom: 0 }}>
// 									<Grid sx={{ position: 'absolute', left: 20, top: 10 }}>
// 										<Icon src={BranchIcon} />
// 									</Grid>
// 									<Grid
// 										px={3}
// 										py={1.8}
// 										mt={0.4}
// 										sx={{
// 											overflow: 'auto',
// 											background: theme => theme.palette.background.covalentPurple,
// 											borderRadius: '8px',
// 											width: '7.813rem'
// 										}}
// 										ml={1.5}
// 									>
// 										<CustomMenu title="Dashboard" path="/" setIsMenuOpen={setIsMenuOpen} />
// 										<CustomMenu title="Projects" path="/projects" setIsMenuOpen={setIsMenuOpen} />
// 										<CustomMenu title="Hardware" path="/hardware" setIsMenuOpen={setIsMenuOpen} />
// 										<CustomMenu
// 											title="Environments"
// 											path="/environments"
// 											setIsMenuOpen={setIsMenuOpen}
// 										/>
// 										<CustomMenu title="Solvers" path="/solvers" setIsMenuOpen={setIsMenuOpen} />
// 									</Grid>
// 								</Box>
// 							</Fade>
// 						)}
// 						<Collapse
// 							in={
// 								!isMenuOpen &&
// 								(loc.pathname === '/' ||
// 									loc.pathname === '/projects' ||
// 									loc.pathname === '/hardware' ||
// 									loc.pathname === '/environments' ||
// 									loc.pathname === '/solvers')
// 							}
// 							timeout={0}
// 						>
// 							<Grid
// 								ml={1.5}
// 								mt={2}
// 								sx={{
// 									display: 'flex',
// 									flexDirection: 'column',
// 									alignItems: 'flex-start'
// 								}}
// 							>
// 								<StepperMenu tail={true} path="/" value="Dashboard" />
// 								<StepperMenu tail={true} path="/projects" value="Projects" />
// 								<StepperMenu tail={true} path="/hardware" value="Hardware" />
// 								<StepperMenu tail={true} path="/environments" value="Environments" />
// 								<StepperMenu path="/solvers" value="Solvers" />
// 							</Grid>
// 						</Collapse>

// 						<Tooltip title="Marketplace" placement="right">
// 							<Grid
// 								elevation={0}
// 								// className={selected !== 'marketplace' && selected !== 'marketplace/hardware' && selected !== 'marketplace/solvers' ? 'iconActive' : 'iconSelected'}
// 								className={!selected?.includes('marketplace') ? 'iconActive' : 'iconSelected'}
// 								marginTop={2}
// 								pt={0.6}
// 							>
// 								<Icon
// 									className="iconProp"
// 									src={MarketPlaceIcon}
// 									alt="marketplaceIcon"
// 									type="pointer"
// 									status={selected === 'marketplace' ? 'active' : ''}
// 									clickHandler={() => onClickHandler('marketplace', '/marketplace')}
// 								/>
// 							</Grid>
// 						</Tooltip>
// 						<Typography sx={{ fontSize: '10px', mt: 5 }}>ADMIN</Typography>
// 						<Tooltip title="Solver Admin" placement="right">
// 							<Grid
// 								elevation={0}
// 								className={selected !== 'solveradmin' ? 'iconActive' : 'iconSelected'}
// 								marginTop={2}
// 								pt={0.6}
// 							>
// 								<Icon
// 									className="iconProp"
// 									src={SolverAdminIcon}
// 									alt="solveradmin"
// 									type="pointer"
// 									status={selected === 'solveradmin' ? 'active' : ''}
// 									clickHandler={() => onClickHandler('solveradmin', '/solveradmin')}
// 								/>
// 							</Grid>
// 						</Tooltip>
// 						<Tooltip title="Hardware Admin" placement="right">
// 							<Grid
// 								elevation={0}
// 								className={selected !== 'hardwareadmin' ? 'iconActive' : 'iconSelected'}
// 								marginTop={2}
// 								pt={0.6}
// 							>
// 								<Icon
// 									className="iconProp"
// 									src={HardwareAdminIcon}
// 									alt="hardwareadmin"
// 									type="pointer"
// 									status={selected === 'hardwareadmin' ? 'active' : ''}
// 									clickHandler={() => onClickHandler('hardwareadmin', '/hardwareadmin')}
// 								/>
// 							</Grid>
// 						</Tooltip>
// 						<Grid
// 							elevation={0}
// 							marginBottom={4}
// 							marginTop={1}
// 							sx={{ position: 'absolute', bottom: 22 }}
// 						>
// 							<Tooltip title="Settings" placement="right">
// 								<Grid
// 									elevation={0}
// 									// className={selected !== 'marketplace' && selected !== 'marketplace/hardware' && selected !== 'marketplace/solvers' ? 'iconActive' : 'iconSelected'}
// 									className={!selected?.includes('settings') ? 'iconActive' : 'iconSelected'}
// 									marginTop={2}
// 									marginBottom={2}
// 									pt={0.8}
// 								>
// 									<Icon
// 										className="iconProp"
// 										src={settings}
// 										alt="marketplaceIcon"
// 										type="pointer"
// 										status={selected === 'settings' ? 'active' : ''}
// 										clickHandler={() => onClickHandler('settings', '/settings')}
// 									/>
// 								</Grid>
// 							</Tooltip>
// 							{picture ? (
// 								<Tooltip title={avatarNameTooltip}>
// 									<Grid sx={{ mr: 2, cursor: 'pointer' }} onClick={handleClick}>
// 										<img
// 											src={picture}
// 											alt="Avatar Placeholder"
// 											style={{
// 												width: '32px',
// 												height: '32px',
// 												borderRadius: '50%',
// 												cursor: 'pointer'
// 											}}
// 										/>
// 									</Grid>
// 								</Tooltip>
// 							) : (
// 								<Tooltip title={avatarNameTooltip}>
// 									<Avatar
// 										sx={{ bgcolor: '#AD7BFF', width: '32px', height: '32px', cursor: 'pointer' }}
// 										onClick={handleClick}
// 									>
// 										{avatar}
// 									</Avatar>
// 								</Tooltip>
// 							)}
// 						</Grid>
// 					</Grid>
// 				</Grid>
// 				<Menu
// 					variant="menu"
// 					anchorEl={anchorEl}
// 					open={open}
// 					onClose={handleClose}
// 					keepMounted={false}
// 					anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
// 					transformOrigin={{ vertical: 'top', horizontal: 'left' }}
// 					PaperProps={{
// 						style: {
// 							maxHeight: '300px',
// 							width: '160px',
// 							transform: 'translateX(48px) translateY(-5px)'
// 						}
// 					}}
// 				>
// 					<MenuItem
// 						data-testid="documentation"
// 						onClick={() => redirectPage('https://docs.covalent.xyz/')}
// 					>
// 						<Icon
// 							src={documentation}
// 							padding="1px 3px 3.5px 3px"
// 							type="static"
// 							alt="documentation"
// 						/>
// 						<Typography variant="subtitle2">Documentation</Typography>
// 					</MenuItem>
// 					<MenuItem
// 						data-testid="contactus"
// 						onClick={() => redirectPage('https://www.covalent.xyz/contact/')}
// 					>
// 						<Icon src={contactus} padding="1px 3px 3.5px 3px" type="static" alt="contactus" />
// 						<Typography variant="subtitle2">Contact us</Typography>
// 					</MenuItem>
// 					<MenuItem data-testid="contactus" onClick={() => handleSignout()}>
// 						<Icon src={signOut} padding="1px 3px 3.5px 3px" type="static" alt="contactus" />
// 						<Typography variant="subtitle2">Log out</Typography>
// 					</MenuItem>
// 				</Menu>
// 			</Grid>
// 		</Paper>
// 	);
// }

// export default NavBar;

/* eslint-disable no-unsafe-optional-chaining */
/* eslint-disable react/jsx-boolean-value */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import Paper from '@mui/material/Paper';
import Tooltip from '@mui/material/Tooltip';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
// import Collapse from '@mui/material/Collapse';
import { Grid, Avatar, Typography, Box, Badge } from '@mui/material';
import { Auth } from 'aws-amplify';
import './style.css';
import covalentLogo from '../../assets/logos/covalentLogo.svg';
// import MarketPlaceIcon from '../../assets/logos/marketplace.svg';
import HomeIcon from '../../assets/logos/home.svg';
// import BranchIcon from '../../assets/logos/branch.svg';
// import HardwareAdminIcon from '../../assets/logos/hardwareAdmin.svg';
// import SolverAdminIcon from '../../assets/logos/solverAdmin.svg';
import settings from '../../assets/helperMenu/settings.svg';
import documentation from '../../assets/helperMenu/documentation.svg';
import signOut from '../../assets/helperMenu/exit.svg';
import contactus from '../../assets/helperMenu/contactus.svg';
import covalentExperimentsIcon from '../../assets/logos/covalentExperimentsIcon.svg';
import covalentSharedIcon from '../../assets/folderIcons/shared.svg';
import covalentHardwareIcon from '../../assets/hardware/covalentHardwareIcon.svg';
import EnvironmentsIcon from '../../assets/logos/environments.svg';
import Icon from '../../icon';
import routes from '../../../constants/routes.json';
import { setUser } from '../../../redux/commonSlice';

// function StepperMenu({ path, tail, value }) {
// 	const navigate = useNavigate();
// 	const location = useLocation();
// 	return (
// 		<Box
// 			pl={location.pathname !== path ? 0.3 : 0}
// 			sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', cursor: 'pointer' }}
// 			onClick={() => {
// 				navigate(path);
// 			}}
// 		>
// 			<Tooltip title={value} placement="right">
// 				<Box
// 					id="circle"
// 					sx={{
// 						'&:hover': {
// 							boxShadow: '0px 0px 8px 2px #5552FF'
// 						},
// 						cursor: 'pointer',
// 						width: location.pathname === path ? '10px' : '6px',
// 						height: location.pathname === path ? '10px' : '6px',
// 						borderRadius: '50%',
// 						background:
// 							location.pathname === path
// 								? theme => theme.palette.background.blue06
// 								: theme => theme.palette.text.primary
// 					}}
// 				/>
// 			</Tooltip>

// 			{tail ? (
// 				<Box
// 					// ml={0.4}
// 					id="line"
// 					sx={{
// 						width: '1px',
// 						height: '29px',
// 						background: theme => theme.palette.text.primary,
// 						cursor: 'pointer'
// 					}}
// 				/>
// 			) : null}
// 		</Box>
// 	);
// }

// function CustomMenu({ title, path, setIsMenuOpen }) {
// 	const navigate = useNavigate();
// 	const location = useLocation();

// 	return (
// 		<Grid
// 			mt={1}
// 			sx={{
// 				display: 'flex',
// 				alignItems: 'center',
// 				cursor: 'pointer'
// 			}}
// 		>
// 			<Typography
// 				variant="h3"
// 				sx={{
// 					px: 1,
// 					py: 0.3,
// 					cursor: 'pointer',
// 					borderRadius: 6,
// 					background: location.pathname === path ? theme => theme.palette.background.blue11 : null,
// 					'&:hover': {
// 						px: 1,
// 						py: 0.3,
// 						background: theme => theme.palette.background.blue11,
// 						borderRadius: 4
// 					}
// 				}}
// 				onClick={() => {
// 					setIsMenuOpen(false);
// 					navigate(path);
// 				}}
// 			>
// 				{title}
// 			</Typography>
// 		</Grid>
// 	);
// }

function NavBar() {
	const loc = useLocation();
	const styledRoute = window.localStorage.getItem('path');
	const [picture, setPicture] = useState(null);
	const dispatch = useDispatch();
	const [selected, setSelected] = useState(styledRoute);
	const [anchorEl, setAnchorEl] = useState(null);
	const [avatar, setAvatar] = useState('');
	const menuInfo = useState(false);
	const setIsMenuOpen = menuInfo[1];
	const [avatarNameTooltip, setAvatarNameTooltip] = useState('');

	const open = Boolean(anchorEl);
	const navigate = useNavigate();
	const collapseRef = useRef(null);

	useEffect(() => {
		const handleOutsideClick = event => {
			if (collapseRef.current && !collapseRef.current.contains(event.target)) {
				setIsMenuOpen(false);
			}
		};

		window.addEventListener('click', handleOutsideClick);

		return () => {
			window.removeEventListener('click', handleOutsideClick);
		};
	}, []);

	const onClickHandler = (value, path) => {
		setIsMenuOpen(false);
		setSelected(value);
		navigate(path);
		if (path === '/settings') setAnchorEl(null);
	};

	useEffect(() => {
		window.localStorage.setItem('path', loc.pathname.slice(1));
		if (loc?.pathname?.slice(1)?.includes('graph')) {
			window.localStorage.setItem('path', 'graph');
			setSelected('');
		} else {
			setSelected(window.localStorage.getItem('path'));
		}
	}, [loc]);

	useEffect(() => {
		Auth.currentAuthenticatedUser().then(user => {
			dispatch(setUser({ user }));
			const res =
				user?.attributes?.given_name || user?.attributes?.family_name || user?.attributes?.email;
			setAvatarNameTooltip(res?.charAt(0)?.toUpperCase() + res?.slice(1));
			const initial = res?.charAt(0)?.toUpperCase();
			setAvatar(initial);
			const pictureAttribute = user?.attributes?.picture;
			setPicture(pictureAttribute);
		});
	}, []);

	const handleClose = () => {
		setAnchorEl(null);
	};

	const handleClick = event => {
		setAnchorEl(event.currentTarget);
	};

	function handleSignout() {
		Auth.signOut()
			.then(() => {
				localStorage.setItem('AUTH_ACCESS_TOKEN', null);
				localStorage.setItem('AUTH_ID_TOKEN', null);
				window.localStorage.setItem('path', null);
				navigate('/login');
			})
			.catch(() => {
				console.log('Error signing out');
			});
	}

	const redirectPage = link => {
		window.open(`${link}`, '_blank');
		handleClose();
	};

	const checkSelected = page => {
		const pageText = page?.slice(1);
		const isSelected = selected === pageText || selected?.startsWith(pageText);
		return isSelected;
	};

	return (
		<Paper square className="navbar" data-testid="navbar" sx={{ zIndex: 111 }}>
			<Grid
				sx={{
					background: theme => theme.palette.background.blue10,
					width: '80%',
					height: '96%',
					borderRadius: '8px'
				}}
			>
				<Tooltip title="Home" placement="right">
					<Box pt={3} sx={{ display: 'flex', width: '100%', justifyContent: 'center' }}>
						<Icon
							src={covalentLogo}
							alt="covalentLogo"
							type="pointer"
							clickHandler={() => onClickHandler('', '/')}
						/>
					</Box>
				</Tooltip>

				<Grid
					ml={-0.3}
					sx={{ height: '80vh' }}
					container
					elevation={0}
					direction="column"
					justifyContent="space-between"
					alignItems="center"
					className="navIcons"
					data-testid="covalentLogo"
				>
					<Grid item xs={6} mt={0.5} ref={collapseRef} sx={{ width: '25px' }}>
						{/* <Tooltip title="Home" placement="right">
							<Grid
								elevation={0}
								className={
									isMenuOpen ||
									(!isMenuOpen &&
										(loc.pathname === '/' ||
											loc.pathname === '/projects' ||
											loc.pathname === '/hardware' ||
											loc.pathname === '/environments' ||
											loc.pathname === '/solvers'))
										? 'iconSelected'
										: 'iconActive'
								}
								marginTop={4.5}
								pt={0.7}
								id="graph"
							>
								<Icon
									padding="1px 0px 0px 0px"
									className="iconProp"
									src={HomeIcon}
									status={selected === 'projects' ? 'active' : ''}
									alt="homeIcon"
									type="pointer"
									clickHandler={() => {
										// onClickHandler('projects', '/projects');
										setIsMenuOpen(prev => !prev);
									}}
								/>
							</Grid>
						</Tooltip> */}
						<Tooltip title="Dashboard" placement="right">
							<Grid
								elevation={0}
								className={selected !== '' ? 'iconActive' : 'iconSelected'}
								marginTop={4.5}
								pt={0.7}
								onClick={() => onClickHandler('', '/')}
								sx={{ cursor: 'pointer' }}
								id="graph"
							>
								<Icon
									className="iconProp"
									src={HomeIcon}
									status={selected === '' ? 'active' : ''}
									alt="covalentExperimentsIcon"
									type="pointer"
								/>
							</Grid>
						</Tooltip>
						<Tooltip title="Projects" placement="right">
							<Grid
								id="projectsPage"
								elevation={0}
								className={!checkSelected(routes?.PROJECTS) ? 'iconActive' : 'iconSelected'}
								marginTop={2}
								pt={0.3}
								onClick={() => onClickHandler('projects', '/projects')}
								sx={{ cursor: 'pointer' }}
							>
								<Icon
									// padding="2px 0px 0px 0px"
									className="iconProp"
									src={covalentExperimentsIcon}
									status={checkSelected(routes?.PROJECTS) ? 'active' : ''}
									alt="covalentExperimentsIcon"
									type="pointer"
								/>
							</Grid>
						</Tooltip>
						<Tooltip title="Shared with me" placement="right">
							<Grid
								id="sharedPage"
								elevation={0}
								className={!checkSelected(routes?.SHARED) ? 'iconActive' : 'iconSelected'}
								marginTop={2}
								pt={0.6}
								sx={{ cursor: 'pointer' }}
								onClick={() => onClickHandler('shared', '/shared')}
							>
								<Badge
									variant="dot"
									sx={{
										'& .MuiBadge-badge': {
											color: theme => theme.palette.text.success,
											backgroundColor: theme => theme.palette.text.success,
											marginTop: '0.15rem',
											marginRight: '0.25rem'
										}
									}}
								>
									<Icon
										className="iconProp"
										src={covalentSharedIcon}
										alt="covalentSharedIcon"
										type="pointer"
										status={checkSelected(routes?.SHARED) ? 'active' : ''}
									/>
								</Badge>
							</Grid>
						</Tooltip>
						<Tooltip title="Hardware" placement="right">
							<Grid
								id="hardwarePage"
								elevation={0}
								className={!checkSelected(routes?.HARDWARE) ? 'iconActive' : 'iconSelected'}
								marginTop={2}
								pt={0.3}
								sx={{ cursor: 'pointer' }}
								onClick={() => onClickHandler('hardware', '/hardware')}
							>
								<Icon
									className="iconProp"
									src={covalentHardwareIcon}
									alt="covalentHardwareIcon"
									type="pointer"
									status={checkSelected(routes?.HARDWARE) ? 'active' : ''}
								/>
							</Grid>
						</Tooltip>
						<Tooltip title="Environments" placement="right">
							<Grid
								id="environmentsPage"
								elevation={0}
								className={!checkSelected(routes?.ENVIRONMENTS) ? 'iconActive' : 'iconSelected'}
								marginTop={2}
								pt={0.6}
								sx={{ cursor: 'pointer' }}
								onClick={() => onClickHandler('environments', '/environments')}
							>
								<Icon
									className="iconProp"
									src={EnvironmentsIcon}
									alt="environmentsIcon"
									type="pointer"
									status={checkSelected(routes?.ENVIRONMENTS) ? 'active' : ''}
								/>
							</Grid>
						</Tooltip>
						<Grid
							elevation={0}
							marginBottom={4}
							marginTop={1}
							sx={{ position: 'absolute', bottom: 22 }}
						>
							<Tooltip title="Settings" placement="right">
								<Grid
									elevation={0}
									// className={selected !== 'marketplace' && selected !== 'marketplace/hardware' && selected !== 'marketplace/solvers' ? 'iconActive' : 'iconSelected'}
									className={!checkSelected(routes?.SETTINGS) ? 'iconActive' : 'iconSelected'}
									marginTop={2}
									marginBottom={2}
									pt={0.3}
								>
									<Icon
										className="iconProp"
										src={settings}
										alt="marketplaceIcon"
										type="pointer"
										status={checkSelected(routes?.SETTINGS) ? 'active' : ''}
										clickHandler={() => onClickHandler('settings', '/settings')}
									/>
								</Grid>
							</Tooltip>
							{picture ? (
								<Tooltip title={avatarNameTooltip}>
									<Grid sx={{ mr: 2, cursor: 'pointer' }} onClick={handleClick}>
										<img
											src={picture}
											alt="Avatar Placeholder"
											style={{
												width: '32px',
												height: '32px',
												borderRadius: '50%',
												cursor: 'pointer'
											}}
										/>
									</Grid>
								</Tooltip>
							) : (
								<Tooltip title={avatarNameTooltip}>
									<Avatar
										sx={{ bgcolor: '#AD7BFF', width: '32px', height: '32px', cursor: 'pointer' }}
										onClick={handleClick}
									>
										{avatar}
									</Avatar>
								</Tooltip>
							)}
						</Grid>
					</Grid>
				</Grid>
				<Menu
					variant="menu"
					anchorEl={anchorEl}
					open={open}
					onClose={handleClose}
					keepMounted={false}
					anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
					transformOrigin={{ vertical: 'top', horizontal: 'left' }}
					PaperProps={{
						style: {
							maxHeight: '300px',
							width: '160px',
							transform: 'translateX(48px) translateY(-5px)'
						}
					}}
				>
					<MenuItem
						data-testid="documentation"
						onClick={() => redirectPage('https://docs.covalent.xyz/')}
					>
						<Icon
							src={documentation}
							padding="1px 3px 3.5px 3px"
							type="static"
							alt="documentation"
						/>
						<Typography variant="subtitle2">Documentation</Typography>
					</MenuItem>
					<MenuItem
						data-testid="contactus"
						onClick={() => redirectPage('https://www.covalent.xyz/contact/')}
					>
						<Icon src={contactus} padding="1px 3px 3.5px 3px" type="static" alt="contactus" />
						<Typography variant="subtitle2">Contact us</Typography>
					</MenuItem>
					<MenuItem data-testid="contactus" onClick={() => handleSignout()}>
						<Icon src={signOut} padding="1px 3px 3.5px 3px" type="static" alt="contactus" />
						<Typography variant="subtitle2">Log out</Typography>
					</MenuItem>
				</Menu>
			</Grid>
		</Paper>
	);
}

export default NavBar;
