/* eslint-disable import/no-unused-modules */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import { Avatar, Box, Grid, Stack, Typography, Tooltip } from '@mui/material';
import Icon from '../../icon';
// import Chips from '../../chips';
import DefaultBadge from '../../badge/environments';
import { statusIcon } from '../../../utils/statusIcons';

function EnvOverviewHeader({ envName, image, defaultEnv, status }) {
	const [name, setName] = React.useState(envName);
	React.useEffect(() => {
		setName(envName);
	}, [envName]);

	// Commenting this as this is dummy data and can be uncomment to check this placeholder data.

	// const chipData = {
	// 	tags: ['python', 'react', 'quantum', 'fdfsdfdsfsdfsdfsdfsdfsdfsdfsdfdsf', 'sass']
	// };

	return (
		<Grid container p={0} mt={3} alignItems="center">
			<Grid item xs={12} p={0}>
				<Stack direction="row" spacing={2} alignItems="center">
					{image ? (
						<Box>
							<Icon src={image} alt="" width="82px" height="82px" type="static" />
						</Box>
					) : (
						<Avatar
							sx={{
								bgcolor: theme => theme.palette.background.blue13,
								width: '82px',
								height: '82px',
								color: theme => theme.palette.text.primary,
								borderRadius: '20px'
							}}
							variant="rounded"
						>
							S
						</Avatar>
					)}
					<Box>
						<Box display="flex">
							<Typography
								variant="h5"
								sx={{
									color: theme => theme.palette.text.gray04,
									cursor: 'default',
									textWrap: 'nowrap'
								}}
							>
								{name}
							</Typography>
							<Box padding="0 10px 0 3px">
								<DefaultBadge isDefault={defaultEnv} value="Default" />
							</Box>
							<Tooltip title={status} placement="bottom">
								<span>{status && statusIcon(status, '4px 0px 3.5px 0px', 'env')}</span>
							</Tooltip>
							{['IN_PROGRESS', 'CREATING'].includes(status) ? (
								<Box ml="10px" mt={0.2} display="flex" alignItems="center">
									<Typography variant="h2" mr="0.5rem">
										Saving changes, please wait..
									</Typography>
								</Box>
							) : null}
							{/* {status && statusIcon(status, '4px 0px 3.5px 0px', 'env')} */}
						</Box>
						{/* // Commenting this as this is dummy data and can be uncomment to check this placeholder data. */}

						{/* <Typography variant="h2" mt={2}>
							{desc} - This is Sample Data
						</Typography> */}
						{/* {chipData?.tags?.length > 0 ? (
							<Chips items={chipData?.tags} isExpandable={false} />
						) : (
							<Box sx={{ height: '44px' }} />
						)} */}
					</Box>
				</Stack>
			</Grid>
		</Grid>
	);
}

export default EnvOverviewHeader;
