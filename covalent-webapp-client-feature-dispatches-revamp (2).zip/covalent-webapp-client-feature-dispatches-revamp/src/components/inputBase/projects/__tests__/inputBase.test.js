/* eslint-disable react/jsx-no-constructed-context-values */
/* eslint-disable testing-library/no-node-access */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
import InputBase from '..';
import { ProjectContext } from '../../../../containers/projects/projectContext';

describe('Input Base', () => {
	test('renders input base', () => {
		render(<InputBase />);
		const element = screen.getByTestId('inputBase');
		expect(element).toBeInTheDocument();
	});
	test('renders tickIcon accordingly', () => {
		render(<InputBase alt="tickIcon" />);
		const element = screen.getByAltText('tickIcon');
		expect(element).toBeInTheDocument();
	});
	test('renders closeIcon accordingly', () => {
		render(<InputBase alt="closeIcon" />);
		const element = screen.getByAltText('closeIcon');
		expect(element).toBeInTheDocument();
	});

	test('calls function when save action is clicked', () => {
		const handleClick = jest.fn();
		render(
			<ProjectContext.Provider value={{ addListItem: handleClick }}>
				<InputBase value="User" />
			</ProjectContext.Provider>
		);
		const element = screen.getByAltText('tickIcon');
		expect(element).toBeInTheDocument();
		fireEvent.click(element);
		expect(handleClick).toBeCalledTimes(1);
	});

	test('calls function when close action is clicked', () => {
		const handleClick = jest.fn();
		render(
			<ProjectContext.Provider value={{ addListItem: handleClick }}>
				<InputBase />
			</ProjectContext.Provider>
		);
		const element = screen.getByAltText('closeIcon');
		expect(element).toBeInTheDocument();
		fireEvent.click(element);
		expect(handleClick).toBeCalledTimes(1);
	});
	test('Change value on typing', () => {
		render(<InputBase />);
		const element = screen.getByTestId('inputBase');
		const elementType = element.querySelector('input');
		expect(elementType).toBeInTheDocument();
		fireEvent.change(elementType, { target: { value: 'User' } });
		const inputValue = screen.getByDisplayValue('User');
		expect(inputValue).toBeInTheDocument();
	});

	test('calls function when enter key is pressed', () => {
		const handleClick = jest.fn();
		render(
			<ProjectContext.Provider value={{ addListItem: handleClick }}>
				<InputBase />
			</ProjectContext.Provider>
		);
		const element = screen.getByTestId('inputBase');
		const elementType = element.querySelector('input');
		expect(elementType).toBeInTheDocument();
		fireEvent.keyDown(elementType, { key: 'Enter', charCode: 13 });
		expect(handleClick).toBeCalledTimes(1);
	});
	test('Show error on typing', () => {
		render(<InputBase />);
		const element = screen.getByTestId('inputBase');
		const elementType = element.querySelector('input');
		expect(elementType).toBeInTheDocument();
		fireEvent.change(elementType, { target: { value: '%%%' } });
		const inputValue = screen.getByText('Forbidden characters not allowed');
		expect(inputValue).toBeInTheDocument();
	});
});
