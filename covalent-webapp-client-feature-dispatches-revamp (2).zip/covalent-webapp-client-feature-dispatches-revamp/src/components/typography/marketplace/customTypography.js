import { Typography } from '@mui/material';
import React from 'react';

function CustomTypography({ content, onClick, category }) {
	return (
		<Typography
			fontSize="14px"
			sx={{
				paddingBottom: '20px',
				color: category === content ? '#5552FF' : '#CBCBD7',
				cursor: 'pointer'
			}}
			onClick={onClick}
		>
			{content}
		</Typography>
	);
}

export default CustomTypography;
