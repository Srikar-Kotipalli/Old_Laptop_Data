/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable react/jsx-no-useless-fragment */

import * as React from 'react';
import Tooltip from '@mui/material/Tooltip';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import Grid from '@mui/material/Grid';
import { makeStyles } from '@mui/styles';
import '../tags/projects/style.css';
import useTagParams from '../../utils/useTagParams';

const useStyles = makeStyles({
	chipRoot: {
		marginRight: '5px',
		marginBottom: '5px',
		'& .MuiChip-label': {
			padding: '0px 3px 0px 4px'
		},
		'& .MuiChip-icon': {
			order: 1,
			marginRight: '4px',
			cursor: 'pointer'
		},
		'& .MuiChip-deleteIcon': {
			order: 2,
			color: 'transparent'
		}
	}
});

export default function ListTagsShared(props) {
	const { items, filterTags } = props;
	const classes = useStyles();
	const { numberOfItems, maxWidth } = useTagParams();

	return (
		<div>
			<Stack direction="row" spacing={1}>
				{items.tags &&
					items.tags.length <= numberOfItems &&
					items.tags.map(tags => (
						<Tooltip title={tags} key={tags}>
							<Chip
								classes={{
									root: classes.chipRoot
								}}
								variant="filled"
								size="small"
								label={
									<Grid
										sx={{
											maxWidth,
											cursor: 'pointer',
											whiteSpace: 'nowrap',
											textOverflow: 'ellipsis',
											overflow: 'hidden'
										}}
										onClick={() => filterTags(tags)}
									>
										{tags}
									</Grid>
								}
								key={tags}
							/>
						</Tooltip>
					))}
				{items.tags &&
					items.tags.length > numberOfItems &&
					items.tags.slice(0, numberOfItems).map(tags => (
						<Tooltip title={tags} key={tags}>
							<Chip
								classes={{
									root: classes.chipRoot
								}}
								variant="filled"
								size="small"
								label={
									<Grid
										sx={{
											maxWidth,
											cursor: 'pointer',
											whiteSpace: 'nowrap',
											textOverflow: 'ellipsis',
											overflow: 'hidden'
										}}
										onClick={() => filterTags(tags)}
									>
										{tags}
									</Grid>
								}
								key={tags}
							/>
						</Tooltip>
					))}
				{items.tags && items.tags.length > numberOfItems && (
					<Tooltip
						title={items.tags.slice(numberOfItems, items.tags.length).map(tags => (
							<Chip
								classes={{
									root: classes.chipRoot
								}}
								variant="filled"
								size="small"
								label={
									<Grid sx={{ cursor: 'pointer' }} onClick={() => filterTags(tags)}>
										{tags}
									</Grid>
								}
								key={tags}
							/>
						))}
						key={`+${items.tags.slice(numberOfItems, items.tags.length).length}`}
						placement="top"
					>
						<Chip
							className="chipContainer"
							sx={{ cursor: 'pointer' }}
							variant="filled"
							color="secondary"
							size="small"
							label={`+${items.tags.slice(numberOfItems, items.tags.length).length}`}
						/>
					</Tooltip>
				)}
			</Stack>
		</div>
	);
}
