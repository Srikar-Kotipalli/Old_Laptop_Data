/* eslint-disable react/jsx-boolean-value */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState, useEffect } from 'react';
import { Auth } from 'aws-amplify';
import Grid from '@mui/material/Grid';
import Tooltip from '@mui/material/Tooltip';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import InputLabel from '@mui/material/InputLabel';
import CustomisedSnackbar from '../../snackbar/projects';
import ResetPasswordDialogBox from '../../dialogBox/settings';
import TokenComponent from './tokenComponent';
import InputField from './inputField';
import copyIcon from '../../../assets/actions/copy.svg';
import tickIcon from '../../../assets/checkmarks/checkmark.svg';

function SettingsForm() {
	const [identityProvider, setIdentityProvider] = useState(false);
	const [username, setUsername] = useState('');
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage, setSnackbarMessage] = useState('');
	const [resetPassword, setResetPassword] = useState(false);
	const [oldPassword, setOldPassword] = useState('');
	const [password, setPassword] = useState('');
	const [rePassword, setRePassword] = useState('');
	const [disable, setDisable] = useState(true);
	const [errorPassword, setErrorPassword] = React.useState('');
	const [errorRePassword, setErrorRePassword] = React.useState('');
	const [errorOldPassword, setErrorOldPassword] = React.useState('');
	useEffect(() => {
		Auth.currentAuthenticatedUser().then(user => {
			const res = user?.attributes;
			const idp = res?.identities?.includes('Google');
			if (idp) setIdentityProvider(true);
			const usernameRes = (res && res['preferred_username']) || user?.username;
			setUsername(usernameRes);
		});
	}, []);

	const resetPasswordValue = () => {
		Auth.currentAuthenticatedUser()
			.then(user => {
				return Auth.changePassword(user, oldPassword, password);
			})
			.then(() => {
				setResetPassword(false);
				setOpenSnackbar(true);
				setSnackbarMessage('Password changed successfully!');
				setPassword('');
				setRePassword('');
				setOldPassword('');
			})
			.catch(err => {
				setOpenSnackbar(true);
				setSnackbarMessage(err?.message);
			});
	};

	useEffect(() => {
		if (resetPassword) {
			let val = !(password && rePassword && oldPassword);
			setErrorOldPassword(oldPassword ? '' : errorOldPassword);
			setErrorPassword(password ? '' : errorPassword);
			setErrorRePassword(rePassword ? '' : errorRePassword);
			if (rePassword !== '' && password !== rePassword) {
				setErrorRePassword('Password do not match');
				val = true;
			}
			setDisable(val);
		}
	}, [password, rePassword, oldPassword, resetPassword]);

	const validateInput = () => {
		if (!password) {
			setDisable(true);
			setErrorPassword('Password is mandatory!');
		}
		if (!rePassword) {
			setDisable(true);
			setErrorRePassword('Password Confirmation is mandatory!');
		}
		if (!oldPassword) {
			setDisable(true);
			setErrorOldPassword('Old password is mandatory!');
		}
		if (!disable) resetPasswordValue();
	};

	const handleCloseFn = () => {
		setResetPassword(false);
		setPassword('');
		setRePassword('');
		setOldPassword('');
		setErrorPassword('');
		setErrorRePassword('');
		setErrorOldPassword('');
	};

	return (
		<form>
			<CustomisedSnackbar
				testId="projectSnackbar"
				action="addItem"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			<ResetPasswordDialogBox
				openDialogBox={resetPassword}
				handleClose={handleCloseFn}
				password={password}
				setPassword={setPassword}
				errorPassword={errorPassword}
				validateInput={validateInput}
				rePassword={rePassword}
				setRePassword={setRePassword}
				errorRePassword={errorRePassword}
				oldPassword={oldPassword}
				setOldPassword={setOldPassword}
				errorOldPassword={errorOldPassword}
			/>
			<Box sx={{}}>
				<InputLabel
					variant="standard"
					htmlFor="uncontrolled-native"
					sx={{
						fontSize: '16px',
						mt: 3,
						mb: 1
					}}
				>
					Username
				</InputLabel>
				<Grid container alignItems="center">
					<Grid sx={{ fontSize: '14px', mr: 2 }}>covalent.xyz/</Grid>
					<Tooltip title={username?.length > 34 ? username : ''}>
						<Grid>
							<InputField
								name="username"
								label="Username"
								widthStyle="250px"
								value={username}
								disabled={true}
							/>
						</Grid>
					</Tooltip>
				</Grid>
			</Box>
			{/* <Box sx={{ mb: 4 }}>
				<InputLabel
					variant="standard"
					htmlFor="uncontrolled-native"
					sx={{
						fontSize: '16px',
						mb: 2
					}}
				>
					Avatar
				</InputLabel>
				<Grid container elevation={0} alignItems="center">
					{picture ?
						<Tooltip title={avatarNameTooltip}>
							<Grid sx={{ mr: 2 }}>
								<img
									src={picture}
									alt="Avatar Placeholder"
									style={{
										width: '32px',
										height: '32px',
										borderRadius: '50%'
									}}
								/>
							</Grid>
						</Tooltip >
						:
						<Tooltip title={avatarNameTooltip}>
							<Avatar
								sx={{ bgcolor: '#AD7BFF', width: '32px', height: '32px', marginRight: '10px' }}
							>
								{avatar}
							</Avatar>
						</Tooltip>
					}
					<Grid
						sx={{
							border: '1px solid #6473FF',
							borderRadius: '68px',
							padding: '4px 16px',
							cursor: 'pointer'
						}}
					>
						<ReactFileReader
							fileTypes={['.png', '.jpg']}
							base64={true}
							handleFiles={handleFiles}
							ref={settingFormRef}
						>
							<Grid container>
								<Icon src={uploadIcon} type="static" alt="uploadIcon" />
								<Typography sx={{ mx: 1, fontSize: '14px', color: '#BEBEBE' }}>Upload</Typography>
							</Grid>
						</ReactFileReader>
					</Grid>
				</Grid>
			</Box> */}
			{!identityProvider && (
				<Box sx={{}}>
					<InputLabel
						variant="standard"
						htmlFor="uncontrolled-native"
						sx={{
							fontSize: '16px',
							mt: 3,
							mb: 1
						}}
					>
						Password
					</InputLabel>
					<Button
						variant="contained"
						disableElevation
						sx={{
							'&:hover': { backgroundColor: theme => theme.palette.background.covalentPurple },
							padding: '8px 16px',
							width: '226px',
							height: '32px',
							borderRadius: '70px',
							border: '1px solid',
							borderColor: theme => theme.palette.background.blue05,
							backgroundColor: theme => theme.palette.background.paper
						}}
						onClick={() => setResetPassword(true)}
					>
						Reset Password
					</Button>
				</Box>
			)}
			<Box sx={{}}>
				<InputLabel
					variant="standard"
					htmlFor="uncontrolled-native"
					sx={{
						fontSize: '16px',
						mt: 3,
						mb: 1
					}}
				>
					Token
				</InputLabel>
				<TokenComponent
					copyIcon={copyIcon}
					copiedIcon={tickIcon}
					value="715515b0-d6d1-4f9d-88d3-ecfff6"
					isDisabled={true}
					from="settings"
					copyEnable={true}
				/>
			</Box>
			{/* <Box>
				<InputLabel
					variant="standard"
					htmlFor="uncontrolled-native"
					sx={{
						fontSize: '16px',
						mb: 2
					}}
				>
					Delete data
				</InputLabel>
				<Button
					variant="contained"
					disableElevation
					sx={{
						padding: '4px 16px',
						width: '226px',
						height: '32px',
						border: '1px solid #6473FF',
						background: '#08081A',
						borderRadius: '68px',
						fontSize: '14px'
					}}
				>
					Delete data & account
				</Button>
			</Box> */}
		</form>
	);
}

export default SettingsForm;
