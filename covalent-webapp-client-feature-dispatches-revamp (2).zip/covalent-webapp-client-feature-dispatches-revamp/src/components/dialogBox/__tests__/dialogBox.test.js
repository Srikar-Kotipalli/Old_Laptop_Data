/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import '@testing-library/jest-dom';
import { render, screen, fireEvent } from '@testing-library/react';
import React from 'react';
import DialogBox from '../index';

describe('dialogBox', () => {
	const handler = jest.fn();
	const selected = [{ title: 'name' }];

	test('dialogBox rendered', () => {
		render(<DialogBox openDialogBox selected={selected} />);
		const element = screen.getByTestId('dialogBox');
		expect(element).toBeInTheDocument();
	});

	test('close button rendered', () => {
		render(<DialogBox openDialogBox selected={selected} />);
		const element = screen.getAllByTestId('actionButton');
		expect(element).toHaveLength(2);
		expect(element[0]).toBeInTheDocument();
	});

	test('move button rendered', () => {
		render(<DialogBox openDialogBox selected={selected} />);
		const element = screen.getAllByTestId('actionButton');
		expect(element[1]).toBeInTheDocument();
	});

	test('move title rendered', () => {
		render(<DialogBox openDialogBox selected={selected} />);
		const element = screen.getByTestId('messageTitle');
		expect(element).toBeInTheDocument();
	});

	test('message rendered', () => {
		render(<DialogBox openDialogBox selected={selected} totalItems={5} />);
		const element = screen.getByTestId('message');
		expect(element).toBeInTheDocument();
	});

	test('move function called', () => {
		render(<DialogBox openDialogBox handler={handler} selected={selected} />);
		const element = screen.getAllByTestId('actionButton');
		fireEvent.click(element[1]);
		expect(handler).toBeCalledTimes(1);
	});
});
