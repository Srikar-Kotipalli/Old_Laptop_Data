/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable react/jsx-no-useless-fragment */

import * as React from 'react';
import Tooltip from '@mui/material/Tooltip';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import Grid from '@mui/material/Grid';
import { makeStyles } from '@mui/styles';
import { ProjectContext } from '../../../containers/projects/projectContext';
import editIcon from '../../../assets/actions/edit.svg';
import Icon from '../../icon';
import TagsInput from '../../inputBase/projects/tagsInput';
import './style.css';
import useTagParams from '../../../utils/useTagParams';
import PackagesTooltip from '../../tooltip/packagesTooltip';

const useStyles = makeStyles({
	chipRoot: {
		marginRight: '5px',
		marginBottom: '5px',
		'& .MuiChip-label': {
			padding: '0px 4px 0px 4px'
		},
		'& .MuiChip-icon': {
			order: 1,
			marginRight: '4px',
			cursor: 'pointer'
		},
		'& .MuiChip-deleteIcon': {
			order: 2,
			color: '#9999b2'
		}
	}
});

export default function ListTags(props) {
	const projectContext = React.useContext(ProjectContext);
	const { filterTags, addTags, showArchived, editableText, setEditableText, deleteListTags } =
		projectContext;
	const { items, type, owner } = props;
	const classes = useStyles();
	const { numberOfItems, maxWidth } = useTagParams();

	return (
		<div>
			{items.isAddTag ? (
				<TagsInput
					type={type}
					listItem={items}
					editableText={editableText}
					setEditableText={setEditableText}
				/>
			) : (
				<Stack direction="row" spacing={1}>
					{items.tags &&
						items.tags.length <= numberOfItems &&
						items.tags.map(tags => (
							<Chip
								classes={{
									root: classes.chipRoot
								}}
								onDelete={!showArchived && !owner ? () => deleteListTags(items, tags) : null}
								variant="filled"
								size="small"
								label={
									<PackagesTooltip
										chip={tags}
										onClick={() => filterTags(tags)}
										maxWidth={maxWidth}
									/>
								}
								key={tags}
								icon={
									!showArchived && !owner ? (
										<Grid>
											<Icon
												clickHandler={() => addTags(items, tags)}
												src={editIcon}
												padding="1px 0px 1px 1px"
											/>
										</Grid>
									) : null
								}
							/>
						))}
					{items.tags &&
						items.tags.length > numberOfItems &&
						items.tags.slice(0, numberOfItems).map(tags => (
							<Tooltip title={tags} key={tags}>
								<Chip
									classes={{
										root: classes.chipRoot
									}}
									onDelete={!showArchived && !owner ? () => deleteListTags(items, tags) : null}
									variant="filled"
									size="small"
									label={
										<Grid
											sx={{
												maxWidth,
												cursor: 'pointer',
												whiteSpace: 'nowrap',
												textOverflow: 'ellipsis',
												overflow: 'hidden'
											}}
											onClick={() => filterTags(tags)}
										>
											{tags}
										</Grid>
									}
									key={tags}
									icon={
										!showArchived && !owner ? (
											<Grid>
												<Icon
													clickHandler={() => addTags(items, tags)}
													src={editIcon}
													padding="1px 0px 1px 1px"
												/>
											</Grid>
										) : null
									}
								/>
							</Tooltip>
						))}
					{items.tags && items.tags.length > numberOfItems && (
						<Tooltip
							title={items.tags.slice(numberOfItems, items.tags.length).map(tags => (
								<Chip
									classes={{
										root: classes.chipRoot
									}}
									onDelete={!showArchived && !owner ? () => deleteListTags(items, tags) : null}
									variant="filled"
									size="small"
									label={
										<Grid sx={{ cursor: 'pointer' }} onClick={() => filterTags(tags)}>
											{tags}
										</Grid>
									}
									key={tags}
									icon={
										!showArchived && !owner ? (
											<Grid>
												<Icon
													clickHandler={() => addTags(items, tags)}
													src={editIcon}
													padding="1px 0px 1px 1px"
												/>
											</Grid>
										) : null
									}
								/>
							))}
							key={`+${items.tags.slice(numberOfItems, items.tags.length).length}`}
							placement="top"
						>
							<Chip
								className="chipContainer"
								sx={{ cursor: 'pointer' }}
								variant="filled"
								color="secondary"
								size="small"
								label={`+${items.tags.slice(numberOfItems, items.tags.length).length}`}
							/>
						</Tooltip>
					)}
					{!items.isAdd && !showArchived && !owner && !owner && (
						<>
							<Chip
								className="chipContainer"
								variant="filled"
								size="small"
								label="+ add"
								sx={{
									backgroundColor: '#08081A',
									'&:hover': {
										borderColor: theme => theme.palette.background.blue03
									}
								}}
								onClick={() => addTags(items)}
							/>
						</>
					)}
				</Stack>
			)}
		</div>
	);
}
