/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import { Box, Grid, SvgIcon, Select, MenuItem, Button, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import DatePicker from 'react-datepicker';
import ascending from '../../assets/marketplace/ascending.svg';
import SearchInput from '../inputBase/projects/searchInput';
import 'react-datepicker/dist/react-datepicker.css';
import AddIcon from '../../assets/actions/add.svg';
import routes from '../../constants/routes.json';

function CustomIcon(props) {
	return (
		// eslint-disable-next-line react/jsx-props-no-spreading
		<SvgIcon {...props} style={{ transform: 'translateY(10%)' }}>
			<svg
				width="16"
				height="16"
				viewBox="0 0 16 22"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					d="M8 10.9998L3 5.9998L3.7 5.2998L8 9.59981L12.3 5.2998L13 5.9998L8 10.9998Z"
					fill="#CBCBD7"
				/>
			</svg>
		</SvgIcon>
	);
}

function SubHeaderControls({
	datePicker,
	filterComponent,
	sortComponent,
	width,
	sort,
	setSort,
	sortBy,
	setSortBy,
	searchValue,
	setSearchValue,
	setDateRange,
	startDate,
	endDate,
	placement
}) {
	const navigate = useNavigate();

	// cancel search
	const cancelSearch = () => {
		setSearchValue('');
	};

	const handleSortClick = () => {
		setSort(sort === 'asc' ? 'desc' : 'asc');
	};

	const selectionChangeHandler = event => {
		setSortBy(event?.target?.value);
	};

	return (
		<Box sx={{ width }}>
			<Grid
				container
				direction="row"
				justifyContent="space-between"
				alignItems="center"
				mt={3}
				width="100%"
			>
				<SearchInput
					sx={{
						border: theme => `1px solid ${theme?.palette?.background?.blue03}`,
						borderRadius: '20px',
						width: '260px',
						height: '32.69px',
						'&.Mui-focused ': {
							border: theme => `1px solid ${theme.palette.background.blue05}`
						},
						'&:hover': {
							border: theme => `1px solid ${theme.palette.text.gray04}`
						}
						// mt:'10rem'
					}}
					value={searchValue || ''}
					onChange={e => setSearchValue(e?.target?.value)}
					cancelSearch={cancelSearch}
				/>
				<Box sx={{ display: 'flex' }}>
					{datePicker && (
						<Box sx={{ mr: '27px' }}>
							<DatePicker
								className="usersDateRangePicker"
								selectsRange
								startDate={startDate}
								endDate={endDate}
								onChange={update => {
									setDateRange(update);
								}}
								isClearable
								placeholderText={'\xa0\xa0\xa0\xa0Start Date - End Date'}
								dateFormat="dd 'th' MMM"
							/>
						</Box>
					)}
					{placement === 'add' && (
						<Button
							variant="outlined"
							sx={{
								'&:hover': {
									backgroundColor: theme => theme?.palette?.background?.covalentPurple,
									color: theme => theme?.palette?.text?.secondary,
									borderRadius: '25px',
									borderColor: theme => theme?.palette?.background?.blue05
								},
								display: 'flex',
								justifyContent: 'center',
								borderRadius: '25px',
								height: '32px',
								marginLeft: '0.2rem',
								marginRight: '2rem'
							}}
							endIcon={
								<img
									src={AddIcon}
									alt="add icon"
									style={{ transform: sort === 'desc' ? 'rotate(180deg)' : '' }}
								/>
							}
							onClick={() => navigate(routes?.ADD_ENVIRONMENT)}
						>
							<Typography
								pt={0}
								variant="popUpDispatch"
								sx={{
									color: theme => theme?.palette?.background?.blue09,
									display: 'flex',
									width: '130px'
								}}
							>
								Create Environment
							</Typography>
						</Button>
					)}
					{filterComponent && (
						<Box
							sx={{ paddingRight: '27px' }}
							display="flex"
							direction="row"
							justifyContent="space-between"
							spacing={3}
						>
							<Select
								IconComponent={CustomIcon}
								value={sortBy}
								onChange={selectionChangeHandler}
								className="tableHeaderSelect"
								sx={{
									fontSize: '14px',
									background: theme => theme?.palette?.background?.paper,
									borderRadius: '200px',
									width: '91px',
									height: '32px',
									color: theme => theme?.palette?.background?.blue09,
									'&:hover': {
										backgroundColor: theme => theme?.palette?.background?.covalentPurple,
										color: theme => theme?.palette?.text?.secondary,
										borderRadius: '25px',
										borderColor: theme => theme?.palette?.background?.blue05
									},
									'.MuiOutlinedInput-notchedOutline': {
										borderColor: theme => theme?.palette?.background?.blue05
									},
									'&.Mui-focused .MuiOutlinedInput-notchedOutline': {
										borderColor: theme => theme?.palette?.background?.blue05
									},
									'&:hover .MuiOutlinedInput-notchedOutline': {
										borderColor: theme => theme?.palette?.background?.blue05
									},
									'.MuiSvgIcon-root ': {
										fill: 'transparent !important'
									}
								}}
							>
								<MenuItem sx={{ fontSize: '14px' }} value="status">
									Status
								</MenuItem>
								<MenuItem sx={{ fontSize: '14px' }} value="build_completed_at">
									Time
								</MenuItem>
							</Select>
							<Button
								variant="outlined"
								sx={{
									'&:hover': {
										backgroundColor: theme => theme?.palette?.background?.covalentPurple,
										color: '#FFFFFF',
										borderRadius: '25px',
										borderColor: theme => theme?.palette?.background?.blue05
									},
									display: 'flex',
									justifyContent: 'center',
									borderRadius: '25px',
									height: '32px',
									width: '121px',
									marginLeft: '32px'
								}}
								endIcon={
									<img
										src={ascending}
										alt={sort}
										style={{ transform: sort === 'desc' ? 'rotate(180deg)' : '' }}
									/>
								}
								onClick={handleSortClick}
							>
								<Typography variant="h2" pt={0}>
									{sort === 'asc' ? 'Ascending' : 'Descending'}
								</Typography>
							</Button>
						</Box>
					)}
					{sortComponent && (
						<Grid container maxWidth="fit-content">
							<Button
								variant="outlined"
								sx={{
									'&:hover': {
										backgroundColor: theme => theme?.palette?.background?.covalentPurple,
										color: theme => theme?.palette?.text?.secondary,
										borderRadius: '25px',
										borderColor: theme => theme?.palette?.background?.blue05
									},
									display: 'flex',
									justifyContent: 'center',
									borderRadius: '25px',
									height: '32px',
									width: '121px',
									marginLeft: '0.2rem',
									marginRight: '2rem'
								}}
								endIcon={
									<img
										src={ascending}
										alt={sort}
										style={{ transform: sort === 'desc' ? 'rotate(180deg)' : '' }}
									/>
								}
								onClick={() => (sort === 'asc' ? setSort('desc') : setSort('asc'))}
							>
								<Typography
									pt={0}
									variant="popUpDispatch"
									sx={{ color: theme => theme?.palette?.background?.blue09 }}
								>
									Status
								</Typography>
							</Button>
							<Button
								variant="outlined"
								sx={{
									'&:hover': {
										backgroundColor: theme => theme?.palette?.background?.covalentPurple,
										color: theme => theme?.palette?.text?.secondary,
										borderRadius: '25px',
										borderColor: theme => theme?.palette?.background?.blue05
									},
									display: 'flex',
									justifyContent: 'center',
									borderRadius: '25px',
									height: '32px',
									width: '160px',
									marginLeft: '0.2rem',
									marginRight: '1rem'
								}}
								endIcon={
									<img
										src={ascending}
										alt={sort}
										style={{ transform: sort === 'desc' ? 'rotate(180deg)' : '' }}
									/>
								}
								onClick={() => (sort === 'asc' ? setSort('desc') : setSort('asc'))}
							>
								<Typography
									pt={0}
									variant="popUpDispatch"
									sx={{ color: theme => theme?.palette?.background?.blue09 }}
								>
									Time
								</Typography>
							</Button>
						</Grid>
					)}
				</Box>
			</Grid>
		</Box>
	);
}

export default SubHeaderControls;
