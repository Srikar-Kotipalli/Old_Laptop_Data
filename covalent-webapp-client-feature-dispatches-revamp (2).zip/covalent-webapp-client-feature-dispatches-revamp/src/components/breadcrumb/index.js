/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react';
import { Breadcrumbs } from '@mui/material';
import { Link } from 'react-router-dom';
import './style.css';

function Breadcrumb({ home, secondary, to, name }) {
	return (
		<Breadcrumbs aria-label="breadcrumb" sx={{ fontSize: '14px' }}>
			{home && <Link to="/">{home}</Link>}
			<Link className="link" to={to}>
				{secondary}
			</Link>
			{name && <span style={{ color: '#CBCBD7' }}>{name}</span>}
		</Breadcrumbs>
	);
}

export default Breadcrumb;
