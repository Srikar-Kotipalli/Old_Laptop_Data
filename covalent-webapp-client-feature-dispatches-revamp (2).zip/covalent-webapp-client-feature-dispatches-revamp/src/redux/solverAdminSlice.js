/* eslint-disable max-len */
/* eslint-disable import/prefer-default-export */
/* eslint-disable import/no-unused-modules */
/* eslint-disable import/no-named-as-default */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import { createSlice } from '@reduxjs/toolkit';
import hardwareImage from '../assets/marketplace/solverHardware.svg';
import Status from '../assets/marketplace/online.svg';

const initialState = {
	accessRequests: [
		{
			type: 'solver',
			category: 'Healthcare',
			solverId: 4,
			technology: 'IonZ',
			per: 'call',
			downloads: 320,
			name: 'Portfolio Optimizer',
			content:
				'Quantum-powered solver for optimizing investment portfolios, considering risk factors and expected returns.',
			price: 95,
			cardimage: 'http://localhost:8080/6ee80768bff8f98bdc028cd95755a8a8.svg',
			solverImage:
				'data:image/svg+xml,%3csvg width=\'21\' height=\'18\' viewBox=\'0 0 21 18\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'%3e %3cpath d=\'M15 0V2.25H6V0H0V6H6V3.75H11.2675C10.7718 4.3955 10.5021 5.18611 10.5 6V12C10.4993 12.5965 10.262 13.1684 9.84018 13.5902C9.41838 14.012 8.84651 14.2493 8.25 14.25H6V12H0V18H6V15.75H8.25C9.24418 15.7488 10.1973 15.3533 10.9003 14.6503C11.6033 13.9473 11.9988 12.9942 12 12V6C11.9998 5.70466 12.0578 5.41218 12.1707 5.13925C12.2836 4.86633 12.4491 4.61832 12.6578 4.40938C12.8666 4.20044 13.1144 4.03467 13.3872 3.92153C13.6601 3.8084 13.9525 3.75011 14.2478 3.75H15V6H21V0H15ZM4.5 4.5H1.5V1.5H4.5V4.5ZM4.5 16.5H1.5V13.5H4.5V16.5ZM19.5 4.5H16.5V1.5H19.5V4.5Z\' fill=\'%23AD7BFF\'/%3e %3c/svg%3e',
			statusimage:
				'data:image/svg+xml,%3csvg width=\'7\' height=\'8\' viewBox=\'0 0 7 8\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'%3e %3ccircle cx=\'3.5\' cy=\'4\' r=\'3.5\' fill=\'%2355D899\'/%3e %3c/svg%3e',
			token: '715515b0-d',
			chipdata: {
				tags: [
					'PortfolioOptimization',
					'QuantumComputing',
					'Finance',
					'InvestmentManagement',
					'HedgeFunds',
					'WealthManagement',
					'QuantitativeResearch'
				]
			},
			headData: {
				name: 'Portfolio Optimizer',
				label: 'PO',
				desc: 'Quantum-powered solver for optimizing investment portfolios, considering risk factors and expected returns.',
				count: '320',
				created_date: '2-10-2022',
				last_build: '12-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			},
			solverdetails: {
				about: [
					'IonZ is at the forefront of developing quantum computing solutions to tackle the world\'s most complex problems. Our main focus is on providing advanced optimization solutions for a range of industries, with a strong emphasis on traffic and logistics.'
				],
				industries: {
					desc: 'The Metro Traffic Optimizer solver is particularly useful for industries and sectors like:',
					listitems: [
						'Transportation',
						'Logistics',
						'Urban Planning',
						'Smart Cities',
						'Public Sector'
					]
				},
				setup:
					'To use the Metro Traffic Optimizer solver, ensure that you have the latest version of Covalent and access to a quantum computing environment.',
				citations:
					'For more details on the methodology and effectiveness of our solver, refer to the following paper: Quantum Computing for Traffic Optimization',
				desc: [
					'The Metro Traffic Optimizer is a quantum computing solution specifically designed for intricate traffic pattern analysis and route optimization. It uses advanced quantum algorithms to model and predict traffic flow, enabling effective traffic management and route planning.',
					'By quantifying and analyzing the various factors that influence urban traffic, such as time of day, weather, and road conditions, Metro Traffic Optimizer can predict congestion points and suggest optimal routes for reducing commute times and improving overall traffic flow.'
				],
				usage:
					'import ctc\nsolver = ctc.solver("metro_traffic_optimizer")\noptimized_route = solver(traffic_data=df, start_point=\'A\', end_point=\'B\')',
				curl: 'curl -X POST -H "Content-Type: application/json" -d \'{"solver_id": "metro_traffic_optimizer", "parameters": {"traffic_data": "<data>", "start_point": "A", "end_point": "B"}}\' http://<covalent_url>/api/solvers/run',
				parameters:
					'def metro_traffic_optimizer(\n  traffic_data: pd.DataFrame,\n  start_point: str,\n  end_point: str\n  ) -> list:'
			},
			requestDate: '2023-07-21T10:31:02.619Z',
			requestedBy: 'Test'
		},
		{
			type: 'solver',
			category: 'Finance',
			solverId: 1,
			technology: 'QuantumPharm',
			per: 'call',
			downloads: 380,
			name: 'BioCompound Explorer',
			content:
				'A quantum computing-assisted solver streamlining drug discovery process, maximizing efficacy while minimizing side effects.',
			price: 75,
			cardimage: 'http://localhost:8080/6ee80768bff8f98bdc028cd95755a8a8.svg',
			solverImage:
				'data:image/svg+xml,%3csvg width=\'21\' height=\'18\' viewBox=\'0 0 21 18\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'%3e %3cpath d=\'M15 0V2.25H6V0H0V6H6V3.75H11.2675C10.7718 4.3955 10.5021 5.18611 10.5 6V12C10.4993 12.5965 10.262 13.1684 9.84018 13.5902C9.41838 14.012 8.84651 14.2493 8.25 14.25H6V12H0V18H6V15.75H8.25C9.24418 15.7488 10.1973 15.3533 10.9003 14.6503C11.6033 13.9473 11.9988 12.9942 12 12V6C11.9998 5.70466 12.0578 5.41218 12.1707 5.13925C12.2836 4.86633 12.4491 4.61832 12.6578 4.40938C12.8666 4.20044 13.1144 4.03467 13.3872 3.92153C13.6601 3.8084 13.9525 3.75011 14.2478 3.75H15V6H21V0H15ZM4.5 4.5H1.5V1.5H4.5V4.5ZM4.5 16.5H1.5V13.5H4.5V16.5ZM19.5 4.5H16.5V1.5H19.5V4.5Z\' fill=\'%23AD7BFF\'/%3e %3c/svg%3e',
			statusimage:
				'data:image/svg+xml,%3csvg width=\'7\' height=\'8\' viewBox=\'0 0 7 8\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'%3e %3ccircle cx=\'3.5\' cy=\'4\' r=\'3.5\' fill=\'%2355D899\'/%3e %3c/svg%3e',
			token: '715515b0-d',
			chipdata: {
				tags: [
					'DrugDiscovery',
					'QuantumComputing',
					'QuantumPharmacy',
					'Pharmaceuticals',
					'Biotechnology',
					'Healthcare',
					'LifeSciences',
					'Research',
					'Academia'
				]
			},
			headData: {
				name: 'BioCompound Explorer',
				label: 'BE',
				desc: 'A quantum computing-assisted solver streamlining drug discovery process, maximizing efficacy while minimizing side effects.',
				count: '380',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			},
			solverdetails: {
				about: [
					'QuantumPharm is a leading provider of quantum computing solutions for the pharmaceutical industry. Our mission is to accelerate drug discovery by leveraging the power of quantum computation, thus creating a healthier future for all.'
				],
				industries: {
					desc: 'The BioCompound Explorer solver is highly beneficial for industries such as:',
					listitems: [
						'Pharmaceuticals',
						'Biotechnology',
						'Healthcare',
						'Life Sciences',
						'Utilities',
						'Research and Academia'
					]
				},
				setup:
					'To use the BioCompound Explorer solver, you need a quantum computing environment alongside the latest version of Covalent.',
				citations:
					'For more details on the methodology and effectiveness of our solver, refer to the following paper: Quantum Computing for Drug Discovery',
				desc: [
					'The BioCompound Explorer is a quantum computing-assisted solver designed to streamline the drug discovery process. Utilizing advanced quantum algorithms, this solver is capable of exploring large compound spaces and identifying potential drug candidates with greater efficiency and accuracy than classical methods.',
					'This solver applies Quantum Monte Carlo methods for molecular dynamics simulations, yielding detailed insights into molecular structures and interactions. By revealing the potential energy surface of molecular systems, BioCompound Explorer expedites the identification of promising drug compounds.'
				],
				usage:
					'import ctc\nsolver = ctc.solver("bio_compound_explorer")\nresults = solver(compound_data=df, search_parameters=params)',
				curl: 'curl -X POST -H "Content-Type: application/json" -d \'{"solver_id": "bio_compound_explorer", "parameters": {"compound_data": "<data>", "search_parameters": "<params>"}}\' http://<covalent_url>/api/solvers/run',
				parameters:
					'def bio_compound_explorer(\n  compound_data: pd.DataFrame,\n  search_parameters: dict\n  ) -> pd.DataFrame:'
			},
			requestDate: '2023-07-21T10:31:04.507Z',
			requestedBy: 'Test'
		},
		{
			type: 'solver',
			category: 'API Management',
			solverId: 0,
			technology: 'OpenAlgo',
			per: 'call',
			downloads: 480,
			name: 'Customer Retention Analyst',
			content:
				'An AI-driven solver predicting customer retention. Ideal for businesses looking to reduce attrition.',
			price: 55,
			solverImage:
				'data:image/svg+xml,%3csvg width=\'21\' height=\'18\' viewBox=\'0 0 21 18\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'%3e %3cpath d=\'M15 0V2.25H6V0H0V6H6V3.75H11.2675C10.7718 4.3955 10.5021 5.18611 10.5 6V12C10.4993 12.5965 10.262 13.1684 9.84018 13.5902C9.41838 14.012 8.84651 14.2493 8.25 14.25H6V12H0V18H6V15.75H8.25C9.24418 15.7488 10.1973 15.3533 10.9003 14.6503C11.6033 13.9473 11.9988 12.9942 12 12V6C11.9998 5.70466 12.0578 5.41218 12.1707 5.13925C12.2836 4.86633 12.4491 4.61832 12.6578 4.40938C12.8666 4.20044 13.1144 4.03467 13.3872 3.92153C13.6601 3.8084 13.9525 3.75011 14.2478 3.75H15V6H21V0H15ZM4.5 4.5H1.5V1.5H4.5V4.5ZM4.5 16.5H1.5V13.5H4.5V16.5ZM19.5 4.5H16.5V1.5H19.5V4.5Z\' fill=\'%23AD7BFF\'/%3e %3c/svg%3e',
			statusimage:
				'data:image/svg+xml,%3csvg width=\'7\' height=\'8\' viewBox=\'0 0 7 8\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'%3e %3ccircle cx=\'3.5\' cy=\'4\' r=\'3.5\' fill=\'%2355D899\'/%3e %3c/svg%3e',
			token: '715515b0-d',
			chipdata: {
				tags: [
					'CustomerRetention',
					'PredictiveAnalytics',
					'MachineLearning',
					'XGBoost',
					'ChurnAnalysis',
					'Business',
					'Telecommunications',
					'FinancialServices',
					'Retail',
					'Ecommerce',
					'Utilities',
					'SoftwareServices'
				]
			},
			headData: {
				name: 'Customer Retention Analyst',
				label: 'CRA',
				desc: 'An AI-driven solver predicting customer retention. Ideal for businesses looking to reduce attrition.',
				count: '480',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			},
			solverdetails: {
				about: [
					'The Customer Retention Analyst is a next-generation solution designed to identify patterns and trends that signal customer churn. By processing complex customer data, this solver uses a combination of statistical analysis and machine learning to predict customer behavior and identify those likely to discontinue their business relationship.',
					'Leveraging the power of XGBoost, a gradient boosting framework renowned for its prediction accuracy and efficiency, Customer Retention Analyst provides businesses with actionable insights, allowing them to proactively mitigate churn risk and maintain a solid customer base.'
				],
				industries: {
					desc: 'The Customer Retention Analyst solver is applicable across a wide array of industries, including:',
					listitems: [
						'Telecommunications',
						'Financial Services',
						'Retail',
						'E-commerce',
						'Utilities',
						'Software Services'
					]
				},
				setup:
					'To use the Customer Retention Analyst solver, ensure that you have the latest version of Covalent and access to a machine learning environment.',
				citations:
					'For more details on the methodology and effectiveness of our solver, refer to the following paper: Predictive Analysis for Customer Churn',
				desc: [
					'The Customer Retention Analyst is a next-generation solution designed to identify patterns and trends that signal customer churn. By processing complex customer data, this solver uses a combination of statistical analysis and machine learning to predict customer behavior and identify those likely to discontinue their business relationship.',
					'Leveraging the power of XGBoost, a gradient boosting framework renowned for its prediction accuracy and efficiency, Customer Retention Analyst provides businesses with actionable insights, allowing them to proactively mitigate churn risk and maintain a solid customer base.'
				],
				usage:
					'import ctc\nsolver = ctc.solver("customer_retention_analyst",api="...")\nprediction = solver(customer_data=df, prediction_window=30, model=\'xgboost\')',
				curl: 'curl -X POST -H "Content-Type: application/json" -d \'{"solver_id": "customer_retention_analyst", "parameters": {"customer_data": "<data>", "prediction_window": 30, "model": "xgboost"}}\' http://<covalent_url>/api/solvers/run',
				parameters:
					'def customer_retention_analyst(\n  customer_data: pd.DataFrame,\n  prediction_window: int,\n  model: str = \'xgboost\'\n  ) -> pd.DataFrame:'
			},
			requestDate: '2023-07-21T10:31:06.050Z',
			requestedBy: 'Test'
		},
		{
			type: 'solver',
			category: 'IDEs',
			solverId: 7,
			technology: 'IonZ',
			per: 'call',
			downloads: 700,
			name: 'Metro Traffic Optimizer',
			content:
				'Uses quantum computing for intricate traffic pattern analysis and route optimization.',
			price: 175,
			solverImage:
				'data:image/svg+xml,%3csvg width=\'21\' height=\'18\' viewBox=\'0 0 21 18\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'%3e %3cpath d=\'M15 0V2.25H6V0H0V6H6V3.75H11.2675C10.7718 4.3955 10.5021 5.18611 10.5 6V12C10.4993 12.5965 10.262 13.1684 9.84018 13.5902C9.41838 14.012 8.84651 14.2493 8.25 14.25H6V12H0V18H6V15.75H8.25C9.24418 15.7488 10.1973 15.3533 10.9003 14.6503C11.6033 13.9473 11.9988 12.9942 12 12V6C11.9998 5.70466 12.0578 5.41218 12.1707 5.13925C12.2836 4.86633 12.4491 4.61832 12.6578 4.40938C12.8666 4.20044 13.1144 4.03467 13.3872 3.92153C13.6601 3.8084 13.9525 3.75011 14.2478 3.75H15V6H21V0H15ZM4.5 4.5H1.5V1.5H4.5V4.5ZM4.5 16.5H1.5V13.5H4.5V16.5ZM19.5 4.5H16.5V1.5H19.5V4.5Z\' fill=\'%23AD7BFF\'/%3e %3c/svg%3e',
			statusimage:
				'data:image/svg+xml,%3csvg width=\'7\' height=\'8\' viewBox=\'0 0 7 8\' fill=\'none\' xmlns=\'http://www.w3.org/2000/svg\'%3e %3ccircle cx=\'3.5\' cy=\'4\' r=\'3.5\' fill=\'%2355D899\'/%3e %3c/svg%3e',
			token: '715515b0-d',
			chipdata: {
				tags: [
					'CustomerRetention',
					'PredictiveAnalytics',
					'MachineLearning',
					'XGBoost',
					'ChurnAnalysis',
					'Business',
					'Telecommunications',
					'FinancialServices',
					'Retail',
					'Ecommerce',
					'Utilities',
					'SoftwareServices'
				]
			},
			headData: {
				name: 'Metro Traffic Optimizer',
				label: 'MTO',
				desc: 'Uses quantum computing for intricate traffic pattern analysis and route optimization.',
				count: '700',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			},
			solverdetails: {
				about: [
					'IonZ is at the forefront of developing quantum computing solutions to tackle the world\'s most complex problems. Our main focus is on providing advanced optimization solutions for a range of industries, with a strong emphasis on traffic and logistics.'
				],
				industries: {
					desc: 'The Metro Traffic Optimizer solver is particularly useful for industries and sectors like:',
					listitems: [
						'Transportation',
						'Logistics',
						'Urban Planning',
						'Smart Cities',
						'Public Sector'
					]
				},
				setup:
					'To use the Metro Traffic Optimizer solver, ensure that you have the latest version of Covalent and access to a quantum computing environment.',
				citations:
					'For more details on the methodology and effectiveness of our solver, refer to the following paper: Quantum Computing for Traffic Optimization',
				desc: [
					'The Metro Traffic Optimizer is a quantum computing solution specifically designed for intricate traffic pattern analysis and route optimization. It uses advanced quantum algorithms to model and predict traffic flow, enabling effective traffic management and route planning.',
					'By quantifying and analyzing the various factors that influence urban traffic, such as time of day, weather, and road conditions, Metro Traffic Optimizer can predict congestion points and suggest optimal routes for reducing commute times and improving overall traffic flow.'
				],
				usage:
					'import ctc\nsolver = ctc.solver("metro_traffic_optimizer")\noptimized_route = solver(traffic_data=df, start_point=\'A\', end_point=\'B\')',
				curl: 'curl -X POST -H "Content-Type: application/json" -d \'{"solver_id": "metro_traffic_optimizer", "parameters": {"traffic_data": "<data>", "start_point": "A", "end_point": "B"}}\' http://<covalent_url>/api/solvers/run',
				parameters:
					'def metro_traffic_optimizer(\n  traffic_data: pd.DataFrame,\n  start_point: str,\n  end_point: str\n  ) -> list:'
			},
			requestDate: '2023-07-21T10:31:12.121Z',
			requestedBy: 'Test'
		}
	],
	allSolvers: [
		{
			type: 'solver',
			category: 'API Management',
			solverId: 0,
			technology: 'OpenAlgo',
			per: 'call',
			apiCalls: '2000',
			revenue: '11234',
			downloads: 480,
			name: 'Customer Retention Analyst',
			content:
				'An AI-driven solver predicting customer retention. Ideal for businesses looking to reduce attrition.',
			price: 55,
			solverImage: hardwareImage,
			statusimage: Status,
			token: '715515b0-d',
			chipdata: {
				tags: [
					'CustomerRetention',
					'PredictiveAnalytics',
					'MachineLearning',
					'XGBoost',
					'ChurnAnalysis',
					'Business',
					'Telecommunications',
					'FinancialServices',
					'Retail',
					'Ecommerce',
					'Utilities',
					'SoftwareServices'
				]
			},

			headData: {
				name: 'Customer Retention Analyst',
				label: 'CRA',
				desc: 'An AI-driven solver predicting customer retention. Ideal for businesses looking to reduce attrition.',
				count: '480',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			},
			solverdetails: {
				about: [
					'The Customer Retention Analyst is a next-generation solution designed to identify patterns and trends that signal customer churn. By processing complex customer data, this solver uses a combination of statistical analysis and machine learning to predict customer behavior and identify those likely to discontinue their business relationship.',
					'Leveraging the power of XGBoost, a gradient boosting framework renowned for its prediction accuracy and efficiency, Customer Retention Analyst provides businesses with actionable insights, allowing them to proactively mitigate churn risk and maintain a solid customer base.'
				],
				industries: {
					desc: 'The Customer Retention Analyst solver is applicable across a wide array of industries, including:',
					listitems: [
						'Telecommunications',
						'Financial Services',
						'Retail',
						'E-commerce',
						'Utilities',
						'Software Services'
					]
				},
				setup:
					'To use the Customer Retention Analyst solver, ensure that you have the latest version of Covalent and access to a machine learning environment.',
				citations:
					'For more details on the methodology and effectiveness of our solver, refer to the following paper: Predictive Analysis for Customer Churn',

				desc: [
					'The Customer Retention Analyst is a next-generation solution designed to identify patterns and trends that signal customer churn. By processing complex customer data, this solver uses a combination of statistical analysis and machine learning to predict customer behavior and identify those likely to discontinue their business relationship.',
					'Leveraging the power of XGBoost, a gradient boosting framework renowned for its prediction accuracy and efficiency, Customer Retention Analyst provides businesses with actionable insights, allowing them to proactively mitigate churn risk and maintain a solid customer base.'
				],
				usage:
					'import ctc\nsolver = ctc.solver("customer_retention_analyst",api="...")\nprediction = solver(customer_data=df, prediction_window=30, model=\'xgboost\')',
				curl: 'curl -X POST -H "Content-Type: application/json" -d \'{"solver_id": "customer_retention_analyst", "parameters": {"customer_data": "<data>", "prediction_window": 30, "model": "xgboost"}}\' http://<covalent_url>/api/solvers/run',
				parameters:
					'def customer_retention_analyst(\n  customer_data: pd.DataFrame,\n  prediction_window: int,\n  model: str = \'xgboost\'\n  ) -> pd.DataFrame:'
			}
		}
	]
};

export const solverAdminSlice = createSlice({
	name: 'common',
	initialState,
	reducers: {
		addAccessRequestSolver: (state, action) => {
			const { solver } = action.payload;
			const checkIndex = state.accessRequests?.findIndex(
				e => e?.solverId === solver?.solverId && !e?.isDenied
			);
			if (checkIndex === -1) state.accessRequests.push(solver);
		},
		markGrantedSolverRequest: (state, action) => {
			const { request } = action.payload;
			const checkIndex = state.accessRequests?.findIndex(
				e => e?.solverId === request?.solverId && !e?.isDenied
			);
			if (checkIndex !== -1)
				state.accessRequests[checkIndex] = { ...state.accessRequests[checkIndex], isGranted: true };
		},
		markDeniedSolverRequest: (state, action) => {
			const { request } = action.payload;
			const checkIndex = state.accessRequests?.findIndex(
				e => e?.solverId === request?.solverId && !e?.isDenied
			);
			if (checkIndex !== -1)
				state.accessRequests[checkIndex] = { ...state.accessRequests[checkIndex], isDenied: true };
		},
		addPublishSolver: (state, action) => {
			const { solver } = action.payload;
			const checkIndex = state.allSolvers?.findIndex(e => e?.solverId === solver?.solverId);
			if (checkIndex === -1) state.allSolvers.push(solver);
		}
	}
});

export const {
	addAccessRequestSolver,
	markGrantedSolverRequest,
	addPublishSolver,
	markDeniedSolverRequest
} = solverAdminSlice.actions;
