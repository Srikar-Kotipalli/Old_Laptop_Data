import React, { useState, useEffect } from 'react';
import { Box, Typography } from '@mui/material';
import './style.css';
import SolversAdminEarningsPage from './earningPage';

function SolversAdminEarnings({ earningsData, toFilter, sort, searchValue }) {
	const [datas, setDatas] = useState([]);

	useEffect(() => {
		let sortedData = [...earningsData];
		if (searchValue) {
			const filteredData = sortedData.filter(item =>
				item.name.toLowerCase().includes(searchValue.toLowerCase())
			);
			sortedData = filteredData;
		}

		if (toFilter === 'last_updated') {
			sortedData.sort((a, b) => {
				const dateA = a.download;
				const dateB = b.download;
				if (sort === 'asc') {
					return dateA - dateB;
				}
				return dateB - dateA;
			});
			setDatas(sortedData);
		}

		if (toFilter === 'popular') {
			sortedData.sort((a, b) => {
				const dateA = a.download;
				const dateB = b.download;
				if (sort === 'asc') {
					return dateB - dateA;
				}
				return dateA - dateB;
			});
			setDatas(sortedData);
		}
	}, [toFilter, sort, searchValue]);

	return (
		<Box>
			{datas.map(data => {
				return <SolversAdminEarningsPage data={data} key={data.id} />;
			})}
			{datas.length < 1 && (
				<Typography
					fontFamily="DM Sans"
					sx={{ color: theme => theme.palette.text.primary }}
					variant="h2"
				>
					No Records Found
				</Typography>
			)}
		</Box>
	);
}

export default SolversAdminEarnings;
