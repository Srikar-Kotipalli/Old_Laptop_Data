/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable no-unused-vars */

import React, { useState, useContext, useEffect } from 'react';
import { Grid, Typography, Button, Stack, Box } from '@mui/material';
import { Auth } from 'aws-amplify';
import { withStyles } from '@mui/styles';
import { compose } from 'redux';
import { useNavigate } from 'react-router-dom';
import LoginInput from '../../components/inputBase/projects/loginInput';
import { LoginContext } from './loginContext';
import WithMediaQuery from '../../utils/useMediaQuery';
import Icon from '../../components/icon';
import ArrowRightIcon from '../../assets/arrows/arrowRightLogin.svg';

// eslint-disable-next-line no-unused-vars
const styles = theme => ({
	container: {
		height: '100vh',
		minHeight: '100%',
		display: 'flex',
		justifyContent: 'center'
	}
});

function ForgotPassword(props) {
	const loginContext = useContext(LoginContext);
	const {
		setMode,
		setOpenSnackbar,
		setSnackbarMessage,
		setOpenLoader,
		setUsername,
		email,
		setEmail,
		setRegisterMode
	} = loginContext;
	const { isMobile } = props;
	const navigate = useNavigate();
	const [errorUsername, setErrorUsername] = React.useState('');
	const [disable, setDisable] = useState(true);

	useEffect(() => {
		if (errorUsername) {
			setErrorUsername(email ? '' : errorUsername);
		}
		setDisable(!(email && !/\s/.test(email?.trim())));
	}, [email]);

	window.onpopstate = () => {
		setMode('login');
	};

	const verifyEmail = () => {
		setOpenLoader(true);
		Auth.forgotPassword(email?.trim())
			.then(_data => {
				setOpenSnackbar(true);
				setSnackbarMessage('Confirmation code sent successfully!');
				setMode('resetPassword');
			})
			.catch(err => {
				setOpenSnackbar(true);
				// eslint-disable-next-line quotes
				if (err?.code === 'InvalidParameterException') {
					err.message = 'Invalid fields.';
				}
				setSnackbarMessage(err?.message);
			})
			.finally(() => setOpenLoader(false));
	};

	const validateInput = () => {
		if (!email) {
			setDisable(false);
			setErrorUsername('Email is mandatory!');
			return;
		}
		if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(email)) {
			setDisable(false);
			setErrorUsername('Invalid email!');
			return;
		}
		verifyEmail();
	};

	return (
		<Grid
			container
			display={!isMobile && 'contents'}
			justifyContent="center"
			mt={isMobile ? '20px' : '42px'}
		>
			<Typography
				className="head-label-requestAccess"
				fontSize={!isMobile ? '27px' : '20px'}
				width="100%"
			>
				Reset your Password
			</Typography>
			<Grid container spacing={2} mb={1}>
				<Grid item xs={12}>
					<Box>
						<Typography
							display="flex"
							alignItems="center"
							variant="h2"
							justifyContent="center"
							sx={{
								height: '32px',
								'@media (max-width: 430px)': {
									height: '40px'
								}
							}}
						>
							Verified User?
							<Typography
								component="div"
								sx={{
									paddingLeft: '8px',
									color: '#6473FF',
									cursor: 'pointer',
									display: 'flex',
									alignItems: 'center',
									fontSize: '14px',
									'&:hover': {
										textDecoration: 'underline'
									}
								}}
								onClick={() => {
									setEmail('');
									setMode('login');
									navigate('/login');
								}}
							>
								Login
								<Icon rowType="experimentRow" src={ArrowRightIcon} alt="ArrowRightIcon" />
							</Typography>
						</Typography>
					</Box>
				</Grid>
			</Grid>
			<Grid
				item
				className="scroll-container"
				sx={{
					justifyContent: 'center',
					border: '1px solid #303067',
					borderRadius: '8px',
					maxHeight: isMobile ? '100vh' : '420px',
					// overflowY: isMobile && 'scroll',
					// minHeight: !isMobile && '550px',
					// padding: isMobile ? '25px' : '0px',
					// position: 'absolute',
					// top: '50%',
					width: !isMobile && '468px',
					maxWidth: '468px',
					margin: isMobile ? '20px 10px 0px' : '42px 10px 0px',
					background: 'linear-gradient(309deg, #08081A -0.75%, rgba(8, 8, 26, 0.00) 108.66%)',
					boxShadow: '0px 5px 9px 0px rgba(0, 0, 0, 0.45)'
					// transform: 'translate(0%, -50%)'
				}}
				xs={12}
				md={4}
			>
				<div style={{ padding: !isMobile ? '34px 63px' : '20px' }}>
					<Box display="flex" flexDirection="row" pt={2} maxWidth="350px">
						<Typography
							variant="h2"
							style={{
								color: 'textPrimary',
								wordWrap: 'break-word',
								paddingTop: '4px'
							}}
						>
							Enter your user account&apos;s verified email address and we will send you a password
							reset code.
						</Typography>
					</Box>
					<Stack spacing={3} mt={1}>
						<LoginInput
							name="forgotEmail"
							id="forgotEmail"
							autoComplete="email"
							value={email !== null ? email : ''}
							handleChange={setEmail}
							type="field"
							error={errorUsername}
							placeholderTxt="Email"
							width="100%"
							handleEnter={validateInput}
						/>
					</Stack>
					<Grid container spacing={2} sx={{ my: 2 }}>
						<Grid item xs={12}>
							<Button
								variant="outlined"
								disableElevation
								sx={{
									width: '100%',
									height: '32px',
									'@media (max-width: 430px)': {
										fontSize: '14px'
									},
									backgroundColor: theme => theme.palette.background.default,
									'&:hover': {
										backgroundColor: theme => theme.palette.background.covalentPurple,
										color: theme => theme.palette.text.secondary,
										borderRadius: '70px',
										borderColor: theme => theme.palette.background.blue05
									}
								}}
								onClick={() => validateInput()}
							>
								Send verification code
							</Button>
						</Grid>

						<Grid item xs={12}>
							<Box>
								<Typography
									display="flex"
									alignItems="center"
									justifyContent="center"
									variant="h2"
									sx={{
										height: '32px',
										'@media (max-width: 430px)': {
											height: '40px'
										}
									}}
								>
									New Member?
									<Typography
										component="div"
										sx={{
											paddingLeft: '8px',
											color: '#6473FF',
											cursor: 'pointer',
											display: 'flex',
											alignItems: 'center',
											fontSize: '14px',
											'&:hover': {
												textDecoration: 'underline'
											}
										}}
										onClick={() => {
											setEmail('');
											setUsername('');
											setRegisterMode('register');
											navigate('/register');
										}}
									>
										Sign up
										<Icon rowType="experimentRow" src={ArrowRightIcon} alt="ArrowRightIcon" />
									</Typography>
								</Typography>
							</Box>
						</Grid>
					</Grid>
				</div>
			</Grid>
		</Grid>
	);
}

export default compose(
	withStyles(styles, {
		name: 'ForgotPassword'
	}),
	WithMediaQuery([['isMobile', theme => theme.breakpoints.down('sm')]])
)(ForgotPassword);
