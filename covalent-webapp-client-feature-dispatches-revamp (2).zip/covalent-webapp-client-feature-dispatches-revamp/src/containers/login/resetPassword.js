/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */

import React, { useState, useContext, useEffect } from 'react';
import { Grid, Typography, Button, Stack, Box } from '@mui/material';
import { Auth } from 'aws-amplify';
import { compose } from 'redux';
import { withStyles } from '@mui/styles';
import LoginInput from '../../components/inputBase/projects/loginInput';
import { LoginContext } from './loginContext';
import WithMediaQuery from '../../utils/useMediaQuery';
import Icon from '../../components/icon';
import ArrowRightIcon from '../../assets/arrows/arrowRightLogin.svg';

// eslint-disable-next-line no-unused-vars
const styles = theme => ({
	container: {
		height: '100vh',
		minHeight: '100%',
		display: 'flex',
		justifyContent: 'center'
	}
});

function ResetPassword(props) {
	const loginContext = useContext(LoginContext);
	const { isMobile } = props;
	const { email, setOpenSnackbar, setSnackbarMessage, setOpenLoader, setMode } = loginContext;
	const [verificationCode, setVerificationCode] = useState('');
	const [password, setPassword] = useState('');
	const [rePassword, setRePassword] = useState('');
	const [disable, setDisable] = useState(true);
	const [errorVerificationCode, setErrorVerificationCode] = React.useState('');
	const [errorPassword, setErrorPassword] = useState('');
	const [errorRePassword, setErrorRePassword] = React.useState('');
	const [isResendCode, setIsResendCode] = useState(false);

	const forgotPasswordSubmit = () => {
		setOpenLoader(true);
		Auth.forgotPasswordSubmit(email?.trim(), verificationCode?.trim(), password)
			// eslint-disable-next-line no-unused-vars
			.then(_data => {
				setOpenSnackbar(true);
				setSnackbarMessage('Password changed successfully');
				setMode('loginEmail');
			})
			.catch(err => {
				setOpenSnackbar(true);
				if (
					err?.message === 'Invalid code provided, please request a code again.' ||
					err?.message === 'Invalid confirmation code provided, please try again.' ||
					err?.message === 'Invalid verification code provided, please try again.'
				) {
					setVerificationCode('');
					setIsResendCode(true);
				} else if (err?.code === 'InvalidParameterException') {
					err.message = 'Invalid fields.';
				}
				setSnackbarMessage(err?.message);
			})
			.finally(() => setOpenLoader(false));
	};

	const resendConfirmationCode = () => {
		setOpenLoader(true);
		Auth.forgotPassword(email?.trim())
			.then(() => {
				setOpenSnackbar(true);
				setSnackbarMessage('Resent confirmation code');
				setIsResendCode(false);
			})
			.catch(err => {
				setOpenSnackbar(true);
				setSnackbarMessage(err?.message);
			})
			.finally(() => setOpenLoader(false));
	};
	useEffect(() => {
		let val = !(rePassword && password && verificationCode && !/\s/.test(verificationCode?.trim()));
		setErrorPassword(password ? '' : errorPassword);
		setErrorRePassword(rePassword ? '' : errorRePassword);
		setErrorVerificationCode(verificationCode ? '' : errorVerificationCode);
		if (rePassword !== '' && password !== rePassword) {
			setErrorRePassword('Password do not match');
			val = true;
		}
		setDisable(val);
	}, [rePassword, password, verificationCode]);

	const validateForgotPasswordInput = () => {
		if (!password) {
			setDisable(true);
			setErrorPassword('Password is mandatory!');
		}
		if (!rePassword) {
			setDisable(true);
			setErrorRePassword('Password Confirmation is mandatory!');
		}
		if (!verificationCode) {
			setDisable(true);
			setErrorVerificationCode('Confirmation code is mandatory!');
		} else if (/\s/.test(verificationCode?.trim())) {
			setDisable(true);
			setErrorVerificationCode('Invalid Confirmation code!');
		}
		if (!disable) forgotPasswordSubmit();
	};
	return (
		<Grid
			container
			display={!isMobile && 'contents'}
			justifyContent="center"
			mt={isMobile ? '20px' : '42px'}
		>
			<Typography
				className="head-label-requestAccess"
				fontSize={!isMobile ? '27px' : '20px'}
				width="100%"
			>
				Reset your Password
			</Typography>
			<Grid
				item
				className="scroll-container"
				sx={{
					justifyContent: 'center',
					border: '1px solid #303067',
					borderRadius: '8px',
					maxHeight: isMobile ? '100vh' : '450px',
					// overflowY: isMobile && 'scroll',
					// minHeight: !isMobile && '550px',
					// padding: isMobile ? '25px' : '0px',
					// position: 'absolute',
					// top: '50%',
					width: !isMobile && '468px',
					maxWidth: '468px',
					margin: isMobile ? '20px 10px 0px' : '42px 10px 0px',
					background: 'linear-gradient(309deg, #08081A -0.75%, rgba(8, 8, 26, 0.00) 108.66%)',
					boxShadow: '0px 5px 9px 0px rgba(0, 0, 0, 0.45)'
					// transform: 'translate(0%, -50%)'
				}}
				xs={12}
				md={4}
			>
				<div style={{ padding: !isMobile ? '34px 63px' : '20px' }}>
					<Box
						display="flex"
						flexDirection="row"
						pt={2}
						maxWidth={isMobile ? '90vw' : '400px'}
						pl={1}
					>
						<Typography
							variant="h2"
							style={{
								color: 'textPrimary',
								wordWrap: 'break-word',
								paddingTop: '4px'
							}}
						>
							Enter the confirmation code sent to your signed-up email address. If you don&apos;t
							see it, check your spam folder.
						</Typography>
					</Box>
					<Stack spacing={2.9} mt={1}>
						<LoginInput
							name="verificationCode"
							id="verificationCode"
							autoComplete="verificationCode"
							value={verificationCode}
							width="100%"
							handleChange={setVerificationCode}
							placeholderTxt="Enter Confirmation code"
							type="field"
							error={errorVerificationCode}
							handleEnter={validateForgotPasswordInput}
						/>
						<LoginInput
							name="resetNewPassword"
							id="resetNewPassword"
							autoComplete="new-password"
							value={password}
							handleChange={setPassword}
							type="field"
							width="100%"
							typeInput="password"
							handleEnter={validateForgotPasswordInput}
							placeholderTxt="Enter password"
							error={errorPassword}
						/>
						<LoginInput
							name="confirmNewPassword"
							id="confirmNewPassword"
							autoComplete="new-password"
							value={rePassword}
							width="100%"
							handleChange={setRePassword}
							placeholderTxt="Re-enter password"
							handleEnter={validateForgotPasswordInput}
							type="field"
							typeInput="password"
							error={errorRePassword}
						/>
					</Stack>
					<Grid container spacing={2} sx={{ mt: 2 }}>
						<Grid item xs={12}>
							<Button
								variant="outlined"
								disableElevation
								sx={{
									height: '32px',
									width: '100%',
									background: '#5552FF',
									borderRadius: '70px',
									fontSize: '14px',
									'@media (max-width: 430px)': {
										fontSize: '14px'
									},
									backgroundColor: theme => theme.palette.background.default,
									'&:hover': {
										backgroundColor: theme => theme.palette.background.covalentPurple,
										color: theme => theme.palette.text.secondary,
										borderRadius: '70px',
										borderColor: theme => theme.palette.background.blue05
									}
								}}
								onClick={() => validateForgotPasswordInput()}
							>
								Change password
							</Button>
						</Grid>
						{isResendCode && (
							<Grid item xs={12}>
								<Typography
									sx={{
										color: '#ffff',
										textDecoration: 'underline',
										cursor: 'pointer',
										fontSize: '12px',
										width: 'fit-content'
									}}
									onClick={() => resendConfirmationCode()}
								>
									Resend verification link
								</Typography>
							</Grid>
						)}
						<Grid item xs={12}>
							<Box>
								<Typography
									variant="h2"
									display="flex"
									alignItems="center"
									justifyContent="center"
									sx={{
										height: '32px',
										'@media (max-width: 430px)': {
											height: '40px'
										}
									}}
								>
									<Typography
										component="div"
										sx={{
											paddingLeft: '10px',
											color: '#6473FF',
											cursor: 'pointer',
											display: 'flex',
											alignItems: 'center',
											fontSize: '14px',
											'&:hover': {
												textDecoration: 'underline'
											}
										}}
										onClick={() => setMode('login')}
									>
										{' '}
										Back to Login
										<Icon rowType="experimentRow" src={ArrowRightIcon} alt="ArrowRightIcon" />
									</Typography>
								</Typography>
							</Box>
						</Grid>
					</Grid>
				</div>
			</Grid>
		</Grid>
	);
}

export default compose(
	withStyles(styles, {
		name: 'ResetPassword'
	}),
	WithMediaQuery([['isMobile', theme => theme.breakpoints.down('sm')]])
)(ResetPassword);
