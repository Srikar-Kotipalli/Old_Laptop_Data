/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */

/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useState, useContext, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Grid, Box, Typography, Button, Checkbox, Link } from '@mui/material';
import Backdrop from '@mui/material/Backdrop';
import { Auth } from 'aws-amplify';
import ReCAPTCHA from 'react-google-recaptcha';
import { withStyles } from '@mui/styles';
import { compose } from 'redux';
import { motion, AnimatePresence } from 'framer-motion';
import { LoginContext } from './loginContext';
import Icon from '../../components/icon';
import LoginInput from '../../components/inputBase/projects/loginInput';
import checkbox from '../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../assets/checkboxes/checkboxChecked.svg';
import { googleRecaptchaVerification, hubSpotLink } from '../../api/signup/signUpApi';
import logoLogin from '../../assets/login/logoLogin.svg';
import ArrowRightIcon from '../../assets/arrows/arrowRightLogin.svg';
import './style.css';
import CustomisedSnackbar from '../../components/snackbar/projects';
import covLoader from '../../assets/loaders/covLoader.svg';
import HubspotPayload from '../../utils/payloadBuilder';
// import TCPopupMenu from '../../components/menu/projects/t&CPopupMenu';
import WithMediaQuery from '../../utils/useMediaQuery';
import useUpdateEffect from '../../utils/useUpdateEffect';

// eslint-disable-next-line no-unused-vars
const styles = theme => ({
	container: {
		height: '100vh',
		minHeight: '100%',
		display: 'flex',
		justifyContent: 'center'
	}
});

function RegisterComponent(props) {
	const loginContext = useContext(LoginContext);
	const { setOpenSnackbar, registerMode, openSnackbar, snackbarMessage, setLocation } =
		loginContext;
	const { isMobile } = props;
	// const [openTC, setOpenTC] = React.useState(false);
	const newLocation = useLocation();

	const bottomToTop = element => {
		element?.scrollTo({
			top: 0,
			behavior: 'smooth'
		});
	};

	useEffect(() => {
		const element = document.querySelector('.scroll-container');
		bottomToTop(element);
		// This is to set the current location for Register page
		setLocation(newLocation);
	}, [registerMode]);

	return (
		<Grid
			container
			// spacing={2}
			minHeight="100%"
			width="100%"
			margin={0}
			alignContent={isMobile ? 'center' : 'auto'}
			sx={{
				backgroundImage: 'linear-gradient(107deg, #1C1C46 24.17%, #0B0B11 69.19%)',
				boxShadow: '0px 5px 9px 0px rgba(0, 0, 0, 0.45)'
			}}
		>
			{/* <TCPopupMenu open={openTC} setOpen={setOpenTC} /> */}
			<CustomisedSnackbar
				testId="projectSnackbar"
				action="addItem"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			<Grid item xs={12} display={{ xs: 'none', sm: 'flex', height: '120px' }}>
				<Box sx={{ padding: '20px 0px 0px 20px' }}>
					<a href={process.env.REACT_APP_COVALENT_URL} target="_blank" rel="noopener noreferrer">
						<Icon src={logoLogin} alt="logo" height="56px" width="101px" />
					</a>
				</Box>
			</Grid>
			<Grid
				item
				xs={12}
				sx={{
					display: 'flex',
					flexDirection: 'column',
					justifyContent: 'center',
					alignItems: 'center',
					padding: '0px !important',
					maxHeight: '800px',
					order: { xs: 1, sm: 2 }
				}}
			>
				<Box sx={{ display: { xs: 'grid', sm: 'none' }, textAlign: 'center' }}>
					<Icon type="static" src={logoLogin} alt="logo" />
				</Box>
				<AnimatePresence mode="wait">
					<motion.div
						key={registerMode}
						initial={{
							x: prevRegisterMode => (prevRegisterMode === 'registerUserProfile' ? -10 : 10),
							opacity: 0
						}}
						animate={{ x: 0, opacity: 1 }}
						exit={{ x: registerMode === 'register' ? -10 : 10, opacity: 0 }}
						transition={{ duration: 0.2 }}
					>
						{registerMode === 'register' && <Register isMobile={isMobile} />}
						{registerMode === 'registerUserProfile' && <RegisterUserProfile isMobile={isMobile} />}
					</motion.div>
				</AnimatePresence>
				{/* </Grid> */}
				<Grid item xs={12} sx={{ display: 'flex', justifySelf: 'flex-end', lignItems: 'center' }}>
					<Box
						sx={{
							display: 'flex',
							justifyContent: 'space-between',
							width: '200px',
							height: '50px'
						}}
					>
						<Link
							href={process.env.REACT_APP_TERMS_AND_CONDITIONS_URL}
							underline="none"
							target="_blank"
							sx={{
								paddingLeft: '8px',
								color: '#6473FF',
								cursor: 'pointer',
								display: 'flex',
								alignItems: 'center',
								'&:hover': {
									textDecoration: 'underline'
								},
								fontSize: '14px'
							}}
						>
							Terms
						</Link>
						<Link
							sx={{
								paddingLeft: '8px',
								color: '#6473FF',
								cursor: 'pointer',
								display: 'flex',
								alignItems: 'center',
								'&:hover': {
									textDecoration: 'underline'
								},
								fontSize: '14px'
							}}
							href={process.env.REACT_APP_PRIVACY_URL}
							underline="none"
							target="_blank"
						>
							Privacy
						</Link>
					</Box>
				</Grid>
			</Grid>
		</Grid>
	);
}

function Register(props) {
	const loginContext = useContext(LoginContext);
	const captchaRef = useRef(null);
	const {
		setMode,
		setRegisterMode,
		setOpenSnackbar,
		setSnackbarMessage,
		setOpenLoader,
		email,
		setEmail,
		username,
		setUsername,
		password,
		setPassword,
		rePassword,
		setRePassword,
		setFirstName,
		setLastName,
		setOrganisationName,
		announcements,
		setAnnouncements,
		openLoader
	} = loginContext;
	const [disable, setDisable] = useState(true);
	const [errorPassword, setErrorPassword] = React.useState('');
	const [errorRePassword, setErrorRePassword] = React.useState('');
	const [errorMail, setErrorMail] = React.useState('');
	const [errorUsername, setErrorUsername] = React.useState('');
	const previousValue = useRef(null);
	const navigate = useNavigate();
	const { isMobile } = props;

	window.onpopstate = () => {
		setRegisterMode('register');
	};

	const clearUserDetailsForm = () => {
		setEmail('');
		setPassword('');
		setRePassword('');
		setFirstName('');
		setLastName('');
		setOrganisationName('');
	};

	function getRandomInt(min, max) {
		min = Math.ceil(min);
		max = Math.floor(max);
		return Math.floor(Math.random() * (max - min) + min); // The maximum is exclusive and the minimum is inclusive
	}

	function generateFromEmail(e) {
		// Retrieve name from email address
		const nameParts = e.replace(/@.+/, '');
		// Replace all special characters like "@ . _ ";
		const name = nameParts.replace(/[&/\\#,+()$~%._@'":*?<>{}]/g, '');
		// Create and return unique username
		return name + getRandomInt(100, 900);
	}

	useUpdateEffect(() => {
		if (email !== '' && email?.match(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]+$/i)) {
			const nameOld = previousValue?.current?.split('@')[0]?.toLowerCase()?.replace(/\./g, '');
			const nameNew = email?.split('@')[0]?.toLowerCase()?.replace(/\./g, '');
			if (nameOld !== nameNew || !username) {
				setUsername(generateFromEmail(email));
			}
			if (nameNew === '') {
				setUsername('');
			}
		} else if (email === '') setUsername('');
		previousValue.current = email;
	}, [email]);

	useEffect(() => {
		let val = !(
			username?.trim() &&
			!/\s/.test(username?.trim()) &&
			email?.trim() &&
			password &&
			rePassword
		);
		previousValue.current = email;
		setErrorPassword(password ? '' : errorPassword);
		setErrorRePassword(rePassword ? '' : errorRePassword);
		setErrorMail(email ? '' : errorMail);
		setErrorUsername(username?.trim() ? '' : errorUsername);
		if (rePassword !== '' && password !== rePassword) {
			setErrorRePassword('Password do not match');
			val = true;
		}
		if (email !== '' && !email?.match(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]+$/i)) {
			setErrorMail('Invalid Email format!');
			val = true;
		}
		setDisable(val);
	}, [email, password, rePassword, username]);

	const continueToNextPage = async () => {
		try {
			const token = captchaRef?.current?.getValue();
			if (token) {
				const bodyParameters = {
					token
				};
				setOpenLoader(true);
				const validToken = await googleRecaptchaVerification(bodyParameters);
				if (validToken?.data?.success) {
					setOpenLoader(false);
					if (!disable) {
						setOpenLoader(false);
						setRegisterMode('registerUserProfile');
					}
				} else {
					setOpenLoader(false);
				}
			} else {
				setOpenSnackbar(true);
				setSnackbarMessage('Please verify you are a human');
			}
		} catch (err) {
			setOpenSnackbar(true);
			setOpenLoader(false);
			if (err.message === 'token is not defined') {
				setOpenSnackbar(true);
				setSnackbarMessage('Please verify you are a human');
			}
			if (err?.message === 'PreSignUp failed with error Sorry, User already exist with same email.')
				setSnackbarMessage('User already exist with same email.');
			else if (
				err?.message ===
				'Username cannot be of email format, since user pool is configured for email alias.'
			)
				setSnackbarMessage('Username cannot be of email format!');
			else if (err?.code === 'InvalidParameterException') setSnackbarMessage('Invalid fields.');
			else setSnackbarMessage(err?.message);
		}
	};

	const validateInput = () => {
		setDisable(false);
		if (!email) {
			setDisable(true);
			setErrorMail('Email is mandatory!');
		}
		if (!username?.trim()) {
			setDisable(true);
			setErrorUsername('Username is mandatory!');
		} else if (/\s/.test(username?.trim())) {
			setDisable(true);
			setErrorUsername('Invalid username!');
		}
		if (!password) {
			setDisable(true);
			setErrorPassword('Password is mandatory!');
		}
		if (!rePassword) {
			setDisable(true);
			setErrorRePassword('Password Confirmation is mandatory!');
		}
		if (!disable) {
			continueToNextPage();
		}
	};

	return (
		<Grid container display={!isMobile && 'contents'} justifyContent="center">
			<Typography className="head-label-requestAccess" fontSize={!isMobile ? '27px' : '20px'}>
				Sign up
			</Typography>
			<Grid container spacing={2} mb={1}>
				<Grid item xs={12} mb={!isMobile ? '42px' : '20px'} maxHeight="32px">
					<Box
						sx={{
							alignItems: 'center'
						}}
					>
						<Typography
							display="flex"
							alignItems="center"
							justifyContent="center"
							variant="h2"
							sx={{
								height: '32px',
								'@media (max-width: 430px)': {
									height: '40px'
								}
							}}
						>
							Verified User?
							<Typography
								component="div"
								sx={{
									paddingLeft: '8px',
									color: '#6473FF',
									cursor: 'pointer',
									display: 'flex',
									alignItems: 'center',
									fontSize: '14px',
									'&:hover': {
										textDecoration: 'underline'
									}
								}}
								onClick={() => {
									clearUserDetailsForm();
									setMode('login');
									navigate('/login');
								}}
							>
								Login
								<Icon rowType="experimentRow" src={ArrowRightIcon} alt="ArrowRightIcon" />
							</Typography>
						</Typography>
					</Box>
				</Grid>
			</Grid>
			<Grid
				item
				className="scroll-container"
				sx={{
					justifyContent: 'center',
					border: '1px solid #303067',
					borderRadius: '8px',
					maxHeight: isMobile ? '100vh' : '720px',
					// overflowY: isMobile && 'scroll',
					// minHeight: !isMobile && '550px',
					// paddingTop: isMobile ? '25px' : '0px',
					// position: 'absolute',
					// top: '50%',
					width: !isMobile && '468px',
					maxWidth: '468px',
					margin: isMobile && '0px 10px',
					background: 'linear-gradient(309deg, #08081A -0.75%, rgba(8, 8, 26, 0.00) 108.66%)',
					boxShadow: '0px 5px 9px 0px rgba(0, 0, 0, 0.45)'
					// transform: 'translate(0%, -50%)'
				}}
				xs={12}
			>
				<div
					style={{
						padding: !isMobile ? '34px 63px' : '5px 20px'
					}}
				>
					<Backdrop open={openLoader} sx={{ zIndex: 5, backgroundColor: 'rgba(0,0,0,0.7)' }}>
						<Icon type="pointer" src={covLoader} />
					</Backdrop>
					<Box>
						<Box sx={{ mb: 3, mt: 1 }}>
							<LoginInput
								name="registerEmail"
								id="registerEmail"
								width="100%"
								autoComplete="email"
								value={email}
								handleChange={setEmail}
								placeholderTxt="*Email"
								type="field"
								typeInput="email"
								error={errorMail}
								handleEnter={validateInput}
							/>
						</Box>
						<Box sx={{ mb: 3 }}>
							<LoginInput
								name="registerPassword"
								id="registerPassword"
								width="100%"
								value={password}
								handleChange={setPassword}
								placeholderTxt="*Password"
								type="field"
								typeInput="password"
								error={errorPassword}
								handleEnter={validateInput}
							/>
						</Box>
						<Box sx={{ mb: 3 }}>
							<LoginInput
								name="registerRePassword"
								id="registerRePassword"
								width="100%"
								value={rePassword}
								handleChange={setRePassword}
								placeholderTxt="*Confirm Password"
								type="field"
								typeInput="password"
								error={errorRePassword}
								handleEnter={validateInput}
							/>
						</Box>
						<Box>
							<LoginInput
								name="registerUsername"
								id="registerUsername"
								autoComplete="registerUsername"
								width="100%"
								value={username}
								handleChange={setUsername}
								placeholderTxt="*Username"
								type="field"
								error={errorUsername}
							/>
						</Box>
						<Box display="flex" flexDirection="row" pt={3}>
							<Checkbox
								data-testid="dispatchCheckbox"
								disableRipple
								size="small"
								value={announcements}
								checked={announcements}
								onChange={() => setAnnouncements(!announcements)}
								icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
								checkedIcon={<Icon src={checkboxChecked} alt="checkboxChecked" type="pointer" />}
							/>
							<Typography
								variant="h2"
								style={{ color: 'textPrimary', wordWrap: 'break-word', paddingTop: '4px' }}
							>
								Would you like to receive product updates and announcements via email?
							</Typography>
						</Box>
						<Box display="flex" flexDirection="row" height="70px !important" mt="5px">
							<Box className="captcha" sx={{ transform: 'scale(0.85)', transformOrigin: '0 0' }}>
								<ReCAPTCHA sitekey={process.env.REACT_APP_SITE_KEY} ref={captchaRef} theme="dark" />
							</Box>
						</Box>
						<Button
							variant="outlined"
							disableElevation
							sx={{
								width: '100%',
								height: '32px',
								borderRadius: '70px',
								margin: '16px 0px 0px !important',
								color: 'white',
								my: 2,
								backgroundColor: theme => theme.palette.background.default,
								'&:hover': {
									backgroundColor: theme => theme.palette.background.covalentPurple,
									color: theme => theme.palette.text.secondary,
									borderRadius: '70px',
									borderColor: theme => theme.palette.background.blue05
								},
								'&:disabled': {
									background: theme => theme.palette.background.covalentPurple,
									color: theme => theme.palette.text.secondary,
									border: '1px solid',
									borderColor: theme => theme.palette.background.blue04,
									borderRadius: '70px'
								}
							}}
							onClick={validateInput}
						>
							Continue
						</Button>
					</Box>
					<Box>
						<Grid container spacing={1} sx={{ mt: 1.8 }}>
							<Grid item xs={12}>
								<Box>
									<Typography
										variant="h2"
										display="flex"
										alignItems="center"
										justifyContent="center"
										sx={{
											height: '32px',
											'@media (max-width: 430px)': {
												height: '40px'
											}
										}}
									>
										Already Signed Up?
										<Typography
											component="div"
											sx={{
												paddingLeft: '10px',
												color: '#6473FF',
												cursor: 'pointer',
												display: 'flex',
												alignItems: 'center',
												fontSize: '14px',
												'&:hover': {
													textDecoration: 'underline'
												}
											}}
											onClick={() => {
												clearUserDetailsForm();
												setMode('verifyUser');
												navigate('/login');
											}}
										>
											{' '}
											Verify User
											<Icon rowType="experimentRow" src={ArrowRightIcon} alt="ArrowRightIcon" />
										</Typography>
									</Typography>
								</Box>
							</Grid>
						</Grid>
					</Box>
				</div>
			</Grid>
		</Grid>
	);
}

function RegisterUserProfile(props) {
	const loginContext = useContext(LoginContext);
	const {
		setMode,
		setRegisterMode,
		setOpenSnackbar,
		setSnackbarMessage,
		setOpenLoader,
		email,
		setEmail,
		setPassword,
		setRePassword,
		username,
		announcements,
		password,
		openLoader,
		firstName,
		lastName,
		// eslint-disable-next-line no-unused-vars
		organisation,
		organisationName,
		setFirstName,
		setLastName,
		// eslint-disable-next-line no-unused-vars
		setOrganisation,
		setOrganisationName
	} = loginContext;
	const [terms, setTerms] = useState(false);
	const [disable, setDisable] = useState(true);
	const [errorOrganisation, setErrorOrganisation] = React.useState('');
	const [errorFirstname, setErrorFirstname] = React.useState('');
	const [errorLastname, setErrorLastname] = React.useState('');
	// const [openTC, setOpenTC] = React.useState(false);
	const navigate = useNavigate();
	const { isMobile } = props;

	window.onpopstate = () => {
		setMode('login');
	};

	const clearUserDetailsForm = () => {
		setEmail('');
		setPassword('');
		setRePassword('');
		setFirstName('');
		setLastName('');
		setOrganisationName('');
	};

	async function signUp() {
		try {
			setOpenLoader(true);
			const { user } = await Auth.signUp({
				username: username?.trim(),
				password,
				attributes: {
					name: firstName?.concat(' ', lastName),
					email,
					given_name: firstName,
					family_name: lastName,
					'custom:isOrganisation': 'True',
					'custom:organisationName': organisationName,
					'custom:isPromotions': announcements ? 'True' : 'False'
				}
			});
			if (user) {
				setOpenSnackbar(true);
				setOpenLoader(false);
				setSnackbarMessage(
					'User signed up successfully. A confirmation code has been sent to your e-mail'
				);

				const payload = HubspotPayload(
					firstName,
					lastName,
					email,
					'Organization',
					announcements,
					organisationName,
					username
				);
				hubSpotLink(payload);
				setMode('verifyUser');
				navigate('/login');
			}
		} catch (err) {
			setOpenSnackbar(true);
			setOpenLoader(false);
			if (err?.message?.includes('User already exist'))
				setSnackbarMessage('User already exist with same email.');
			else if (err?.message === 'Password did not conform with policy: Password not long enough') {
				setSnackbarMessage(err?.message);
				setRegisterMode('register');
			} else if (
				err?.message ===
				'Username cannot be of email format, since user pool is configured for email alias.'
			)
				setSnackbarMessage('Username cannot be of email format!');
			else if (err?.code === 'InvalidParameterException') setSnackbarMessage('Invalid fields.');
			else setSnackbarMessage(err?.message);
		}
	}

	useEffect(() => {
		const val = !(organisationName?.trim() && firstName?.trim() && lastName?.trim() && terms);
		setErrorFirstname(firstName?.trim() ? '' : errorFirstname);
		setErrorLastname(lastName?.trim() ? '' : errorLastname);
		setErrorOrganisation(organisationName?.trim() ? '' : errorOrganisation);
		setDisable(val);
	}, [firstName, lastName, organisationName, terms]);

	const validateInput = () => {
		if (!firstName?.trim()) {
			setDisable(true);
			setErrorFirstname('Firstname is mandatory!');
		}
		if (!lastName?.trim()) {
			setDisable(true);
			setErrorLastname('Lastname is mandatory!');
		}
		if (!terms) {
			setDisable(true);
			setSnackbarMessage('Please read and accept the terms and conditions!');
			setOpenSnackbar(true);
		}
		if (!organisationName?.trim()) {
			setDisable(true);
			setErrorOrganisation('Organization/Affiliation name is mandatory!');
		}
		if (!disable) signUp();
	};

	return (
		<Grid
			container
			display={!isMobile && 'contents'}
			justifyContent="center"
			mt={isMobile ? '20px' : '42px'}
		>
			<Typography className="head-label-requestAccess" fontSize={!isMobile ? '27px' : '20px'}>
				Sign up
			</Typography>

			<Grid container spacing={2} mb={1}>
				<Grid item xs={12}>
					<Box>
						<Typography
							display="flex"
							alignItems="center"
							justifyContent="center"
							variant="h2"
							sx={{
								height: '32px',
								'@media (max-width: 430px)': {
									height: '40px'
								}
							}}
						>
							Verified User?
							<Typography
								component="div"
								sx={{
									paddingLeft: '8px',
									color: '#6473FF',
									cursor: 'pointer',
									display: 'flex',
									alignItems: 'center',
									fontSize: '14px',
									'&:hover': {
										textDecoration: 'underline'
									}
								}}
								onClick={() => {
									clearUserDetailsForm();
									setMode('login');
									navigate('/login');
								}}
							>
								{' '}
								Login
								<Icon rowType="experimentRow" src={ArrowRightIcon} alt="ArrowRightIcon" />
							</Typography>
						</Typography>
					</Box>
				</Grid>
			</Grid>
			<Grid
				item
				className="scroll-container"
				sx={{
					justifyContent: 'center',
					border: '1px solid #303067',
					borderRadius: '8px',
					maxHeight: isMobile ? '100vh' : '720px',
					// overflowY: isMobile && 'scroll',
					// minHeight: !isMobile && '550px',
					// paddingTop: isMobile ? '25px' : '0px',
					// position: 'absolute',
					// top: '50%',
					width: !isMobile && '468px',
					maxWidth: '468px',
					margin: isMobile && '0px 10px',
					background: 'linear-gradient(309deg, #08081A -0.75%, rgba(8, 8, 26, 0.00) 108.66%)',
					boxShadow: '0px 5px 9px 0px rgba(0, 0, 0, 0.45)'
					// transform: 'translate(0%, -50%)'
				}}
				xs={12}
			>
				<div
					style={{
						padding: !isMobile ? '30px 50px 20px' : '20px'
						// width: !isMobile ? '501.31px' : '100%'
					}}
				>
					<Backdrop open={openLoader} sx={{ zIndex: 5, backgroundColor: 'rgba(0,0,0,0.7)' }}>
						<Icon type="pointer" src={covLoader} />
					</Backdrop>
					{/* <TCPopupMenu open={openTC} setOpen={setOpenTC} /> */}
					<Box display="flex" flexDirection="row" justifyContent="center">
						<Typography
							variant="h2"
							style={{ color: 'textPrimary', wordWrap: 'break-word', paddingTop: '4px' }}
						>
							Almost there! Kindly fill in the details to finish Sign up
						</Typography>
					</Box>
					<Box>
						<Box sx={{ mb: 3, mt: 1 }}>
							<LoginInput
								name="registerFirstName"
								id="registerFirstName"
								autoComplete="firstName"
								width="100%"
								value={firstName}
								handleChange={setFirstName}
								placeholderTxt="*Enter first name"
								type="field"
								error={errorFirstname}
								handleEnter={validateInput}
							/>
						</Box>
						<Box sx={{ mb: 3 }}>
							<LoginInput
								name="registerLastName"
								id="registerLastName"
								autoComplete="lastName"
								width="100%"
								value={lastName}
								handleChange={setLastName}
								placeholderTxt="*Enter last name"
								type="field"
								error={errorLastname}
								handleEnter={validateInput}
							/>
						</Box>
						{/* <Box sx={{ mb: 2 }}>
							<LoginInput
								name="registerOrg"
								id="registerOrgs"
								autoComplete="organization"
								value={organisation}
								width="100%"
								handleChange={e => {
									setOrganisationName('');
									setOrganisation(e);
								}}
								type="select"
							/>
						</Box> */}
						<Box sx={{ mb: 3 }}>
							<LoginInput
								name="registerOrgName"
								id="registerOrgName"
								autoComplete="organizationName"
								width="100%"
								value={organisationName}
								handleChange={setOrganisationName}
								placeholderTxt="*Enter Organization/Affiliation Name"
								type="field"
								error={errorOrganisation}
								handleEnter={validateInput}
							/>
						</Box>
						<Box display="flex" flexDirection="row" pt={2}>
							<Checkbox
								data-testid="dispatchCheckbox"
								disableRipple
								size="small"
								value={terms}
								checked={terms}
								onChange={() => setTerms(!terms)}
								icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
								checkedIcon={<Icon src={checkboxChecked} alt="checkboxChecked" type="pointer" />}
							/>
							<Typography
								variant="h2"
								sx={{ color: 'textPrimary', paddingTop: '4px', alignSelf: 'center' }}
							>
								*I agree to the Terms and conditions
							</Typography>
						</Box>
						<Grid container justifyContent="space-between">
							{/* <Grid item xs={5.5}>
								<Button
									variant='outlined'
									disableElevation
									sx={{
										height: '31px',
										width: '100%' ,
										background: 'transparent',
										borderRadius: '70px',
										margin: '16px 0px 0px !important',
										backgroundColor: theme => theme.palette.background.default,
										'&:hover': {
											backgroundColor: theme => theme.palette.background.covalentPurple,
											color: theme => theme.palette.text.secondary,
											borderRadius: '70px',
											borderColor: theme => theme.palette.background.blue05
										}
									}}
									onClick={() => setRegisterMode('register')}
								>
									Back
								</Button>
							</Grid> */}
							<Grid item xs={12}>
								<Button
									variant="outlined"
									disableElevation
									sx={{
										width: '100%',
										height: '32px',
										borderRadius: '70px',
										margin: '16px 0px 0px !important',
										color: 'white',
										my: 2,
										backgroundColor: theme => theme.palette.background.default,
										'&:hover': {
											backgroundColor: theme => theme.palette.background.covalentPurple,
											color: theme => theme.palette.text.secondary,
											borderRadius: '70px',
											borderColor: theme => theme.palette.background.blue05
										}
									}}
									onClick={validateInput}
								>
									Sign up
								</Button>
							</Grid>
							<Grid item xs={12}>
								<Box>
									<Typography
										variant="h2"
										display="flex"
										alignItems="center"
										justifyContent="center"
										margin="16px 0px 0px !important"
										sx={{
											height: '32px',
											'@media (max-width: 430px)': {
												height: '40px'
											}
										}}
									>
										<Typography
											component="div"
											sx={{
												paddingLeft: '10px',
												color: '#6473FF',
												cursor: 'pointer',
												display: 'flex',
												alignItems: 'center',
												'&:hover': {
													textDecoration: 'underline'
												}
											}}
											onClick={() => setRegisterMode('register')}
										>
											{' '}
											Back to previous page
											<Icon rowType="experimentRow" src={ArrowRightIcon} alt="ArrowRightIcon" />
										</Typography>
									</Typography>
								</Box>
							</Grid>
						</Grid>
					</Box>
					<Box>
						<Grid container spacing={1} sx={{ mt: 1.8 }}>
							<Grid item xs={12}>
								<Box>
									<Typography
										display="flex"
										alignItems="center"
										justifyContent="center"
										variant="h2"
										sx={{
											height: '32px',
											'@media (max-width: 430px)': {
												height: '40px'
											}
										}}
									>
										Already Signed Up?
										<Typography
											component="div"
											sx={{
												paddingLeft: '10px',
												color: '#6473FF',
												cursor: 'pointer',
												display: 'flex',
												alignItems: 'center',
												fontSize: '14px',
												'&:hover': {
													textDecoration: 'underline'
												}
											}}
											onClick={() => {
												clearUserDetailsForm();
												setMode('verifyUser');
												navigate('/login');
											}}
										>
											Verify User
											<Icon rowType="experimentRow" src={ArrowRightIcon} alt="ArrowRightIcon" />
										</Typography>
									</Typography>
								</Box>
							</Grid>
						</Grid>
					</Box>
				</div>
			</Grid>
		</Grid>
	);
}

export default compose(
	withStyles(styles, {
		name: 'Login'
	}),
	WithMediaQuery([['isMobile', theme => theme.breakpoints.down('sm')]])
)(RegisterComponent);
