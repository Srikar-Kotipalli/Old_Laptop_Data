import React, { useState } from 'react';
import { Box } from '@mui/material';
import { useSelector } from 'react-redux';
import Breadcrumb from '../../components/breadcrumb';
import { headSolverData } from '../marketplace/marketplaceConstants';
import SolversTab from '../../components/solvers/tab';
import SolversOverview from './overview';
import RunsComponent from './runs/index';
import SolversTabContainer from './solvers';
import { allItemsList } from '../../api/experiments/dispatchApi';
import OverviewHeader from '../hardwareOverview/header';

function Solvers() {
	const { allMySolvers } = useSelector(state => state.solver);
	const recentSolverData = allMySolvers?.slice(-4);
	const [value, setValue] = useState('Overview');
	const [solverName, setSolverName] = useState('');
	const [solverId, setSolverId] = useState('');
	const [allItems, setAllItems] = useState([]);
	const [showArchived] = React.useState(false);
	// state to store multiple dispatches for context actions.
	const [offset] = React.useState(0);
	const [, setOpenLoader] = React.useState(false);
	const [, setOpenSnackbar] = React.useState(false);
	const [, setSnackbarMessage] = React.useState('');
	// handle tab changes

	const itemsListApi = () => {
		setOpenLoader(true);
		const bodyParameters = {
			count: 10,
			filterBy: 'dispatches',
			offset,
			direction: 'asc',
			sort: 'lastUpdated',
			search: '',
			tags: [],
			showArchived
		};
		// setOpenLoader(true);
		allItemsList(bodyParameters)
			.then(response => {
				const list = response?.items.map(e => {
					return {
						...e,
						isChecked: false,
						solverId:
							recentSolverData?.length > 0
								? recentSolverData[[Math.floor(Math.random() * recentSolverData.length)]][
										'solverId'
								  ]
								: '',
						cost: Math.floor(Math.random() * 100)
					};
				});
				setAllItems(list);
				setOpenLoader(false);
			})
			.catch(() => {
				setOpenLoader(false);
				setOpenSnackbar(true);
				setSnackbarMessage('Something went wrong,please contact the administrator!');
				setOpenLoader(false);
			});
	};
	React.useEffect(() => {
		// eslint-disable-next-line no-use-before-define
		itemsListApi();
	}, []);

	const handleTabChange = (_event, newValue) => {
		setSolverName('');
		setSolverId('');
		setValue(newValue);
	};

	const solversCardClick = (selectedSolverName, selectedSolverId) => {
		setSolverName(selectedSolverName);
		setSolverId(selectedSolverId);
		setValue('Runs');
	};

	const getDispatchesForSolver = () => {
		if (solverId) {
			const dispatches = allItems?.filter(e => e?.solverId === solverId);
			return dispatches;
		}
		return allItems;
	};

	return (
		<Box sx={{ mb: 4 }}>
			<Breadcrumb home="Solvers" secondary={value} to="/solvers" />
			<Box>
				<OverviewHeader data={headSolverData} placement="solverAdmin" />
			</Box>
			<Box ml={0.8} mt={3}>
				<SolversTab value={value} onChange={handleTabChange} />
			</Box>
			<Box>
				{value === 'Overview' && (
					<Box>
						<SolversOverview solversCardClick={solversCardClick} />
					</Box>
				)}

				{value === 'Runs' && (
					<Box>
						<RunsComponent
							name={solverName}
							dispatchesList={getDispatchesForSolver()}
							allDispatches={allItems}
						/>
					</Box>
				)}

				{value === 'Solvers' && (
					<Box>
						<SolversTabContainer />
					</Box>
				)}
			</Box>
		</Box>
	);
}

export default Solvers;
