/* eslint-disable quotes */
/* eslint-disable max-len */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { Grid, Typography } from '@mui/material';
import React from 'react';
import { Link } from 'react-router-dom';
import StepsBlock from '../../components/dashboard/stepsBlock';

const codeString = `import covalent as ct
import covalent_cloud as cc

# Save API Key

cc.save_api_key("YOUR_API_KEY")

# Define Environments

cc.create_env("pandas_env", pip=["numpy", "pandas"], conda=["python=3.8", "pip"])
cc.create_env("sklearn_env", pip=["scikit-learn"], conda=["python=3.8", "pip"])
cc.create_env("scipy_env", pip=["scipy"], conda=["python=3.8", "pip"])

# Define Executors

high_compute = cc.CloudExecutor(env="pandas_env", num_cpus=3, memory=1024)
low_compute = cc.CloudExecutor(env="sklearn_env", num_cpus=1, memory=1024)
general_compute = cc.CloudExecutor(env="scipy_env", num_cpus=2, memory=1024)

# Define Computations

@ct.electron(executor=high_compute)
def add(x, y):
    import pandas as pd
    s = pd.Series([x, y])
    return s.sum()

@ct.electron(executor=low_compute)
def multiply(x, y):
    return x \* y

@ct.electron(executor=general_compute)
def divide(x, y):
    return x / y

# Create Workflow

@ct.lattice(executor=low_compute, workflow_executor=low_compute)
def workflow(x, y):
    r1 = add(x, y)
    r2 = [multiply(r1, y) for _ in range(4)]
    r3 = [divide(x, value) for value in r2]
    return r3

# Dispatch Workflow and Get Results

run_id = cc.dispatch(workflow)(1, 2)
result = cc.get_result(run_id)
print(result.result)
`;

const computation = `import covalent as ct
@ct.electron(executor=high_compute)
def add(x, y):
    import pandas as pd
    s = pd.Series([x, y])
    return s.sum()

@ct.electron(executor=low_compute)
def multiply(x, y):
    return x \* y

@ct.electron(executor=general_compute)
def divide(x, y):
    return x / y`;

const workflow = `@ct.lattice(executor=low_compute, workflow_executor=low_compute)
def workflow(x, y):
    r1 = add(x, y)
    r2 = [multiply(r1, y) for _ in range(4)]
    r3 = [divide(x, value) for value in r2]
    return r3`;

const result = `run_id = cc.dispatch(workflow)(1, 2)
result = cc.get_result(run_id)
print(result.result)`;

function GettingStarted() {
	return (
		<Grid container id="getStartedButton">
			<Grid item xs={9}>
				<Grid
					item
					xs={10}
					container
					direction="column"
					sx={{
						background: theme => theme.palette.background.covalentPurple,
						border: '1px solid',
						borderRadius: '6px',
						borderColor: theme => theme.palette.background.blue05
					}}
					mt={2}
					px={3}
					py={2}
				>
					<Typography variant="status" sx={{ fontWeight: 'bold' }}>
						Before you start
					</Typography>
					<Typography variant="h2" mt={2}>
						Ensure you are using a compatible OS and Python version. See the{' '}
						<Link
							to="https://docs.covalent.xyz/docs/user-documentation/compatibility"
							style={{ color: '#CBCBD7' }}
						>
							Compatibility
						</Link>{' '}
						page for supported Python versions and operating systems.
					</Typography>
				</Grid>
				{/* steps to getting started grid */}
				<StepsBlock
					code="$ pip install covalent"
					step="1. Use Pip to install the Covalent server and libraries locally"
					description="Type the following in a terminal window:"
					copyVal="pip install covalent"
				/>
				<StepsBlock
					code="$ pip install covalent-cloud --upgrade"
					step="2. Use Pip to install the cloud server"
					copyVal="pip install covalent-cloud --upgrade"
				/>
				<StepsBlock
					code={'import covalent_cloud as cc\ncc.save_api_key("YOUR_API_KEY")'}
					step="3. Grab your api key from dashboard and save it"
				/>
				<StepsBlock
					code={
						'cc.create_env("pandas_env", pip=["numpy", "pandas"], conda=["python=3.8", "pip"])\ncc.create_env("sklearn_env", pip=["scikit-learn"], conda=["python=3.8", "pip"])\ncc.create_env("scipy_env", pip=["scipy"], conda=["python=3.8", "pip"])'
					}
					step="4. Define environments"
					description={`Environments represent the libraries and packages your computations need. Let' s set them up. This is a one-time process, and you can always refer to them by name later in your code.`}
				/>
				<StepsBlock
					code={`high_compute = cc.CloudExecutor(env="pandas_env", num_cpus=3, memory=1024)\nlow_compute = cc.CloudExecutor(env="sklearn_env", num_cpus=1, memory=1024)\ngeneral_compute = cc.CloudExecutor(env="scipy_env", num_cpus=2, memory=1024)`}
					step="5. Define executors"
					description="Executors manage the computational resources required for your tasks. Here, we are setting up three executors with varying resources."
				/>
				<StepsBlock
					code={computation}
					step="6. Define computations"
					description="With our environments and executors set up, we can now define some computations. We use the @ct.electron decorator to define these tasks."
				/>
				<StepsBlock
					code={workflow}
					step="7. Create workflow"
					description="We are now ready to bring together our computations into a workflow using the @ct.lattice decorator."
				/>
				<StepsBlock
					code={result}
					step="8. Dispatch workflow and get results"
					description="Let's get your workflow in motion! Dispatch your workflow, wait for the computation, and fetch your results."
				/>
				<StepsBlock code={codeString} step="9. Complete workflow for reference" />
			</Grid>
			{/* right grid */}
			{/* <Grid item xs={3}>
				<Typography variant="header20" id="runFlow">
					Activity list
				</Typography>
				<Grid
					mt={2}
					p={2}
					sx={{
						background: theme => theme.palette.background.covalentPurple,
						borderRadius: '8px'
					}}
				>
					<ActivityList height="10rem" items={[]} />
				</Grid>
			</Grid> */}
		</Grid>
	);
}

export default GettingStarted;
