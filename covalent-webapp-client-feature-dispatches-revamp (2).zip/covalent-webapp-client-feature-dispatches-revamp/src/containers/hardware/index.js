import React from 'react';
import { useSelector } from 'react-redux';
import { Grid } from '@mui/material';
import HardwareCustomTab from '../../components/tab/hardware';
import './style.css';
import HardwareCard from '../../components/card/hardware/hardwareCard';
import HardwareInfoCard from '../../components/card/hardware/hardwareInfoCard';

export default function Hardware() {
	const { allMyHardwares } = useSelector(state => state.hardware);
	return (
		<Grid container data-testid="hardwareContainer" sx={{ mb: 4 }}>
			<Grid container>
				<HardwareInfoCard />
			</Grid>
			<Grid container mt={3} mb={2} className="containerSpacing" sx={{ marginLeft: '-30px' }}>
				<HardwareCustomTab />
			</Grid>
			<Grid container direction="row" className="containerSpacing">
				<HardwareCard hardwareInfo={allMyHardwares} from="hardware" />
			</Grid>
		</Grid>
	);
}
