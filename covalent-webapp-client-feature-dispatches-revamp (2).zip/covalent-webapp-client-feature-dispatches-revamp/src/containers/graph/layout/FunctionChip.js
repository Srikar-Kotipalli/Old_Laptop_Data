/* eslint-disable camelcase */
/* eslint-disable no-unused-vars */
/* eslint-disable react/jsx-no-useless-fragment */
import React, { useState, useContext } from 'react';
import { Box } from '@mui/material';
import { useParams } from 'react-router-dom';
import { dpexpStatusIcons } from '../../../utils/statusIcons';
import OverflowTooltip from '../../../components/tooltip/overflowTooltip';
import Qelectron from '../../../assets/graph/QelectronImage.svg';
import GraphRuntime from '../../../utils/GraphRuntime';
import { GraphContext } from '../contexts/GraphContext';
import { Prettify } from '../../../utils/utils';

// eslint-disable-next-line no-unused-vars
function FunctionChip({ functionInfo, from }) {
	const {
		setSelectedNodeId,
		setTabValue,
		selectedNodeId,
		setNodeClickFrom,
		sublatticeId,
		setSublatticeId,
		setBreadcrumb
	} = useContext(GraphContext);
	const [isSelected, setIsSelected] = useState(false);

	const { dispatchID } = useParams();
	const populateBreadcrumbs = () => {
		const breadcrumbdata = [];
		let data = functionInfo?.parentInfo;
		while (data) {
			breadcrumbdata.push({
				name: Prettify(data?.name, data?.type),
				id: data?.sublattice_dispatch_id
			});
			data = data.parentInfo;
		}
		breadcrumbdata.push({ name: 'Main Graph', id: dispatchID });
		breadcrumbdata.reverse();
		setBreadcrumb([...breadcrumbdata]);
	};

	return (
		<>
			<Box
				onClick={e => {
					e.stopPropagation();
					if (from !== 'funcChip') populateBreadcrumbs();
					setIsSelected(!isSelected);
					setSelectedNodeId(functionInfo?.transport_graph_node_id);
					setSublatticeId(functionInfo?.dispatchID);
					setTabValue('Detail View');
					setNodeClickFrom(from);
				}}
				sx={{
					boxShadow: '0px 4px 8px 0px rgba(0, 0, 0, 0.35)',
					height: '38px',
					borderRadius: '8px',
					background:
						(selectedNodeId === functionInfo?.transport_graph_node_id ||
							(selectedNodeId === '' && functionInfo?.transport_graph_node_id === 0)) &&
						sublatticeId === functionInfo?.dispatchID
							? '#303067'
							: 'linear-gradient(91deg, rgba(28, 28, 70, 0.40) 0.19%, rgba(28, 28, 70, 0.00) 99.81%)',
					padding: '10px',
					display: 'flex',
					justifyContent: 'space-between',
					border: '1px solid #08081A',
					'&:hover': {
						background: '#1C1C46'
					},
					alignItems: 'center',
					cursor: 'pointer'
				}}
			>
				<Box sx={{ display: 'flex' }}>
					<OverflowTooltip title={Prettify(functionInfo?.name)} length={16} />
					<Box sx={{ display: 'grid', placeItems: 'center', marginLeft: '8px' }}>
						{dpexpStatusIcons({ status: functionInfo?.status, animated: true })}
					</Box>
					<Box sx={{ display: 'grid', placeItems: 'center', marginLeft: '8px' }}>
						{functionInfo?.contains_qelectrons ? <img src={Qelectron} alt="isQelectron" /> : null}
					</Box>
				</Box>

				{functionInfo?.started_at && functionInfo?.completed_at ? (
					<GraphRuntime
						startTime={functionInfo?.started_at}
						endTime={functionInfo?.completed_at}
						className="overviewsubhead"
						sx={{ fontSize: '14px' }}
					/>
				) : null}
			</Box>
		</>
	);
}

export default FunctionChip;
