import React from 'react';
import { Box, Typography, Stack, Skeleton } from '@mui/material';
import OverflowTooltip from '../../../components/tooltip/overflowTooltip';

function NodeParameter({
	heading,
	time,
	imgSrc,
	padding = '6px 15px 6px 15px',
	backgroundColor,
	isFetching,
	placement,
	fontWeight
}) {
	return (
		<Box
			sx={{
				display: 'flex',
				justifyContent: placement === 'specifications' ? 'left' : 'space-between',
				padding: { padding },
				border: backgroundColor ? '1px solid #303067' : null,
				borderRadius: '8px',
				backgroundColor: backgroundColor || 'transparent'
			}}
		>
			<Stack direction="row" sx={{ width: placement === 'specifications' ? '50%' : '70%' }}>
				<img src={imgSrc} alt="img" />
				<Box sx={{ display: 'flex', alignItems: 'center', width: 'fit-content' }}>
					<Typography
						sx={{
							color: '#CBCBD7',
							fontSize: '14px',
							fontWeight: '400',
							marginLeft: '11px',
							cursor: 'default'
						}}
					>
						{heading}
					</Typography>
				</Box>
			</Stack>
			<Box sx={{ display: 'flex', alignItems: 'center' }}>
				<Typography
					sx={{
						color: '#CBCBD7',
						fontSize: '14px',
						fontWeight: fontWeight || '700',
						cursor: 'default'
					}}
				>
					{isFetching === true ? (
						<Skeleton variant="rounded" width={20} height={20} />
					) : time || time === 0 ? (
						<OverflowTooltip
							title={`${time} `}
							length={15}
							fontSize="12px"
							color={theme => theme.palette.text.secondary}
						/>
					) : (
						'-'
					)}
				</Typography>
			</Box>
		</Box>
	);
}

export default NodeParameter;
