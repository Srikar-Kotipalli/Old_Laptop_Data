/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable no-unused-vars */
/* eslint-disable react/jsx-boolean-value */
import React from 'react';
import { Box, Typography, Skeleton, Tooltip } from '@mui/material';
// import CopyButton from '../../../assets/graph/CopyButton.svg';
import OverflowTooltip from '../../../components/tooltip/overflowTooltip';
import Expanded from '../../../assets/graph/Expanded.svg';
import Collapsed from '../../../assets/graph/collapsed.svg';
import CopyButton from '../../../components/copyButton';
import Qelectron from '../../../assets/graph/qelectron.svg';

function NodeDetailViewAccordionHeader({
	name,
	nodeID,
	isFetching,
	setExpanded,
	expanded,
	type = 'default'
}) {
	const handleClick = () => {
		setExpanded(!expanded);
	};

	return (
		<Box
			sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', cursor: 'pointer' }}
			onClick={handleClick}
		>
			{type === 'qelectron' ? (
				<Box
					sx={{
						display: 'flex',
						flexDirection: 'row',
						width: '53%',
						justifyContent: 'space-between'
					}}
				>
					<Box sx={{ display: 'flex' }}>
						<img src={Qelectron} alt="Qlectron" />
						<Typography
							sx={{
								color: '#CBCBD7',
								fontSize: '16px',
								fontFamily: 'DM Sans',
								margin: '3px 0 0 10px'
							}}
						>
							Qelectron
						</Typography>
					</Box>
				</Box>
			) : (
				<Box
					sx={{
						display: 'flex',
						flexDirection: 'row',
						width: '53%',
						alignItems: 'center'
					}}
				>
					<Typography sx={{ fontSize: '12px', color: '#CBCBD7' }}>Node Id:</Typography>
					{isFetching ? (
						<Skeleton
							variant="rounded"
							width={84}
							height={30}
							sx={{ marginLeft: '10px', marginTop: '5px' }}
						/>
					) : (
						<Box
							sx={{
								display: 'flex',
								borderRadius: '8px',
								border: '1px solid #303067',
								marginLeft: '10px',
								alignItems: 'center'
							}}
							onClick={e => e?.stopPropagation()}
						>
							<Box
								sx={{
									width: '56px',
									padding: '2px 6px 2px 12px',
									display: 'flex',
									alignItems: 'center',
									overflow: 'hidden',
									textOverflow: 'ellipsis'
								}}
							>
								<Tooltip title={nodeID?.toString()} placement="top">
									<Typography
										noWrap
										sx={{
											color: '#CBCBD7',
											fontSize: '12px',
											fontWeight: '400',
											overflow: 'hidden',
											textOverflow: 'ellipsis'
										}}
									>
										{nodeID?.toString()}
									</Typography>
								</Tooltip>
							</Box>
							<Box
								sx={{
									borderLeftStyle: 'solid',
									borderLeftColor: '#303067',
									borderTopRightRadius: '8px',
									borderBottomRightRadius: '8px',
									borderTopColor: 'transparent',
									borderBottomColor: 'transparent',
									borderRightColor: 'transparent',
									display: 'flex',
									alignItems: 'center',
									padding: '3px',
									backgroundColor: '#1C1C46'
								}}
							>
								<CopyButton content={nodeID} borderEnable={false} />
							</Box>
						</Box>
					)}
					<Typography sx={{ fontSize: '12px', color: '#CBCBD7', marginLeft: '2rem' }}>
						Function:
					</Typography>
					<Box
						display="flex"
						sx={{
							border: '1px solid #303067',
							borderRadius: '8px',
							width: '108px',
							alignItems: 'center',
							justifyContent: 'center',
							marginLeft: '10px',
							overflow: 'hidden',
							height: '31px',
							textOverflow: 'ellipsis'
						}}
						onClick={e => e?.stopPropagation()}
					>
						<Tooltip title={name} placement="top">
							<Typography
								noWrap
								sx={{
									color: '#CBCBD7',
									fontSize: '12px',
									fontWeight: '400',
									width: '80%',
									overflow: 'hidden',
									textOverflow: 'ellipsis'
								}}
							>
								{isFetching === true ? <Skeleton variant="rounded" width={70} height={15} /> : name}
							</Typography>
						</Tooltip>
					</Box>
				</Box>
			)}
			<Tooltip title={expanded ? 'View less' : 'View more'}>
				<Box mt="4px">
					<img src={expanded ? Expanded : Collapsed} alt="expanded" />
				</Box>
			</Tooltip>
		</Box>
	);
}
export default NodeDetailViewAccordionHeader;
