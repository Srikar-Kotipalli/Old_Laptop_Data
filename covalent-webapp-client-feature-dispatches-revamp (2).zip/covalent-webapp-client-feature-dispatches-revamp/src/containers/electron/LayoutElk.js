/* eslint-disable consistent-return */
/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
/* eslint-disable import/extensions */
/* eslint-disable no-use-before-define */
/* eslint-disable no-unsafe-optional-chaining */
/* eslint-disable array-callback-return */

import ELK from 'elkjs/lib/elk.bundled.js';
import { isNode } from 'reactflow';
import { isParameter, truncate, isPostProcess } from './misc';
import { Prettify } from '../../utils/utils';

const nodeLabel = (type, name) => {
	switch (type) {
		case 'parameter':
			return name.replace(':parameter:', ' ');
		case 'electron_list':
			return name.replace(':electron_list:', 'electron list');
		case 'sublattice':
			return name.replace(':sublattice:', 'Sublattice:');
		default:
			return name;
	}
};

/**
 * Filter graph by node type.
 */
const filterGraph = (graph, nodePredicate) => {
	const nodes = graph?.nodes?.filter(nodePredicate);
	const nodeSet = new Set(nodes?.map(i => i.id));
	const links = graph?.links?.filter(
		({ source, target }) => nodeSet.has(source) && nodeSet.has(target)
	);
	return { nodes, links };
};

/**
 * Map Covalent graph nodes and links to ReactFlow graph elements.
 */
const mapGraphToElements = (
	graph,
	direction,
	showParams,
	hideLabels,
	preview,
	prettify,
	showPostProcess
) => {
	if (!showPostProcess) {
		graph = filterGraph(graph, node => !isPostProcess(node));
	}

	if (!showParams) {
		graph = filterGraph(graph, node => !isParameter(node));
	}

	const nodes = graph?.nodes?.map(node => {
		const handlePositions = getHandlePositions(direction);
		const isParam = isParameter(node);
		const name = prettify ? Prettify(node.name, node.type) : nodeLabel(node.type, node.name);
		return {
			id: String(node.id),
			type: isParam ? 'parameter' : 'electron',
			data: {
				fullName: name,
				label: truncate(name, 70),
				status: node.status,
				executor: preview ? node?.metadata.executor_name : node.executor_label,
				node_id: preview ? node.id : node.node_id,
				hideLabels,
				nodeType: node.type,
				preview,
				sublattices_id: node.sublattice_dispatch_id ? node.sublattice_dispatch_id : null,
				contains_qelectrons: node?.contains_qelectrons,
				dispatchID: node?.dispatchID
			},
			targetPosition: handlePositions.target,
			sourcePosition: handlePositions.source
		};
	});

	const edges = graph?.links?.map(edge => {
		const { source, target } = edge;
		return {
			id: `${source}-${target}-${Math.floor(Math.random() * 10000)}`,
			source: String(source),
			target: String(target),
			label: edge.edge_name,
			type: 'directed'
		};
	});
	return [...nodes, ...edges];
};

const LayoutElk = async (
	graph,
	direction,
	showParams,
	algorithm,
	hideLabels,
	preview,
	prettify,
	showPostProcess
) => {
	if (Object.entries(graph).length !== 0) {
		const elements = mapGraphToElements(
			graph,
			direction,
			showParams,
			hideLabels,
			preview,
			prettify,
			showPostProcess
		);
		const nodes = [];
		const edges = [];
		const DEFAULT_HEIGHT = 75;

		const elk = new ELK({
			defaultLayoutOptions: {
				'elk.algorithm': algorithm,
				'elk.direction': direction,
				'elk.edgeRouting': 'POLYLINE',
				'elk.layered.nodePlacement.strategy': 'SIMPLE',
				'elk.spacing.edgeEdge': hideLabels ? 10 : 20,
				'elk.spacing.nodeNode': hideLabels ? 60 : 40,
				'elk.spacing.edgeNode': hideLabels ? 60 : 40,
				'elk.spacing.edgeLabel': 10,
				'elk.layered.spacing.nodeNodeBetweenLayers': 80,
				'elk.layered.spacing.baseValue': hideLabels ? 40 : 10
			}
		});
		elements?.map(el => {
			if (isNode(el)) {
				nodes.push({
					id: el.id,
					width: el?.data?.label.length * 15,
					height: DEFAULT_HEIGHT
				});
			} else {
				edges.push({
					id: el.id,
					target: el.target,
					source: el.source
				});
			}
			return true;
		});
		const newGraph = await elk.layout({
			id: 'root',
			children: nodes,
			edges
		});
		return elements?.map(el => {
			if (isNode(el)) {
				const node = newGraph?.children?.find(n => n.id === el.id);
				if (node?.x && node?.y && node?.width && node?.height) {
					el.position = {
						x: node.x,
						y: node.y
					};
				}
			}
			return el;
		});
	}
};

/**
 * Returns source and target handle positions.
 *
 * @param {direction} 'LR'|'RL'|'TB'|'BT'
 *
 * @returns { source: <position>, target: <position> }
 */
const getHandlePositions = direction => {
	switch (direction) {
		case 'DOWN':
			return { source: 'bottom', target: 'top' };
		case 'UP':
			return { source: 'top', target: 'bottom' };
		case 'LEFT':
			return { source: 'left', target: 'right' };
		case 'RIGHT':
			return { source: 'right', target: 'left' };

		default:
			throw new Error(`Illegal direction: ${direction}`);
	}
};

export default LayoutElk;
