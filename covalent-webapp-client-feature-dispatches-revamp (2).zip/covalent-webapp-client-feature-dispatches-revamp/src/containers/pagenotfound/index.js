/* eslint-disable import/no-unused-modules */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React from 'react';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';
import '../../App.css';
import './style.css';
import covalentLogo from '../../assets/logos/covalentlogowithname.svg';
import LeftCube from '../../assets/notfound/leftCube.svg';
import RightCube from '../../assets/notfound/rightCube.svg';
import Circle from '../../assets/notfound/circleBottom.svg';
import notfoundImage from '../../assets/notfound/notfoundImage.svg';
import NavBar from '../../components/navBar/v2/index';
import LoginPopupMenu from '../../components/menu/projects/loginPopupMenu';
import routes from '../../constants/routes.json';

function PageNotFoundScreen({ returnURL, buttonText }) {
	const [open, setOpen] = React.useState(true);

	const navigate = useNavigate();

	const handleNavigate = () => {
		if (returnURL) {
			navigate(returnURL, { replace: true });
		} else {
			navigate(routes?.DASHBOARD);
		}
	};

	return (
		<>
			<Grid pt={0.03}>
				<NavBar open={open} setOpen={setOpen} />
			</Grid>
			<LoginPopupMenu />
			<Grid
				container
				spacing={3}
				direction="row"
				justifyContent="center"
				alignItems="center"
				sx={{
					height: '100vh',
					background: 'linear-gradient(180deg, #1C1C46 0%, #08081A 57.81%), url(.png)'
				}}
			>
				<Grid item xs={12} sx={{ textAlign: 'center' }}>
					<Box className="leftbox">
						<img src={LeftCube} alt="leftcube" role="presentation" />
					</Box>
					<Box className="rightbox">
						<img src={RightCube} alt="rightcube" role="presentation" />
					</Box>
					<Grid className="circleBottom" sx={{ height: '12px' }}>
						<img src={Circle} alt="circle" role="presentation" />
					</Grid>
					<Box className="circleTop">
						<img src={Circle} alt="circle" role="presentation" />
					</Box>
					<Box>
						<img src={covalentLogo} className="notfoundLogo" alt="logo" role="presentation" />
					</Box>
					<Box>
						<img
							src={notfoundImage}
							className="notfoundImage"
							alt="notfoundImage"
							role="presentation"
						/>
					</Box>
					<Box>
						<Typography
							sx={{
								fontSize: '40px',
								letterSpacing: '0.05em',
								textTransform: 'uppercase',
								color: '#F1F1F6',
								fontWeight: 900
							}}
						>
							page not found
						</Typography>
						<Button
							variant="contained"
							disableElevation
							sx={{
								padding: ' 8px 16px',
								width: '220px',
								height: '40px',
								background: '#5552FF',
								borderRadius: '70px',
								my: 3
							}}
							onClick={handleNavigate}
						>
							<Typography
								sx={{
									fontSize: '16px',
									color: '#F1F1F6'
								}}
							>
								{buttonText || 'Back to home'}
							</Typography>
						</Button>
					</Box>
				</Grid>
			</Grid>
		</>
	);
}

export default PageNotFoundScreen;
