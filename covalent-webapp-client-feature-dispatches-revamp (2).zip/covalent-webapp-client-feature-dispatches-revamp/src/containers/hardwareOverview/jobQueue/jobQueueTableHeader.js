/* eslint-disable react/jsx-no-useless-fragment */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import { TableHead, TableSortLabel } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import Box from '@mui/material/Box';
import Icon from '../../../components/icon';
import checkbox from '../../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../../assets/checkboxes/checkboxChecked.svg';
import checkboxDisabled from '../../../assets/checkboxes/checkboxdisabled.svg';
import { ProjectContext } from '../../projects/projectContext';
import { JOBQUEUE_HEADER } from '../../../constants/tableHeaderConstants';

function JobQueueTableHeader({
	checkAllHandler,
	selectAll,
	selected,
	setSelected,
	setToSort,
	toSort
}) {
	const projectContext = React.useContext(ProjectContext);
	const header = JOBQUEUE_HEADER;
	const { showArchived, addMode } = projectContext;

	return (
		<>
			{!!header.length && (
				<TableHead sx={{ '& th': { border: 0 } }}>
					<TableRow className="tableHeader" sx={{ '& td': { border: 0 } }}>
						<TableCell
							align="left"
							sx={{
								width: '3%'
							}}
						>
							<Box display="flex" flexDirection="row">
								<Checkbox
									data-testid="headerCheckbox"
									size="small"
									sx={{ padding: '5px 0px 0px 5px' }}
									checked={selectAll}
									onChange={checkAllHandler}
									icon={
										<Icon
											src={!showArchived && !addMode ? checkbox : checkboxDisabled}
											alt="checkbox"
											type="pointer"
											width="12px"
											height="12px"
										/>
									}
									checkedIcon={
										<Icon
											src={checkboxChecked}
											alt="checkboxChecked"
											type="pointer"
											width="12px"
											height="12px"
										/>
									}
									disabled={showArchived || addMode}
								/>
							</Box>
						</TableCell>
						{header.map(h => (
							<TableCell
								width={h.width}
								key={h.id}
								colSpan={h.colSpan || 1}
								align={h.align || 'center'}
								data-testid="tableHeader"
								sx={{ fontWeight: 'bold', borderBottom: 'none' }} // Apply styling here
							>
								<TableSortLabel
									active={selected === h.id}
									direction={toSort === 'asc' ? 'asc' : 'desc'}
									onClick={() => {
										setSelected(h.id);
										if (toSort === 'desc') {
											setToSort('asc');
										} else setToSort('desc');
									}}
								>
									{h.label}
								</TableSortLabel>
							</TableCell>
						))}
					</TableRow>
				</TableHead>
			)}
		</>
	);
}

export default JobQueueTableHeader;
