/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable react/jsx-no-useless-fragment */
import React from 'react';
import { useSelector } from 'react-redux';
import { Box } from '@mui/material';
import DataTable from '../../solveradmin/AccessRequests/acessRequests';

function AccessRequestComponent(props) {
	const { selected, searchValue, sort, setSelected, setSort, toFilter, setToFilter } = props;
	const { accessRequests } = useSelector(state => state.hardwareAdmin);

	return (
		<Box>
			<Box>
				<DataTable
					accessRequests={accessRequests}
					searchValue={searchValue}
					selected={selected}
					sort={sort}
					setSelected={setSelected}
					setSort={setSort}
					toFilter={toFilter}
					setToFilter={setToFilter}
					type="hardware"
				/>
			</Box>
		</Box>
	);
}

export default AccessRequestComponent;
