/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import { useSelector } from 'react-redux';
import { Grid, Typography } from '@mui/material';
// import NavBar from '../../components/navBar/v1';
import MiniDrawer from '../../components/navBar/v2/index';
import Tour from '../../components/appWalkthrough/Tour';
import LoginPopupMenu from '../../components/menu/projects/loginPopupMenu';
import { selectNavbarState } from '../../redux/navbarSlice';

function Template({ title, screen, layout }) {
	const { tourActive } = useSelector(state => state.tour);
	const isOpen = useSelector(selectNavbarState);
	// const [open, setOpen] = React.useState(true);

	return (
		<div>
			<MiniDrawer open={isOpen} />
			{/* <NavBar /> */}
			{tourActive && <Tour />}
			<LoginPopupMenu />
			<Grid
				item
				container
				pl={layout !== 'graph' ? 15 : '6.25rem'}
				pr={layout !== 'graph' ? 4.875 : '0rem'}
				pt={layout !== 'graph' ? (title ? 6.1 : 5.5) : ''}
				pb="2rem"
				sx={{ display: 'flex', flexDirection: 'column' }}
			>
				<Typography
					pl={isOpen ? 10 : 0}
					mb={3}
					sx={{
						fontSize: '32px',
						height: 'auto',
						width: 'fit-content',
						transition: 'padding-left 0.3s ease-in-out'
					}}
					id="appWalkthrough"
				>
					{title}
				</Typography>
				<Grid pl={isOpen ? 10 : 0} sx={{ transition: 'padding-left 0.3s ease-in-out' }}>
					{screen}
				</Grid>
			</Grid>
		</div>
	);
}

export default Template;
