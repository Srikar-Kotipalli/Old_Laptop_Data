/* eslint-disable array-callback-return */
/* eslint-disable react/no-unescaped-entities */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Grid, Box, Typography, SvgIcon, Select, MenuItem, Button } from '@mui/material';
import BannerRight from '../../assets/marketplace/bannerRight.svg';
import BannerLeft from '../../assets/marketplace/bannerLeft.svg';
import ascending from '../../assets/marketplace/ascending.svg';
import SearchInput from '../../components/inputBase/projects/searchInput';
// eslint-disable-next-line import/no-named-as-default
// import data from '../../components/Card/marketplace/hardwareData';
// eslint-disable-next-line import/no-named-as-default
// import solverdata from '../../components/Card/marketplace/solverData';
import MarketplaceCard from '../../components/card/marketplace/marketplaceCard';
import MarketPlaceTab from '../../components/tab/marketPlace';
import CustomTypography from '../../components/typography/marketplace/customTypography';
// eslint-disable-next-line import/no-named-as-default
// import Pagination from '@mui/material/Pagination';
// import ScrollToTopButton from '../../components/scrollToTopButton';

function CustomIcon(props) {
	return (
		// eslint-disable-next-line react/jsx-props-no-spreading
		<SvgIcon {...props} style={{ transform: 'translateY(20%)' }}>
			<svg
				width="16"
				height="16"
				viewBox="0 0 16 22"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					d="M8 10.9998L3 5.9998L3.7 5.2998L8 9.59981L12.3 5.2998L13 5.9998L8 10.9998Z"
					fill="#CBCBD7"
				/>
			</svg>
		</SvgIcon>
	);
}

function MarketPlaceScreen() {
	const { data } = useSelector(state => state.marketplace);
	const { solverdata } = useSelector(state => state.marketplace);
	const allData = [...data.details, ...solverdata.details];
	const categories = [
		{ id: 1, category: 'All', status: true },
		{ id: 2, category: 'API Management', status: false },
		{ id: 3, category: 'Finance', status: false },
		{ id: 4, category: 'Code Quality', status: false },
		{ id: 5, category: 'Code Review', status: false },
		{ id: 6, category: 'Healthcare', status: false },
		{ id: 7, category: 'Dependency Management', status: false },
		{ id: 8, category: 'Portfolio', status: false },
		{ id: 9, category: 'IDEs', status: false },
		{ id: 10, category: 'Learning', status: false },
		{ id: 11, category: 'Localization', status: false },
		{ id: 12, category: 'Mobile', status: false },
		{ id: 13, category: 'Project Management', status: false },
		{ id: 14, category: 'Security', status: false },
		{ id: 15, category: 'Monitoring', status: false }
	];

	const [searchKey, setSearchKey] = useState('');
	const [selected, setSelected] = useState('last_updated');
	const [sort, setSort] = useState('asc');
	const [value, setValue] = useState('All');
	const [sortedData, setSortedData] = useState(allData);
	const [category, setCategory] = useState('All');

	const filterCategories = item => {
		// eslint-disable-next-line no-use-before-define
		setCategory(item.category);
	};

	const handleChange = (_e, val) => {
		setValue(val);
	};

	useEffect(() => {
		const filterData = () => {
			let filteredData = [];

			if (value === 'All') {
				filteredData = [...allData];
			} else if (value === 'Hardware') {
				filteredData = [...data.details];
			} else {
				filteredData = [...solverdata.details];
			}

			if (category !== 'All') {
				filteredData = filteredData.filter(item => item.category === category);
			}

			if (searchKey !== '') {
				const searchKeyLC = searchKey.toLowerCase();
				filteredData = filteredData.filter(
					item =>
						item.name.toLowerCase().includes(searchKeyLC) ||
						item.technology.toLowerCase().includes(searchKeyLC)
				);
			}

			return filteredData;
		};

		const filteredData = filterData();

		const column = 'downloads';
		const sortedDatas = [...filteredData];
		sortedDatas.sort((a, b) => {
			if (sort === 'asc') {
				return a[column] - b[column];
			}
			return b[column] - a[column];
		});

		setSortedData(sortedDatas);
	}, [searchKey, selected, sort, category, value]);

	const handleSortClick = () => {
		setSort(sort === 'asc' ? 'dsc' : 'asc');
	};

	const cancelSearch = () => {
		setSearchKey('');
	};

	const selectionChangeHandler = event => {
		setSelected(event.target.value);
	};

	return (
		<>
			<Box
				mt={2}
				sx={{
					height: '190px',
					width: '100%',
					border: '1px solid #5552FF',
					borderRadius: '8px',
					display: 'grid',
					placeItems: 'center'
				}}
			>
				<Grid container>
					<Grid
						item
						xs={3}
						sx={{ display: 'grid', placeItems: 'flex-start', paddingLeft: '1.7rem' }}
					>
						<img style={{ height: '100%' }} src={BannerLeft} alt="leftBanner" />
					</Grid>
					<Grid item xs={6} sx={{ display: 'grid', placeItems: 'center', textAlign: 'center' }}>
						<Typography sx={{ color: '#FFFFFF', fontSize: '32px', fontWeight: '500' }}>
							Covalent Marketplace
						</Typography>
						<Box sx={{ fontSize: '14px' }}>
							<Box sx={{ textAlign: 'center', fontSize: '14px' }}>
								A trove of advanced solvers and hardware at your service
							</Box>
						</Box>
					</Grid>
					<Grid
						item
						xs={3}
						sx={{ display: 'grid', placeItems: 'flex-end', paddingRight: '1.7rem' }}
					>
						<img src={BannerRight} alt="bannerRight" />
					</Grid>
				</Grid>
			</Box>
			<Grid
				container
				direction="row"
				justifyContent="space-between"
				alignItems="center"
				mt={12}
				width="100%"
			>
				<SearchInput
					sx={{
						border: '1px solid #303067',
						borderRadius: '20px',
						width: '260px',
						height: '32px',
						'&.Mui-focused ': {
							border: '1px solid #6473ff'
						},
						'& ::placeholder': {
							color: '#CBCBD7'
						}
						// mt:'10rem'
					}}
					value={searchKey || ''}
					onChange={e => setSearchKey(e.target.value)}
					cancelSearch={cancelSearch}
				/>
				<Box sx={{ display: 'flex' }}>
					<Box display="flex" direction="row" spacing={3}>
						<Select
							IconComponent={CustomIcon}
							value={selected}
							onChange={selectionChangeHandler}
							sx={{
								fontSize: '14px',
								background: '#08081A',
								borderRadius: '200px',
								padding: '0rem 1rem',
								height: '32px',
								width: '139px',
								color: '#BEBEBE',
								'.MuiOutlinedInput-notchedOutline': {
									borderColor: '#6473FF'
								},
								'&.Mui-focused .MuiOutlinedInput-notchedOutline': {
									borderColor: '#6473FF'
								},
								'&:hover .MuiOutlinedInput-notchedOutline': {
									borderColor: '#6473FF'
								},
								'.MuiSvgIcon-root ': {
									fill: 'transparent !important'
								}
							}}
						>
							<MenuItem sx={{ fontSize: '14px' }} value="last_updated">
								Last Updated
							</MenuItem>
							<MenuItem sx={{ fontSize: '14px' }} value="popular">
								Popular
							</MenuItem>
						</Select>
						<Button
							variant="outlined"
							sx={{
								'&:hover': {
									backgroundColor: theme => theme.palette.background.covalentPurple,
									color: '#FFFFFF',
									borderRadius: '25px',
									borderColor: theme => theme.palette.background.blue05
								},
								display: 'flex',
								justifyContent: 'center',
								borderRadius: '25px',
								height: '32px',
								width: '121px',
								marginLeft: '2rem'
							}}
							endIcon={
								<img
									src={ascending}
									alt={sort}
									style={{ transform: sort === 'dsc' ? 'rotate(180deg)' : '' }}
								/>
							}
							onClick={handleSortClick}
						>
							<Typography variant="h2" pt={0}>
								{sort === 'asc' ? 'Ascending' : 'Descending'}
							</Typography>
						</Button>
					</Box>
				</Box>
			</Grid>
			<Grid container direction="row" sx={{ marginTop: '2rem', ml: 1, mb: '30px' }}>
				<Grid item xs={10} sx={{ border: '1px solid #303067', borderRadius: '8px' }}>
					<Grid sx={{ margin: '2rem' }}>
						<Grid sx={{ marginLeft: '-19px' }}>
							<MarketPlaceTab value={value} onChange={handleChange} />
						</Grid>
						<Grid sx={{ overflow: 'auto', height: '800px', marginTop: '20px' }}>
							<Grid
								container
								rowSpacing={{ lg: 3, xl: 4, xxl: 5 }}
								columnSpacing={{ lg: 3, xl: 4, xxl: 5 }}
								sx={{ padding: '0 1rem 2rem 1rem' }}
							>
								{sortedData.map(i => (
									<Grid item xs={6} sm={4} md={4} lg={4} xl={4} xxl={4} key={i.id}>
										<MarketplaceCard
											technology={i.technology}
											downloads={i.downloads}
											per={i.per}
											name={i?.name}
											price={i.price}
											content={i.content}
											cardimage={i.cardimage}
											hardwareimage={i?.hardwareimage}
											solverImage={i?.solverImage}
											statusimage={i.statusimage}
											chipdata={i.chipdata}
											tabvalue={value}
											hardwareId={i.hardwareId}
											solverId={i.solverId}
											type={i.type}
											category={i.category}
										/>
									</Grid>
								))}
								{sortedData.length < 1 && (
									<Box id="noRecords" style={{ margin: '3rem 0 3rem 2.75rem' }}>
										<Typography>No records found</Typography>
									</Box>
								)}
							</Grid>
						</Grid>
					</Grid>
				</Grid>
				<Grid item xs={2} sm={2} md={2} lg={2} xl={2} xxl={2} sx={{ pl: { sm: 2, lg: 4, xl: 8 } }}>
					<Typography fontSize="18px" color="#ffffff" sx={{ marginBottom: '20px' }}>
						CATEGORIES
					</Typography>

					{categories.map(item => (
						<CustomTypography
							key={item.id}
							category={category}
							content={item.category}
							status={item.status}
							onClick={() => filterCategories(item)}
						/>
					))}
				</Grid>
			</Grid>
		</>
	);
}
export default MarketPlaceScreen;
