/* eslint-disable max-len */
/* eslint-disable import/prefer-default-export */
/* eslint-disable import/no-unused-modules */
export const headData = {
	name: 'Hardware Admin',
	label: 'Ik',
	desc: 'Hardware created by you will be available in this space',
	count: '400',
	created_date: '2-10-2022',
	last_build: '5-5-2023'
};

export const headSolverData = {
	name: 'Solvers',
	label: 'Ik',
	desc: 'Solvers created by you will be available in this space',
	created_date: '2-10-2022',
	last_build: '5-5-2023'
};

export const headDataSolverAdmin = {
	name: 'Solver Admin',
	label: 'Ik',
	desc: 'Solvers created by you will be available in this space',
	created_date: '2-10-2022',
	last_build: '5-5-2023'
};

export const descriptionData = {
	data: `Covalent is Teradata's design system used to create Teradata branded experiences. This space is intended to be used to support developers creating coded experiences for Teradata products. Currently we are only supporting angular and a library of web components.
&nbsp;

&nbsp;

Vision: To build an atomic, reusable component platform for Teradata to consume, while collaborating in an open source model.
&nbsp;

&nbsp;


## Setup

 - Ensure you have Node 12.20.x + and NPM 6 + installed.
 - Install Angular CLI npm i - g @angular/cli
 - Install Typescript npm i - g typescript
 - Install Node packages npm ci
 - Run local build npm run start
 &nbsp;

 &nbsp;
 - [Getting Started](https://github.com/Teradata/covalent/blob/main/docs/GETTING_STARTED.md)
 - [Contributing Guidelines](https://github.com/Teradata/covalent/blob/main/docs/CONTRIBUTING.md)
 - [Developer Guide](https://github.com/Teradata/covalent/blob/main/docs/DEVELOPER_GUIDE.md)
 - [Upgrading](https://github.com/Teradata/covalent/blob/main/docs/UPGRADE.md)
 - [Releasing](https://github.com/Teradata/covalent/blob/main/docs/RELEASE.md)
 - [Changelog](https://github.com/Teradata/covalent/blob/main/docs/CHANGELOG.md)
 - [StackBlitz Template](https://stackblitz.com/edit/covalent)
 - [Plunker Template](https://plnkr.co/edit/XhSrUWBw2RhCkXPoE4fn)`
};

export const priceTableData = [
	{
		id: 1,
		configuration: 'per vCPU per hour',
		price: '$0.0124402'
	},
	{
		id: 2,
		configuration: 'per vCPU per hour',
		price: '$0.0124402'
	},
	{
		id: 3,
		configuration: 'per vCPU per hour',
		price: '$0.0124402'
	},
	{
		id: 4,
		configuration: 'per vCPU per hour',
		price: '$0.0124402'
	},
	{
		id: 5,
		configuration: 'per vCPU per hour',
		price: '$0.0124402'
	}
];

export const ioData = {
	data: `- uses: actions/setup-node@v3
 with:
   # Version Spec of the version to use in SemVer notation.
   # It also emits such aliases as lts, latest, nightly and canary builds
   # Examples: 12.x, 10.15.1, >=10.15.0, lts/Hydrogen, 16-nightly, latest, node
   node-version: ''

   # File containing the version Spec of the version to use.  Examples: .nvmrc, .node-version, .tool-versions.
   # If node-version and node-version-file are both provided the action will use version from node-version. 
   node-version-file: ''

   # Set this option if you want the action to check for the latest available version 
   # that satisfies the version spec.
   # It will only get affect for lts Nodejs versions (12.x, >=10.15.0, lts/Hydrogen). 
   # Default: false
   check-latest: false

   # Target architecture for Node to use. Examples: x86, x64. Will use system architecture by default.
   # Default: ''. The action use system architecture by default 
   architecture: ''

   # Used to pull node distributions from https://github.com/actions/node-versions. 
   # Since there's a default, this is typically not supplied by the user. 
   # When running this action on github.com, the default value is sufficient. 
   # When running on GHES, you can pass a personal access token for github.com if you are experiencing rate limiting.
   #
   # We recommend using a service account with the least permissions necessary. Also
   # when generating a new PAT, select the least scopes necessary.
   #
   # [Learn more about creating and using encrypted secrets](https://help.github.com/en/actions/automating-your-workflow-with-github-actions/creating-and-using-encrypted-secrets)
   #
`
};
