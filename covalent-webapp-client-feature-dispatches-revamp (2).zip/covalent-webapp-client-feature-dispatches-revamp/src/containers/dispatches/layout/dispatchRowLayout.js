/* eslint-disable consistent-return */
/* eslint-disable no-unused-vars */
/* eslint-disable import/no-unused-modules */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import moment from 'moment';
import { Grid, Box, Chip, Typography, TableRow } from '@mui/material';
import { makeStyles } from '@mui/styles';
import { Link } from 'react-router-dom';
// import './style.css';
import editName from '../../../assets/actions/editName.svg';
import redispatchEnabled from '../../../assets/redispatchEnabled.svg';
import redispatchDisabled from '../../../assets/redispatchDisabled.svg';
import CopyButton from '../../../components/copyButton';
import { capitalizeName, dateFormatter } from '../../../utils/utils';
import { dpexpStatusIcons } from '../../../utils/statusIcons';
import RuntimeTooltip from '../../../components/tooltip/runTimeTooltip';
import EllipsisDefaultTooltip from '../../../components/tooltip/ellipsisTooltip';
import EditInputBase from '../../../components/inputBase/dispatches/editInputBase';
import Runtime from '../../../utils/Runtime';
import OverflowTooltip from '../../../components/tooltip/overflowTooltip';
import DispatchIO from './dispatchIO';
import Icon from '../../../components/icon';

const useStyles = makeStyles({
	table: {
		minWidth: 650
	},
	sticky: {
		position: 'sticky',
		left: 0,
		background: 'rgba(28, 28, 70,0.3)',
		// background: 'rgba(28, 28, 70)',
		borderLeft: '1px solid #303067 !important',
		borderRight: '1px solid #303067 !important'
	}
});

const getStatusBgColor = status => {
	// eslint-disable-next-line default-case
	switch (status) {
		case 'RUNNING':
			return 'rgba(218, 195, 255, 0.10)';
		case 'COMPLETED':
			return 'rgba(85, 216, 153, 0.10)';
		case 'FAILED':
			return 'rgba(255, 100, 100, 0.10)';
		case 'NEW_OBJECT':
			return 'rgba(255, 193, 100, 0.10)';
	}
};

const getStatusBorderColor = status => {
	// eslint-disable-next-line default-case
	switch (status) {
		case 'RUNNING':
			return '0.5px solid rgba(173, 123, 255, 0.70)';
		case 'COMPLETED':
			return '0.2px solid rgba(85, 216, 153, 0.70)';
		case 'FAILED':
			return '0.2px solid rgba(255, 100, 100, 0.70)';
		case 'NEW_OBJECT':
			return '0.2px solid rgba(255, 193, 100, 0.70)';
	}
};

export default function DispatchRowLayout(props) {
	const { dispatch, onClickEditIcon, triggerEditLatticeName, keyy } = props;
	const classes = useStyles();

	return (
		// eslint-disable-next-line react/jsx-no-useless-fragment
		<>
			<TableCell
				className={classes.sticky}
				align="left"
				key="id"
				sx={{
					minWidth: 150,
					borderTop: dispatch?.starting && '1px solid #303067 !important',
					borderTopLeftRadius: dispatch?.starting ? '4px !important' : '0px !important',
					borderTopRightRadius: dispatch?.starting ? '4px !important' : '0px !important',
					borderBottom: dispatch?.ending && '1px solid #303067 !important',
					borderBottomLeftRadius: dispatch?.ending ? '4px !important' : '0px !important',
					borderBottomRightRadius: dispatch?.ending ? '4px !important' : '0px !important'
				}}
			>
				<Box display="flex" flexDirection="row">
					<Box display="flex">
						<OverflowTooltip title={dispatch?.dispatch_id} length={10} position="top-start" />
						<CopyButton content={dispatch?.dispatch_id} />
					</Box>
				</Box>
			</TableCell>
			<TableCell align="left" key="name" sx={{ minWidth: 150 }}>
				<Box marginLeft={1}>
					{dispatch?.isAdd ? (
						<EditInputBase editLatticeName={triggerEditLatticeName} dispatch={dispatch} />
					) : (
						<Box display="flex">
							<Link
								style={{ color: '#CBCBD7', textDecoration: 'none' }}
								to={`/graph/${dispatch?.dispatch_id}`}
								state={{}}
							>
								{/* <Grid container sx={{ width: '100%' }}> */}
								<OverflowTooltip title={dispatch?.name} length={10} position="top-start" />
								{/* </Grid> */}
							</Link>
							<Icon
								src={editName}
								alt="editName"
								clickHandler={e => {
									e?.stopPropagation();
									onClickEditIcon(dispatch?.dispatch_id);
								}}
							/>
						</Box>
					)}
				</Box>
			</TableCell>
			<TableCell
				align="left"
				// key="redispatch"
				sx={{ minWidth: 100 }}
			>
				<Box pl={4}>
					<Icon src={dispatch?.is_redispatch ? redispatchEnabled : redispatchDisabled} />
				</Box>
			</TableCell>
			<TableCell align="left" key="runtime" sx={{ minWidth: 150 }}>
				<Chip
					variant="small"
					icon={dpexpStatusIcons({ status: dispatch?.status, width: '14px', height: '14px' })}
					sx={{
						backgroundColor: getStatusBgColor(dispatch?.status),
						border: getStatusBorderColor(dispatch?.status),
						padding: '2px 6px',
						height: 'auto',
						borderRadius: '4px'
					}}
					label={
						dispatch?.status === 'RUNNING' && dispatch?.started_at && dispatch?.runtime ? (
							<Runtime
								startTime={dispatch?.started_at}
								runTime={moment.duration(dispatch?.runtime).asSeconds()}
							/>
						) : (
							<RuntimeTooltip
								value={moment.duration(dispatch?.runtime).asSeconds()}
								placement="top"
							/>
						)
					}
				/>
			</TableCell>
			<TableCell align="left" key="started_at" sx={{ minWidth: 150 }}>
				{dispatch?.started_at ? (
					<Box display="flex">
						<Typography sx={{ fontSize: '14px', color: '#CBCBD7', width: '3rem' }}>
							{dateFormatter(`${dispatch?.started_at}Z`, 'HH:mm:ss')}
						</Typography>
						<Typography sx={{ fontSize: '14px', color: '#86869A', ml: 2 }}>
							{dateFormatter(`${dispatch?.started_at}Z`, 'DD MMM')}
						</Typography>
					</Box>
				) : (
					''
				)}
			</TableCell>
			<TableCell align="left" key="updated_at" sx={{ minWidth: 150 }}>
				{dispatch?.updated_at ? (
					<Box display="flex">
						<Typography sx={{ fontSize: '14px', color: '#CBCBD7', width: '3rem' }}>
							{dateFormatter(`${dispatch?.updated_at}Z`, 'HH:mm:ss')}
						</Typography>
						<Typography sx={{ fontSize: '14px', color: '#86869A', ml: 2 }}>
							{dateFormatter(`${dispatch?.updated_at}Z`, 'DD MMM')}
						</Typography>
					</Box>
				) : (
					''
				)}
			</TableCell>
			<TableCell align="left" key="input" sx={{ minWidth: 250 }}>
				<DispatchIO isLoading={false} value="{a, b}" copyValue="{a, b}" />
			</TableCell>
			<TableCell align="left" key="output" sx={{ minWidth: 250 }}>
				<DispatchIO isLoading={false} value="{a, b}" copyValue="{a, b}" />
			</TableCell>
			<TableCell align="left" key="compute_cost" sx={{ minWidth: 150 }}>
				<Typography sx={{ fontSize: '14px' }}>
					{dispatch?.charge_micro_dollars &&
					!Number.isNaN(parseInt(dispatch?.charge_micro_dollars, 10))
						? `$${(parseInt(dispatch?.charge_micro_dollars, 10) / 1000000)?.toFixed(2)} USD`
						: '-'}
				</Typography>
			</TableCell>
		</>
	);
}
