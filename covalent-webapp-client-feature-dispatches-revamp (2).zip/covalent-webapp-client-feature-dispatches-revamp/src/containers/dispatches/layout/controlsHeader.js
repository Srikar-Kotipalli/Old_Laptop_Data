/* eslint-disable no-unused-vars */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import { Box, Grid, Tabs, Tab, tabsClasses } from '@mui/material';
import SearchInput from '../../../components/inputBase/projects/searchInput';
import { dpexpStatusIcons } from '../../../utils/statusIcons';

function ControlsHeader({
	width,
	setSortBy,
	searchKey,
	setSearchKey,
	filterValue,
	setFilterValue,
	setPage,
	setData
}) {
	// cancel search
	const cancelSearch = () => {
		setSearchKey('');
	};

	const handleChange = newValue => {
		setData([]);
		if (newValue === filterValue) setFilterValue(false);
		else setFilterValue(newValue);
		setPage(0);
	};

	return (
		<Grid
			container
			direction="row"
			justifyContent="space-between"
			alignItems="center"
			mt={3}
			width="100%"
		>
			<Box
				sx={{
					maxWidth: { xs: 320, sm: 480 }
				}}
			>
				<Tabs
					value={filterValue}
					variant="scrollable"
					scrollButtons
					aria-label="scrollable filter chips"
					sx={{
						alignItems: 'center',
						border: '1px solid 303067',
						borderRadius: '8px',
						[`& .${tabsClasses.scrollButtons}`]: {
							'&.Mui-disabled': { opacity: 0.3 },
							borderRadius: '0px 8px 8px 0px'
						},
						'& .MuiTab-root.Mui-selected': {
							backgroundColor: '#1C1C46',
							color: '#CBCBD7 !important'
						},
						'& .MuiButtonBase-root.MuiTab-root': {
							border: '1px solid transparent',
							borderRadius: '8px',
							marginRight: '8px',
							height: '24px !important',
							minHeight: '24px',
							padding: '6px',
							fontSize: '12px',
							color: '#CBCBD7',
							'&:hover': {
								border: '1px solid #303067',
								backgroundColor: '#1C1C46'
							},
							'&.Mui-selected': {
								border: '1px solid #303067',
								backgroundColor: '#1C1C46'
							}
						}
					}}
				>
					<Tab
						icon={dpexpStatusIcons({ status: 'COMPLETED', width: '14px' })}
						iconPosition="start"
						label="Completed (100)"
						value="COMPLETED"
						onClick={() => handleChange('COMPLETED')}
					/>
					<Tab
						icon={dpexpStatusIcons({ status: 'FAILED', width: '14px' })}
						iconPosition="start"
						label="Failed (90)"
						value="FAILED"
						onClick={() => handleChange('FAILED')}
					/>
					<Tab
						icon={dpexpStatusIcons({ status: 'RUNNING', width: '14px' })}
						iconPosition="start"
						label="Running (110)"
						value="RUNNING"
						onClick={() => handleChange('RUNNING')}
					/>
					<Tab
						icon={dpexpStatusIcons({ status: 'NEW_OBJECT', width: '14px' })}
						iconPosition="start"
						label="Starting (10)"
						value="NEW_OBJECT"
						onClick={() => handleChange('NEW_OBJECT')}
					/>
				</Tabs>
			</Box>
			<SearchInput
				sx={{
					border: theme => `1px solid ${theme?.palette?.background?.blue03}`,
					borderRadius: '20px',
					width: '260px',
					height: '32.69px',
					'&.Mui-focused ': {
						border: theme => `1px solid ${theme.palette.background.blue05}`
					},
					'&:hover': {
						border: theme => `1px solid ${theme.palette.text.gray04}`
					}
					// mt:'10rem'
				}}
				value={searchKey || ''}
				onChange={e => setSearchKey(e?.target?.value)}
				cancelSearch={cancelSearch}
			/>
		</Grid>
	);
}

export default ControlsHeader;
