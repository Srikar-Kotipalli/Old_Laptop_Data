/* eslint-disable consistent-return */
/* eslint-disable no-unused-vars */
/* eslint-disable import/no-unused-modules */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import { Grid, Box, Chip } from '@mui/material';
import { makeStyles } from '@mui/styles';
import { Link } from 'react-router-dom';
// import './style.css';
import editName from '../../../assets/actions/editName.svg';
import CopyButton from '../../../components/copyButton';
import { capitalizeName, dateFormatter } from '../../../utils/utils';
import { dpexpStatusIcons } from '../../../utils/statusIcons';
import RuntimeTooltip from '../../../components/tooltip/runTimeTooltip';
import EllipsisDefaultTooltip from '../../../components/tooltip/ellipsisTooltip';
import EditInputBase from '../../../components/inputBase/dispatches/editInputBase';
import Runtime from '../../../utils/Runtime';
import OverflowTooltip from '../../../components/tooltip/overflowTooltip';
import DispatchIO from './dispatchIO';
import Icon from '../../../components/icon';

const useStyles = makeStyles({
	table: {
		minWidth: 650
	},
	sticky: {
		position: 'sticky',
		left: 0,
		// zIndex: 50000,
		// background: 'rgba(28, 28, 70,0.3)',
		// boxShadow: "1px",
		borderBottomLeftRadius: '0px !important',
		borderTopLeftRadius: '0px !important'
	}
});

export default function TitleRowLayout(props) {
	const { title } = props;
	const classes = useStyles();

	return (
		// eslint-disable-next-line react/jsx-no-useless-fragment
		<>
			<TableCell
				className={classes.sticky}
				align="left"
				// key="id"
				sx={{ minWidth: 150 }}
			>
				<Box display="flex" flexDirection="row">
					<OverflowTooltip
						title={title}
						length={16}
						position="top-start"
						width="100%"
						fontSize="14px"
						fontWeight={600}
					/>
				</Box>
			</TableCell>
			<TableCell
				align="left"
				// key="name"
				sx={{ minWidth: 150 }}
			/>
			<TableCell
				align="left"
				// key="redispatch"
				sx={{ minWidth: 100 }}
			/>
			<TableCell
				align="left"
				// key="runtime"
				sx={{ minWidth: 150 }}
			/>
			<TableCell
				align="left"
				// key="started_at"
				sx={{ minWidth: 150 }}
			/>
			<TableCell
				align="left"
				// key="updated_at"
				sx={{ minWidth: 150 }}
			/>
			<TableCell
				align="left"
				// key="input"
				sx={{ minWidth: 250 }}
			/>
			<TableCell
				align="left"
				// key="output"
				sx={{ minWidth: 250 }}
			/>
			<TableCell
				align="left"
				// key="compute_cost"
				sx={{ minWidth: 100 }}
			/>
		</>
	);
}
