import { useEffect, useRef } from 'react';

export default function useUpdateEffect(callback, dependencies) {
	const firstRenderRef = useRef(true);

	useEffect(() => {
		if (firstRenderRef.current) {
			firstRenderRef.current = false;
			return;
		}
		// eslint-disable-next-line
		return callback();
	}, dependencies);
}
