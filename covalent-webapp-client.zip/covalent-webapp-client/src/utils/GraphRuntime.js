/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import * as React from 'react';
import { Typography } from '@mui/material';
import { differenceInMilliseconds, isValid } from 'date-fns';
import humanizeDuration from 'humanize-duration';

// eslint-disable-next-line import/no-unused-modules
export const humanize = humanizeDuration.humanizer({
	largest: 3,
	round: true,
	delimiter: ' ',
	spacer: '',
	units: ['h', 'm', 's'],
	language: 'shortEn',
	languages: {
		shortEn: {
			y: () => 'y',
			mo: () => 'mo',
			w: () => 'w',
			d: () => 'd',
			h: () => 'h',
			m: () => 'm',
			s: () => 's',
			ms: () => 'ms'
		}
	}
});

function GraphRuntime({ startTime, endTime, sx }) {
	const startTimeConvert = `${startTime}Z`;
	const endTimeConvert = `${endTime}Z`;
	const startTimeToLocal = new Date(startTimeConvert);
	const endTimeToLocal = new Date(endTimeConvert);

	if (!isValid(endTimeToLocal)) {
		return <RuntimeTicker sx={sx} startTime={startTimeToLocal} />;
	}
	return <RuntimeConst sx={sx} startTime={startTimeToLocal} endTime={endTimeToLocal} />;
}

function RuntimeConst({ startTime, endTime, sx, className }) {
	const diffMs = differenceInMilliseconds(startTime, endTime);
	return (
		<Typography data-testid="runTime" sx={sx} className={className}>
			{humanize(diffMs)}
		</Typography>
	);
}

function RuntimeTicker({ startTime, sx }) {
	const [now, setNow] = React.useState(new Date());

	React.useEffect(() => {
		const intervalId = setInterval(() => {
			setNow(new Date());
		}, 1000);

		return () => {
			if (intervalId) {
				clearInterval(intervalId);
			}
		};
	});

	return <RuntimeConst sx={sx} startTime={startTime} endTime={now} />;
}

// eslint-disable-next-line import/no-unused-modules
export default GraphRuntime;
