/* eslint-disable eqeqeq */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable react/jsx-props-no-spreading */
/* eslint-disable no-unused-expressions */
/* eslint-disable no-unsafe-optional-chaining */
import React, { useState, useEffect, useRef } from 'react';
import { Auth } from 'aws-amplify';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Slide from '@mui/material/Slide';
import { TableContainer, TableHead, Tooltip } from '@mui/material';
import Divider from '@mui/material/Divider';
import ButtonGroup from '@mui/material/ButtonGroup';
import Avatar from '@mui/material/Avatar';
import AvatarGroup from '@mui/material/AvatarGroup';
import Button from '@mui/material/Button';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import TableSortLabel from '@mui/material/TableSortLabel';
import { useSelector } from 'react-redux';
import shareIcon from '../../../assets/shareIcon.svg';
import arrowUpIcon from '../../../assets/arrows/caretUp.svg';
import Icon from '../../icon/index';
import { statusIcon, statusColor } from '../../icon/misc';
import DispatchIcon from '../../icon/dispatchIcon';
import DropDownTab from '../../tabs/graphLayout/dropDownTab';
import Overview from '../dispatchOverview';
import SharePopup from '../sharePopup';
import userMultipleIcon from '../../../assets/icons/userMultiple.svg';
import './style.css';
import EllipsisTooltip from '../../tooltip/ellipsisTooltip';
import { SUBLATTICE_HEADER } from '../../../constants/tableHeaderConstants';
import {
	getSublatticesByDispatchID,
	getDispatchByInput,
	getCodeByLattice
} from '../../../api/graph/graphLayoutApi';
import { Capitalize } from '../../../utils/utils';
import Notes from '../../notes/projects';
import useDidMountEffect from '../../../utils/useDidMountEffect';
import SolverViewPopup from '../solverPopup';

function CustomAvatar(props) {
	const { user, variant, index } = props;

	const avatarColors = ['#AD7BFF', '#6D7CFF', '#8B31FF', '#464660', '#998CEB'];

	function stringAvatar(name) {
		return {
			sx: {
				bgcolor: avatarColors[index],
				width: '1.75rem',
				height: '1.75rem',
				fontSize: '12px',
				color: theme => theme.palette.text.secondary
			},
			children: variant === 'total' ? ` +${name}` : `${name.toUpperCase().slice(0, 1)}`
		};
	}
	return (
		<Tooltip title={variant === 'total' ? ` +${user}` : `${user}`}>
			<Avatar {...stringAvatar(user)} />
		</Tooltip>
	);
}

function LatticeTopBar(props) {
	const {
		latticeDetails,
		dispatchID,
		userList,
		openShareLoader,
		userId,
		setOpenShareLoader,
		setTriggerShare
	} = props;
	// Live refresh
	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);
	const socketData = useSelector(({ socket }) => socket.socketData);
	const [dropDownTabvalue, setDropDownTabvalue] = useState('overview');
	const [dropDownEnable, setDropDownEnable] = useState(true);
	const [sharePopupEnable, setSharePopupEnable] = useState(false);
	const [enableShareOption, setEnableShareOption] = useState(false);
	const header = SUBLATTICE_HEADER;
	const [sortColumn, setSortColumn] = useState('completed_task_num');
	const [sortOrder, setSortOrder] = useState('desc');
	const pageState = useState(0);
	const page = pageState[0];
	const [sublatticeDetails, setSublatticeDetails] = useState([]);
	const [result, setResult] = useState();
	const [resultObject, setResultObject] = useState();
	const [codeOutput, setCodeOutput] = useState();
	const [codeObject, setCodeObject] = useState();
	const listInnerRef = useRef();
	const [description, setDescription] = useState();
	const [inputs, setInputs] = useState();
	const [errorValue, setError] = useState();
	const [userEmail, setUserEmail] = useState();
	const [totalCount, setTotalCount] = useState(0);
	const [count, setCount] = useState(5);
	const [moveLoader, setMoveLoader] = useState(false);
	const containerRef = React.useRef(null);
	const [solverPopupEnable, setSolverPopupEnable] = useState(false);

	useEffect(() => {
		Auth.currentAuthenticatedUser().then(user => {
			const res = user?.attributes;
			const ownerID = res && res['custom:userID'];
			const ownerEmail = res?.email;
			setUserEmail(ownerEmail);
			if (ownerID === userId) setEnableShareOption(true);
		});
	}, [userId]);

	const handleDropdownTabChange = (_e, newValue) => {
		setDropDownTabvalue(newValue);
	};

	const dropdownEnalbleFn = () => {
		setDropDownEnable(!dropDownEnable);
	};

	const shareFn = () => {
		setSharePopupEnable(!sharePopupEnable);
	};

	const sharePopupClose = () => {
		setSharePopupEnable(false);
	};

	const dropDownClose = () => {
		setDropDownEnable(false);
	};

	const getSublatticesApi = value => {
		const parameter = {
			count,
			pageValue: page,
			dispatch_Id: dispatchID,
			direction: sortOrder,
			sort: sortColumn
		};
		if (value !== 'sorting') setMoveLoader(true);
		getSublatticesByDispatchID(parameter)
			.then(response => {
				setSublatticeDetails(response?.records);
				setTotalCount(response?.metadata?.total_count);
				setMoveLoader(false);
			})
			.catch(error => {
				console.log(error);
				setMoveLoader(false);
			});
	};
	const copyObject = obj => {
		return `
			import pickle
			import base64		
			string_object = "${obj}"		
			decoded_object = base64.b64decode(string_object)		
			deserialized_object = pickle.loads(decoded_object)		
			print(deserialized_object)`;
	};

	const getResultsByLattice = () => {
		getDispatchByInput(dispatchID, 'result', 'string')
			.then(response => {
				setResult(response.toString());
			})
			.catch(error => {
				console.log(error);
			});

		getDispatchByInput(dispatchID, 'inputs', 'string')
			.then(response => {
				setInputs(response);
			})
			.catch(error => {
				console.log(error);
			});

		if (latticeDetails?.status === 'FAILED') {
			getDispatchByInput(dispatchID, 'error')
				.then(response => {
					setError(response);
				})
				.catch(error => {
					console.log(error);
				});
		}

		getDispatchByInput(dispatchID, 'result', 'object')
			.then(response => {
				setResultObject(copyObject(response));
			})
			.catch(error => {
				console.log(error);
			});
	};

	const getCodeByLatticeApi = () => {
		getCodeByLattice(dispatchID, '__doc__')
			.then(response => {
				setDescription(response);
			})
			.catch(error => {
				console.log(error);
			});

		getCodeByLattice(dispatchID, 'workflow_function_string')
			.then(response => {
				setCodeOutput(response);
			})
			.catch(error => {
				console.log(error);
			});

		getCodeByLattice(dispatchID, 'workflow_function', 'object')
			.then(response => {
				setCodeObject(copyObject(response));
			})
			.catch(error => {
				console.log(error);
			});
	};

	const onSort = column => {
		const isAsc = sortColumn === column && sortOrder === 'asc';
		setSortOrder(isAsc ? 'desc' : 'asc');
		setSortColumn(column);
	};

	useEffect(() => {
		getSublatticesApi();
		getResultsByLattice();
		getCodeByLatticeApi();
	}, []);

	useDidMountEffect(() => {
		if (socketData?.dispatch_id === dispatchID) {
			getSublatticesApi();
			getResultsByLattice();
			getCodeByLatticeApi();
		}
	}, [liveRefresh]);

	useEffect(() => {
		if (listInnerRef.current) {
			getSublatticesApi();
		}
	}, [page, count]);

	useEffect(() => {
		if (listInnerRef.current) {
			getSublatticesApi('sorting');
		}
	}, [sortOrder]);

	// temporarily disabled the feature
	// const convertSolver = () => {
	// 	setSolverPopupEnable(true);
	// };

	const convertSolverClose = () => {
		setSolverPopupEnable(false);
	};

	return (
		<Grid
			container
			direction="row"
			alignItems="start"
			pr="1.2em"
			// pr={{ xs: '1%', large: '2.65%' }}
			sx={{
				mb: 3,
				position: 'absolute',
				top: '3%',
				width: '100%',
				height: '55px',
				left: 0,
				paddingLeft: '7%',
				ml: 0,
				marginBottom: 0,
				zIndex: -1
			}}
		>
			<Grid xs={3} sm={4} md={4} item>
				<Grid container>
					{/* <Grid item>
						<Box
							sx={{
								border: '1px solid #303067',
								borderRadius: '8px',
								padding: '1px 3px'
							}}
						>
							<Icon src={infoIcon} alt="infoIcon" />
						</Box>
					</Grid> */}
					<Grid>
						<Box
							ref={containerRef}
							sx={{
								height: '28px',
								width: '25rem',
								ml: 0,
								border: '1px solid #303067',
								borderRadius: '50px',
								padding: '4px 8px',
								cursor: 'pointer',
								display: 'flex',
								alignItems: 'center'
							}}
							onClick={dropdownEnalbleFn}
						>
							<EllipsisTooltip value={latticeDetails?.dispatch_id} type="grid" placement="topbar" />
							<Icon
								src={arrowUpIcon}
								alt="arrowUpIcon"
								style={{
									marginLeft: '10px',
									transform: !dropDownEnable && 'rotate(180deg)'
								}}
								padding="0em 0px 0em 0px"
							/>
						</Box>

						<Slide
							timeout={400}
							direction="down"
							in={dropDownEnable}
							mountOnEnter
							unmountOnExit
							container={containerRef.current}
							// add this prop
						>
							<Box
								mt={2}
								open={dropDownEnable}
								onClose={dropDownClose}
								scroll="paper"
								className="dropdowntab"
								sx={{
									background: 'rgba(28, 28, 70,0.9)',
									borderRadius: '8px',
									width: { sm: '24rem', md: '24rem', lg: '25rem' }
									// width: { md: '30vw', lg: '24.5vw', xl: '23vw', large: '23vw' }
								}}
							>
								<Grid container item id="scroll-dialog-title" sx={{ p: 0 }} xs={12}>
									<DropDownTab
										value={dropDownTabvalue}
										onChange={handleDropdownTabChange}
										sublatticeDetails={sublatticeDetails}
										userList={userList}
										enableShareOption={enableShareOption}
									/>
								</Grid>
								<Grid
									pb={0.5}
									sx={{
										p: 0,
										overflow: dropDownTabvalue === 'notes' ? 'hidden' : 'auto',
										maxHeight: { sm: '78vh', lg: '80vh', xl: '86.5vh' },
										width: '99%'
									}}
								>
									<Grid>
										{dropDownTabvalue === 'overview' && (
											<Box className="tabBody" sx={{ px: 2, pt: 1, pb: 2 }}>
												<Overview
													latticeDetails={latticeDetails}
													inputs={inputs}
													result={result}
													resultObject={resultObject}
													codeOutput={codeOutput}
													description={description}
													codeObject={codeObject}
													error={errorValue}
												/>
											</Box>
										)}
										{dropDownTabvalue === 'sublattices' && (
											<Box className="tabBody sublattice-table" ref={listInnerRef}>
												<Table stickyHeader aria-label="sticky table">
													<TableHead className="tableHeader-Sublattice">
														<TableRow>
															{header.map((h, index) => (
																<TableCell
																	sx={{ paddingLeft: h.paddingLeft || 0 }}
																	width={h.width}
																	key={h.label}
																	colSpan={h.colSpan || 1}
																	align={h.align || 'center'}
																	data-testid="tableHeader"
																>
																	<Grid sx={{ display: index === 0 && 'flex' }}>
																		<TableSortLabel
																			active={sortColumn === h.id}
																			direction={sortColumn === h.id ? sortOrder : 'asc'}
																			onClick={() => onSort(h.id)}
																			data-testid="tableSort"
																			disabled={h.id === 'runtime'} // disabling runtime sort temporarily
																		>
																			{h.label}
																		</TableSortLabel>
																	</Grid>
																</TableCell>
															))}
														</TableRow>
													</TableHead>
												</Table>
												<TableContainer className="sublattice-tableRow">
													<Table>
														<TableBody>
															<DispatchIcon
																data={sublatticeDetails}
																showMore={() => setCount(prev => prev + 5)}
																totalCount={totalCount}
																moveLoader={moveLoader}
															/>
														</TableBody>
													</Table>
												</TableContainer>
											</Box>
										)}

										<Box>
											{enableShareOption && (
												<Box>
													{dropDownTabvalue === 'notes' && (
														<Box className="tabBody dropdownNotes">
															<Notes sidebarId={dispatchID} name="dispatch" />
														</Box>
													)}
												</Box>
											)}
										</Box>
									</Grid>
								</Grid>
							</Box>
						</Slide>
					</Grid>
				</Grid>
			</Grid>
			<Grid xs={4} item>
				<Grid container justifyContent="center">
					<Grid sx={{ color: statusColor(latticeDetails?.status) }}>
						{Capitalize(latticeDetails?.status)}
					</Grid>
					<Grid sx={{ mx: 3 }}>
						<Divider orientation="vertical" sx={{ borderColor: '#333333' }} />
					</Grid>
					<Grid sx={{ color: statusColor(latticeDetails?.status) }}>
						{statusIcon(latticeDetails?.status)}
						&nbsp; {latticeDetails?.completed_task_num}/{latticeDetails?.task_num}
					</Grid>
				</Grid>
			</Grid>
			<Grid xs={4} item sx={{ textAlign: 'right', display: 'flex', justifyContent: 'flex-end' }}>
				{/* <Button
					variant="contained"
					color="primary"
					onClick={convertSolver}
					sx={{
						background: '#5552FF',
						fontSize: '14px',
						padding: '8px 16px',
						height: '32px',
						color: 'white',
						borderRadius: '70px'
					}}
				>
					Convert to Solver
				</Button> */}
				{enableShareOption ? (
					<Grid
						xs={4}
						item
						sx={{ textAlign: 'right', display: 'flex', justifyContent: 'flex-end' }}
					>
						{/* {userList?.length && ( */}
						<AvatarGroup sx={{ mr: 2 }} max={5} className="customAvatarCtr">
							{userList?.length > 0 &&
								userList?.map((users, index) => (
									<CustomAvatar user={users?.sharedWithEmail} index={index} key={Math.random()} />
								))}
							{/* <CustomAvatar user={(userList.length - 1).toString()} /> */}
							{/* )} */}
						</AvatarGroup>

						{/* <ButtonGroup variant="outlined" className="MuiButtonGroup-grouped-multiple" sx={{ mr: 5 }}>
					<Button sx={{ padding: '6px 6px 3px 6px' }} className="gropbutton-active">
						<img src={loadBalancerIcon} alt="loadBalancerIcon" />
					</Button>
					<Button sx={{ padding: '6px 6px 3px 6px', opacity: 0.5 }}>
						<img src={dataTableIcon} alt="dataTableIcon" />
					</Button>
				</ButtonGroup> */}
						{sharePopupEnable && <Icon src={userMultipleIcon} alt="userMultipleIcon" />}
						<Grid sx={{ display: 'flex', justifyContent: 'flex-end' }}>
							{' '}
							<Tooltip title="Share">
								<ButtonGroup
									variant="outlined"
									className="MuiButtonGroup-grouped-single"
									sx={{ mr: 1, ml: 1 }}
								>
									<Button
										sx={{ padding: '6px 6px 3px 6px' }}
										onClick={shareFn}
										className={`${sharePopupEnable ? 'gropbutton-active' : ''}`}
									>
										<img src={shareIcon} alt="adjustIcon" style={{ width: '12px' }} />
									</Button>
								</ButtonGroup>
							</Tooltip>
							{/* <ButtonGroup variant="outlined" className="MuiButtonGroup-grouped-single">
							<Button sx={{ padding: '6px 6px 3px 6px', opacity: 0 }}>
								<img src={adjustIcon} alt="adjustIcon" />
							</Button>
						</ButtonGroup> */}
						</Grid>
					</Grid>
				) : (
					<Grid
						xs={4}
						item
						sx={{ textAlign: 'right', display: 'flex', justifyContent: 'flex-end' }}
					/>
				)}
				{sharePopupEnable && (
					<SharePopup
						sharePopupEnable={sharePopupEnable}
						sharePopupClose={sharePopupClose}
						openShareLoader={openShareLoader}
						setOpenShareLoader={setOpenShareLoader}
						userList={userList}
						dispatchID={latticeDetails?.dispatch_id}
						userEmail={userEmail}
						setTriggerShare={setTriggerShare}
					/>
				)}

				{solverPopupEnable && (
					<SolverViewPopup
						convertSolverClose={convertSolverClose}
						solverPopupEnable={solverPopupEnable}
						dispatchID={dispatchID}
					/>
				)}
			</Grid>
		</Grid>
	);
}

export default LatticeTopBar;
