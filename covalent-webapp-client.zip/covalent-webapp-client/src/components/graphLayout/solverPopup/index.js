/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
/* eslint-disable import/no-unused-modules */
/* eslint-disable react/jsx-props-no-spreading */

import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Box, Button, Stack, TextField, Grid, Input, FormHelperText } from '@mui/material';
import Typography from '@mui/material/Typography';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Chip from '@mui/material/Chip';
import Slide from '@mui/material/Slide';
import { styled } from '@mui/material/styles';
import { addPublishSolver } from '../../../redux/solverAdminSlice';
import './style.css';
import UploadComponent from './fileUpload';
import Status from '../../../assets/marketplace/online.svg';
import MarketplaceDialogBox from '../../dialogBox/marketplace/index';
import dispatchIcon from '../../../assets/dispatch/dispatchIcon.svg';
import Icon from '../../icon';
import hardwareImage from '../../../assets/marketplace/solverHardware.svg';
import { statusIcon } from '../../../utils/statusIcons';
import CustomisedSnackbar from '../../snackbar/projects/index';

const Transition = React.forwardRef((props, ref) => {
	return <Slide direction="down" ref={ref} {...props} />;
});

const ListItem = styled('li')(({ theme }) => ({
	margin: theme.spacing(0.5)
}));

function SolverViewPopup(props) {
	const { convertSolverClose, solverPopupEnable, dispatchID } = props;
	const [about, setAbout] = useState('');
	const [industries, setIndustries] = useState('');
	const [setup, setSetup] = useState('');
	const [citations, setCitations] = useState('');
	const [solverName, setSolverName] = useState('');
	const [description, setDescription] = useState('');
	const [tags, setTags] = useState('');
	const [chipdata, setChipData] = useState([]);
	const { solverdata } = useSelector(state => state.marketplace);
	const { allSolvers } = useSelector(state => state.solverAdmin);
	const [openDialogBox, setOpenDialogBox] = useState(false);
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [snackbarMessage] = useState(false);
	const [usage, setUsage] = useState('');
	const [curlCommand, setCurlCommand] = useState('');
	const [parameters, setParameters] = useState('');
	const [disablePublish, setDisablePublish] = useState(true);

	const dispatch = useDispatch();
	const handleDelete = tag => {
		// handle delete
		const chips = [...chipdata];
		const index = chips.indexOf(tag);
		if (index !== -1) {
			chips.splice(index, 1);
		}
		setChipData([...chips]);
	};
	useEffect(() => {
		if (
			about &&
			usage &&
			curlCommand &&
			parameters &&
			chipdata &&
			about &&
			setup &&
			citations &&
			industries &&
			solverName &&
			description
		) {
			setDisablePublish(false);
		} else {
			setDisablePublish(true);
		}
	}, [
		about,
		usage,
		curlCommand,
		parameters,
		chipdata,
		about,
		setup,
		citations,
		industries,
		solverName,
		description
	]);

	const calculateId = () => {
		const id = solverdata?.details?.length;
		const checkinAdmin = allSolvers?.findIndex(e => e?.solverId === id);
		if (checkinAdmin === -1) return id;

		const arr = allSolvers.map(e => {
			return e?.solverId;
		});
		return Math.max(...arr) + 1;
	};

	const onPublishClick = () => {
		const prepareSolverData = {
			type: 'solver',
			category: 'API Management',
			solverId: calculateId(),
			technology: 'Testing',
			per: 'call',
			apiCalls: '0',
			revenue: '0',
			downloads: 0,
			name: solverName,
			content:
				'An AI-driven solver predicting customer retention. Ideal for businesses looking to reduce attrition.',
			price: 55,
			solverImage: hardwareImage,
			statusimage: Status,
			token: '715515b0-d',
			chipdata: {
				tags: chipdata
			},
			headData: {
				name: solverName,
				label: 'IK',
				desc: 'An AI-driven solver predicting customer retention. Ideal for businesses looking to reduce attrition.',
				count: '480',
				created_date: '2-10-2022',
				last_build: '5-5-2023'
			},
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			},
			solverdetails: {
				about: [
					{
						id: 1,
						point: about
					}
				],
				industries: {
					desc: [
						{
							id: 1,
							point: description
						}
					],
					listitems: [{ id: 1, point: industries }]
				},
				setup,
				citations,
				desc: [description],
				usage,
				curl: curlCommand,
				parameters
			}
		};
		dispatch(addPublishSolver({ solver: prepareSolverData }));
		convertSolverClose();
		setOpenDialogBox(false);
		// setOpenSnackbar(true);
		// setSnackbarMessage('Converted to Solver!');
	};

	const handleKeyDown = event => {
		if (event.key === 'Enter') {
			const chips = [...chipdata];
			let tagsArray = tags?.trim()?.replace(/ +/g, ' ')?.toLowerCase()?.split(/,+/);
			tagsArray = tagsArray.filter(e => e !== '');
			tagsArray = tagsArray.map(e => e.trim());
			chips.push(...tagsArray);
			setChipData([...new Set(chips)]);
			setTags('');
		}
	};

	return (
		<>
			<MarketplaceDialogBox
				openDialogBox={openDialogBox}
				setOpenDialogBox={setOpenDialogBox}
				title="Convert to Solver"
				message="Are you sure you want to convert the dispatch to solver?"
				confirmButtonTitle="Convert to Solver"
				handler={onPublishClick}
			/>
			<CustomisedSnackbar
				testId="solversSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			<Dialog
				PaperProps={{
					style: {
						backgroundColor: '#1c1c46',
						boxShadow: 'none',
						borderRadius: '8px'
					}
				}}
				fullScreen
				TransitionComponent={Transition}
				keepMounted
				open={solverPopupEnable}
				onClose={convertSolverClose}
				scroll="paper"
				className="codeViewCtr"
			>
				<DialogTitle id="scroll-dialog-title">
					<Grid
						container
						justifyContent="space-between"
						alignItems="center"
						sx={{ background: ' #1c1c46 ' }}
					>
						<Grid>
							<Typography sx={{ fontSize: '20px', color: '#F1F1F6' }}>Convert to Solver</Typography>
						</Grid>
						<Grid>
							<Stack direction="row" spacing={2}>
								<Button
									variant="contained"
									color="primary"
									sx={{
										background: '#5552FF',
										fontSize: '14px',
										padding: '8px 16px',
										height: '32px',
										color: 'white',
										borderRadius: '70px',
										'&:disabled': {
											background: theme => theme.palette.background.covalentPurple,
											color: theme => theme.palette.text.secondary,
											border: '1px solid',
											borderColor: theme => theme.palette.background.blue04,
											borderRadius: '70px'
										}
									}}
									disabled={disablePublish}
									onClick={() => setOpenDialogBox(true)}
								>
									Publish
								</Button>
								<Button
									onClick={convertSolverClose}
									sx={{
										background: '#08081A',
										fontSize: '14px',
										padding: '8px 16px',
										height: '32px',
										color: 'white',
										borderRadius: '70px'
									}}
								>
									Cancel
								</Button>
							</Stack>
						</Grid>
					</Grid>
				</DialogTitle>
				<DialogContent>
					<DialogContentText component="span">
						<Box>
							{/* first section */}

							<Grid container spacing={5}>
								<Grid item xs={7}>
									<Grid
										container
										spacing={2}
										alignItems="center"
										sx={{
											m: 0,
											border: '1px solid #303067',
											padding: '3px 16px 20px 4px'
										}}
									>
										<Grid item xs={6}>
											<Stack direction="column" spacing={2}>
												<Input
													sx={{
														padding: '8px 12px',
														width: '100%',
														height: '32px',
														border: '1px solid #303067',
														borderRadius: '60px',
														fontSize: '14px',
														color: '#CBCBD7',
														background: '#08081A'
													}}
													value={solverName || ''}
													onChange={e => setSolverName(e.target.value)}
													disableUnderline
													placeholder="Solver Name"
												/>
												<TextField
													placeholder="Description"
													multiline
													rows={4}
													maxRows={4}
													value={description}
													onChange={e => setDescription(e.target.value)}
													className="textAreaBox"
												/>
												<Input
													sx={{
														padding: '8px 12px',
														width: '100%',
														height: '32px',
														border: '1px solid #303067',
														borderRadius: '60px',
														fontSize: '14px',
														color: '#CBCBD7',
														background: '#08081A'
													}}
													value={tags || ''}
													onChange={e => setTags(e.target.value)}
													onKeyDown={handleKeyDown}
													disableUnderline
													placeholder="Add Tags"
												/>
												<FormHelperText className="helperText">
													Please press enter to add tags
												</FormHelperText>
												<Box
													sx={{
														display: 'flex',
														listStyle: 'none',
														background: 'none',
														flexWrap: 'wrap',
														overflowY: 'auto',
														maxHeight: '45px'
													}}
													className="addTagsBox"
													component="ul"
												>
													{chipdata?.map((data, index) => {
														return (
															// eslint-disable-next-line react/no-array-index-key
															<ListItem key={index}>
																<Chip
																	label={data}
																	size="small"
																	onDelete={() => handleDelete(data)}
																/>
																{/* <Icon src={chipCloseIcon} /> */}
															</ListItem>
														);
													})}
												</Box>
											</Stack>
										</Grid>
										<Grid item xs={6}>
											<UploadComponent />
										</Grid>
										{/*  */}
										<Grid item xs={6}>
											<TextField
												placeholder="About"
												multiline
												rows={3}
												maxRows={3}
												fullWidth
												value={about}
												onChange={e => setAbout(e.target.value)}
												className="textAreaBox"
											/>
										</Grid>
										<Grid item xs={6}>
											<TextField
												placeholder="Industries"
												multiline
												rows={3}
												maxRows={3}
												fullWidth
												value={industries}
												onChange={e => setIndustries(e.target.value)}
												className="textAreaBox"
											/>
										</Grid>
										<Grid item xs={6}>
											<TextField
												placeholder="Setup"
												multiline
												fullWidth
												rows={3}
												maxRows={3}
												value={setup}
												onChange={e => setSetup(e.target.value)}
												className="textAreaBox"
											/>
										</Grid>
										<Grid item xs={6}>
											<TextField
												placeholder="Citations"
												multiline
												fullWidth
												rows={3}
												maxRows={3}
												value={citations}
												onChange={e => setCitations(e.target.value)}
												className="textAreaBox"
											/>
										</Grid>
										<Grid item xs={6}>
											<TextField
												placeholder="Usage"
												multiline
												fullWidth
												rows={3}
												maxRows={3}
												value={usage}
												onChange={e => setUsage(e.target.value)}
												className="textAreaBox"
											/>
										</Grid>
										<Grid item xs={6}>
											<TextField
												placeholder="Curl command"
												multiline
												fullWidth
												rows={3}
												maxRows={3}
												value={curlCommand}
												onChange={e => setCurlCommand(e.target.value)}
												className="textAreaBox"
											/>
										</Grid>
										<Grid item xs={12}>
											<TextField
												placeholder="Parameters"
												multiline
												fullWidth
												rows={3}
												maxRows={3}
												value={parameters}
												onChange={e => setParameters(e.target.value)}
												className="textAreaBox"
											/>
										</Grid>
									</Grid>
								</Grid>
								<Grid item xs={1} />
								<Grid item xs={4}>
									<Box className="selectedDispatchCtr">
										<Typography>Selected Dispatch</Typography>
										<Stack
											direction="row"
											gap={0}
											alignItems="center"
											className="selectedDispatch"
											sx={{ my: 3 }}
										>
											<Box>{statusIcon('COMPLETED', '0px 8px 3.5px 0px', 'dashboard')}</Box>
											<Box>
												<Icon src={dispatchIcon} type="static" />
											</Box>
											<Box>
												<Typography
													sx={{
														color: theme => theme.palette.text.primary,
														fontSize: theme => theme.typography.popUpDispatch.fontSize,
														fontWeight: theme => theme.typography.popUpDispatch.fontWeight
													}}
												>
													{dispatchID}
												</Typography>
											</Box>
										</Stack>
									</Box>
								</Grid>
							</Grid>
						</Box>
					</DialogContentText>
				</DialogContent>
			</Dialog>
		</>
	);
}

export default SolverViewPopup;
