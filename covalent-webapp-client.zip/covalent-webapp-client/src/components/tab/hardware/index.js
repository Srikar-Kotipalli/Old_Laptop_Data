import React from 'react';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';

function HardwareCustomTab() {
	return (
		<TabContext value="all">
			<TabList
				TabIndicatorProps={{
					style: {
						display: 'none'
					}
				}}
			>
				<Tab label="All" value="all" />
			</TabList>
		</TabContext>
	);
}

export default HardwareCustomTab;
