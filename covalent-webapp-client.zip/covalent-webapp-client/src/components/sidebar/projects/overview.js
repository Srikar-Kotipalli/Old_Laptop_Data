import React from 'react';
import { Typography, Grid, Box } from '@mui/material';
import { statusIcon } from '../../../utils/statusIcons';
import Icon from '../../icon';
import info from '../../../assets/sidebar/info.svg';
import copyIcon from '../../../assets/actions/copy.svg';
import tickIcon from '../../../assets/checkmarks/checkmark.svg';
import SidebarTags from './tags';
import FailedCard from './failedCard';
import HardwareList from './hardWareList';
import ActivityList from './activityList';
import { experimentStatus } from '../../../utils/utils';
import TokenComponent from '../../form/settings/tokenComponent';

function Overview({
	overviewData,
	experimentData,
	setValue,
	setSortOrder,
	setExperimentData,
	activityList
}) {
	return (
		<Grid
			mt={0}
			sx={{
				height: '83.5vh',
				'@media (min-height: 840px)': {
					height: '85.5vh'
				},
				'@media (min-height: 920px)': {
					height: '87vh'
				},
				'@media (min-height: 1000px)': {
					height: '89vh'
				},
				width: '100%',
				background: theme => theme.palette.background.covalentPurple,
				borderBottomLeftRadius: '15px',
				borderBottomRightRadius: '15px'
			}}
		>
			<Grid
				container
				pt={2}
				px={2}
				direction="row"
				justifyContent="space-between"
				alignItems="center"
			>
				{experimentData?.status && (
					<Grid container item direction="row" xs={6} alignItems="center">
						{statusIcon(experimentData?.status, '3px 3px 3.5px 0px')}
						{experimentStatus(experimentData?.status)}
					</Grid>
				)}
				{experimentData?.status && experimentData?.status !== 'NEW' && (
					<Grid>
						<Typography pl={3} variant="h2">
							{experimentData?.completedElectrons}/{experimentData?.totalElectrons}
						</Typography>
					</Grid>
				)}
			</Grid>
			{experimentData?.failedDispatches?.length > 0 ? (
				<Grid px={2}>
					<FailedCard
						items={experimentData?.failedDispatches}
						setValue={setValue}
						setSortOrder={setSortOrder}
						count={experimentData?.failedCount}
					/>
				</Grid>
			) : null}
			<Grid pt={2} px={2}>
				<Typography
					sx={{
						fontSize: theme => theme.typography.sidebar,
						color: theme => theme.typography.sidebarTitle.color
					}}
					mb={1}
				>
					Tags
				</Typography>
				<SidebarTags
					type="experimentSidebar"
					sidebarTags={experimentData}
					setExperimentData={setExperimentData}
				/>
			</Grid>
			<Grid pl={2} pt={2}>
				<Typography
					sx={{
						fontSize: theme => theme.typography.sidebar,
						color: theme => theme.typography.sidebarTitle.color
					}}
					mb={1}
				>
					API key
				</Typography>
				<TokenComponent
					fontSize="12px"
					copyIcon={copyIcon}
					copiedIcon={tickIcon}
					isDisabled
					TooltipColor="#08081A"
					from="settings"
					copyEnable
				/>
			</Grid>
			<Grid pl={2} pt={2}>
				<HardwareList items={overviewData?.hardware} />
			</Grid>
			<Grid pl={2} pt={2}>
				<Typography
					sx={{
						fontSize: theme => theme.typography.sidebar,
						color: theme => theme.typography.sidebarTitle.color
					}}
				>
					Total cost
				</Typography>
				<Box display="flex" direction="row">
					<Typography variant="h2" pt={1}>
						{overviewData?.cost}
					</Typography>
					<Icon src={info} alt="info" padding="10px 3px 3.5px 5px" type="static" />
				</Box>
			</Grid>
			<Grid pl={2} pt={2}>
				<Typography
					sx={{
						fontSize: theme => theme.typography.sidebar,
						color: theme => theme.typography.sidebarTitle.color
					}}
				>
					Activity
				</Typography>
				<ActivityList items={activityList} count={activityList?.length} />
			</Grid>
		</Grid>
	);
}

export default Overview;
