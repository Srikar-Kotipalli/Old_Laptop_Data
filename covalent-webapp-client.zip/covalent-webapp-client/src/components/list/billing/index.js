/* eslint-disable camelcase */
/* eslint spaced-comment: ["error", "always"] */
/* eslint-disable react/jsx-curly-brace-presence */
/* eslint no-inline-comments: "error" */

import React from 'react';
import { Table, TableBody, TableRow, Box, Grid, Typography } from '@mui/material';
import BillingTableHeader from './billingTableHeader';
import BillingTableRow from './billingTableRow';
import BillingTableFooter from './billingTableFooter';
import { BillingContext } from '../../../containers/billing/billingContext';
import Loader from '../../loader';
import Icon from '../../icon';
import ArchiveIcon from '../../../assets/billing/archive.svg';

function BillingTable() {
	const billingContext = React.useContext(BillingContext);
	const { invoices, invoicesLoader } = billingContext;

	return (
		<Grid sx={{ width: '100%' }}>
			<Table width="100%">
				{invoices?.length > 0 && <BillingTableHeader />}
				<TableBody>
					{!invoicesLoader &&
						invoices &&
						invoices?.map((invoice, index) => (
							<TableRow key={invoice?.external_invoice_id} data-testid="billingListView">
								<BillingTableRow invoice={invoice} index={index} hierarchyType="dispatch" />
							</TableRow>
						))}
				</TableBody>
			</Table>
			{invoicesLoader && (
				<Box
					sx={{
						marginTop: '20px',
						marginBottom: '20px',
						height: '167px',
						border: '1px solid',
						borderRadius: '8px',
						borderColor: theme => theme.palette.background.blue03,
						display: 'flex',
						alignItems: 'center',
						justifyContent: 'center'
					}}
				>
					<Loader isFetching={invoicesLoader} width="100%" position="relative" height="100%" />
				</Box>
			)}
			{!invoicesLoader && invoices?.length > 0 && <BillingTableFooter />}
			{!invoicesLoader && invoices?.length === 0 && (
				<Box
					sx={{
						marginTop: '20px',
						marginBottom: '20px',
						// width: '61vw',
						height: '167px',
						border: '1px solid',
						borderRadius: '8px',
						borderColor: theme => theme.palette.background.blue03,
						display: 'flex',
						alignItems: 'center',
						justifyContent: 'center'
					}}
				>
					<Box
						sx={{
							display: 'flex',
							flexDirection: 'column',
							alignItems: 'center',
							justifyContent: 'center'
						}}
					>
						<Icon src={ArchiveIcon} />
						<Typography variant="h2" sx={{ marginTop: '22px' }}>
							No invoices to show
						</Typography>
					</Box>
				</Box>
			)}
		</Grid>
	);
}

export default BillingTable;
