/* eslint-disable import/no-unused-modules */
/* eslint-disable react/jsx-curly-brace-presence */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import { Stack, Box, Typography } from '@mui/material';
import Icon from '../../icon';
import downloadIcon from '../../../assets/actions/downloadGrey.svg';
import { capitalizeName } from '../../../utils/utils';
import { BillingContext } from '../../../containers/billing/billingContext';
import OverflowTooltip from '../../tooltip/overflowTooltip';
import CopyButton from '../../copyButton';

export default function BillingTableRow(props) {
	const billingContext = React.useContext(BillingContext);
	const { downloadInvoice } = billingContext;
	const { invoice } = props;
	return (
		<>
			<TableCell align="left">
				<Stack direction={'row'} alignItems="center" spacing={2} ml={1}>
					<OverflowTooltip length={10} title={invoice?.id} />
					<CopyButton content={invoice?.id} regular={false} />
					<Box
						sx={{
							display: 'flex',
							justifyContent: 'center',
							alignItems: 'center',
							width: '24px',
							height: '24px',
							border: '1px solid transparent',
							cursor: 'pointer',
							'&:hover': {
								background: theme => theme.palette.background.covalentPurple,
								borderRadius: '8px',
								border: '1px solid',
								borderColor: theme => theme.palette.background.blue05
							}
						}}
					>
						<Icon
							src={downloadIcon}
							alt="downloadIcon"
							type="pointer"
							title="Download Invoice"
							clickHandler={() => downloadInvoice(invoice?.id)}
						/>
					</Box>
				</Stack>
			</TableCell>
			<TableCell align="left">
				<Box
					sx={{
						display: 'flex',
						alignItems: 'center',
						justifyContent: 'center',
						width: '70px',
						height: '21px',
						pt: '2px',
						background: invoice?.payment_status ? '#55D8991A' : '#FF64641A',
						border: '1px solid',
						borderColor: invoice?.payment_status ? '#55D899B2' : '#FF6464B2',
						borderRadius: '4px',
						color: invoice?.payment_status ? '##55D899' : '#FF6464'
					}}
				>
					<Typography sx={{ fontSize: '13px' }}>
						{invoice?.payment_status ? 'Paid' : 'Pending'}
					</Typography>
				</Box>
			</TableCell>
			<TableCell align="left">{invoice?.issued_date}</TableCell>
			<TableCell align="left">{capitalizeName(invoice?.external_issuing_type)}</TableCell>
			<TableCell align="left">{`$${((parseInt(invoice?.total_amount_cents, 10) || 0) / 100).toFixed(
				2
			)} ${invoice?.total_amount_currency}`}</TableCell>
			{/* <TableCell align="left">
				<Stack direction={'row'}>
					<Icon
						src={downloadIcon}
						alt="downloadIcon"
						type="pointer"
						clickHandler={() => downloadInvoice(invoice?.id)}
					/>
				</Stack>
			</TableCell> */}
		</>
	);
}
