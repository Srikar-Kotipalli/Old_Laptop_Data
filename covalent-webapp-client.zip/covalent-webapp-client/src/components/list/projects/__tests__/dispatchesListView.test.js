/* eslint-disable react/jsx-no-constructed-context-values */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import React from 'react';
import DispatchListView from '../dispatchesListView';
import { ProjectContext } from '../../../../containers/projects/projectContext';

const header = { label: 'Title', align: 'left', width: '20%', id: 'title' };

const dispatches = [
	{
		completedElectrons: 2,
		count: '',
		id: '3a4e328c-11d5-430d-b261-42e724bcc675',
		isPinned: false,
		lastUpdated: '2022-01-09 01:43:00',
		title: 'Maroon Silver Dalmatian',
		runTime: 543500,
		startTime: '2022-01-09 06:57:00',
		status: 'FAILED',
		tags: ['react', 'rust', 'node', 'js', 'html', '.net', 'pandas', 'jupyter'],
		totalElectrons: 5,
		type: 'dispatch'
	},
	{
		completedElectrons: 12,
		count: '',
		id: '68c1729c-eceb-4711-84de-51a564d079be',
		isPinned: false,
		lastUpdated: '2022-01-05 12:25:00',
		title: 'Fuschia Steel Fox Terrier',
		runTime: 5123000,
		startTime: '2022-01-05 14:13:00',
		status: 'FAILED',
		tags: ['react', 'rust', 'node', 'js', 'html', '.net', 'pandas', 'jupyter'],
		totalElectrons: 13,
		type: 'dispatch'
	}
];
const noRecordsFound = [];
const timeFormatter = jest.fn();
const dateFormatter = jest.fn();

describe('Dispatches list view', () => {
	test('renders dispacthes filtered list view', () => {
		render(
			<ProjectContext.Provider value={{ allItems: dispatches }}>
				<DispatchListView
					header={header}
					timeFormatter={timeFormatter}
					dateFormatter={dateFormatter}
				/>
			</ProjectContext.Provider>
		);
		const element = screen.getAllByTestId('dispatchListView');
		expect(element).toHaveLength(2);
	});
	test('renders no records', () => {
		render(
			<ProjectContext.Provider value={{ allItems: noRecordsFound }}>
				<DispatchListView
					header={header}
					timeFormatter={timeFormatter}
					dateFormatter={dateFormatter}
				/>
			</ProjectContext.Provider>
		);
		const element = screen.getByTestId('noDispatchesFound');
		expect(element).toBeInTheDocument();
	});
});
