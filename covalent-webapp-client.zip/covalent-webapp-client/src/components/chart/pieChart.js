import React from 'react';
import Chart from 'react-apexcharts';

function PieChart({ revenueChartData, height }) {
	const donutData = {
		series: revenueChartData.series,
		options: {
			dataLabels: {
				enabled: false
			},
			labels: revenueChartData.labels,
			colors: revenueChartData.colors,
			chart: {
				type: 'donut'
			},
			// plotOptions: {
			//   pie: {
			//     expandOnClick: false
			//   }
			// },
			stroke: {
				colors: revenueChartData.colors
			},
			responsive: [
				{
					breakpoint: 480,
					options: {
						chart: {
							width: 200
						},
						dataLabels: {
							enabled: false
						},
						legend: {
							position: 'bottom'
						}
					}
				}
			]
		}
	};
	return (
		<Chart
			options={donutData.options}
			series={donutData.series}
			height={height || 240}
			type="donut"
		/>
	);
}

export default PieChart;
