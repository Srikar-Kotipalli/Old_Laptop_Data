import React, { useState, useEffect } from 'react';
import { Editor } from 'react-draft-wysiwyg';
import { EditorState, ContentState, convertToRaw } from 'draft-js';
import htmlToDraft from 'html-to-draftjs';
import draftToHtml from 'draftjs-to-html';
import { Backdrop, Box } from '@mui/material';
// eslint-disable-next-line import/no-relative-packages
import '../../../../node_modules/react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import './style.css';
import bold from '../../../assets/notes/bold.svg';
import italic from '../../../assets/notes/italic.svg';
import underline from '../../../assets/notes/underline.svg';
import ordered from '../../../assets/notes/orderedlists.svg';
import left from '../../../assets/notes/alignleft.svg';
import center from '../../../assets/notes/alignmiddle.svg';
import fontsize from '../../../assets/notes/fontsize.svg';
import code from '../../../assets/notes/code.svg';
import { getNotes, addNotes } from '../../../api/experiments/dispatchApi';
import covLoader from '../../../assets/loaders/covLoader.svg';
import Icon from '../../icon';

const editorLabels = {
	'components.controls.blocktype.code': '</>'
};
function Notes({ sidebarId, name }) {
	const [editorState, setEditorState] = useState(() => EditorState.createEmpty());
	const [convertedContent, setConvertedContent] = useState(null);
	const [isFetching, setIsFetching] = useState(true);
	const [archive, setArchived] = useState(false);
	const userCheckRef = React.useRef(convertedContent); // ref to store state value
	const handleEditorChange = state => {
		setEditorState(state);
	};

	useEffect(() => {
		const html = draftToHtml(convertToRaw(editorState.getCurrentContent()));
		setConvertedContent(html);
		userCheckRef.current = html;
	}, [editorState]);

	useEffect(() => {
		const bodyParameters = {
			id: sidebarId,
			name
		};
		getNotes(bodyParameters)
			.then(res => {
				const html = res.notes;
				setArchived(res?.isArchived);
				const contentBlock = htmlToDraft(html);
				if (contentBlock) {
					const contentState = ContentState.createFromBlockArray(contentBlock.contentBlocks);
					const editorStatenew = EditorState.createWithContent(contentState);
					setEditorState(editorStatenew);
				}
				setIsFetching(false);
			})
			.catch(() => {
				setIsFetching(false);
			});
	}, []);

	useEffect(() => {
		return () => {
			const parameter = {
				id: sidebarId,
				name,
				notes: userCheckRef?.current
			};
			if (parameter.notes !== null) {
				addNotes(parameter);
			}
		};
	}, []);

	return (
		<div>
			{isFetching ? (
				<div className="loaderParent">
					<Backdrop className="loaderBackDrop" open={isFetching}>
						<Box className="loaderInnerStyle">
							<Icon type="pointer" src={covLoader} />
						</Box>
					</Backdrop>
				</div>
			) : (
				<Editor
					localization={{ locale: 'en', translations: editorLabels }}
					editorState={editorState}
					onEditorStateChange={handleEditorChange}
					wrapperClassName="wrapper-class"
					toolbarClassName="toolbar-class"
					readOnly={archive}
					toolbar={{
						options: ['inline', 'fontSize', 'textAlign', 'list', 'blockType'],
						inline: {
							inDropdown: false,
							options: ['bold', 'italic', 'underline'],
							className: 'inline-class',
							bold: { icon: bold },
							italic: { icon: italic },
							underline: { icon: underline }
						},

						blockType: {
							inDropdown: false,
							options: ['Code'],
							Code: { icon: code },
							className: 'block-class'
						},
						fontSize: {
							options: ['small', 'medium', 'large'],
							className: 'inline-class',
							icon: fontsize
						},
						list: {
							options: ['ordered'],
							ordered: { icon: ordered }
						},
						textAlign: {
							options: ['left', 'center'],
							left: { icon: left },
							center: { icon: center }
						}
					}}
				/>
			)}
		</div>
	);
}

export default Notes;
