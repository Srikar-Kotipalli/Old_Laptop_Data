/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
/* eslint-disable react/jsx-no-useless-fragment */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React, { useRef, useEffect, useState } from 'react';
import Tooltip from '@mui/material/Tooltip';
import Chip from '@mui/material/Chip';
import Grid from '@mui/material/Grid';
import './style.css';
import { useMediaQuery, useTheme } from '@mui/material';

function EllipsisTooltip(props) {
	// Define state and function to update the value
	const [hoverStatus, setHover] = useState(false);

	const {
		value,
		subValue,
		type,
		width,
		fixWidth,
		attribute,
		variant,
		paddingTop,
		paddingRight,
		paddingLeft,
		paddingBottom,
		placement
	} = props;
	// Create Ref
	const textElementRef = useRef();

	const compareSize = () => {
		const compare = textElementRef.current.scrollWidth > textElementRef.current.clientWidth;
		setHover(compare);
	};

	// compare once and add resize listener on "componentDidMount"
	useEffect(() => {
		compareSize();
		window.addEventListener('resize', compareSize);
	}, []);

	// remove resize listener again on "componentWillUnmount"
	useEffect(
		() => () => {
			window.removeEventListener('resize', compareSize);
		},
		[]
	);

	const [maxWidth, setMaxWidth] = useState('305px');
	const theme = useTheme();
	const onlyExtraSmall = useMediaQuery(theme.breakpoints.only('xs')); // 0px - 1000px
	const onlySmallScreen = useMediaQuery(theme.breakpoints.only('sm')); // 1000px-1420px
	const onlyMediumScreen = useMediaQuery(theme.breakpoints.only('md')); // 1420- 1500px
	const onlyLargeScreen = useMediaQuery(theme.breakpoints.only('lg')); // 1500px- 1800px
	useEffect(() => {
		if (onlyExtraSmall) {
			setMaxWidth(placement === 'topbar' ? '100%' : '100px');
		} else if (onlySmallScreen) {
			setMaxWidth(placement === 'topbar' ? '100%' : '200px');
		} else if (onlyMediumScreen || onlyLargeScreen) {
			setMaxWidth(placement === 'topbar' ? '100%' : '210px');
		} else {
			setMaxWidth(placement === 'topbar' ? '100%' : '285px');
		}
	});

	const fontSizeFn = val => {
		if (val === 'subtitle1' || val === 'env') {
			return '1rem';
		} else if (val === 'chip') {
			return '0.75rem';
		} else if (val === 'environment') {
			return '18px';
		}
		return '0.875rem';
	};

	const getDataForToolTip = () => {
		// eslint-disable-next-line default-case
		switch (type) {
			case 'grid':
				return (
					<>
						<Tooltip
							title={value}
							interactive="true"
							disableHoverListener={!hoverStatus}
							style={{ fontSize: '2em' }}
							placement="top"
						>
							<Grid
								ref={textElementRef}
								style={{
									width: attribute === 'electron' ? width : maxWidth,
									whiteSpace: 'nowrap',
									overflow: 'hidden',
									textOverflow: 'ellipsis',
									fontSize: fontSizeFn(variant),
									paddingTop: paddingTop || ''
								}}
							>
								{value}
							</Grid>
						</Tooltip>
					</>
				);
			case 'menu':
				return (
					<>
						<Tooltip
							title={value}
							interactive="true"
							disableHoverListener={!hoverStatus}
							style={{ fontSize: '2em' }}
							placement="top"
						>
							<Grid
								ref={textElementRef}
								style={{
									whiteSpace: 'nowrap',
									overflow: 'hidden',
									textOverflow: 'ellipsis',
									fontSize: variant === 'subtitle1' ? '1rem' : '0.875rem'
								}}
							>
								{value}
							</Grid>
						</Tooltip>
					</>
				);
			default:
				return (
					<>
						<Grid
							style={{
								display: 'flex',
								width: attribute === 'electron' || fixWidth ? width : maxWidth,
								paddingRight: paddingRight || null,
								paddingLeft: paddingLeft || null,
								paddingBottom: paddingBottom || null
							}}
						>
							<Tooltip
								title={value}
								interactive="true"
								disableHoverListener={!hoverStatus}
								style={{ fontSize: '2em' }}
								placement="top"
							>
								<Grid
									ref={textElementRef}
									style={{
										whiteSpace: 'nowrap',
										overflow: 'hidden',
										textOverflow: 'ellipsis',
										fontSize: type === 'project' ? '1rem' : '0.875rem',
										paddingRight: '10px',
										paddingTop: '1px'
									}}
								>
									{value}
								</Grid>
							</Tooltip>
							{type !== 'dispatch' && (
								<Chip
									label={subValue}
									variant="outlined"
									size="small"
									sx={{
										minWidth: '24px',
										height: '24px',
										fontSize: '0.875rem',
										borderRadius: '8px',
										backgroundColor: '#1C1C46',
										'& .MuiChip-label': {
											overflow: 'visible'
										}
									}}
								/>
							)}
						</Grid>
					</>
				);
		}
	};
	return <>{getDataForToolTip()}</>;
}

export default EllipsisTooltip;
