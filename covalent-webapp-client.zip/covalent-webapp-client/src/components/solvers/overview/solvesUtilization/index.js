import { Stack, Box, Typography } from '@mui/material';
import React from 'react';
import Icon from '../../../icon';
import costIcon from '../../../../assets/costIcon.svg';
import PieChart from '../../../chart/pieChart';

function SolversUtilization() {
	const revenueChartData = {
		series: [23, 11, 54, 72],
		labels: ['Downloads', 'Api call', 'Earnings', 'Other'],
		colors: ['#8B31FF', '#41418D', '#AD7BFF', '#6D7CFF']
	};
	return (
		<Box className="utilCtr">
			<Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1 }}>
				<Box className="utilizationHeaderIcon">
					<Icon type="static" src={costIcon} />
				</Box>
				<Box>
					<Typography className="utilzationLabel" sx={{ color: '#FFF' }}>
						Solvers Utilization
					</Typography>
				</Box>
			</Stack>
			<Box>
				<PieChart revenueChartData={revenueChartData} height={160} />
			</Box>
		</Box>
	);
}

export default SolversUtilization;
