/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import { Grid, Table, TableRow, TableHead, Box, Checkbox, TableCell } from '@mui/material';

import ExpandMoreIcon from '../../../assets/arrows/caretDown.svg';
import checkbox from '../../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../../assets/checkboxes/checkboxChecked.svg';
import ExpandLessIcon from '../../../assets/arrows/caretUp.svg';
import Icon from '../../icon';

function BillingAccordion({ data, checkboxHandler, selectedItems }) {
	const [expand, setExpand] = React.useState(false);

	const toggleAcordion = () => {
		setExpand(prev => !prev);
	};

	return (
		<Grid item xs={12} mt={2}>
			<Accordion
				elevation={0}
				expanded={expand}
				sx={{
					width: { xs: '94%', sm: '97.5%', lg: '98%', xl: '98%', xxl: '98.5%' },
					border: '1px solid',
					borderColor: expand
						? theme => theme.palette.background.blue05
						: theme => theme.palette.background.covalentPurple
				}}
			>
				<AccordionSummary
					aria-controls="panel1a-content"
					id="panel1a-header"
					sx={{
						height: '2rem',
						padding: 0,
						'& .MuiAccordionSummary-content': {
							margin: 0
						}
					}}
					p={0}
				>
					<Table style={{ width: '100%' }} className="tabComponentTable">
						<tbody>
							<TableRow sx={{ '&:hover': { backgroundColor: 'transparent' } }}>
								<TableCell sx={{ width: '0.5%', border: 'none' }}>
									<Checkbox
										data-testid="headerCheckbox"
										size="small"
										sx={{ padding: '0px 0px 0px 5px' }}
										value={data.id}
										checked={selectedItems.includes(data.id)}
										onChange={checkboxHandler}
										icon={
											<Icon
												src={checkbox}
												alt="checkbox"
												type="pointer"
												width="12px"
												height="12px"
											/>
										}
										checkedIcon={
											<Icon
												src={checkboxChecked}
												alt="checkboxChecked"
												type="pointer"
												width="12px"
												height="12px"
											/>
										}
										// disabled={ || addMode}
									/>
								</TableCell>
								<TableCell onClick={toggleAcordion} sx={{ width: '17.5%', border: 'none' }}>
									<Box sx={{ display: 'flex', alignItems: 'center' }}>
										<span style={{ paddingBottom: '3px', paddingLeft: '5px' }}>
											{data.organisationName}
										</span>
									</Box>
								</TableCell>
								<TableCell onClick={toggleAcordion} sx={{ width: '17.5%', border: 'none' }}>
									<Typography />
								</TableCell>
								<TableCell onClick={toggleAcordion} sx={{ width: '17.5%', border: 'none' }}>
									<Typography variant="h2">{data.purchaseDate} </Typography>
								</TableCell>
								<TableCell onClick={toggleAcordion} sx={{ width: '17.5%', border: 'none' }}>
									<Typography variant="h2">{data.cost}</Typography>
								</TableCell>
								<TableCell onClick={toggleAcordion} sx={{ width: '17.5%', border: 'none' }}>
									<Typography variant="h2" ml={{ lg: 0.7, xl: 0 }}>
										{data.runs}
									</Typography>
								</TableCell>
							</TableRow>
						</tbody>
					</Table>
					<Grid
						onClick={toggleAcordion}
						sx={{ position: 'absolute', right: 15, display: 'flex', alignItems: 'center', top: 16 }}
					>
						<Icon src={!expand ? ExpandMoreIcon : ExpandLessIcon} padding="0.3px 0px 0px 0px" />
					</Grid>
				</AccordionSummary>
				<AccordionDetails
					sx={{
						padding: 0
					}}
					p={0}
				>
					{data.solvers.map(solver => {
						return (
							<Table style={{ width: '100%' }} key={solver.id}>
								<TableHead>
									<TableRow sx={{ '&:hover': { backgroundColor: 'transparent' } }}>
										<TableCell sx={{ width: '1.5%', border: 'none' }} />
										<TableCell sx={{ width: '17.5%', border: 'none' }} />
										<TableCell sx={{ width: '17.5%', border: 'none' }}>
											<Typography variant="h2">{solver.name}</Typography>
										</TableCell>
										<TableCell sx={{ width: '17.5%', border: 'none' }}>
											<Typography variant="h2"> {solver.purchaseDate}</Typography>
										</TableCell>
										<TableCell sx={{ width: '17.5%', border: 'none' }}>
											<Typography variant="h2">{solver.cost}</Typography>
										</TableCell>
										<TableCell sx={{ width: '17.5%', border: 'none' }}>
											<Typography ml={{ lg: 0.7, xl: 0 }} variant="h2">
												{solver.Runs}
											</Typography>
										</TableCell>
									</TableRow>
								</TableHead>
							</Table>
						);
					})}
				</AccordionDetails>
			</Accordion>
		</Grid>
	);
}

export default BillingAccordion;
