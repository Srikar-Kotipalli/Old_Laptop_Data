/* eslint-disable react/require-default-props */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

/* eslint-disable import/prefer-default-export */
/* eslint-disable react/jsx-props-no-spreading */
/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import { Box, Typography, Avatar, Skeleton } from '@mui/material';
import Tooltip, { tooltipClasses } from '@mui/material/Tooltip';
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { styled } from '@mui/material/styles';
import { useNavigate } from 'react-router-dom';

import Icon from '../../../icon';
import { statusIcon, dpexpStatusIcons } from '../../../../utils/statusIcons';
import CopyButton from '../../../copyButton';
import OverflowTooltip from '../../../tooltip/overflowTooltip';
import VirtualImage from '../../../../assets/environments/virtualMachine.svg';
import CostImage from '../../../../assets/cost.svg';
import { capitalizeName } from '../../../../utils/utils';
import RightIcon from '../../../../assets/rightIcon.svg';
import LeftIcon from '../../../../assets/leftIcon.svg';
import DisabledleftIcon from '../../../../assets/disabledLeft.svg';
import DisabledRightIcon from '../../../../assets/disabledRight.svg';
import { getAssetFromUrl } from '../../../../api/graph/graphLayoutApi';
import GraphRuntime from '../../../../utils/GraphRuntime';
import useLength from '../../../../utils/useLength';
import CodePane from '../../../codePane';
import Pane from '../../../../assets/graph/pane.svg';
import routes from '../../../../constants/routes.json';

const DarkTooltip = styled(({ className, ...props }) => (
	<Tooltip {...props} classes={{ popper: className }} />
))(() => ({
	[`& .${tooltipClasses.tooltip}`]: {
		backgroundColor: '#1C1C46'
	}
}));

export const RecentDispatchCard = props => {
	const navigate = useNavigate();
	const [input, setInput] = useState('');
	const [isLoading, setIsLoading] = useState(true);
	const [openCodePane, setOpenCodePane] = useState(false);

	const { name, status, dispatchid, time, inputUrl } = props;

	const getInput = () => {
		setIsLoading(true);
		getAssetFromUrl(inputUrl)
			.then(res => {
				setInput(res?.data?.toString());
				setIsLoading(false);
			})
			// eslint-disable-next-line no-unused-vars
			.catch(err => {
				setInput('None');
				setIsLoading(false);
			});
	};

	useEffect(() => {
		getInput();
	}, []);

	const goTo = dispatchId => {
		navigate(`${routes.GRAPH}/${dispatchId}`);
	};
	return (
		<Box
			sx={{
				border: theme => `1px solid ${theme.palette.background.blue03}`,
				padding: '6px 14px',
				display: 'flex',
				borderRadius: '6px',
				background: theme => theme.palette.background.blue08,
				marginBottom: '8px',
				'&:hover': {
					background: theme => theme.palette.background.blue0380
				},
				cursor: 'pointer'
			}}
			onClick={() => goTo(dispatchid)}
		>
			<Box sx={{ width: '60%' }}>
				<Box
					sx={{
						display: 'flex',
						placeItems: 'center'
					}}
				>
					<Box sx={{ marginRight: '5px' }}>
						<OverflowTooltip
							title={name}
							length={15}
							fontSize="12px"
							color={theme => theme.palette.text.gray03}
						/>
					</Box>
					{status === '' ? dpexpStatusIcons('NEW_OBJECT') : dpexpStatusIcons(status)}
				</Box>
				<Box sx={{ display: 'flex', placeItems: 'center' }}>
					<Box sx={{ marginTop: '3px', cursor: 'pointer' }}>
						<OverflowTooltip title={dispatchid} length={10} fontSize="10px" />
					</Box>

					<CopyButton content={dispatchid} margin="2px 0 0 12px" />
				</Box>
			</Box>
			<Box sx={{ width: '40%' }}>
				<Box sx={{ display: 'flex', placeItems: 'center', justifyContent: 'space-between' }}>
					<Typography sx={{ color: theme => theme.palette.text.gray03, fontSize: '12px' }}>
						Input:
					</Typography>
					{isLoading ? (
						<Box
							sx={{
								border: theme => `0.5px solid ${theme.palette.background.blue06}`,
								fontSize: '10px',
								color: theme => theme.palette.text.primary,
								padding: '4px',
								width: '70%',
								borderRadius: '4px'
							}}
						>
							<Skeleton variant="rounded" width={50} height={10} />
						</Box>
					) : (
						<Box
							sx={{
								border: theme => `0.5px solid ${theme.palette.background.blue06}`,
								fontSize: '10px',
								color: theme => theme.palette.text.primary,
								padding: '4px',
								width: '70%',
								borderRadius: '4px',
								display: 'flex',
								justifyContent: 'space-between',
								maxHeight: '21px',
								alignItems: 'center'
							}}
						>
							<Box
								sx={{
									overflow: 'hidden',
									fontSize: '10px',
									maxHeight: '13px',
									pb: '13px',
									color: theme => theme.palette.text.primary
								}}
							>
								{input}
							</Box>
							<Box
								onClick={e => {
									e.stopPropagation();
								}}
							>
								<Icon
									src={Pane}
									alt="controlPane"
									padding="4.3px"
									title="View more"
									clickHandler={() => setOpenCodePane(true)}
									placement="top"
								/>
								<CodePane
									tabValue="Input"
									open={openCodePane}
									setOpen={setOpenCodePane}
									jsonInput={input}
									page="dashboard"
								/>
							</Box>
						</Box>
					)}
				</Box>

				<GraphRuntime
					startTime={time?.startTime}
					endTime={time?.endTime}
					className="overviewsubhead"
					sx={{ color: theme => theme.palette.text.gray03, fontSize: '10px', marginTop: '7px' }}
				/>
			</Box>
		</Box>
	);
};

RecentDispatchCard.propTypes = {
	name: PropTypes.string.isRequired,
	status: PropTypes.string.isRequired,
	// input: PropTypes.string.isRequired,
	dispatchid: PropTypes.string.isRequired,
	time: PropTypes.object.isRequired
};

export const SharedDispatchCard = props => {
	const navigate = useNavigate();
	const { status, name, sharedWith } = props;
	const lengthVal = useLength({ xs: 5, s: 7, m: 10, l: 13, xl: 16 });

	const goToDispatch = dispatchId => {
		// navigate(`/graph/${dispatchId}`);
		navigate(`${routes.GRAPH}/${dispatchId}`);
	};
	return (
		<Box
			onClick={() => goToDispatch(name)}
			sx={{
				cursor: 'pointer',
				borderRadius: '8px',
				background: theme => theme.palette.background.covalentSidebar,
				padding: '4px 10px',
				border: '1px solid #303067',
				display: 'flex',
				justifyContent: 'space-between',
				height: '32px',
				'&:hover': {
					background: theme => theme.palette.background.recentDispatchCard
				},
				'&:active': {
					background: theme => theme.palette.background.covalentPurple
				}
			}}
		>
			<Box sx={{ display: 'flex', alignItems: 'center' }}>
				<Box sx={{ display: 'flex' }}>
					<Box sx={{ marginTop: '2px' }}>{statusIcon(status)}</Box>
					<Box
						sx={{
							color: theme => theme.palette.text.primary,
							margin: '0 4px',
							display: 'flex',
							alignItems: 'center'
						}}
					>
						<OverflowTooltip
							title={name || ''}
							length={lengthVal}
							fontSize="14px"
						/>
					</Box>
					<CopyButton content={name} margin="2px 0 0 0" />
				</Box>
			</Box>
			<Box sx={{ display: 'grid', placeItems: 'center' }}>
				<DarkTooltip title={sharedWith || ''} placement="top">
					<Avatar
						sx={{
							width: '14px',
							height: '14px',
							fontSize: '10px',
							// position: 'unset',
							// float: 'right',
							bgcolor: '#AD7BFF',
							color: 'white'
						}}
					>
						{capitalizeName(sharedWith?.slice(0, 1)) || ''}
					</Avatar>
				</DarkTooltip>
			</Box>
		</Box>
	);
};

SharedDispatchCard.propTypes = {
	name: PropTypes.string.isRequired,
	status: PropTypes.string.isRequired,
	sharedWith: PropTypes.string.isRequired
};

export const RecentEnvironmentCard = props => {
	const navigate = useNavigate();
	const { name, date, environmentid } = props;
	const goToEnv = envId => {
		navigate(`/environments/${envId}`);
	};

	return (
		<Box
			onClick={() => goToEnv(environmentid)}
			sx={{
				borderRadius: '8px',
				background: theme => theme.palette.background.covalentSidebar,
				padding: '4px 10px',
				border: '1px solid #303067',
				display: 'flex',
				justifyContent: 'space-between',
				height: '28px',
				cursor: 'pointer',
				'&:hover': {
					background: theme => theme.palette.background.recentDispatchCard
				},
				'&:active': {
					background: theme => theme.palette.background.covalentPurple
				}
			}}
		>
			<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
				<Box sx={{ display: 'flex' }}>
					<img src={VirtualImage} alt="env" />
					<Box
						sx={{
							color: theme => theme.palette.text.primary,
							margin: '0 6px',
							display: 'flex',
							alignItems: 'center'
						}}
					>
						<OverflowTooltip title={name} length={12} fontSize="14px" />
					</Box>
					<CopyButton content={name} margin="2px 0 0 0" />
				</Box>
			</Box>
			<Typography
				sx={{
					color: theme => theme.palette.text.primary,
					fontSize: '10px',
					fontWeight: '500',
					display: 'flex',
					alignItems: 'center'
				}}
			>
				{date}
			</Typography>
		</Box>
	);
};
RecentEnvironmentCard.propTypes = {
	name: PropTypes.string.isRequired,
	date: PropTypes.string.isRequired,
	environmentid: PropTypes.string.isRequired
};

export const SummaryCard = props => {
	const { heading, value, isLoading, subContent, type } = props;
	const months = [
		'Jan',
		'Feb',
		'Mar',
		'Apr',
		'May',
		'Jun',
		'Jul',
		'Aug',
		'Sep',
		'Oct',
		'Nov',
		'Dec'
	];
	return (
		<Box>
			<Box sx={{ display: 'flex', marginBottom: '-7px' }}>
				<Icon src={CostImage} type='static'/>
				<Typography
					sx={{
						marginLeft: '5px',
						display: 'flex',
						alignItems: 'center',
						color: theme => theme.palette.text.blue01,
						fontWeight: 'bold',
						fontSize: '14px'
					}}
				>
					{heading}
				</Typography>
			</Box>
			{isLoading ? (
				<Skeleton
					variant="rounded"
					width={130}
					height={35}
					sx={{
						m: '15px 0 0 5px'
					}}
				/>
			) : (
				<Typography
					sx={{
						marginLeft: '5px',
						display: 'flex',
						alignItems: 'center',
						fontSize: '28px',
						color: theme => theme.palette.text.primary,
						marginTop: '15px',
						fontWeight: 'bold'
					}}
				>
					{value}
				</Typography>
			)}

			{isLoading
				? type === 'cost' &&
				  !subContent && (
						<Skeleton
							variant="rounded"
							width={90}
							height={15}
							sx={{
								m: '2px 0 0 5px'
							}}
						/>
				  )
				: type === 'cost' && (
						<Typography sx={{ ml: '6px' }} variant="h3">
							for {months[new Date().getMonth()]} {new Date().getFullYear()}
						</Typography>
				  )}
		</Box>
	);
};
SummaryCard.propTypes = {
	heading: PropTypes.string.isRequired,
	value: PropTypes.string.isRequired,
	isLoading: PropTypes.string.isRequired,
	subContent: PropTypes.string.isRequired,
	type: PropTypes.string.isRequired
};

export const SeeAll = props => {
	const {
		goto,
		leftClick,
		rightClick,
		leftClickDisable,
		rightClickDisable,
		// count,
		havePagination = false,
		isContentDisabled,
		haveSeeall = true,
		color
	} = props;
	const navigate = useNavigate();
	const goTo = () => {
		navigate(goto);
	};
	return (
		<Box sx={{ display: 'flex' }}>
			{haveSeeall && (
				<Typography
					sx={{
						fontSize: '14px',
						lineHeight: '18.23px',
						cursor: 'pointer',
						width: '50px',
						color: color || '#5552FF',
						'&:hover': {
							textDecoration: 'underline'
						}
					}}
					onClick={goTo}
				>
					See All
				</Typography>
			)}

			{havePagination && (
				<>
					<Icon
						src={leftClickDisable ? DisabledleftIcon : LeftIcon}
						disabled={isContentDisabled || leftClickDisable}
						clickHandler={leftClick}
						margin="-2px 0 0 0"
						type={leftClickDisable && 'static'}
					/>
					<Icon
						src={rightClickDisable ? DisabledRightIcon : RightIcon}
						disabled={isContentDisabled || rightClickDisable}
						clickHandler={rightClick}
						margin="-2px 0 0 0"
						type={rightClickDisable && 'static'}
					/>
				</>
			)}

			{/* {havePagination && (
				<Pagination
					count={2} // Set itemCount to 1 to display only one page
					// page={1} // Set the current page
					// onChange={leftClickDisable}
					// className={classes.hideText}
				/>
			)} */}
		</Box>
	);
};
SeeAll.propTypes = {
	leftClick: PropTypes.func,
	rightClick: PropTypes.func,
	leftClickDisable: PropTypes.bool,
	rightClickDisable: PropTypes.bool,
	havePagination: PropTypes.bool,
	isContentDisabled: PropTypes.bool,
	haveSeeall: PropTypes.bool
};

export const GettingStartedCard = props => {
	const { img, heading, goTo, iconPadding = null } = props;
	// const Goto = () => {
	// 	// navigate(goTo);
	// 	window.location.href = goTo;
	// };
	return (
		<Box
			sx={{
				padding: '6px 10px',
				borderRadius: '8px',
				background: theme => theme.palette.background.blue03,
				display: 'inline-block',
				marginRight: '10px',
				'&:hover': {
					background: theme => theme.palette.background.recentDispatchCard
				}
			}}
			onClick={goTo ? () => window.open(`${goTo}`, '_blank') : null}
		>
			<Box sx={{ display: 'flex' }}>
				<Icon src={img} padding={iconPadding} style={{ marginRight: '4px' }} />
				<Typography
					sx={{
						color: theme => theme.palette.text.primary,
						fontSize: '14px',
						display: 'grid',
						placeItems: 'center'
					}}
				>
					{heading}
				</Typography>
			</Box>
		</Box>
	);
};
GettingStartedCard.propTypes = {
	img: PropTypes.string.isRequired,
	heading: PropTypes.string.isRequired,
	goTo: PropTypes.string.isRequired
};

SummaryCard.propTypes = {
	heading: PropTypes.string.isRequired
	// value: PropTypes.string.isRequired
};
