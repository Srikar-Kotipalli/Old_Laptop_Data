/* eslint-disable no-unsafe-optional-chaining */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Box, Grid, Typography } from '@mui/material';
import './style.css';
import Chart from 'react-apexcharts';
import Icon from '../../icon';
import VirtualImage from '../../../assets/environments/virtualMachine.svg';
import Online from '../../../assets/environments/online.svg';
import Edit from '../../../assets/actions/edit.svg';
import Delete from '../../../assets/actions/delete.svg';
import Copy from '../../../assets/actions/copy.svg';
import { capitalizeName } from '../../../utils/utils';
import MarketplaceChip from '../../marketplace/chip/marketplaceChip';

function PieCharts({ revenueChartData }) {
	const donutData = {
		series: revenueChartData.series,
		options: {
			dataLabels: {
				enabled: false
			},
			legend: {
				show: false
			},
			labels: revenueChartData.labels,
			colors: revenueChartData.colors,
			chart: {
				type: 'donut'
			},
			plotOptions: {
				pie: {
					customScale: 0.7
				}
			},
			// plotOptions: {
			//   pie: {
			//     expandOnClick: false
			//   }
			// },
			stroke: {
				colors: revenueChartData.colors
			}
			// responsive: [
			// 	{
			// 		breakpoint: 480,
			// 		options: {
			// 			chart: {
			// 				width: 200
			// 			},
			// 			dataLabels: {
			// 				enabled: false
			// 			},

			// 		}
			// 	}
			// ]
		}
	};
	return <Chart options={donutData.options} series={donutData.series} height={100} type="donut" />;
}

function PackagesLabel({ title, color, value }) {
	return (
		<Grid sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
			<Box sx={{ width: '6px', height: '6px', borderRadius: '50%', background: color }} />
			<Typography variant="h3" ml={1}>
				{title}
			</Typography>
			<Typography variant="h3" ml={1}>
				{value}
			</Typography>
		</Grid>
	);
}

function EnvironmentCard(props) {
	const { envData, onDelete } = props;
	// const revenueChartData = ;
	const [dataReady, setDataReady] = useState(false);
	const [data, setData] = useState({});
	const chipData = { tags: ['python', 'react', 'quantum', 'sass'] };

	useEffect(() => {
		// Assuming envData.parsedData is fetched asynchronously
		if (envData?.parsedData) {
			setData({
				series: [
					envData?.parsedData?.channels?.length,
					envData?.parsedData?.dependencies?.length - 1,
					envData?.parsedData?.dependencies[0]?.pip?.length || 0
				],
				labels: ['channels', 'conda', 'pip'],
				colors: ['#DAC3FF', '#AD7BFF', '#6473FF']
			});

			// Data is now ready
			setDataReady(true);
		}
	}, [envData]);

	return (
		<Box
			className="envCard"
			sx={{
				borderColor: theme => theme.palette.background.blue03,
				background: theme => theme.palette.background.blue12
			}}
		>
			<Grid className="cardTitleContainer">
				<Box className="containerFlex">
					<Icon src={VirtualImage} width="12px" height="12px" padding="1px 0 0 0" type="static" />
					<Typography ml={1} varaint="h4">
						{capitalizeName(envData.name)}
					</Typography>
					<Icon src={Online} padding="3px 0 0 0" type="static" style={{ marginLeft: '6px' }} />
				</Box>
				<Box>
					<Icon src={Edit} padding="3px 0 0 0" type="static" title="Edit" />
					<Icon src={Copy} padding="3px 0 0 0" type="static" style={{ marginLeft: '20px' }} />
					<Icon
						src={Delete}
						padding="3px 0 0 0"
						type="pointer"
						style={{ marginLeft: '20px' }}
						clickHandler={() => onDelete(envData.id)}
						title="Delete"
					/>
				</Box>
			</Grid>
			<Grid>
				{chipData?.tags?.length > 0 ? (
					<MarketplaceChip items={chipData} isExpandable={false} />
				) : (
					<Box sx={{ height: '44px' }} />
				)}
			</Grid>
			<Grid
				container
				direction="row"
				alignItems="center"
				mt={3}
				pl={0.5}
				sx={{ borderTop: theme => `1px solid ${theme.palette.background.blue03}` }}
			>
				<Grid
					item
					xs={9}
					mt={1}
					sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}
				>
					<PackagesLabel
						title="channels"
						color="#DAC3FF"
						value={envData.parsedData.channels.length}
					/>
					<PackagesLabel
						title="conda"
						color="#AD7BFF"
						value={envData.parsedData.dependencies.length - 1 || 0}
					/>
					<PackagesLabel
						title="pip"
						color="#6473FF"
						value={envData.parsedData.dependencies[0]?.pip?.length || 0}
					/>
				</Grid>
				<Grid
					item
					xs={3}
					pt={1}
					pl={3}
					sx={{ display: 'flex', alignItems: 'center', height: '70px', justifyContent: 'flex-end' }}
				>
					{/* <PieChart
						style={{ height: '70px', marginLeft: '45px' }}
						data={data}
						lineWidth={25} // Adjust the line width for a smaller chart
						radius={40} // Use a smaller radius for a small chart
					/>{' '} */}

					{dataReady && <PieCharts revenueChartData={data} />}
				</Grid>
			</Grid>
		</Box>
	);
}

EnvironmentCard.propTypes = {
	envData: PropTypes.shape({
		id: PropTypes.string.isRequired,
		name: PropTypes.string.isRequired,
		definition: PropTypes.string.isRequired,
		status: PropTypes.string.isRequired,
		env_vars: PropTypes.object,
		secrets: PropTypes.object,
		parsedData: PropTypes.shape({
			channels: PropTypes.arrayOf(PropTypes.string),
			dependencies: PropTypes.arrayOf(
				PropTypes.oneOfType([
					PropTypes.shape({
						pip: PropTypes.arrayOf(PropTypes.string)
					}),
					PropTypes.string
				])
			)
		}),
		default: PropTypes.bool
	}).isRequired
};

export default EnvironmentCard;
