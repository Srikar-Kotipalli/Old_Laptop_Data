/* eslint-disable react/jsx-boolean-value */
import React, { useEffect } from 'react';
import { Grid, Card, CardContent, Typography, Divider } from '@mui/material';
import './style.css';
import copyIcon from '../../../assets/copyIcon.svg';
import Icon from '../../icon';
import tickIcon from '../../../assets/checkmarks/checkmark.svg';
import { getHardwareSourceIcon } from '../../../utils/statusIcons';
import TokenComponent from '../../form/settings/tokenComponent';

function HardwareCard({ hardwareInfo, from }) {
	useEffect(() => {
		return () => {
			// Cleanup function
			// Cancel any subscriptions or asynchronous tasks here
		};
	}, []);

	return (
		<Grid container spacing={2} item xs={12}>
			{hardwareInfo.map(info => (
				<Grid item xs={6} lg={3} md={4} key={info.hardwareId}>
					<Card square className="hardwareCardContainer">
						<CardContent>
							<Grid container className="cardContent">
								<Grid container item xs={12} direction="column">
									<Grid item sx={{ paddingLeft: '15px', paddingTop: '17px', fontSize: '16px' }}>
										{info.status !== 'NA' ? (
											<Typography>{info.technology}</Typography>
										) : (
											<Typography sx={{ color: '#86869A' }}>{info.technology}</Typography>
										)}
									</Grid>
									<Grid
										item
										sx={{
											paddingLeft: '11px',
											paddingTop: info.status !== 'NA' ? '16px' : '-16px'
										}}
									>
										<Icon
											src={getHardwareSourceIcon(info.type, info.status)}
											type="static"
											alt="HardwareIcon"
										/>
									</Grid>
								</Grid>
								<Grid item xs={10} sx={{ paddingLeft: '15px', paddingTop: '16px' }}>
									{info.status === 'online' && (
										<Typography sx={{ color: '#55D899', fontSize: '14px' }}>Online</Typography>
									)}
									{info.status === 'offline' && (
										<Typography sx={{ color: '#FF6464', fontSize: '14px' }}>Offline</Typography>
									)}
									{info.status === 'NA' && (
										<Typography sx={{ color: '#86869A', fontSize: '14px', paddingBottom: '17px' }}>
											Coming Soon
										</Typography>
									)}
								</Grid>
								<Grid container direction="row" sx={{ paddingTop: '16px' }}>
									{info.status !== 'NA' ? (
										<>
											<Grid item sx={{ paddingLeft: '15px' }}>
												<Typography
													sx={{ fontSize: '12px' }}
												>{`Qubits=${info.parameters.num_qbits}`}</Typography>
											</Grid>
											<Grid item>
												<Divider
													sx={{
														borderColor: '#CBCBD7',
														paddingLeft: '14px',
														height: '1px',
														paddingTop: '16px'
													}}
													orientation="vertical"
													flexItem
												/>
											</Grid>
											<Grid item sx={{ paddingLeft: '14px' }}>
												<Typography sx={{ fontSize: '12px' }}>{`Device=${info.name}`}</Typography>
											</Grid>
										</>
									) : (
										<Grid container direction="row" sx={{ paddingTop: '16px' }} />
									)}
								</Grid>
								<Grid item xs={12} sx={{ paddingTop: '16px', paddingLeft: '14px' }}>
									{info.status !== 'NA' && (
										<TokenComponent
											TooltipColor="#08081A"
											copyIcon={copyIcon}
											copiedIcon={tickIcon}
											width={from === 'settings' && info.key !== '' ? '65%' : '63%'}
											height="24px"
											isStartAdornReqd={false}
											fontSize="12px"
											iconWidth="24px"
											iconHeight="24px"
											mxval={0.3}
											paddingVal="0.5px"
											status={info.status}
											value={info.key}
											isDisabled
											from="settings"
											copyEnable
										/>
									)}
								</Grid>
							</Grid>
						</CardContent>
					</Card>
				</Grid>
			))}
		</Grid>
	);
}

export default HardwareCard;
