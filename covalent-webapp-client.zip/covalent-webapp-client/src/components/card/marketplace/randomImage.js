/* eslint-disable import/no-unused-modules */
/* eslint-disable react/no-array-index-key */
/* eslint-disable no-use-before-define */
import React, { useEffect, useState } from 'react';
import Box from '@mui/material/Box';

function RandomImage() {
	useEffect(() => {
		generateBoxes(10);
	}, []);

	const [boxes, setBoxes] = useState([]);

	const colors = ['#303067', '#AD7BFF', '#FFC164', '#5552FF', '#55D899', '#CBCBD7', '#FF6464'];

	const backgroundColors = [
		'#DFFF00',
		'#FFBF00',
		'#FF7F50',
		'#DE3163',
		'#9FE2BF',
		'#40E0D0',
		'#6495ED',
		'#CCCCFF'
	];

	const generateBoxes = limit => {
		// shapes for corners
		const newBoxes = [
			{
				backgroundColor: colors[Math.floor(Math.random() * colors.length)],
				height: `${Math.floor(Math.random() * 50 + 30)}px`,
				width: `${Math.floor(Math.random() * 60 + 50)}px`,
				top: 0,
				left: 0,
				borderRadius: '10px'
			},
			{
				backgroundColor: colors[Math.floor(Math.random() * colors.length)],
				height: `${Math.floor(Math.random() * 50 + 30)}px`,
				width: `${Math.floor(Math.random() * 60 + 50)}px`,
				top: 0,
				right: 0,
				borderRadius: '10px'
			},
			{
				backgroundColor: colors[Math.floor(Math.random() * colors.length)],
				height: `${Math.floor(Math.random() * 50 + 30)}px`,
				width: `${Math.floor(Math.random() * 60 + 50)}px`,
				bottom: 0,
				left: 0,
				borderRadius: '10px'
			},
			{
				backgroundColor: colors[Math.floor(Math.random() * colors.length)],
				height: `${Math.floor(Math.random() * 50 + 30)}px`,
				width: `${Math.floor(Math.random() * 60 + 50)}px`,
				bottom: 0,
				right: 0,
				borderRadius: '10px'
			}
		];
		// add squares/rectangles
		for (let i = 0; i < limit; i++) {
			const box = {
				backgroundColor: colors[Math.floor(Math.random() * colors.length)],
				height: `${Math.floor(Math.random() * 50 + 30)}px`,
				width: `${Math.floor(Math.random() * 60 + 50)}px`,
				top: `${Math.floor(Math.random() * 50)}%`,
				left: `${Math.floor(Math.random() * 90)}%`,
				borderRadius: '10px'
			};
			newBoxes.push(box);
		}

		// add circles
		const add = [20, 30, 40, 50, 60, 70, 80, 90, 100];
		const circles = limit / 2;
		for (let i = 0; i < circles; i++) {
			const diameter =
				Math.floor(Math.random()) * 100 + add[Math.floor(Math.random() * add.length)];
			const box = {
				backgroundColor: colors[Math.floor(Math.random() * colors.length)],
				height: `${diameter}px`,
				width: `${diameter}px`,
				top: `${Math.floor(Math.random() * 50)}%`,
				left: `${Math.floor(Math.random() * 90)}%`,
				borderRadius: '50%'
			};
			newBoxes.push(box);
		}
		setBoxes(newBoxes);
	};

	return (
		<Box
			sx={{
				height: '116px',
				position: 'relative',
				overflow: 'hidden',
				backgroundColor: backgroundColors[Math.floor(Math.random() * backgroundColors.length)]
			}}
		>
			{boxes.map((box, index) => (
				<div
					key={index}
					className="box"
					style={{
						position: 'absolute',
						opacity: '0.4',
						borderRadius: box.borderRadius,
						backgroundColor: box.backgroundColor,
						height: box.height,
						width: box.width,
						top: box.top,
						left: box.left,
						bottom: box.bottom,
						right: box.right
					}}
				/>
			))}
		</Box>
	);
}

export default RandomImage;
