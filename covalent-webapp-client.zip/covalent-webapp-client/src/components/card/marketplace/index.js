/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React from 'react';
import { Card, CardContent, Typography, Box } from '@mui/material';

const marketCardHero = ({ title, description, imageUrl, count, content, backgroundColor }) => {
	const cardStyle = {
		background: backgroundColor || 'white', // Set default background color if not provided
		paddingLeft: '38px',
		paddingRight: '48px',
		marginTop: '1rem',
		height: '156px',
		// width:'560px',
		display: 'flex'
	};

	return (
		<Box>
			<Card style={cardStyle}>
				<Box>
					<CardContent sx={{ marginTop: '12px' }}>
						<Typography sx={{ fontSize: '24px', paddingBottom: '8px' }}>{title}</Typography>
						<Box sx={{ fontSize: '14px', paddingBottom: '8px' }}>{description}</Box>
						<Typography sx={{ fontSize: '12px', paddingBottom: '8px' }}>
							{content} {count}
						</Typography>
					</CardContent>
				</Box>
				<Box mt={3}>
					<img src={imageUrl} alt="heroCard" />
				</Box>
			</Card>
		</Box>
	);
};

export default marketCardHero;
