/* eslint-disable no-unused-vars */
/* eslint-disable quotes */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to AgnostiUser has no billing accountq at: [support@agnostiq.com].
 */

import React, { useEffect, useState } from 'react';
import Chart from 'react-apexcharts';
import { Box, Grid, Typography, Select, MenuItem, SvgIcon } from '@mui/material';
// import { BarChart } from '@mui/x-charts/BarChart';
import { Auth } from 'aws-amplify';
// import CostImage from '../../assets/cost.svg';
import Icon from '../icon';
import { getDispatchesCharges, getHardwareData } from '../../api/dashboard/dashboardApi';
import GraphTab from '../tab/graph';
import {
	startAndEndDate,
	formattedDate,
	replaceMissingDates,
	getFormattedDate,
	groupInputArray,
	changeDateFormat,
	getDate,
	processData
} from '../../utils/utils';

import RevampedActivityList from './revampedActivityList';
import useUpdateEffect from '../../utils/useUpdateEffect';
import Loader from '../loader';
import GraphIcon from '../../assets/dashboard/graphIcon.svg';

function CustomIcon(props) {
	return (
		// eslint-disable-next-line react/jsx-props-no-spreading
		<SvgIcon {...props} style={{ transform: 'translateY(20%)' }}>
			<svg width="16" height="16" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path
					d="M8 10.9998L3 5.9998L3.7 5.2998L8 9.59981L12.3 5.2998L13 5.9998L8 10.9998Z"
					fill="#CBCBD7"
				/>
			</svg>
		</SvgIcon>
	);
}

// function DonutChart(chartData = [44, 55, 41, 17], chartLabels = ['CPU', 'GPU1', 'GPU2', 'GPU3']) {
// 	return (
// 		<Chart
// 			options={{
// 				series: chartData,
// 				background: {
// 					enabled: true,
// 					foreColor: 'red'
// 				},
// 				stroke: { colors: ['transparent'] },
// 				labels: chartLabels,
// 				colors: ['#5552FF', '#303067', '#BB5DA2', '#55A2C2'],
// 				chart: {
// 					type: 'donut'
// 				},
// 				plotOptions: {
// 					pie: {
// 						donut: {
// 							size: '70%'
// 						}
// 					}
// 				},
// 				dataLabels: {
// 					enabled: false
// 				}
// 			}}
// 			series={chartData}
// 			// height={250}
// 			type="donut"
// 		/>
// 	);
// }

function DispatchChart({ UsageChartData }) {
	const chartData = {
		series: [
			{
				data: UsageChartData?.data
			}
		],
		options: {
			chart: {
				type: 'line',
				zoom: {
					enabled: false,
					type: 'x'
				},
				toolbar: {
					show: false
				}
			},
			grid: {
				show: false
			},
			legend: {
				show: false
			},
			dataLabels: {
				enabled: false
			},
			colors: ['#5552FF'],
			stroke: {
				curve: 'smooth',
				width: 2
			},
			// markers: {
			// 	size: 2,
			// 	colors: ['#FFA500'],
			// 	strokeWidth: 0,
			// 	strokeOpacity: 0,
			// 	strokeDashArray: 0,
			// 	fillOpacity: 0,
			// 	radius: 0,
			// 	offsetX: 0,
			// 	offsetY: 0,
			// 	hover: {
			// 		size: 3,
			// 		sizeOffset: 0
			// 	}
			// },
			yaxis: [
				{
					title: {
						text: UsageChartData?.parameters?.yAxisTitle,
						style: {
							color: 'white'
						}
					},
					tickAmount: UsageChartData?.parameters?.xAxisParams?.tickAmount,
					min: UsageChartData?.parameters?.xAxisParams?.min,
					max: UsageChartData?.parameters?.xAxisParams?.max,
					axisTicks: {
						show: true
					},
					axisBorder: {
						show: true
					},
					crosshairs: {
						show: true
					},
					labels: {
						style: {
							colors: ['white']
						}
					}
				}
			],
			// xaxis: {
			// 	title: {
			// 		text: 'Time',
			// 		style: {
			// 			color: 'white'
			// 		}
			// 	},
			// 	axisTicks: {
			// 		show: false
			// 	},
			// 	crosshairs: {
			// 		show: false
			// 	},
			// 	axisBorder: {
			// 		show: false
			// 	},
			// 	labels: {
			// 		show: false
			// 	},
			// 	tooltip: {
			// 		enabled: false
			// 	},
			// 	// type: 'datetime',
			// 	categories: UsageChartData.categories
			// },
			xaxis: {
				title: {
					text: UsageChartData?.parameters?.xAxisTitle,
					style: {
						color: 'white',
						align: 'center'
					}
				},
				axisTicks: {
					show: false
				},
				crosshairs: {
					show: false
				},
				axisBorder: {
					show: false
				},
				labels: {
					show: true, // Set this to true to display X-axis labels
					style: {
						colors: '#ffffff',
						fontSize: '11px'
					},
					rotate: 0
				},
				tooltip: {
					enabled: false
				},
				// type: 'datetime',
				categories: UsageChartData?.categories
			},
			// grid: {
			// 	borderColor: '#303067'
			// },
			tooltip: {
				custom({ series, seriesIndex, dataPointIndex }) {
					return `${series[seriesIndex][dataPointIndex]}`;
				}
			}
		}
	};
	return <Chart options={chartData?.options} series={chartData?.series} height={220} />;
}

function Statistics() {
	const [userId, setUserId] = useState('');
	const [selected, setSelected] = useState('This week');
	const [dates, setDates] = useState({ startDate: '', endDate: '' });
	const [tabValue, setTabValue] = useState('Cost');
	const [hasBillingAccount, setHasBillingAccount] = useState(true);
	const [graphLoader, setGraphLoader] = useState(true);
	// const [pieChartData, setPieChartdata] = useState({});

	const [costs, setCosts] = useState([0]);
	const [xAxis, setXAxis] = useState([0]);
	const [maxDispatchYAxis, setMaxDispatchYAxis] = useState([0]);
	const [dispatchCount, setDispatchCount] = useState([0]);
	const [maxYAxis, setMaxYAxis] = useState(0);

	const [totalRecords, setTotalRecords] = useState(0);

	const selectionChangeHandler = event => {
		setSelected(event?.target?.value);
		startAndEndDate(event?.target?.value, setDates, dates);
	};

	// sets the costs and dates for cost graph
	const costArray = (array, select) => {
		const groupedArray = groupInputArray(array);
		let costValues = [];
		let dispatchCountValues = [];

		const today = new Date();

		const week = [];
		const month = [];
		const last3Months = [];

		if (select === 'This week') {
			costValues = [0, 0, 0, 0, 0, 0, 0, 0];
			dispatchCountValues = [0, 0, 0, 0, 0, 0, 0, 0];
			const xAxisDates = [
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 7)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 6)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 5)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 4)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 3)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 2)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 1)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today?.getDate()))
			];

			// getting only the dates from each object
			const onlyDates = groupedArray?.map(obj => obj.date);

			const transformedDates = xAxisDates?.map(e => {
				return new Date(e)?.toDateString();
			});

			// adding the dates which has cost to the xAxis array which are not present
			for (let i = 0; i < onlyDates?.length; i++) {
				if (!transformedDates?.includes(new Date(onlyDates[i])?.toDateString())) {
					week.push(onlyDates[i]);
				}
			}

			week?.push(...xAxisDates);
			week?.sort((a, b) => new Date(a) - new Date(b)); // sort the array in asc order
			setXAxis(week?.map(formattedDate));

			// sets the cost array which is used in the graph
			for (let i = 0; i < week.length; i++) {
				if (
					groupedArray.some(
						obj => new Date(obj?.date)?.toDateString() === new Date(week[i])?.toDateString()
					)
				) {
					const index = groupedArray.findIndex(
						obj => new Date(obj?.date)?.toDateString() === new Date(week[i])?.toDateString()
					);
					costValues[i] = groupedArray[index].cost / 1000000;
					dispatchCountValues[i] = groupedArray[index]?.count;
				} else {
					costValues[i] = 0;
					dispatchCountValues[i] = 0;
				}
			}
		}
		if (select === 'This month') {
			costValues = [0, 0, 0, 0, 0];
			dispatchCountValues = [0, 0, 0, 0, 0];
			const xMonth = [
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 28)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 21)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 14)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 7)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today?.getDate()))
			];
			const xAxisDates = [];

			for (let i = 28; i >= 0; i--) {
				xAxisDates?.push(
					changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - i))
				);
			}

			const onlyDates = groupedArray?.map(obj => obj.date);

			const transformedDates = xAxisDates?.map(e => {
				return new Date(e)?.toDateString();
			});

			for (let i = 0; i < onlyDates?.length; i++) {
				if (!transformedDates.includes(new Date(onlyDates[i])?.toDateString())) {
					month?.push(onlyDates[i]);
				}
			}

			month?.push(...xAxisDates);
			month?.sort((a, b) => new Date(a) - new Date(b));
			setXAxis(month?.map(getFormattedDate));

			for (let i = 0; i < month?.length; i++) {
				if (
					groupedArray?.some(
						obj => new Date(obj.date).toDateString() === new Date(month[i]).toDateString()
					)
				) {
					const index = groupedArray?.findIndex(
						obj => new Date(obj.date).toDateString() === new Date(month[i]).toDateString()
					);
					costValues[i] = groupedArray[index].cost / 1000000;
					dispatchCountValues[i] = groupedArray[index]?.count;
				} else {
					costValues[i] = 0;
					dispatchCountValues[i] = 0;
				}
			}
			setXAxis(replaceMissingDates(xAxisDates, xMonth)?.map(formattedDate));
		}
		if (select === 'Last 3 months') {
			costValues = [0, 0, 0, 0, 0, 0, 0];
			dispatchCountValues = [0, 0, 0, 0, 0, 0, 0];
			const xLast3months = [
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 90)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 75)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 60)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 45)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 30)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - 15)),
				changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today?.getDate()))
			];
			const xAxisDates = [];

			for (let i = 90; i >= 0; i--) {
				xAxisDates.push(
					changeDateFormat(new Date(today?.getFullYear(), today?.getMonth(), today.getDate() - i))
				);
			}

			const onlyDates = groupedArray?.map(obj => obj.date);

			const transformedDates = xAxisDates?.map(e => {
				return new Date(e)?.toDateString();
			});

			for (let i = 0; i < onlyDates?.length; i++) {
				if (!transformedDates?.includes(new Date(onlyDates[i])?.toDateString())) {
					last3Months?.push(onlyDates[i]);
				}
			}

			last3Months?.push(...xAxisDates);
			last3Months?.sort((a, b) => new Date(a) - new Date(b));
			setXAxis(last3Months?.map(getFormattedDate));

			for (let i = 0; i < last3Months.length; i++) {
				if (
					groupedArray?.some(
						obj => new Date(obj?.date)?.toDateString() === new Date(last3Months[i])?.toDateString()
					)
				) {
					const index = groupedArray?.findIndex(
						obj => new Date(obj?.date)?.toDateString() === new Date(last3Months[i])?.toDateString()
					);
					costValues[i] = groupedArray[index].cost / 1000000;
					dispatchCountValues[i] = groupedArray[index].count;
				} else {
					costValues[i] = 0;
					dispatchCountValues[i] = 0;
				}
			}
			setXAxis(replaceMissingDates(xAxisDates, xLast3months)?.map(formattedDate));
		}
		return { cost: costValues, dispatch: dispatchCountValues };
	};

	// returns the date 'days' days previous to todays date in yyyy-mm-dd format
	const beforeDate = days => {
		const today = new Date();

		const nDaysAgo = new Date(today);
		nDaysAgo?.setDate(nDaysAgo.getDate() - days);

		const year = nDaysAgo?.getFullYear();
		const month = nDaysAgo.getMonth() + 1;
		const day = nDaysAgo?.getDate();

		return `${year}-${month}-${day}`;
	};

	// returns the date 'n' months previous to todays date in yyyy-mm-dd format
	const prevMonths = n => {
		const today = new Date();

		const nMonthsAgo = new Date(today?.getFullYear(), today.getMonth() - n, today?.getDate());

		const year = nMonthsAgo?.getFullYear();
		const month = nMonthsAgo.getMonth() + 1;
		const day = nMonthsAgo?.getDate();

		return `${year}-${month}-${day}`;
	};

	const [fromDate, setFromDate] = useState(beforeDate(7));

	const onTabChange = (_e, val) => {
		setTabValue(val);
	};
	// useEffect(() => {
	// 	if (userId) {
	// 		getHardwareData(userId, '2020-01-01', getDate())
	// 			.then(payload => {
	// 				if (payload) {
	// 					setPieChartdata(processData(payload?.records));
	// 				}
	// 			})
	// 			.catch(err => {
	// 				console.log(err);
	// 			});
	// 	}
	// }, [userId]);

	useEffect(() => {
		setGraphLoader(true);
		Auth.currentAuthenticatedUser()
			.then(user => {
				const res = user?.attributes;
				const userID = res && res['custom:userID'];
				setUserId(res && res['custom:userID']);
				getDispatchesCharges(userID, fromDate, getDate(), 0)
					.then(payload => {
						if (payload) {
							setTotalRecords(payload.metadata.total_count);
						}
						setGraphLoader(false);
					})
					.catch(() => {
						setHasBillingAccount(false);
						setGraphLoader(false);
					});
			})
			.catch(() => {
				setHasBillingAccount(false);
				setGraphLoader(false);
			});
	}, [fromDate]);

	useEffect(() => {
		Auth.currentAuthenticatedUser()
			.then(user => {
				const res = user?.attributes;
				const userID = res && res['custom:userID'];
				getDispatchesCharges(userID, fromDate, getDate(), totalRecords)
					.then(payload => {
						if (payload) {
							setCosts(costArray(payload?.records, selected).cost);
							setMaxYAxis(1.2 * Math.max(...costArray(payload.records, selected).cost));
							setMaxDispatchYAxis(
								Math.ceil(1.1 * Math.max(...costArray(payload.records, selected).dispatch))
							);
							setDispatchCount(costArray(payload?.records, selected).dispatch);
						}
					})
					.catch(() => {
						setHasBillingAccount(false);
					});
			})
			.catch(() => {
				setHasBillingAccount(false);
			});
	}, [totalRecords, fromDate]);

	useEffect(() => {
		if (selected === 'This week') {
			setFromDate(beforeDate(7));
		}
		if (selected === 'This month') {
			setFromDate(prevMonths(1));
		}

		if (selected === 'Last 3 months') {
			setFromDate(prevMonths(3));
		}
	}, [selected]);

	const costGraphData = {
		allTimeMonth: {
			min: 0,
			max: maxYAxis,
			divisions: 5,
			axis: xAxis,
			data: costs
		}
	};

	const dispatchGraphData = {
		allTimeMonth: {
			min: 0,
			max: maxDispatchYAxis,
			divisions: 5,
			axis: xAxis,
			data: dispatchCount
		}
	};
	return (
		<Box
			sx={{
				border: theme => `1px solid ${theme.palette.background.blue03}`,
				borderRadius: '8px',
				height: '317px',
				padding: '20px',
				display: 'flex',
				background: theme => theme.palette.background.covalentSidebar
			}}
		>
			<Grid container>
				<Grid item xs={8}>
					<Box sx={{ display: 'flex', width: '90%', marginTop: '-10px' }}>
						<GraphTab
							value={tabValue}
							onChange={onTabChange}
							firstValue="Cost"
							secondValue="Dispatch"
							headingFontSize="16px"
						/>
						<Box sx={{ display: 'flex', alignItems: 'center' }}>
							<Select
								IconComponent={CustomIcon}
								value={selected}
								onChange={selectionChangeHandler}
								variant="outlined"
								size="small"
								className="shownBtn"
								sx={{
									background: theme => theme.palette.background.paper,
									borderRadius: '200px',
									padding: '0 0 0 14px',
									width: '150px',
									height: '30px',
									color: 'white',
									fontSize: '14px',
									'.MuiOutlinedInput-notchedOutline': {
										borderColor: theme => theme.palette.background.blue05
									},
									'&.Mui-focused .MuiOutlinedInput-notchedOutline': {
										borderColor: theme => theme.palette.background.blue05
									},
									'&:hover .MuiOutlinedInput-notchedOutline': {
										borderColor: theme => theme.palette.background.blue05
									},
									'&:hover': {
										background: theme => theme.palette.background.covalentPurple
									},
									'.MuiSvgIcon-root ': {
										fill: 'transparent !important'
									}
								}}
							>
								<MenuItem value="This week" sx={{ fontSize: '14px' }}>
									This week
								</MenuItem>
								<MenuItem value="This month" sx={{ fontSize: '14px' }}>
									This month
								</MenuItem>
								<MenuItem value="Last 3 months" sx={{ fontSize: '14px' }}>
									Last 3 months
								</MenuItem>
							</Select>
						</Box>
					</Box>

					{tabValue === 'Cost' && (
						<Box sx={{ width: '90%', height: 'calc(100% - 38px)' }}>
							{hasBillingAccount ? (
								graphLoader ? (
									<Loader isFetching={graphLoader} position="relative" width="100%" height="100%" />
								) : (
									<DispatchChart
										UsageChartData={{
											data: costGraphData?.allTimeMonth?.data,
											categories: costGraphData?.allTimeMonth?.axis,
											parameters: {
												xAxisTitle: 'Time',
												yAxisTitle: 'Cost ($)',
												xAxisParams: {
													tickAmount: costGraphData?.allTimeMonth?.divisions,
													min: costGraphData?.allTimeMonth?.min,
													max: costGraphData?.allTimeMonth?.max
												}
											}
										}}
									/>
								)
							) : (
								<Box
									sx={{
										width: '100%',
										height: '100%',
										display: 'flex',
										alignItems: 'center',
										justifyContent: 'center'
									}}
								>
									<Box sx={{ display: 'grid', placeItems: 'center' }}>
										<Icon src={GraphIcon} style={{ rotate: '-90deg' }} />
										<Typography>Breakdown will be shown once costs are incurred</Typography>
									</Box>
								</Box>
							)}
						</Box>
					)}
					{tabValue === 'Dispatch' && (
						<Box sx={{ width: '90%', height: 'calc(100% - 38px)' }}>
							{hasBillingAccount ? (
								graphLoader ? (
									<Loader isFetching={graphLoader} position="relative" width="100%" height="100%" />
								) : (
									// <BarChart
									// 	series={[{ data: dispatchCount }]}
									// 	height={220}
									// 	xAxis={[{ data: xAxis, scaleType: 'band', label: 'Time' }]}
									// 	yAxis={[
									// 		{
									// 			label: 'Dispatch'
									// 		}
									// 	]}
									// />
									<DispatchChart
										UsageChartData={{
											data: dispatchGraphData?.allTimeMonth?.data,
											categories: dispatchGraphData?.allTimeMonth?.axis,
											parameters: {
												xAxisTitle: 'Time',
												yAxisTitle: 'Dispatch',
												xAxisParams: {
													tickAmount: dispatchGraphData?.allTimeMonth?.divisions,
													min: dispatchGraphData?.allTimeMonth?.min,
													max: dispatchGraphData?.allTimeMonth?.max
												}
											}
										}}
									/>
								)
							) : (
								<Box
									sx={{
										width: '100%',
										height: '100%',
										display: 'grid',
										placeItems: 'center'
									}}
								>
									<Box sx={{ display: 'grid', placeItems: 'center' }}>
										<Icon src={GraphIcon} style={{ rotate: '-90deg' }} />
										<Typography>Breakdown will be shown once costs are incurred</Typography>
									</Box>
								</Box>
							)}
						</Box>
					)}
				</Grid>

				<Grid item xs={4} sx={{ height: '100%' }}>
					{/* <Box
						sx={{
							border: theme => `1px solid ${theme.palette.background.blue03}`,
							background: theme => theme.palette.background.dashboardCard,
							borderRadius: '8px',
							boxShadow: '0px 4px 4px 0px rgba(0, 0, 0, 0.45)',
							padding: '20px'
						}}
					>
						<Box sx={{ display: 'flex', alignItems: 'center', marginBottom: '30px' }}>
							<Icon src={CostImage} />
							<Typography
								sx={{
									marginLeft: '5px',
									display: 'flex',
									alignItems: 'center',
									color: theme => theme.palette.text.blue01,
									fontWeight: '700',
									fontSize: '14px'
								}}
							>
								Hardware Breakdown
							</Typography>
						</Box>
						{DonutChart(pieChartData?.cost, pieChartData?.vcpus)}
					</Box> */}
					<Box sx={{ height: '100%' }}>
						<Typography sx={{ mb: '5px' }}>Activity</Typography>

						<RevampedActivityList />
					</Box>
				</Grid>
			</Grid>
		</Box>
	);
}

export default Statistics;
