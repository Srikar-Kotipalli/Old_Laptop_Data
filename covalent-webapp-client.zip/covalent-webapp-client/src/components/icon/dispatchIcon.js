/* eslint-disable react/jsx-no-useless-fragment */
/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
/* eslint-disable react/no-array-index-key */

import React from 'react';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import TableCell from '@mui/material/TableCell';
import { Tooltip, ListItemButton, Typography } from '@mui/material';
import TableRow from '@mui/material/TableRow';
import OverlappingIcons from './overlappingIcons';
import RunTimeTooltip from '../tooltip/runTimeTooltip';
import MiniMoreLoader from '../../assets/loaders/loader.svg';
import caretDownIcon from '../../assets/arrows/caretDown.svg';
import Icon from './index';
import { stringReducer } from '../../utils/utils';

function DispatchIcon(props) {
	const { data, totalCount, showMore, moveLoader } = props;
	return (
		<>
			{data.map((item, key) => (
				<TableRow sx={{ borderRadius: '18px' }} key={key}>
					<TableCell sx={{ pl: 2, width: '53%' }}>
						<Grid container direction="row" spacing={2} alignItems="center" sx={{ width: '11rem' }}>
							<Grid item>
								<Box>
									<OverlappingIcons type="DISPATCH" status={item?.status?.toUpperCase()} />
								</Box>
							</Grid>
							<Tooltip title={item?.name}>
								<Grid item>{stringReducer(item?.name)}</Grid>
							</Tooltip>
						</Grid>
					</TableCell>
					<TableCell>
						<RunTimeTooltip value={item?.runtime} placement="top" />
					</TableCell>
					<TableCell align="right" sx={{ pr: 2, width: '22%' }}>
						{item?.completed_task_num} / {item?.electron_num}
					</TableCell>
				</TableRow>
			))}
			<TableRow>
				{data?.length !== 0 && data?.length < totalCount && (
					<TableCell>
						<ListItemButton
							component="div"
							onClick={showMore}
							sx={{
								paddingLeft: '1.3rem',
								background: 'transparent',
								'&:hover': {
									background: 'transparent'
								}
							}}
						>
							{moveLoader ? (
								<Icon src={MiniMoreLoader} type="static" alt="moveLoader" />
							) : (
								<Icon
									src={caretDownIcon}
									type="pointer"
									alt="caretDown"
									padding="0px 3px 2px 3px"
								/>
							)}
							<Typography variant="subtitle2" color="textPrimary" pl={2.5}>
								Show more
							</Typography>
						</ListItemButton>
					</TableCell>
				)}
			</TableRow>
		</>
	);
}

export default DispatchIcon;
