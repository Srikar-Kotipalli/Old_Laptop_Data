import React from 'react';
import { Box, Grid, SvgIcon, Select, MenuItem, Button, Typography } from '@mui/material';
import DatePicker from 'react-datepicker';
import ascending from '../../assets/marketplace/ascending.svg';
import SearchInput from '../inputBase/projects/searchInput';
import 'react-datepicker/dist/react-datepicker.css';

function CustomIcon(props) {
	return (
		// eslint-disable-next-line react/jsx-props-no-spreading
		<SvgIcon {...props} style={{ transform: 'translateY(20%)' }}>
			<svg
				width="16"
				height="16"
				viewBox="0 0 16 22"
				fill="none"
				xmlns="http://www.w3.org/2000/svg"
			>
				<path
					d="M8 10.9998L3 5.9998L3.7 5.2998L8 9.59981L12.3 5.2998L13 5.9998L8 10.9998Z"
					fill="#CBCBD7"
				/>
			</svg>
		</SvgIcon>
	);
}

function SubHeaderControls({
	width,
	sort,
	setSort,
	searchValue,
	setSearchValue,
	from,
	setDateRange,
	startDate,
	endDate,
	value,
	setToFilter,
	toFilter
}) {
	// const [searchKey, setSearchKey] = useState('');

	// const [sortColumn, setSortColumn] = useState('Descending');

	// const onSort = event => {
	// 	setSortColumn(event.target.value);
	// };

	// cancel search
	const cancelSearch = () => {
		setSearchValue('');
	};

	const selectionChangeHandler = event => {
		setToFilter(event.target.value);
	};

	return (
		<Box sx={{ width }}>
			<Grid
				container
				direction="row"
				justifyContent="space-between"
				alignItems="center"
				mt={3}
				width="100%"
			>
				<SearchInput
					sx={{
						border: theme => `1px solid ${theme.palette.background.blue03}`,
						borderRadius: '20px',
						width: '260px',
						height: '32.69px',
						'&.Mui-focused ': {
							border: theme => `1px solid ${theme.palette.background.blue05}`
						}
						// mt:'10rem'
					}}
					value={searchValue || ''}
					onChange={e => setSearchValue(e.target.value)}
					cancelSearch={cancelSearch}
				/>
				<Box sx={{ display: 'flex' }}>
					{from === 'hardwareUsers' && (
						<Box sx={{ mr: '27px' }}>
							<DatePicker
								className="usersDateRangePicker"
								selectsRange
								startDate={startDate}
								endDate={endDate}
								onChange={update => {
									setDateRange(update);
								}}
								isClearable
								placeholderText={'\xa0\xa0\xa0\xa0Start Date - End Date'}
								dateFormat="dd 'th' MMM"
							/>
						</Box>
					)}
					<Box sx={{ paddingRight: '27px' }} display="flex" direction="row" spacing={3}>
						<Select
							IconComponent={CustomIcon}
							value={toFilter}
							onChange={selectionChangeHandler}
							className="tableHeaderSelect"
							sx={{
								fontSize: '14px',
								background: theme => theme.palette.background.paper,
								borderRadius: '200px',
								// padding: '0rem 1rem',
								width: toFilter === 'popular' ? '6rem' : '139px',
								height: '32px',
								color: theme => theme.palette.background.blue09,
								'&:hover': {
									backgroundColor: theme => theme.palette.background.covalentPurple,
									color: theme => theme.palette.text.secondary,
									borderRadius: '25px',
									borderColor: theme => theme.palette.background.blue05
								},
								'.MuiOutlinedInput-notchedOutline': {
									borderColor: theme => theme.palette.background.blue05
								},
								'&.Mui-focused .MuiOutlinedInput-notchedOutline': {
									borderColor: theme => theme.palette.background.blue05
								},
								'&:hover .MuiOutlinedInput-notchedOutline': {
									borderColor: theme => theme.palette.background.blue05
								},
								'.MuiSvgIcon-root ': {
									fill: 'transparent !important'
								}
							}}
						>
							<MenuItem sx={{ fontSize: '14px', width: '139px' }} value="last_updated">
								Last Updated{' '}
							</MenuItem>
							<MenuItem sx={{ fontSize: '14px', width: '139px' }} value="popular">
								Popular{' '}
							</MenuItem>
						</Select>
					</Box>
					{(value === 'Hardware' || value === 'Solvers' || value === 'Earnings') && (
						<Button
							variant="outlined"
							sx={{
								'&:hover': {
									backgroundColor: theme => theme.palette.background.covalentPurple,
									color: theme => theme.palette.text.secondary,
									borderRadius: '25px',
									borderColor: theme => theme.palette.background.blue05
								},
								display: 'flex',
								justifyContent: 'center',
								borderRadius: '25px',
								height: '32px',
								width: '121px',
								marginLeft: '0.2rem',
								marginRight: '2rem'
							}}
							endIcon={
								<img
									src={ascending}
									alt={sort}
									style={{ transform: sort === 'desc' ? 'rotate(180deg)' : '' }}
								/>
							}
							onClick={() => (sort === 'asc' ? setSort('desc') : setSort('asc'))}
							// onClick={handleSortClick}
						>
							<Typography
								pt={0}
								variant="popUpDispatch"
								sx={{ color: theme => theme.palette.background.blue09 }}
							>
								{sort === 'asc' ? 'Ascending' : 'Descending'}
							</Typography>
						</Button>
					)}
				</Box>
			</Grid>
		</Box>
	);
}

export default SubHeaderControls;
