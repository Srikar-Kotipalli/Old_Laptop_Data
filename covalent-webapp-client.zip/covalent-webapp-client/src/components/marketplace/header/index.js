import React, { useEffect, useState } from 'react';
import { Avatar, Box, Grid, Stack, Typography } from '@mui/material';
import Icon from '../../icon';
import starIcon from '../../../assets/starFilled.svg';
import IBMquanto from '../../../assets/IBMquanto.svg';
import EnvironmentImage from '../../../assets/EnvironmentImage.svg';
import HardwareImage from '../../../assets/hardwareImage.svg';
import './style.css';

function MarketplaceHeader({ data, solverSection }) {
	const [hardwareImage, setHardwareImage] = useState(true);
	useEffect(() => {
		if (window.location.pathname.includes('hardware')) {
			setHardwareImage(true);
		} else {
			setHardwareImage(false);
		}
	});
	return (
		<Grid container columnSpacing={4} className="headerCtr" alignItems="center">
			<Grid item xs={3}>
				<Stack direction="row" spacing={2} alignItems="center" sx={{ width: '400px' }}>
					<Box>
						<Avatar variant="rounded" className="avatartImg">
							{hardwareImage ? (
								<Icon src={HardwareImage} alt="" />
							) : (
								<Icon src={EnvironmentImage} alt="" />
							)}
						</Avatar>
					</Box>
					<Box>
						<Typography className="typHead">{data?.name}</Typography>
						<Typography className="typPara">{data?.desc}</Typography>
						{data?.count && (
							<Stack direction="row" spacing={1} alignItems="center">
								<Box>
									<Icon src={starIcon} />
								</Box>
								<Box className="startCountLabel">{data?.count}</Box>
							</Stack>
						)}
					</Box>
				</Stack>
			</Grid>
			{!solverSection && (
				<Grid item xs={9}>
					<Box sx={{ textAlign: 'right' }}>
						<Icon src={IBMquanto} type="static" />
					</Box>
					<Box sx={{ float: 'right', mt: 2 }}>
						<Grid container>
							<Grid>
								<Stack direction="row" spacing={2} alignItems="center">
									<Box className="createdlabel">Created Date</Box>
									<Box className="createdlabelsub" sx={{ fontSize: '14px' }}>
										{data?.created_date}
									</Box>
								</Stack>
							</Grid>
							<Grid sx={{ ml: 5 }}>
								<Stack direction="row" spacing={2} alignItems="center">
									<Box className="createdlabel">Last Build</Box>
									<Box className="createdlabelsub" sx={{ fontSize: '14px' }}>
										{data?.last_build}
									</Box>
								</Stack>
							</Grid>
						</Grid>
					</Box>
				</Grid>
			)}
		</Grid>
	);
}

export default MarketplaceHeader;
