/* eslint-disable import/no-unused-modules */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React from 'react';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Link from '@mui/material/Link';
import '../../App.css';
import './style.css';
import covalentLogo from '../../assets/logos/covalentlogowithname.svg';
import LeftCube from '../../assets/notfound/leftCube.svg';
import RightCube from '../../assets/notfound/rightCube.svg';
import Circle from '../../assets/notfound/circleBottom.svg';
import notfoundImage from '../../assets/notfound/notfoundImage.svg';

function DispatchNotFound() {
	return (
		<Grid
			container
			spacing={3}
			direction="row"
			justifyContent="center"
			alignItems="center"
			sx={{
				top: 0,
				left: 30,
				position: 'absolute',
				height: '102vh',
				width: '100vw',
				background: 'linear-gradient(180deg, #1C1C46 0%, #08081A 57.81%), url(.png)'
			}}
		>
			<Grid item xs={12} sx={{ textAlign: 'center' }}>
				<Box className="leftbox">
					<img src={LeftCube} alt="leftcube" role="presentation" />
				</Box>
				<Box className="rightbox">
					<img src={RightCube} alt="rightcube" role="presentation" />
				</Box>
				<Grid className="circleBottom" sx={{ height: '12px' }}>
					<img src={Circle} alt="circle" role="presentation" />
				</Grid>
				<Box className="circleTop">
					<img src={Circle} alt="circle" role="presentation" />
				</Box>
				<Box>
					<img src={covalentLogo} className="notfoundLogo" alt="logo" role="presentation" />
				</Box>
				<Box>
					<img
						src={notfoundImage}
						className="notfoundImage"
						alt="notfoundImage"
						role="presentation"
					/>
				</Box>
				<Box>
					<Typography
						sx={{
							fontSize: '40px',
							letterSpacing: '0.05em',
							textTransform: 'uppercase',
							color: '#F1F1F6',
							fontWeight: 900
						}}
					>
						dispatch not found
					</Typography>
					<Button
						variant="contained"
						disableElevation
						sx={{
							padding: ' 8px 16px',
							width: '220px',
							height: '40px',
							background: '#5552FF',
							borderRadius: '70px',
							my: 3
						}}
					>
						<Link
							href="/"
							underline="none"
							sx={{
								fontSize: '16px',
								color: '#F1F1F6'
							}}
						>
							Back to home
						</Link>
					</Button>
				</Box>
			</Grid>
		</Grid>
	);
}

export default DispatchNotFound;
