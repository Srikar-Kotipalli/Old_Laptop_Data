/* eslint-disable import/no-unused-modules */
/* eslint-disable max-len */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

// import React, { useState, useEffect } from 'react';
// import { Grid, Typography } from '@mui/material';theme=>
// import { useSelector } from 'react-redux';
// import Icon from '../../components/icon';
// import ViewAll from '../../assets/arrows/caretRight.svg';
// import ActivityList from '../../components/sidebar/projects/activityList';
// import GithubIcon from '../../assets/github.svg';
// import Banner from '../../assets/banner/Banner.png';
// import SupportList from '../../components/supportList';
// import Carousel from '../../components/carousel';
import React from 'react';
import { Grid, Box } from '@mui/material';
import RecentDispatches from '../../components/dashboard/recentDispatches';
import SharedDispatches from '../../components/dashboard/sharedDispatches';
import RecentEnvironments from '../../components/dashboard/recentEnvironments';
import Summary from '../../components/dashboard/summary';
import Statistics from '../../components/dashboard/statistics';
import GettingStarted from '../../components/dashboard/gettingStarted';
import DashboardProvider from './contexts/DashboardContext';
import Overview from '../../components/dashboard/overview';
// import Recent from '../../components/dashboard/recent';
// import Shared from '../../components/dashboard/shared';
// import TokenComponent from '../../components/form/settings/tokenComponent';
// import copyIcon from '../../assets/actions/copy.svg';
// import tickIcon from '../../assets/checkmarks/checkmark.svg';
// import slackIcon from '../../assets/logos/slack.svg';
// import { getActivityList } from '../../api/activity/activityApi';
// import useDidMountEffect from '../../utils/useDidMountEffect';
import Tutorials from '../../components/dashboard/tutorials';
// import Warning from '../../assets/environments/warning.svg';
// import routes from '../../constants/routes.json';
// import { getPaymentMethods } from '../../api/billing/billingApi';

// const help = [
// 	{
// 		title: 'Getting started',
// 		link: 'https://docs.covalent.xyz/docs/get-started/install'
// 	},
// 	{
// 		title: 'Tutorials',
// 		link: 'https://docs.covalent.xyz/docs/user-documentation/tutorials/'
// 	},
// 	// eslint-disable-next-line quotes
// 	{
// 		title: 'How-to\'s',
// 		link: 'https://docs.covalent.xyz/docs/user-documentation/how-to/how-to-guide'
// 	},
// 	{ title: 'Covalent blog', link: 'https://www.covalent.xyz/blog/' },
// 	{theme=>
// 		title: 'API Reference',
// 		link: 'https://docs.covalent.xyz/docs/user-documentation/api-reference/cov-api'
// 	},
// 	{
// 		title: 'Documentation',
// 		link: 'https://docs.covalent.xyz/'
// 	}
// ];

// const bannerData = {
// 	image: `${Banner}`,
// 	header: 'Introduction',
// 	paragraph:
// 		// eslint-disable-next-line max-len
// 		'Covalent is a Pythonic workflow tool for computational scientists, AI/ML software engineers, and anyone who needs to run experiments on limited or expensive computing resources including quantum computers, HPC clusters, GPU arrays, and cloud services.',
// 	buttonGetStarted: 'Get started',
// 	buttonWalkthrough: 'Start app walkthrough'
// };

// function Dashboard() {
// 	const [activityList, setActivityList] = useState([]);
// 	const [openActivityLoader, setOpenActivityLoader] = useState(false);
// 	// Live refresh
// 	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);

// 	useEffect(() => {
// 		setOpenActivityLoader(true);
// 		getActivityList(20)
// 			.then(payload => {
// 				const activityListPayload = payload?.items?.map(e => {
// 					return { ...e, sub_category: e.sub_category || 'Blank' };
// 				});
// 				setOpenActivityLoader(false);
// 				setActivityList(activityListPayload);
// 			})
// 			.catch(error => {
// 				setOpenActivityLoader(false);
// 				console.log(error);
// 			});
// 	}, []);

// 	useDidMountEffect(() => {
// 		getActivityList(20)
// 			.then(payload => {
// 				const activityListPayload = payload?.items?.map(e => {
// 					return { ...e, sub_category: e.sub_category theme=>
// 			});
// 	}, [liveRefresh]);

// 	return (
// 		<Grid sx={{ mb: 4 }}>
// 			<Grid container spacing={{ xs: 3.5, xl: 4, xxl: 5 }}>
// 				<Grid item className="left-side" xs={8.75} xl={9}>
// 					<Carousel bannerData={bannerData} />
// 					{/* <Grid
// 						xs={12}
// 						sx={{
// 							width: '100%',
// 							height: '40vh',
// 							backgroundImage: `url(${Banner})`,
// 							backgroundPosition: 'center',
// 							backgroundSize: 'cover',
// 							backgroundRepeat: 'no-repeat',
// 							zindex: 10
// 						}}
// 					>
// 						hi{' '}
// 					</Grid> */}
// 					<Overview />
// 					<Recent />
// 					<Shared />
// 					<Grid pt={3}>
// 						<Grid item id="SupportLinks">
// 							<Typography variant="header20" sx={{ color: theme => theme.palette.text.secondary }}>
// 								Knowledgebase & support
// 							</Typography>
// 							<Grid container item xs={12} pt={2} direction="row" columnGap={3} rowGap={2}>
// 								<Grid
// 									item
// 									container
// 									xs={9}
// 									rowGap={2}
// 									sx={{
// 										borderRight: '1px solid',
// 										borderColor: theme => theme.palette.background.covalentPurple
// 									}}
// 								>
// 									<SupportList list={help} />
// 									<Grid item sx={{ display: 'flex' }}>
// 										{/* <Typography
// 										variant="h2"
// 										pb={0.5}
// 										sx={{
// 											color: 'rgba(174, 182, 255, 1)',
// 											cursor: 'pointer',
// 											'&:hover': {
// 												textDecoration: 'underline',
// 												color: theme => theme.palette.text.secondary
// 											}
// 										}}
// 									>
// 										View all
// 									</Typography>
// 									<Icon src={ViewAll} /> */}
// 									</Grid>
// 								</Grid>
// 								<Grid>
// 									<Grid container direction="row" alignItems="center">
// 										<Icon src={GithubIcon} type="static" />
// 										<Typography
// 											variant="h2"
// 											pl={1}

// 											// sx={{
// 											// 	cursor: 'pointer',
// 											// 	'&:hover': {
// 											// 		textDecoration: 'underline',
// 											// 		color: theme => theme.palette.text.secondary
// 											// 	}
// 											// }}
// 										>
// 											Submit an issue
// 										</Typography>
// 									</Grid>
// 									<Grid
// 										item
// 										pt={2}
// 										sx={{ display: 'flex', alignItems: 'center' }}
// 										onClick={() => window.open('https://github.com/AgnostiqHQ/covalent', '_blank')}
// 									>theme=>
// 										<Typography
// 											variant="h2"
// 											pl={0.5}
// 											sx={{
// 												color: theme => theme.palette.text.link,
// 												cursor: 'pointer',

// 												'&:hover': {
// 													textDecoration: 'underline',
// 													color: theme => theme.palette.text.secondary
// 												}
// 											}}
// 										>
// 											Visit github
// 										</Typography>
// 										<Icon src={ViewAll} />
// 									</Grid>
// 								</Grid>
// 							</Grid>
// 						</Grid>
// 					</Grid>
// 				</Grid>
// 				<Grid item className="right-side" xs={3.25} xl={3}>
// 					<Typography
// 						pt={0}
// 						mt={0}
// 						variant="header20"
// 						sx={{ color: theme => theme.palette.text.secondary }}
// 						id="apiKey"
// 					>
// 						API Key
// 					</Typography>
// 					<Grid mt={2}>
// 						<TokenComponent
// 							fontSize="12px"
// 							copyIcon={copyIcon}
// 							copiedIcon={tickIcon}
// 							isDisabled
// 							from="settings"
// 							copyEnable
// 						/>
// 					</Grid>

// 					<Grid mt={3} id="act" pr={0} mr={0}>
// 						<Typography
// 							pb={2}
// 							variant="header20"
// 							sx={{ color: theme => theme.palette.text.secondary }}
// 						>
// 							Activity List
// 						</Typography>
// 						<ActivityList
// 							openActivityLoader={openActivityLoader}
// 							items={activityList}
// 							count={activityList?.length}
// 							noLabel
// 							height="34rem"
// 						/>
// 					</Grid>
// 				</Grid>
// 			</Grid>
// 		</Grid>
// 	);
// }

// // eslint-disable-next-line import/no-unused-modules
// export default Dashboard;

function Dashboard() {
	const [tutorialsOpen, setTutorialsOpen] = useState(false);
	return (
		<DashboardProvider>
			<Box
				sx={{
					// height: 'calc(100vh - 123px)',
					// width: 'calc(100vw - 123px)',
					height: '100%',
					width: '100%'
				}}
			>
				<Grid container>
					<Grid
						item
						xs={8}
						sx={{
							padding: '10px'
						}}
					>
						<Box>
							<Summary />
						</Box>
						<Box sx={{ paddingTop: '10px' }}>
							<Statistics />
							<Tutorials tutorialsOpen={tutorialsOpen} setTutorialsOpen={setTutorialsOpen} />
							<Overview setTutorialsOpen={setTutorialsOpen} />
						</Box>
					</Grid>
					<Grid
						item
						xs={4}
						sx={{
							padding: '10px 10px 10px 0'
						}}
					>
						<RecentDispatches />
					</Grid>
					<Grid
						item
						xs={5}
						sx={{
							padding: '10px'
						}}
					>
						<SharedDispatches />
					</Grid>
					<Grid
						item
						xs={3}
						sx={{
							padding: '10px'
						}}
					>
						<RecentEnvironments />
					</Grid>
					<Grid
						item
						xs={4}
						sx={{
							padding: '10px 10px 10px 0'
						}}
					>
						<GettingStarted />
					</Grid>
				</Grid>
			</Box>
		</DashboardProvider>
	);
}

export default Dashboard;
