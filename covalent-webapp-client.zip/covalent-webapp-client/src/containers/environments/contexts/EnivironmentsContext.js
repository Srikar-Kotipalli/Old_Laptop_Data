import React, { createContext, useState, useMemo } from 'react';
import { getSecrets } from '../../../api/environments/environmentsApi';

export const EnvironmentContext = createContext();

const EnvironmentProvider = ({ children }) => {
	const [testState, setTestState] = useState('new');
	const [storedData, setStoredData] = useState([]);
	const [count, setCount] = useState(0);
	const [openSecretLoader, setOpenSecretLoader] = useState(true);
	const [fetchApi, setFetchApi] = useState(false);
	const [secretsData, setSecretsData] = useState([]);

	const fetchSecretsApi = () => {
		getSecrets()
			.then(response => {
				setCount(response?.names?.length);
				setStoredData(response?.names);
				const sortedData = response?.names?.sort((a, b) => b?.localeCompare(a));
				setSecretsData(sortedData);
			})
			.catch(err => console.error(err))
			.finally(() => {
				setOpenSecretLoader(false);
			});
	};

	const contextValue = useMemo(
		() => ({
			testState,
			setTestState,
			fetchSecretsApi,
			storedData,
			setStoredData,
			count,
			setCount,
			openSecretLoader,
			setOpenSecretLoader,
			fetchApi,
			setFetchApi,
			secretsData,
			setSecretsData
		}),
		[
			testState,
			setTestState,
			fetchSecretsApi,
			storedData,
			setStoredData,
			count,
			setCount,
			openSecretLoader,
			setOpenSecretLoader,
			fetchApi,
			setFetchApi,
			secretsData,
			setSecretsData
		]
	);

	return <EnvironmentContext.Provider value={contextValue}>{children}</EnvironmentContext.Provider>;
};

export default EnvironmentProvider;
