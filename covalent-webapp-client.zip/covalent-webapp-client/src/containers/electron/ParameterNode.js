/**
 * Copyright 2021 Agnostiq Inc.
 *
 * This file is part of Covalent.
 *
 * Licensed under the GNU Affero General Public License 3.0 (the "License").
 * A copy of the License may be obtained with this software package or at
 *
 *      https://www.gnu.org/licenses/agpl-3.0.en.html
 *
 * Use of this file is prohibited except in compliance with the License. Any
 * modifications or derivative works of this file must retain this copyright
 * notice, and modified files must contain a notice indicating that they have
 * been altered from the originals.
 *
 * Covalent is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the License for more details.
 *
 * Relief from the License may be granted by purchasing a commercial license.
 */
/* eslint-disable react/jsx-props-no-spreading */

import React from 'react';
import { Typography, Tooltip, tooltipClasses, Grid, Paper } from '@mui/material';
import { Handle } from 'reactflow';
import { styled } from '@mui/material/styles';
import { nodeLabelIcon, truncate, truncateMiddle, statusColor } from './misc';

const ParameterTooltip = styled(({ className, ...props }) => (
	<Tooltip {...props} classes={{ popper: className }} />
))(() => ({
	[`& .${tooltipClasses.tooltip}`]: {
		// customize tooltip
	}
}));

function ParameterNode({ data, sourcePosition, targetPosition, isConnectable }) {
	return (
		<Grid
			sx={{
				display: 'flex',
				flexDirection: 'column',
				alignItems: 'center',
				justifyContent: 'center'
			}}
		>
			{data.executor ? (
				<ParameterTooltip title={truncate(data?.executor, 70)} arrow placement="bottom-end">
					<Paper
						sx={{
							position: 'absolute',
							top: -15,
							zIndex: -100,
							display: 'flex',
							alignItems: 'center',
							justifyContent: 'center',
							borderRadius: '5px 5px 0px 0px',
							minWidth: '30%',
							overflow: 'hidden',
							bgcolor: theme => theme.palette.background.covalentPurple,
							color: theme => theme.palette.text.tertiary,
							cursor: 'default',
							'&:hover': {
								color: theme => theme.palette.text.primary
							}
						}}
					>
						<Handle type="target" position={targetPosition} isConnectable={isConnectable} />
						<Typography sx={{ fontSize: '0.625rem' }}>
							{truncateMiddle(data.executor, 4, 0)}
						</Typography>
						<Handle type="source" position={sourcePosition} isConnectable={isConnectable} />
					</Paper>
				</ParameterTooltip>
			) : null}

			<ParameterTooltip
				title={
					data.hideLabels ? (
						<>
							<Typography sx={{ fontSize: '0.75rem' }} color="inherit">
								name : {data.fullName}
							</Typography>
							<Typography sx={{ fontSize: '0.75rem' }} color="inherit">
								executor : {data.executor}
							</Typography>
							<Typography sx={{ fontSize: '0.75rem' }} color="inherit">
								node_id : {data.node_id}
							</Typography>
						</>
					) : (
						data.fullName
					)
				}
				arrow
				placement="bottom-end"
			>
				<Paper
					sx={theme => ({
						px: 1,
						py: 0,
						borderRadius: '100px',
						bgcolor: theme.palette.background.paper,
						color: 'rgba(250, 250, 250, 0.6)',
						fontSize: 12,
						display: 'flex',
						alignItems: 'center',
						justifyItems: 'space-between',
						cursor: 'default',
						borderColor: statusColor(data.status),
						borderStyle: 'solid',
						borderWidth: 1,
						'&:hover': {
							bgcolor: theme.palette.background.coveBlack02,
							color: theme.palette.primary.white
						}
					})}
				>
					{/* <Grid sx={{ height: '36px' }}>{nodeLabelIcon(data.nodeType)}</Grid> */}
					<Handle type="source" position={sourcePosition} isConnectable={isConnectable} />
					<Grid pt={0.8}>{nodeLabelIcon(data.nodeType)}</Grid>
					<Typography sx={{ fontSize: 14, mb: 0.3, mt: 0.8 }}>
						{data.label}
						<Handle
							data-testid="parameternode"
							type="source"
							position={sourcePosition}
							isConnectable={isConnectable}
						/>
					</Typography>
				</Paper>
			</ParameterTooltip>
			{!data.hideLabels ? (
				<ParameterTooltip title={truncate(data?.node_id, 70)} arrow placement="bottom-end">
					<Paper
						sx={{
							position: 'absolute',
							top: 31,
							display: 'flex',
							alignItems: 'center',
							justifyContent: 'center',
							borderRadius: '16px',
							minWidth: '20%',
							bgcolor: theme => theme.palette.background.covalentPurple,
							color: theme => theme.palette.text.tertiary,
							cursor: 'default',
							'&:hover': {
								color: theme => theme.palette.text.primary
							}
						}}
					>
						<Handle type="target" position={targetPosition} isConnectable={isConnectable} />
						<Typography sx={{ fontSize: '0.625rem' }}>{data.node_id}</Typography>
						<Handle type="source" position={sourcePosition} isConnectable={isConnectable} />
					</Paper>
				</ParameterTooltip>
			) : null}
		</Grid>
	);
}

export default ParameterNode;
