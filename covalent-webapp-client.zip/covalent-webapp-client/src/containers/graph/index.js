/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable no-unused-vars */
/* eslint-disable import/no-unused-modules */
import React, { useState, useContext, useEffect } from 'react';
import { Auth } from 'aws-amplify';
import { Grid, Box, Button } from '@mui/material';
import { useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import LatticeAccordion from './layout/LatticeAccordion';
import GraphTab from '../../components/tab/graph';
import GraphView from './layout/GraphView';
import DetailView from './layout/DetailView';
import { GraphContext } from './contexts/GraphContext';
import DispatchNotFoundScreen from '../pagenotfound/dispatchNotFound';
import PageNotFoundScreen from '../pagenotfound';
import SharePopup from '../../components/graphLayout/sharePopup';
import { sharedUserDetails } from '../../api/shared/sharedApi';

function GraphContainer() {
	const { dispatchID } = useParams();
	// Live refresh
	const liveRefresh = useSelector(({ socket }) => socket.canCallAPI);
	const socketData = useSelector(({ socket }) => socket.socketData);

	const {
		code,
		input,
		getGraphDetailsApi,
		getLatticeAPI,
		getDispatchResult,
		dispatchResult,
		dispatchResultcopy,
		getDispatchResultCopy,
		getInput,
		getCode,
		getDispatchCodeCopy,
		dispatchCodeCopy,
		latticeDetails,
		error,
		errorFunctions,
		description,
		getElectronDetailsFromNodeid,
		nodeData,
		nodeInput,
		nodeResult,
		selectedNodeResult,
		selectedNodeInput,
		nodeInputCopy,
		selectedNodeInputCopy,
		getNodeCode,
		selectedNodeCode,
		getNodeCodeCopy,
		selectedNodeCodeCopy,
		getJobsOfQElectronNode,
		tabValue,
		setTabValue,
		selectedNodeId,
		// skeleton states
		isFetchingLatticeDetails,
		isFetchingLatticeInput,
		isFetchingLatticeResult,
		isFetchingLatticeError,
		isFetchingLatticeErrorFunctions,
		isFetchingNodeData,
		nodeClickFrom,
		sublatticeId,
		setSublatticeId,
		setBreadcrumb,
		selectedNodeResultCopy,
		notFound,
		nodeErrorFn,
		setNodeDetailClose,
		getLatticeCostValue,
		getNodeCostValue,
		setIsFetchingNodeCost,
		setIsFetchingLatticeCost,
		getErrorFunctions,
		entireGraph,
		nodeConsole
	} = useContext(GraphContext);

	const [sharePopupEnable, setSharePopupEnable] = useState(false);
	const [enableShareOption, setEnableShareOption] = useState(false);
	const [userList, setUserList] = useState([]);
	const [openShareLoader, setOpenShareLoader] = useState(false);
	const [triggerShare, setTriggerShare] = useState(false);
	const [ownerId, setOwnerId] = useState(null);
	const [userEmail, setUserEmail] = useState();

	useEffect(() => {
		setIsFetchingLatticeCost(true);
		setSublatticeId(dispatchID);
		setBreadcrumb([{ name: 'Main Graph', id: dispatchID }]);
		getGraphDetailsApi(dispatchID, true);
		getLatticeAPI(dispatchID, '');
		getDispatchResult(dispatchID);
		getDispatchResultCopy(dispatchID);
		getInput(dispatchID);
		getCode(dispatchID);
		getDispatchCodeCopy(dispatchID);
	}, [dispatchID]);

	useEffect(() => {
		getErrorFunctions(); // gets error functions of dispatch
	}, [entireGraph]);

	useEffect(() => {
		getErrorFunctions(); // gets error functions of dispatch
	}, [entireGraph]);

	const triggerNodeInfoApi = val => {
		if (val === 'Detail View') {
			let nodeNum = 0;
			if (selectedNodeId) nodeNum = selectedNodeId;
			let disId = dispatchID;
			if (nodeClickFrom === 'funcChip') disId = dispatchID;
			else if (sublatticeId && sublatticeId !== dispatchID) disId = sublatticeId;
			getElectronDetailsFromNodeid(disId, nodeNum);
			nodeResult(disId, nodeNum, 'output', 'string');
			nodeResult(disId, nodeNum, 'output', 'object');
			nodeInput(disId, nodeNum, 'STRING');
			nodeInputCopy(disId, nodeNum, 'OBJECT');
			getNodeCode(disId, nodeNum, 'function_string');
			getNodeCodeCopy(disId, nodeNum, 'function');
			nodeErrorFn(disId, nodeNum, 'stderr');
			nodeConsole(disId, nodeNum, 'stdout');
		}
	};

	useEffect(() => {
		triggerNodeInfoApi(tabValue);
	}, [tabValue, selectedNodeId, sublatticeId]);

	useEffect(() => {
		if (
			enableShareOption &&
			nodeData &&
			nodeData?.jobs &&
			nodeData?.jobs?.length > 0 &&
			nodeData?.jobs[0]?.id
		)
			getNodeCostValue(nodeData?.jobs[0]?.id);
		else setIsFetchingNodeCost(false);
		if (nodeData?.contains_qelectrons) {
			let nodeNum = 0;
			if (selectedNodeId) nodeNum = selectedNodeId;
			let disId = dispatchID;
			if (nodeClickFrom === 'funcChip') disId = dispatchID;
			getJobsOfQElectronNode(disId, nodeNum);
		}
	}, [nodeData, dispatchID]);

	const onTabChange = (_e, val) => {
		setTabValue(val);
		if (val === 'Graph View' && selectedNodeId !== '') {
			getGraphDetailsApi(sublatticeId);
		}
	};
	useEffect(() => {
		if (socketData?.dispatch_id === dispatchID) {
			getGraphDetailsApi(dispatchID, true, true);
			getLatticeAPI(dispatchID, '', true);
			if (socketData?.status === 'COMPLETED') {
				getDispatchResult(dispatchID);
				getDispatchResultCopy(dispatchID);
			}
			let nodeNum = 0;
			if (selectedNodeId) nodeNum = selectedNodeId;
			getElectronDetailsFromNodeid(dispatchID, nodeNum, true);
			nodeResult(dispatchID, nodeNum, 'output', 'string');
			nodeResult(dispatchID, nodeNum, 'output', 'object');
			nodeInput(dispatchID, nodeNum, 'STRING');
			nodeInputCopy(dispatchID, nodeNum, 'OBJECT');
			nodeErrorFn(dispatchID, nodeNum, 'stderr');
			nodeConsole(dispatchID, nodeNum, 'stdout');
			if (enableShareOption) getLatticeCostValue(dispatchID);
		}
	}, [liveRefresh]);

	const sharePopupClose = () => {
		setSharePopupEnable(false);
	};

	useEffect(() => {
		if (ownerId) {
			Auth.currentAuthenticatedUser()
				.then(user => {
					const res = user?.attributes;
					const userId = res && res['custom:userID'];
					const ownerEmail = res?.email;
					setUserEmail(ownerEmail);
					if (userId === ownerId) {
						setEnableShareOption(true);
						getLatticeCostValue(dispatchID);
					} else setIsFetchingLatticeCost(false);
				})
				.catch(err => {
					setIsFetchingLatticeCost(false);
					setEnableShareOption(false);
				});
		}
	}, [ownerId, dispatchID]);

	// API fetch shared users
	const getSharedUsersList = () => {
		setOpenShareLoader(true);
		sharedUserDetails(dispatchID)
			.then(response => {
				setOwnerId(response?.owner_id);
				setUserList(response?.shared);
			})
			.catch(err => {
				setIsFetchingLatticeCost(false);
				console.log(err);
			})
			.finally(() => {
				setOpenShareLoader(false);
			});
	};

	useEffect(() => {
		getSharedUsersList();
	}, [triggerShare]);

	return (
		<>
			{notFound ? (
				<DispatchNotFoundScreen />
			) : (
				<>
					<Grid item container xs={12} direction="column">
						<LatticeAccordion
							isFetchingLatticeDetails={isFetchingLatticeDetails}
							isFetchingLatticeInput={isFetchingLatticeInput}
							isFetchingLatticeResult={isFetchingLatticeResult}
							isFetchingLatticeError={isFetchingLatticeError}
							isFetchingLatticeErrorFunctions={isFetchingLatticeErrorFunctions}
							dispatchID={dispatchID}
							dispatchResult={dispatchResult}
							dispatchResultcopy={dispatchResultcopy}
							dispatchCodeCopy={dispatchCodeCopy}
							input={input}
							Code={code}
							description={description}
							status={latticeDetails?.status}
							error={error}
							errorFunctions={errorFunctions}
							executedElectrons={latticeDetails?.completed_task_num}
							totalElectrons={latticeDetails?.task_num}
							started_at={latticeDetails?.started_at}
							completed_at={latticeDetails?.completed_at}
							setSharePopupEnable={setSharePopupEnable}
							userList={userList}
							enableShareOption={enableShareOption}
						/>

						<Box mt={4} display="flex" direction="row">
							<GraphTab
								value={tabValue}
								onChange={onTabChange}
								firstValue="Graph View"
								secondValue="Detail View"
							/>
							{tabValue === 'Graph View' && (
								<Box
									display="flex"
									direction="row"
									mt={1}
									// sx={{ justifyContent: 'space-around' }}
								>
									<Button
										variant="outlined"
										disabled={
											!((selectedNodeId || selectedNodeId === 0) && nodeData?.type !== 'sublattice')
										}
										sx={{
											height: '32px',
											color: '#CBCBD7',
											border: '1px solid #303067',
											'&:disabled': {
												background: '#08081A',
												color: '#46465C !important',
												border: '0.869px solid #46465C'
											}
										}}
										onClick={() => setNodeDetailClose(prev => !prev)}
									>
										Overview
									</Button>
								</Box>
							)}
						</Box>
						{tabValue === 'Graph View' && <GraphView />}
						{tabValue === 'Detail View' && (
							<DetailView
								isFetchingNodeData={isFetchingNodeData}
								nodeStatus={nodeData?.status}
								selectedNodeResult={selectedNodeResult}
								selectedNodeData={nodeData}
								selectedNodeInput={selectedNodeInput}
								selectedNodeInputCopy={selectedNodeInputCopy}
								selectedNodeCode={selectedNodeCode}
								selectedNodeCodeCopy={selectedNodeCodeCopy}
								selectedNodeResultCopy={selectedNodeResultCopy}
								enableShareOption={enableShareOption}
							/>
						)}
					</Grid>
					{sharePopupEnable && (
						<SharePopup
							sharePopupEnable={sharePopupEnable}
							sharePopupClose={sharePopupClose}
							openShareLoader={openShareLoader}
							setOpenShareLoader={setOpenShareLoader}
							userList={userList}
							dispatchID={dispatchID}
							userEmail={userEmail}
							setTriggerShare={setTriggerShare}
						/>
					)}
				</>
			)}
		</>
	);
}

const UUID_PATTERN =
	/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;

export function DispatchLayoutValidate() {
	const { dispatchID } = useParams();
	if (!UUID_PATTERN.test(dispatchID)) {
		return <DispatchNotFoundScreen />;
		// eslint-disable-next-line brace-style
	}
	// eslint-disable-next-line no-else-return
	else return <GraphContainer />;
}

export default DispatchLayoutValidate;
