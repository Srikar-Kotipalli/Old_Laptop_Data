/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Auth } from 'aws-amplify';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
// import Stack from '@mui/material/Stack';
// import Divider from '@mui/material/Divider';
import '../../../fonts.css';
import AlertCarousel from '../../../components/alertCarousel';
import {
	getAllInvoices,
	addPaymentMethods,
	getBillingAccounts,
	getPaymentMethods,
	getUserCharges,
	downloadInvoiceDetails,
	detachPaymentMethod
} from '../../../api/billing/billingApi';
import { BillingContext } from '../billingContext';
import BillingTable from '../../../components/list/billing';
import BillingCard from '../../../components/card/billing';
import BillingInfo from '../../../components/billingInfo';
// import BillingGraph from '../../../../components/graphLayout/billing';
import CustomisedSnackbar from '../../../components/snackbar/projects';

function BillingContainer() {
	// User charges states
	const [charges, setCharges] = useState(null);
	const [isChargesLoading, setIsChargesLoading] = useState(true);

	// Billing account state
	const [billingAccount, setBillingAccount] = useState(null);
	const [isBillingAccountPresent, setIsBillingAccountPresent] = useState(false);

	// Payment method states
	const [paymentMethod, setPaymentMethod] = useState(null);
	const [defaultPaymentMethod, setDefaultPaymentMethod] = useState(false);
	const [triggerBillingApi, setTriggerBillingApi] = useState(false);
	const [isLoading, setIsLoading] = useState(true);
	const [triggerIntent, setTriggerIntent] = useState(false);

	// Snackbar states
	const [openSnackbar, setOpenSnackbar] = React.useState(false);
	const [snackbarMessage, setSnackbarMessage] = React.useState('');

	// Invoices states
	const [invoices, setInvoices] = useState([]);
	const [invoicesLoader, setInvoicesLoader] = useState(false);
	const [sort, setSort] = useState('issued_date');
	const [direction, setDirection] = useState('desc');
	const [totalRecords, setTotalRecords] = useState();
	const [page, setPage] = useState(1);
	const count = 10;

	// Add or edit card details form state
	const [openDetails, setOpenDetails] = useState(false);

	// Delete card popup state
	const [openDeletePopup, setOpenDeletePopup] = useState(false);

	const billingInfoRef = useRef(null);

	const toggleDeleteModal = value => {
		setOpenDeletePopup(value);
	};

	const toggleOpenDetails = value => {
		setOpenDetails(value);
	};

	useEffect(() => {
		if (openDetails && billingInfoRef.current) {
			billingInfoRef.current.scrollIntoView({ behavior: 'smooth' });
		}
	}, [openDetails]);

	const handlePageChanges = (_event, pageValue) => {
		setPage(pageValue);
	};

	const downloadInvoice = invoiceId => {
		downloadInvoiceDetails(invoiceId)
			.then(response => {
				// Create a URL for the Blob
				const blobUrl = window.URL.createObjectURL(response);
				// Create a temporary anchor element
				const a = document.createElement('a');
				a.style.display = 'none';
				a.href = blobUrl;
				a.download = `${invoiceId}.pdf`;
				// Attach the anchor to the document body
				document.body.appendChild(a);
				// Trigger a click event to initiate the download
				a.click();
				// Remove the anchor element
				document.body.removeChild(a);
				// Revoke the Blob URL to release memory (optional)
				window.URL.revokeObjectURL(blobUrl);
			})
			.then(() => {
				setOpenSnackbar(true);
				setSnackbarMessage('PDF downloaded successfully');
			})
			.catch(error => {
				console.log(error);
				setOpenSnackbar(true);
				setSnackbarMessage('PDF could not be downloaded');
			});
	};

	const getBillingInvoices = () => {
		setInvoicesLoader(true);
		getAllInvoices(sort, direction, page - 1, count)
			.then(response => {
				setInvoices(response?.records || []);
				setTotalRecords(response?.metadata?.total_count);
				setInvoicesLoader(false);
			})
			.catch(() => {
				setInvoices([]);
				setTotalRecords(null);
				setInvoicesLoader(false);
			});
	};

	const onSort = id => {
		const isAsc = sort === id && direction === 'asc';
		setDirection(isAsc ? 'desc' : 'asc');
		setSort(id);
	};

	useEffect(() => {
		getBillingInvoices();
	}, [page, sort, direction]);

	useEffect(() => {
		Auth.currentAuthenticatedUser().then(user => {
			const res = user?.attributes;
			const userID = res && res['custom:userID'];
			setIsChargesLoading(true);
			getUserCharges(userID)
				.then(payload => {
					if (payload) {
						setCharges(payload);
					}
					setIsChargesLoading(false);
				})
				.catch(() => {
					setCharges(null);
					setIsChargesLoading(false);
				});
		});
	}, []);

	useEffect(() => {
		const paymentMethodsPromise = getPaymentMethods()
			.then(paymentMeth => {
				if (paymentMeth && Array.isArray(paymentMeth)) {
					if (paymentMeth.length > 0) {
						setPaymentMethod(paymentMeth?.[0]);
						setDefaultPaymentMethod(true);
					}
				}
			})
			.catch(() => {
				setPaymentMethod(null);
				setDefaultPaymentMethod(false);
			});
		const billingAccountsPromise = getBillingAccounts()
			.then(billingAcc => {
				if (billingAcc) {
					setBillingAccount(billingAcc);
					setIsBillingAccountPresent(true);
				}
			})
			.catch(() => {
				setBillingAccount(null);
				setIsBillingAccountPresent(false);
			});
		Promise.all([paymentMethodsPromise, billingAccountsPromise]).finally(() => {
			setIsLoading(false);
			// togglePaymentModal(false);
		});
	}, [triggerBillingApi]);

	// get external setup intent
	const [externalSetupIntent, setExternalSetupIntent] = useState(null);
	useEffect(() => {
		addPaymentMethods()
			.then(resp => setExternalSetupIntent(resp?.external_setup_intent))
			.catch(err => {
				console.log(err);
			})
			.finally(() => {
				toggleOpenDetails(false);
			});
	}, [triggerIntent]);

	const deletePaymentMethod = () => {
		toggleDeleteModal(false);
		if (paymentMethod) {
			setIsLoading(true);
			detachPaymentMethod(paymentMethod?.external_payment_method_id)
				.then(() => {
					setPaymentMethod(null);
					setDefaultPaymentMethod(false);
				})
				.catch(err => {
					console.log(err);
				})
				.finally(() => {
					setIsLoading(false);
					setTriggerIntent(prev => !prev);
				});
		}
	};

	const contextValues = useMemo(
		() => ({
			invoices,
			sort,
			direction,
			totalRecords,
			page,
			setPage,
			setDirection,
			onSort,
			setInvoices,
			setTotalRecords,
			handlePageChanges,
			charges,
			invoicesLoader,
			isChargesLoading,
			setTriggerBillingApi,
			paymentMethod,
			defaultPaymentMethod,
			billingAccount,
			isLoading,
			isBillingAccountPresent,
			toggleOpenDetails,
			openDetails,
			setOpenDetails,
			setTriggerIntent,
			externalSetupIntent,
			setOpenSnackbar,
			setSnackbarMessage,
			downloadInvoice,
			setIsChargesLoading,
			openDeletePopup,
			toggleDeleteModal,
			deletePaymentMethod
		}),
		[
			count,
			sort,
			direction,
			page,
			totalRecords,
			charges,
			invoices,
			invoicesLoader,
			isChargesLoading,
			setIsChargesLoading,
			paymentMethod,
			defaultPaymentMethod,
			billingAccount,
			isBillingAccountPresent,
			isLoading,
			toggleOpenDetails,
			openDetails,
			setOpenDetails,
			externalSetupIntent,
			openDeletePopup,
			toggleDeleteModal
		]
	);

	return (
		<Grid sx={{ width: '927px' }}>
			<CustomisedSnackbar
				testId="billingSnackbar"
				open={openSnackbar}
				message={snackbarMessage}
				clickHandler={() => setOpenSnackbar(false)}
				onClose={() => setOpenSnackbar(false)}
			/>
			{/* <Box sx={{ display: 'flex', alignItems: 'center' }}>
				<Typography
					variant="h1"
					mr={1}
					sx={{ fontFamily: 'Machina, sans-serif', color: '#FFFFFF !important' }}
				>
					Billing
				</Typography>
				<Tooltip
					placement="right"
					title="View and manage your invoices, update billing information, set your credit card and billing address, and track usage details."
				>
					<span>
						<Icon src={HintIcon} />
					</span>
				</Tooltip>
			</Box> */}
			<BillingContext.Provider value={contextValues}>
				<Box>
					<AlertCarousel />
				</Box>
				<Grid container spacing={3}>
					{/* This is charges container */}
					<BillingCard openLoader={isChargesLoading} charges={charges} />
					{/* This is graph container */}
					{/* <BillingGraph /> */}
					{/* <Grid item></Grid> */}
				</Grid>
				<Box ref={billingInfoRef}>
					<BillingInfo />
				</Box>
				<Grid sx={{ marginTop: '20px' }}>
					<BillingTable />
				</Grid>
			</BillingContext.Provider>
		</Grid>
	);
}

export default BillingContainer;
