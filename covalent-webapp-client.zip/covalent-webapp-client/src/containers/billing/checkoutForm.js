import React, { useState } from 'react';
import { PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { Grid, Typography, Tooltip, FormHelperText, Box } from '@mui/material';
import iso3311a2 from 'iso-3166-1-alpha-2';
import PrimaryButton from '../../components/primaryButton';
import CustomInput from '../../components/inputBase/projects/inputField';
import { BillingContext } from './billingContext';
import { updateBillingAccounts, setDefaultPaymentMethod } from '../../api/billing/billingApi';
// import Loader from '../../../components/loader';
import countryCodes from '../../constants/countryCodes.json';
import Icon from '../../components/icon';
import EditIcon from '../../assets/actions/edit.svg';
import Running from '../../assets/dispatch/dispatchRunningDashboard.svg';

// import closeIcon from '../../../assets/actions/close.svg';

const gridStyle = {
	marginTop: '5px'
};

function CheckoutForm(props) {
	const { togglePaymentModal } = props;
	const billingContext = React.useContext(BillingContext);
	const {
		billingAccount,
		paymentMethod,
		defaultPaymentMethod,
		setTriggerBillingApi,
		setOpenSnackbar,
		setSnackbarMessage,
		setTriggerIntent,
		setOpenDetails
	} = billingContext;
	const [errorLegalname, setErrorLegalname] = React.useState('');
	const [errorAddr1, setErrorAddr1] = React.useState('');
	const [errorAddr2, setErrorAddr2] = React.useState('');
	const [errorCountry, setErrorCountry] = React.useState('');
	const [errorCity, setErrorCity] = React.useState('');
	const [errorState, setErrorState] = React.useState('');
	const [errorZip, setErrorZip] = React.useState('');
	const [disable, setDisable] = React.useState(true);
	// const [errorCompany, setErrorCompany] = React.useState('');
	// const [menuItems, setMenuItems] = React.useState(iso3311a2.getData());  temporarily disabling and exposing only 2 countries' country codes
	// eslint-disable-next-line no-unused-vars
	const menuInfo = React.useState(countryCodes);
	const menuItems = Array.isArray(menuInfo) && menuInfo?.length > 0 ? menuInfo[0] : {};
	const [isLoading, setIsLoading] = React.useState(false);
	const [isEditCard, setIsEditCard] = React.useState(false);

	React.useEffect(() => {
		if (!defaultPaymentMethod) setIsEditCard(true);
		else setIsEditCard(false);
	}, []);

	const options = {
		layout: {
			type: 'auto',
			defaultCollapsed: false,
			radios: true,
			spacedAccordionItems: false,
			wallets: {
				applePay: 'never',
				googlePay: 'never'
			}
		}
	};
	const stripe = useStripe();
	const elements = useElements();

	const errorMapping = {
		legal_name: setErrorLegalname,
		address_line_1: setErrorAddr1,
		address_line_2: setErrorAddr2,
		country: setErrorCountry,
		city: setErrorCity,
		state: setErrorState,
		zip_code: setErrorZip
		// company: setErrorCompany
	};

	// update billing account information like legal_name,adress etc.
	const [formData, setFormData] = useState({
		legalName: billingAccount?.legal_name || null,
		// company: userCompany || null,
		addressLine1: billingAccount?.company_address?.address_line_1 || null,
		addressLine2: billingAccount?.company_address?.address_line_2 || null,
		country: billingAccount?.company_address?.country || null,
		city: billingAccount?.company_address?.city || null,
		state: billingAccount?.company_address?.state || null,
		zipCode: billingAccount?.company_address?.zip_code || null
	});

	const updateFormData = evt => {
		const name = evt.target.name;
		const value = evt.target.value;
		setFormData(prevState => ({
			...prevState,
			[name]: value
		}));
	};

	React.useEffect(() => {
		let val = !(
			formData?.legalName?.trim() &&
			formData?.addressLine1?.trim() &&
			formData?.country &&
			formData?.city?.trim() &&
			formData?.state?.trim() &&
			formData?.zipCode?.trim()
		);
		if (formData?.country && !iso3311a2?.getCountry(formData?.country)) {
			setErrorCountry('Country is mandatory!');
			val = true;
		} else setErrorCountry('');
		setErrorLegalname(formData?.legalName ? '' : errorLegalname);
		setErrorAddr1(formData?.addressLine1 ? '' : errorAddr1);
		setErrorCity(formData?.city ? '' : errorCity);
		// setErrorCompany(formData?.company ? '' : errorCompany);
		setErrorState(
			formData?.state
				? ''
				: errorState?.includes('is mandatory')
				? `${formData?.country === 'CA' ? 'Province' : 'State'} is mandatory!`
				: errorState
		);
		setErrorZip(formData?.zipCode ? '' : errorZip);
		setDisable(val);
	}, [formData]);

	// add or edit card details

	const handleSubmit = async () => {
		setDisable(false);
		const bodyParameters = {
			organization_id: billingAccount?.organization_id,
			external_subscription_id: billingAccount?.external_subscription_id,
			plan_id: billingAccount?.plan_id,
			legal_name: formData?.legalName?.trim(),
			// company: formData?.company,
			company_address: {
				address_line_1: formData?.addressLine1?.trim(),
				address_line_2: formData?.addressLine2?.trim(),
				zip_code: formData?.zipCode?.trim(),
				country: formData?.country,
				city: formData?.city?.trim(),
				state: formData?.state?.trim()
			}
		};
		// get details of form
		if (!bodyParameters?.legal_name) {
			setDisable(true);
			setErrorLegalname('Billing Contact is mandatory!');
		}
		if (!bodyParameters?.company_address?.address_line_1) {
			setDisable(true);
			setErrorAddr1('Address Line 1 is mandatory!');
		}
		if (!iso3311a2?.getCountry(bodyParameters?.company_address?.country)) {
			setDisable(true);
			setErrorCountry('Country is mandatory!');
		}
		if (!bodyParameters?.company_address?.city) {
			setDisable(true);
			setErrorCity('City is mandatory!');
		}
		if (!bodyParameters?.company_address?.state) {
			setDisable(true);
			setErrorState(`${formData?.country === 'CA' ? 'Province' : 'State'} is mandatory!`);
		}
		if (!bodyParameters?.company_address?.zip_code) {
			setDisable(true);
			setErrorZip('Zip Code is mandatory!');
		}
		if (!bodyParameters?.external_subscription_id) {
			setSnackbarMessage('Something went wrong,please contact the administrator!');
			setOpenSnackbar(true);
			setDisable(true);
		}
		// We don't want to let default form submission happen here,
		// which would refresh the page.
		// event.preventDefault();

		if (!stripe || !elements) {
			// Stripe.js hasn't yet loaded.
			// Make sure to disable form submission until Stripe.js has loaded.
			return;
		}

		if (!disable) {
			setIsLoading(true);
			updateBillingAccounts(billingAccount?.id, bodyParameters)
				.then(() => {
					if (isEditCard) {
						stripe
							.confirmSetup({
								elements,
								redirect: 'if_required',
								confirmParams: {
									return_url: process.env.REACT_APP_STRIPE_REDIRECT_URL
								}
							})
							.then(response => {
								if (response?.error) {
									if (
										response?.error?.code !== 'incomplete_number' &&
										response?.error?.code !== 'incomplete_expiry' &&
										response?.error?.code !== 'incomplete_cvc' &&
										response?.error?.code !== 'incomplete_zip'
									) {
										setOpenSnackbar(true);
										if (response?.error?.message) setSnackbarMessage(response?.error?.message);
										else setSnackbarMessage('Failed to add payment method.Please try again later!');
										// togglePaymentModal(false);
										setTriggerIntent(prev => !prev);
									}
									setIsLoading(false);
								} else {
									if (response?.setupIntent?.id) {
										setDefaultPaymentMethod(response?.setupIntent?.id)
											.then(() => {
												setOpenSnackbar(true);
												setSnackbarMessage('Payment method added succesfully!');
												// setIsLoading(false);
												// togglePaymentModal(false);
											})
											.catch(() => {
												setOpenSnackbar(true);
												setSnackbarMessage('Failed to set payment method as default.');
												setIsLoading(false);
											})
											.finally(() => {
												setTriggerIntent(prev => !prev);
											});
									}
								}
							})
							.catch(() => {
								setIsLoading(false);
							});
					} else {
						setOpenSnackbar(true);
						setSnackbarMessage('Billing account updated succesfully!');
						setIsLoading(false);
						setOpenDetails(false);
					}
					setTriggerBillingApi(prev => !prev);
				})
				.catch(res => {
					if (
						res?.status === 422 &&
						res?.detail &&
						Array.isArray(res?.detail) &&
						res?.detail?.length > 0
					) {
						res?.detail?.forEach(e => {
							if (e?.loc && e?.loc?.length > 0) {
								const field = e?.loc[e.loc.length - 1];
								if (errorMapping[field]) {
									const setFunc = errorMapping[field];
									// pretiffy message
									// eslint-disable-next-line no-unsafe-optional-chaining
									const message = e?.msg?.charAt(0)?.toUpperCase() + e?.msg?.slice(1);
									setFunc(message);
								} else if (res?.detail?.length === 1 && e?.type === 'uuid_parsing') {
									setSnackbarMessage('Something went wrong,please contact the administrator!');
									setOpenSnackbar(true);
								}
							}
						});
					} else {
						setSnackbarMessage('Please enter valid details!');
						setOpenSnackbar(true);
					}
					setIsLoading(false);
				});
		}
	};

	return (
		// <form id="payment-form" autoComplete='off' onSubmit={handleSubmit} style={{ background: '#1C1C46', padding: 25 }}>
		<div style={{ padding: '5px 0px', background: '#08081A' }}>
			{/* <Box display="flex" justifyContent="flex-end" pr={3}>
				<Icon
					src={closeIcon}
					type="pointer"
					alt="arrowRightAltIcon"
					clickHandler={() => togglePaymentModal(false)}
					width="20px"
					height="20px"
				/>
			</Box> */}
			{/* <Loader
				isFetching={isLoading}
				position="absolute"
				width="100%"
				height="100%"
				background="rgba(0, 0, 0, 0.3)"
			/> */}
			<Box>
				<Typography
					variant="h4"
					sx={{
						marginBottom: '15px',
						color: theme => theme.palette.text.primary,
						fontWeight: 'bold'
					}}
				>
					{paymentMethod?.card_last4 ? 'Edit card details' : 'Add card Details'}
				</Typography>
			</Box>
			<Grid container style={{ justifyContent: 'space-between' }}>
				<Grid item xs={5} style={{ paddingBottom: '25px' }}>
					{/* <Typography
						variant="h4"
						color="#FFF"
						style={{ marginBottom: '16px', paddingLeft: '3px' }}
					>
						{' '}
						Billing Address{' '}
					</Typography> */}
					<Grid container style={gridStyle}>
						<Grid item xs={12} sx={{ marginTop: '15px' }}>
							<CustomInput
								id="outlined-basic"
								fieldName="Billing Contact*"
								variant="outlined"
								name="legalName"
								autocomplete="off"
								handleChange={updateFormData}
								value={formData?.legalName}
								size="normal"
								height={56}
								width="100%"
								error={errorLegalname}
								errorTop="0px"
							/>
							{!errorLegalname && <FormHelperText sx={{ height: '20px' }} />}
						</Grid>
						{/* <Grid item xs={12} sx={{ marginTop: '15px' }}>
							<CustomInput
								id="outlined-basic"
								fieldName="Company"
								variant="outlined"
								name="company"
								autocomplete="off"
								handleChange={updateFormData}
								value={formData?.company}
								size="normal"
								height={56}
								width="100%"
								error={errorCompany}
								errorTop="0px"
							/>
						</Grid> */}
						<Grid item xs={12}>
							<CustomInput
								fullWidth
								id="outlined-basic"
								fieldName="Address Line 1*"
								variant="outlined"
								autocomplete="off"
								name="addressLine1"
								handleChange={updateFormData}
								value={formData?.addressLine1}
								size="normal"
								height={56}
								width="100%"
								error={errorAddr1}
								errorTop="0px"
							/>
							{!errorAddr1 && <FormHelperText sx={{ height: '20px' }} />}
						</Grid>
						<Grid item xs={12}>
							<CustomInput
								fullWidth
								id="outlined-basic"
								fieldName="Address Line 2"
								variant="outlined"
								autocomplete="off"
								name="addressLine2"
								handleChange={updateFormData}
								value={formData?.addressLine2}
								size="normal"
								height={56}
								width="100%"
								error={errorAddr2}
								errorTop="0px"
							/>
							{!errorAddr2 && <FormHelperText sx={{ height: '20px' }} />}
						</Grid>
						<Grid item xs={12}>
							<CustomInput
								fullWidth
								id="outlined-basic"
								fieldName="Country*"
								variant="outlined"
								autocomplete="off"
								name="country"
								handleChange={updateFormData}
								value={formData?.country}
								size="normal"
								height={56}
								width="100%"
								error={errorCountry}
								errorTop="0px"
								type="select"
								defaultText="Select Country Code"
								menuItems={menuItems}
								menuProps={{ PaperProps: { sx: { maxHeight: 155 } } }}
							/>
							{!errorCountry && <FormHelperText sx={{ height: '20px' }} />}
						</Grid>
						<Grid item xs={12}>
							<CustomInput
								fullWidth
								id="outlined-basic"
								fieldName="City*"
								variant="outlined"
								autocomplete="off"
								name="city"
								handleChange={updateFormData}
								value={formData?.city}
								size="normal"
								height={56}
								width="100%"
								error={errorCity}
								errorTop="0px"
							/>
							{!errorCity && <FormHelperText sx={{ height: '20px' }} />}
						</Grid>
						<Grid item xs={12}>
							<Grid container style={{ justifyContent: 'space-between' }}>
								<Grid item xs={6} style={{ padding: '3px 3px 0px 0px' }}>
									<CustomInput
										fullWidth
										id="outlined-basic"
										fieldName={formData?.country === 'CA' ? 'Province*' : 'State*'}
										variant="outlined"
										autocomplete="off"
										name="state"
										handleChange={updateFormData}
										value={formData?.state}
										size="normal"
										height={56}
										error={errorState}
										errorTop="0px"
									/>
									{!errorState && <FormHelperText sx={{ height: '20px' }} />}
								</Grid>
								<Grid item xs={6} style={{ padding: '3px 0px 0px 3px' }}>
									<CustomInput
										fullWidth
										id="outlined-basic"
										fieldName="Zip Code*"
										variant="outlined"
										autocomplete="off"
										name="zipCode"
										handleChange={updateFormData}
										value={formData?.zipCode}
										size="normal"
										height={56}
										error={errorZip}
										errorTop="0px"
									/>
									{!errorZip && <FormHelperText sx={{ height: '20px' }} />}
								</Grid>
								<Grid
									item
									xs={12}
									mt={2}
									sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
								>
									<Box
										sx={{
											cursor: 'pointer',
											display: 'flex',
											alignItems: 'center',
											justifyContent: 'center',
											background: '#1C1C46',
											fontSize: '14px',
											padding: '8px 16px',
											height: '32px',
											minWidth: '170px',
											color: 'white',
											borderRadius: '70px',
											'&:hover': {
												background: '#403cff'
											}
										}}
										onClick={handleSubmit}
									>
										{isLoading ? 'Saving Details' : 'Save Details'}{' '}
										{isLoading ? (
											<Box ml={1}>
												<Icon
													src={Running}
													status="circleRunningStatus"
													type="static"
													alt="runningIcon"
												/>
											</Box>
										) : null}
									</Box>
									{/* <PrimaryButton
										title="Save Details"
										color={theme => theme.palette.text.secondary}
										bgColor="#1C1C46"
										hoverColor="#403cff"
										className="submit"
										handler={() => handleSubmit()}
										sx={{ width: '45%', height: '32px' }}
										// fontSize={15}
										// borderRadius='13px'
									/> */}
									<PrimaryButton
										title="Cancel"
										bgColor="#08081A"
										hoverColor="#403cff"
										className="cancel"
										borderisPresent
										handler={() => togglePaymentModal(false)}
										sx={{ width: '45%', height: '32px' }}
										// sx={{ width: "100%", height: '50px' }}
										// fontSize={15}
										// borderRadius='13px'
									/>
								</Grid>
							</Grid>
						</Grid>
					</Grid>
				</Grid>
				<Grid
					sx={{
						width: '1px',
						backgroundColor: theme => theme.palette.background.blue03
					}}
				/>
				<Grid item xs={5} style={{ paddingBottom: '25px' }}>
					{/* <Typography
						variant="h4"
						color="#FFF"
						style={{ paddingLeft: '3px', marginBottom: '16px' }}
					>
						{' '}
						Card Details{' '}
					</Typography> */}
					{!isEditCard && (
						<Grid item xs={12} sx={{ marginTop: '35px' }}>
							<CustomInput
								fullWidth
								id="outlined-basic"
								fieldName="Existing Card Number"
								variant="outlined"
								autocomplete="off"
								name="cardNumber"
								value={`**** **** **** ${paymentMethod?.card_last4}`}
								size="normal"
								height={56}
								readOnly
								endAdornment={
									<Tooltip title="Edit Card Details" placement="top">
										<span>
											<Icon
												src={EditIcon}
												alt="editCard"
												type="pointer"
												clickHandler={() => setIsEditCard(prev => !prev)}
											/>
										</span>
									</Tooltip>
								}
							/>
						</Grid>
					)}
					{isEditCard && (
						<Grid item xs={12} sx={{ marginTop: '35px' }}>
							<PaymentElement options={options} />
						</Grid>
					)}
					<Grid
						container
						display="flex"
						justifyContent="flex-end"
						// spacing={1}
						// mt={4}
						sx={{ maxWidth: '100%', marginTop: '38.79px' }}
					>
						<Grid item container direction="row" columnSpacing={5} justifyContent="flex-end">
							{/* <Grid item mr={1}>
							</Grid> */}
							{isEditCard && defaultPaymentMethod && (
								<PrimaryButton
									title="Cancel"
									bgColor="#08081A"
									hoverColor="#403cff"
									borderisPresent
									className="cancel"
									handler={() => setIsEditCard(false)}
									sx={{ width: '40%', height: '32px' }}
									// sx={{ width: "100%", height: '50px' }}
									// fontSize={15}
									// borderRadius='13px'
								/>
							)}
							{/* <PrimaryButton
								title="Save"
								bgColor="#1C1C46"
								hoverColor="#403cff"
								className="submit"
								handler={() => handleSubmit()}
								sx={{ width: '40%', height: '32px' }}
								// sx={{ width: "100%", height: '50px' }}
								// fontSize={15}
								// borderRadius='13px'
							/> */}
						</Grid>
					</Grid>
				</Grid>
			</Grid>
		</div>
		// </form >
	);
}

export default CheckoutForm;
