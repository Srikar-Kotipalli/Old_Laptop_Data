/* eslint-disable import/no-unused-modules */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import { Box, Avatar, Stack } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import Icon from '../../../components/icon';
import checkbox from '../../../assets/checkboxes/checkbox.svg';
import checkboxChecked from '../../../assets/checkboxes/checkboxChecked.svg';
import checkboxDisabled from '../../../assets/checkboxes/checkboxdisabled.svg';
import EllipsisDefaultTooltip from '../../../components/tooltip/ellipsisTooltip';
import { capitalizeName } from '../../../utils/utils';
import { statusIcon } from '../../../utils/statusIcons';
import CopyButton from '../../../components/copyButton';
import { ProjectContext } from '../../projects/projectContext';

export default function JobQueueRow(props) {
	const { dispatch, onCheckboxChecked, indentType, selectedItems } = props;
	const projectContext = React.useContext(ProjectContext);
	const { showArchived } = projectContext;
	// eslint-disable-next-line consistent-return
	const getAlignmentFromHierarchy = () => {
		if (indentType === 'singleHierarchy') {
			return '1.9rem';
		} else if (indentType === 'doubleHierarchy') {
			return '3.8rem';
		}
	};

	return (
		<>
			<TableCell
				sx={{
					width: '3%'
				}}
				align="left"
				data-testid="dispatchRow"
			>
				<Box paddingLeft={getAlignmentFromHierarchy()}>
					<Checkbox
						data-testid="dispatchCheckbox"
						size="small"
						value={dispatch.id}
						checked={selectedItems.includes(dispatch.id)}
						disabled={showArchived || !!(dispatch?.shared && dispatch?.shared[0]?.sharedByName)}
						onChange={e => onCheckboxChecked(e, dispatch)}
						icon={
							<Icon
								src={
									!(dispatch?.shared && dispatch?.shared[0]?.sharedByName) && !showArchived
										? checkbox
										: checkboxDisabled
								}
								alt="checkbox"
								type="pointer"
								width="12px"
								height="12px"
							/>
						}
						checkedIcon={
							<Icon
								src={checkboxChecked}
								alt="checkboxChecked"
								type="pointer"
								width="12px"
								height="12px"
							/>
						}
					/>
				</Box>
			</TableCell>
			<TableCell width="12%" align="left">
				<Stack direction="row" alignItems="center">
					<EllipsisDefaultTooltip
						variant="subtitle2"
						value={dispatch.job_id}
						type="dispatch"
						width="100px"
						fixWidth
					/>
					<CopyButton content={dispatch.job_id} />
				</Stack>
			</TableCell>
			<TableCell width="5%" align="left">
				{statusIcon(dispatch.status)}
			</TableCell>
			<TableCell align="left">{dispatch.user}</TableCell>
			<TableCell align="left">
				<Stack direction="row" alignItems="center" gap={1}>
					<Avatar
						sx={{
							width: 24,
							height: 24,
							fontSize: 12,
							bgcolor: '#8B31FF',
							color: 'white'
						}}
					>
						{capitalizeName(dispatch?.organization?.slice(0, 1))}
					</Avatar>
					<Box>{dispatch?.organization}</Box>
				</Stack>
			</TableCell>
			<TableCell align="left">{dispatch?.hardware}</TableCell>
			<TableCell align="left">{dispatch?.started}</TableCell>
			<TableCell align="left">{dispatch?.completed}</TableCell>
			<TableCell align="left">{`$${dispatch?.pricing}`}</TableCell>
		</>
	);
}
