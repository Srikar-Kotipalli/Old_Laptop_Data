/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
/* eslint-disable no-unused-vars */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */

import React, { useState, useContext, useEffect } from 'react';
import { Grid, Typography, Button, Stack, Box } from '@mui/material';
import { Auth } from 'aws-amplify';
import { withStyles } from '@mui/styles';
import { compose } from 'redux';
import { useNavigate } from 'react-router-dom';
import LoginInput from '../../components/inputBase/projects/loginInput';
import { LoginContext } from './loginContext';
import WithMediaQuery from '../../utils/useMediaQuery';
import Icon from '../../components/icon';
import ArrowRightIcon from '../../assets/arrows/arrowRightLogin.svg';

const styles = theme => ({
	container: {
		height: '100vh',
		minHeight: '100%',
		display: 'flex',
		justifyContent: 'center'
	}
});

function ConfirmationCode(props) {
	const loginContext = useContext(LoginContext);
	const {
		setMode,
		setOpenSnackbar,
		setSnackbarMessage,
		setOpenLoader,
		username,
		setUsername,
		setEmail,
		setPassword,
		setRePassword,
		setOrganisationName,
		setOrganisation,
		setFirstName,
		setLastName,
		setRegisterMode,
		location
	} = loginContext;
	const navigate = useNavigate();
	const { isMobile } = props;
	const [verificationCode, setVerificationCode] = useState('');
	const [errorUsername, setErrorUsername] = React.useState('');
	const [errorVerificationCode, setErrorVerificationCode] = React.useState('');
	const [disable, setDisable] = useState(true);
	const [isResendCode, setIsResendCode] = useState(false);

	useEffect(() => {
		const val = !(
			username &&
			!/\s/.test(username?.trim()) &&
			verificationCode &&
			!/\s/.test(verificationCode?.trim())
		);
		setErrorUsername(username ? '' : errorUsername);
		setErrorVerificationCode(verificationCode ? '' : errorVerificationCode);
		setDisable(val);
	}, [username, verificationCode]);

	window.onpopstate = () => {
		setMode('login');
	};

	async function resendConfirmationCode() {
		try {
			await Auth.resendSignUp(username);
			setSnackbarMessage('Resent confirmation code');
			setOpenSnackbar(true);
			setIsResendCode(false);
		} catch (error) {
			setSnackbarMessage('Please enter a valid username');
			setOpenSnackbar(true);
		}
	}

	async function verifyUser() {
		try {
			setOpenLoader(true);
			await Auth.confirmSignUp(username?.trim(), verificationCode);
			setOpenSnackbar(true);
			setSnackbarMessage(
				'Thank you for signing up! We\'re excited to have you on board. We\'re currently setting up your account and will notify you once everything is ready for you'
			);
			setOpenLoader(false);
			setMode('loginEmail');
		} catch (error) {
			setOpenLoader(false);
			setOpenSnackbar(true);
			if (error?.code === 'InvalidParameterException') {
				error.message = 'Invalid fields.';
			}
			setSnackbarMessage(error?.message);
			if (
				error?.message === 'Invalid code provided, please request a code again.' ||
				error?.message === 'Invalid confirmation code provided, please try again.' ||
				error?.message === 'Invalid verification code provided, please try again.'
			) {
				setVerificationCode('');
				setIsResendCode(true);
			}
		}
	}

	const validateInput = () => {
		if (!username) {
			setDisable(true);
			setErrorUsername('Username is mandatory!');
		} else if (/\s/.test(username?.trim())) {
			setDisable(true);
			setErrorUsername('Invalid username!');
		}
		if (!verificationCode) {
			setDisable(true);
			setErrorVerificationCode('Confirmation code is mandatory!');
		} else if (/\s/.test(verificationCode?.trim())) {
			setDisable(true);
			setErrorVerificationCode('Invalid Confirmation code!');
		}
		if (!disable) verifyUser();
	};

	const goBack = () => {
		setEmail('');
		setPassword('');
		setRePassword('');
		setOrganisationName('');
		setOrganisation('');
		setFirstName('');
		setLastName('');
		if (location?.pathname === '/login') {
			setMode('login');
		} else {
			navigate('/register');
			setRegisterMode('register');
		}
	};

	return (
		<Grid
			container
			display={!isMobile && 'contents'}
			justifyContent="center"
			mt={isMobile ? '20px' : '42px'}
		>
			<Typography
				className="head-label-requestAccess"
				fontSize={!isMobile ? '27px' : '20px'}
				width="100%"
			>
				{' '}
				Verify Account
			</Typography>
			<Grid
				item
				className="scroll-container"
				sx={{
					justifyContent: 'center',
					border: '1px solid #303067',
					borderRadius: '8px',
					maxHeight: isMobile ? '100vh' : '420px',
					// overflowY: isMobile && 'scroll',
					// minHeight: !isMobile && '550px',
					// paddingTop: isMobile ? '25px' : '0px',
					// position: 'absolute',
					// top: '50%',
					width: !isMobile && '468px',
					maxWidth: '468px',
					margin: isMobile ? '20px 10px 0px' : '42px 10px 0px',
					background: 'linear-gradient(309deg, #08081A -0.75%, rgba(8, 8, 26, 0.00) 108.66%)',
					boxShadow: '0px 5px 9px 0px rgba(0, 0, 0, 0.45)'
					// transform: 'translate(0%, -50%)'
				}}
				xs={12}
				md={4}
			>
				<div style={{ padding: !isMobile ? '34px 63px' : '20px' }}>
					<Box display="flex" flexDirection="row" pt={2}>
						<Typography
							variant="h2"
							style={{
								color: 'textPrimary',
								wordWrap: 'break-word',
								paddingTop: '4px'
							}}
						>
							We have sent you an email with a confirmation code
						</Typography>
					</Box>
					<Stack spacing={3} mt={1}>
						<LoginInput
							name="verifyCodeUsername"
							id="verifyCodeUsername"
							autoComplete="verifyCodeUsername"
							width="100%"
							value={username}
							handleChange={setUsername}
							type="field"
							placeholderTxt="Enter username"
							error={errorUsername}
							handleEnter={validateInput}
						/>
						<LoginInput
							name="confirmationCode"
							id="confirmationCode"
							autoComplete="verificationCode"
							width="100%"
							value={verificationCode}
							handleChange={setVerificationCode}
							placeholderTxt="Enter Confirmation code"
							type="field"
							error={errorVerificationCode}
							handleEnter={validateInput}
						/>
					</Stack>
					<Grid container spacing={2} sx={{ mt: 2 }}>
						<Grid item xs={12}>
							<Button
								variant="outlined"
								disableElevation
								sx={{
									width: '100%',
									height: '32px',
									'@media (max-width: 430px)': {
										fontSize: '14px'
									},
									borderRadius: '70px',
									backgroundColor: theme => theme.palette.background.default,
									'&:hover': {
										backgroundColor: theme => theme.palette.background.covalentPurple,
										color: theme => theme.palette.text.secondary,
										borderRadius: '70px',
										borderColor: theme => theme.palette.background.blue05
									}
								}}
								onClick={() => validateInput()}
							>
								Verify user
							</Button>
						</Grid>
						{isResendCode && (
							<Grid item xs={12}>
								<Typography
									sx={{
										color: '#ffff',
										textDecoration: 'underline',
										cursor: 'pointer',
										fontSize: '12px',
										width: 'fit-content'
									}}
									onClick={() => resendConfirmationCode()}
								>
									Resend verification link
								</Typography>
							</Grid>
						)}
						<Grid item xs={12}>
							<Box>
								<Typography
									variant="h2"
									display="flex"
									alignItems="center"
									justifyContent="center"
									sx={{
										height: '32px',
										'@media (max-width: 430px)': {
											height: '40px'
										}
									}}
								>
									<Typography
										component="div"
										sx={{
											paddingLeft: '10px',
											color: '#6473FF',
											cursor: 'pointer',
											display: 'flex',
											alignItems: 'center',
											fontSize: '14px',
											'&:hover': {
												textDecoration: 'underline'
											}
										}}
										onClick={goBack}
									>
										{' '}
										Back to previous page
										<Icon rowType="experimentRow" src={ArrowRightIcon} alt="ArrowRightIcon" />
									</Typography>
								</Typography>
							</Box>
						</Grid>
						{/* <Grid item xs={12}>
							{isResendCode && (
								<Button
									variant="contained"
									disableElevation
									sx={{
										width: '100%',
										height: '32px',
										background: '#FFFFFF',
										borderRadius: '70px',
										color: 'black',
										':hover': {
											background: '#86869A'
										}
									}}
									// disabled={!email}
									onClick={() => resendConfirmationCode()}
								>
									Resend verification link
								</Button>
							)}
						</Grid> */}
					</Grid>
				</div>
			</Grid>
		</Grid>
	);
}

export default compose(
	withStyles(styles, {
		name: 'ConfirmationCode'
	}),
	WithMediaQuery([['isMobile', theme => theme.breakpoints.down('sm')]])
)(ConfirmationCode);
