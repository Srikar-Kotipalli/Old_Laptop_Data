/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */

import React from 'react';
import { useSelector } from 'react-redux';
import { Grid, Typography, Tooltip, Box } from '@mui/material';
// import NavBar from '../../components/navBar/v1';
import MiniDrawer from '../../components/navBar/v2/index';
import Tour from '../../components/appWalkthrough/Tour';
import LoginPopupMenu from '../../components/menu/projects/loginPopupMenu';
import { selectNavbarState } from '../../redux/navbarSlice';
import Icon from '../../components/icon';
import HintIcon from '../../assets/actions/hint.svg';
import CustomScrollbars from '../../components/customScroll/v2';

function Template({ title, screen, layout }) {
	const { tourActive } = useSelector(state => state.tour);
	const isOpen = useSelector(selectNavbarState);
	// const [open, setOpen] = React.useState(true);

	return (
		<CustomScrollbars>
			<div>
				<MiniDrawer open={isOpen} />
				{/* <NavBar /> */}
				{tourActive && <Tour />}
				<LoginPopupMenu />
				<Grid
					item
					container
					pl={layout !== 'graph' ? 15 : '6.25rem'}
					pr={layout !== 'graph' ? 4.875 : '0rem'}
					pt={layout !== 'graph' ? (title ? 8.1 : 5.5) : ''}
					pb="2rem"
					sx={{ display: 'flex', flexDirection: 'column' }}
				>
					{title === 'Billing' ? (
						<Box sx={{ display: 'flex', alignItems: 'center' }}>
							<Typography
								pl={isOpen ? 10 : 0}
								mb={1}
								mr={1}
								sx={{
									fontSize: '32px',
									height: 'auto',
									width: 'fit-content',
									transition: 'padding-left 0.3s ease-in-out'
								}}
								id="appWalkthrough"
								// temporarily commenting out until neu machina render is fixed
								// pl={isOpen ? 10 : 0}
								// variant="h1"
								// mr={1}
								// sx={{ fontFamily: 'Machina, sans-serif', color: '#FFFFFF !important'
								// }}
							>
								{title}
							</Typography>
							<Tooltip
								placement="right"
								title="View and manage your invoices, update billing information, set your credit card and billing address, and track usage details."
							>
								<span>
									<Icon src={HintIcon} />
								</span>
							</Tooltip>
						</Box>
					) : (
						<Typography
							pl={isOpen ? 10 : 0}
							mb={3}
							sx={{
								fontSize: '32px',
								height: 'auto',
								width: 'fit-content',
								transition: 'padding-left 0.3s ease-in-out'
							}}
							id="appWalkthrough"
						>
							{title}
						</Typography>
					)}
					<Grid pl={isOpen ? 10 : 0} sx={{ transition: 'padding-left 0.3s ease-in-out' }}>
						{screen}
					</Grid>
				</Grid>
			</div>
		</CustomScrollbars>
	);
}

export default Template;
