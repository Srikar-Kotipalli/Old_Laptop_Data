/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import React from 'react';
import { useSelector } from 'react-redux';
import Grid from '@mui/material/Grid';
import '../../App.css';
// import NavBar from '../../components/navBar/v1';
import Tour from '../../components/appWalkthrough/Tour';
import LoginPopupMenu from '../../components/menu/projects/loginPopupMenu';

function Screen({ screen }) {
	const { tourActive } = useSelector(state => state.tour);
	// const UUID_PATTERN =
	// 	/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
	// const { dispatchID } = useParams();

	// const getLayout = () => {
	// 	if (layout !== 'graph') return 'mainContainer';
	// 	if (!UUID_PATTERN.test(dispatchID)) return '';
	// 	return 'graphContainer';
	// };

	return (
		<div>
			{/* <NavBar /> */}
			{tourActive && <Tour />}
			<LoginPopupMenu />
			<Grid container padding="2rem 2rem 2rem 6.25rem">
				{screen}
			</Grid>
		</div>
	);
}

// eslint-disable-next-line import/no-unused-modules
export default Screen;
