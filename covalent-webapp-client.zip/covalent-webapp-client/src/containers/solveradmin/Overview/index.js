import React from 'react';
import { Grid, Stack, Box, Typography } from '@mui/material';
import SolverContent from '../../../components/card/admin/solverContent';
import utilizationIcon from '../../../assets/utilizationIcon.svg';
import Icon from '../../../components/icon';
import OverviewTemplate from '../../../components/solvers/overview';
import utilizationGraph from '../../../assets/utilizationGraph.png';
import costIcon from '../../../assets/costIcon.svg';
import solverGraph from '../../../assets/solverGraph.png';

function AdminOverview({ overviewData }) {
	return (
		<Box>
			<Grid container columnSpacing={2} my={3}>
				<Grid item xs={4}>
					<OverviewTemplate
						heading="API Calls Made"
						headingIcon={utilizationIcon}
						contentImage={utilizationGraph}
						type="utlization"
					/>
				</Grid>
				<Grid item xs={4}>
					<OverviewTemplate heading="Earning" headingIcon={costIcon} type="cost" />
				</Grid>
				<Grid item xs={4}>
					<OverviewTemplate
						heading="Solver Purchase"
						headingIcon={costIcon}
						contentImage={solverGraph}
						type="solversUtlization"
					/>
				</Grid>
			</Grid>

			<Box
				sx={{
					border: theme => `1px solid ${theme.palette.background.blue03}`,
					borderRadius: '8px',
					padding: '15px 0 15px 0'
				}}
			>
				<Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1, marginLeft: '26px' }}>
					<Box className="utilizationHeaderIcon">
						<Icon src={utilizationIcon} type="statc" />
					</Box>
					<Box>
						<Typography
							className="utilzationLabel"
							sx={{ color: theme => theme.palette.text.secondary }}
						>
							Recent Solvers
						</Typography>
					</Box>
				</Stack>
				<Grid
					container
					spacing={2}
					sx={{
						marginTop: '0px'
					}}
					px={4}
				>
					{overviewData?.map(solver => (
						<Grid key={solver.solverId} item xs={6} sm={4} md={4} lg={4} xl={4} xxl={4}>
							<SolverContent
								solverImage={solver.solverImage}
								downloads={solver.downloads}
								name={solver?.name}
								apiCalls={solver.apiCalls}
								revenue={solver.revenue}
								chipData={solver?.chipdata}
								borderRadius={['8px', '8px', '8px', '8px']}
							/>
						</Grid>
					))}
				</Grid>
			</Box>
		</Box>
	);
}
export default AdminOverview;
