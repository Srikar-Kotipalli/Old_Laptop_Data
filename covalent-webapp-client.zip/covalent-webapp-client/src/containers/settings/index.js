/* eslint-disable import/no-named-as-default-member */
/* eslint-disable react/no-unescaped-entities */
/* eslint-disable react/jsx-props-no-spreading */
/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable import/extensions */
/* eslint-disable react/jsx-boolean-value */
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import '../../App.css';
import Checkbox from '@mui/material/Checkbox';
import SettingsForm from '../../components/form/settings/index';
// import SettingsTab from '../../components/tab/settings/index';
import emailIcon from '../../assets/email.svg';
import checkbox from '../../assets/checkboxes/checkbox.svg';
import slackIcon from '../../assets/slack.svg';
import BrandIcon from '../../assets/brand.svg';
import Icon from '../../components/icon/index';
import HardwareCard from '../../components/card/hardware/hardwareCard';

function Settings() {
	const location = useLocation();
	// const navigate = useNavigate();
	const pathname = location?.pathname;
	const [value, setValue] = useState('account');
	const label = { inputProps: { 'aria-label': 'Checkbox demo' } };
	const { allMyHardwares } = useSelector(state => state.hardware);

	// this will handle tab change event
	// const handleTabChange = (_event, newValue) => {
	// 	if (newValue === 'account') navigate('/settings/account');
	// 	if (newValue === 'hardware') navigate('/settings/hardware');
	// 	if (newValue === 'notifications') navigate('/settings/notifications');
	// };

	useEffect(() => {
		if (pathname === '/settings') setValue('account');
		// if (pathname === '/settings/hardware') setValue('hardware');
		// if (pathname === '/settings/notifications') setValue('notifications');
	}, [pathname]);

	return (
		<div>
			<Grid id="settingsPage">
				{/* <SettingsTab value={value} handleTabChange={handleTabChange} /> */}
				{value === 'account' && (
					<Grid>
						<Typography
							variant="h6"
							sx={{
								color: 'white',
								fontSize: '16px'
							}}
						>
							<SettingsForm />
						</Typography>
					</Grid>
				)}
				{value === 'hardware' && (
					<Grid>
						<Typography
							sx={{
								color: 'white',
								fontSize: '16px',
								mt: 3
							}}
						>
							Hardware
						</Typography>
						<Typography
							mt={1}
							sx={{
								color: '#CBCBD7',
								fontSize: '14px'
							}}
						>
							You are currently using the following devices
						</Typography>
						<Grid sx={{ my: 3 }}>
							<Typography
								sx={{
									color: 'white',
									fontSize: '16px',
									marginBottom: '15px'
								}}
							>
								Manageable devices
							</Typography>
							<HardwareCard hardwareInfo={allMyHardwares} from="settings" />
						</Grid>
						<Grid>
							<Typography
								mb={1}
								sx={{
									color: 'white',
									fontSize: '16px'
								}}
							>
								Unmanageable devices
							</Typography>
							<Typography
								sx={{
									color: '#CBCBD7',
									fontSize: '14px'
								}}
							>
								You don’t use any unmanageable devices
							</Typography>
						</Grid>
					</Grid>
				)}
				{value === 'notifications' && (
					<Grid>
						<Typography
							variant="h6"
							mt={3}
							mb={2}
							sx={{
								color: 'white',
								fontSize: '16px'
							}}
						>
							Notifications
						</Typography>
						<Grid container sx={{ mb: 1 }}>
							<Grid item xs={6} md={6} lg={2}>
								{' '}
							</Grid>
							<Grid item xs={2} md={2} lg={0.5}>
								<Icon src={emailIcon} type="static" alt="emailIcon" />
							</Grid>
							<Grid item xs={2} md={2} lg={0.5}>
								<Icon src={slackIcon} type="static" alt="slackIcon" />
							</Grid>
							<Grid item xs={2} md={2} lg={0.5}>
								<Icon src={BrandIcon} type="static" alt="BrandIcon" />
							</Grid>
						</Grid>
						<Grid container sx={{ mb: 1.5 }} alignItems="center">
							<Grid item xs={6} md={6} lg={2}>
								<Typography sx={{ fontSize: '16px', color: '#CBCBD7' }}>Status changes</Typography>
							</Grid>
							<Grid item xs={2} md={2} lg={0.5}>
								<Checkbox
									disabled
									{...label}
									icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
									size="small"
									sx={{ p: 0 }}
								/>
							</Grid>
							<Grid item xs={2} md={2} lg={0.5}>
								<Checkbox
									disabled
									{...label}
									icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
									size="small"
									sx={{ p: 0 }}
								/>
							</Grid>
							<Grid item xs={2} md={2} lg={0.5}>
								<Checkbox
									disabled
									{...label}
									icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
									size="small"
									sx={{ p: 0 }}
								/>
							</Grid>
						</Grid>
						<Grid container sx={{ mb: 1.5 }} alignItems="center">
							<Grid item xs={6} md={6} lg={2}>
								<Typography sx={{ fontSize: '16px', color: '#CBCBD7' }}>
									Hardware changes
								</Typography>
							</Grid>
							<Grid item xs={2} md={2} lg={0.5}>
								<Checkbox
									disabled
									{...label}
									icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
									size="small"
									sx={{ p: 0 }}
								/>
							</Grid>
							<Grid item xs={2} md={2} lg={0.5}>
								<Checkbox
									disabled
									{...label}
									icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
									size="small"
									sx={{ p: 0 }}
								/>
							</Grid>
							<Grid item xs={2} md={2} lg={0.5}>
								<Checkbox
									disabled
									{...label}
									icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
									size="small"
									sx={{ p: 0 }}
								/>
							</Grid>
						</Grid>
						<Grid container sx={{ mb: 1.5 }} alignItems="center">
							<Grid item xs={6} md={6} lg={2}>
								<Typography sx={{ fontSize: '16px', color: '#CBCBD7' }}>Status changes</Typography>
							</Grid>
							<Grid item xs={2} md={2} lg={0.5}>
								<Checkbox
									disabled
									{...label}
									icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
									size="small"
									sx={{ p: 0 }}
								/>
							</Grid>
							<Grid item xs={2} md={2} lg={0.5}>
								<Checkbox
									disabled
									{...label}
									icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
									size="small"
									sx={{ p: 0 }}
								/>
							</Grid>
							<Grid item xs={2} md={2} lg={0.5}>
								<Checkbox
									disabled
									{...label}
									icon={<Icon src={checkbox} alt="checkbox" type="pointer" />}
									size="small"
									sx={{ p: 0 }}
								/>
							</Grid>
						</Grid>
					</Grid>
				)}
			</Grid>
		</div>
	);
}

export default Settings;
