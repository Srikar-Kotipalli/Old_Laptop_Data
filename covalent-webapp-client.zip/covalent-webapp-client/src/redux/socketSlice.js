/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
	socketData: [],
	isSocketOpen: false,
	canCallAPI: false
};

export const socketSlice = createSlice({
	name: 'common',
	initialState,
	reducers: {
		socketConnection(state) {
			state.isSocketOpen = true;
		},
		socketDisconnection(state) {
			state.isSocketOpen = false;
		},
		socketConnectionOpen(state, { payload: data }) {
			state.isSocketOpen = true;
			state.socketData = data;
		},
		callAPI(state) {
			state.canCallAPI = !state.canCallAPI;
		}
	}
});

export const { socketConnection, socketDisconnection, socketConnectionOpen, callAPI } =
	socketSlice.actions;
