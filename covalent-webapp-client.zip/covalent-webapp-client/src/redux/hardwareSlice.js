/* eslint-disable import/prefer-default-export */
/* eslint-disable import/no-unused-modules */
/* eslint-disable import/no-named-as-default */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
	allMyHardwares: [
		{
			hardwareId: 0,
			technology: 'IBM Quantum',
			status: 'online',
			price: '$1234',
			core: '##',
			memory: '###',
			type: 'Classical',
			key: 'd2d8bf3f-2a02-4408-bb21-ffaab7',
			parameters: {
				cpus: 32,
				gpus: 5,
				num_qbits: 8,
				dispatches: 34
			},
			name: 'Kolkata'
		}
	]
};

export const hardwareSlice = createSlice({
	name: 'common',
	initialState,
	reducers: {
		addNewHardware: (state, action) => {
			const { hardware } = action.payload;
			state.allMyHardwares.push(hardware);
		}
	}
});

export const { addNewHardware } = hardwareSlice.actions;
