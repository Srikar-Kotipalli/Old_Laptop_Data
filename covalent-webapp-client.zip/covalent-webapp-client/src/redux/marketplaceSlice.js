/* eslint-disable import/prefer-default-export */
/* eslint-disable import/no-unused-modules */
/* eslint-disable import/no-named-as-default */
/*
 * Copyright 2022 Agnostiq Inc.
 * Note: This file is subject to a proprietary license agreement entered into between
 * you (or the person or organization that you represent) and Agnostiq Inc. Your rights to
 * access and use this file is subject to the terms and conditions of such agreement.
 * Please ensure you carefully review such agreements and, if you have any questions
 * please reach out to Agnostiq at: [support@agnostiq.com].
 */
import { createSlice } from '@reduxjs/toolkit';
import { solverdata } from '../components/card/marketplace/solverData';
import { data } from '../components/card/marketplace/hardwareData';

const initialState = {
	data,
	solverdata
};

export const marketplaceSlice = createSlice({
	name: 'common',
	initialState,
	reducers: {
		addSolverCard: (state, action) => {
			const { solver } = action.payload;
			const checkIndex = state.solverdata?.details?.findIndex(
				e => e?.solverId === solver?.solverId
			);
			if (checkIndex === -1) state.solverdata?.details?.push(solver);
		}
	}
});

export const { addSolverCard } = marketplaceSlice.actions;
